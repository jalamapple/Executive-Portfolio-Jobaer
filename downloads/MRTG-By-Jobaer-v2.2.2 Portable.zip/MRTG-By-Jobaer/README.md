# MRTG By Jobaer v2.2 — Windows Monitor + IAM + Availability Alerts + Mobile Access

A standalone Windows x64 network traffic monitoring dashboard with **individual user accounts, role-based access control (RBAC)**, management controls and a local audit log. This builds on the existing MRTG By JALAM v1.2 monitoring engine; your existing targets/history are kept when running from the same Windows account.

## Downloads

- `MRTG-By-Jobaer.exe` is a portable Windows executable (no Go/.NET installation necessary).
- `Start-MRTG-LAN.cmd` launches the dashboard on the server's private LAN IP address.
- `README-IAM.txt` has detailed step-by-step deployment instructions.
- Complete source includes Go unit/integration tests and an Inno Setup installer `.iss` script. The distribution includes a compiled portable Windows EXE, **not a compiled Setup wizard**.

## First login

1. **Exit the OLD MRTG from its tray icon** before starting v2.0. Do not run two copies writing the same data.
2. Launch `MRTG-By-Jobaer.exe` for localhost-only access, or `Start-MRTG-LAN.cmd` for authenticated LAN access. On LAN use the actual IP assigned to the monitoring PC (e.g. `192.168.101.150`).
3. Open `http://127.0.0.1:18976` on the server PC; LAN clients open `http://SERVER-IP:18976`.
4. On first run the app creates an administrator account `admin` with a random password in `%APPDATA%\MRTGByJALAM\FIRST-RUN-ADMIN.txt`. Open that file on the PC running the server and sign in.
5. You will be required to replace that password. The bootstrap file is deleted after the password change completes successfully.
6. Open **Identity & Access** to create users and assign roles.

## Role matrix

| Permission | Viewer | Operator | Admin |
|---|---|---|---|
| See dashboard / history / alerts | Yes | Yes | Yes |
| Export reports | Optional per account | Optional per account | Optional per account |
| Manage network devices, SNMP and probes | No | Yes | Yes |
| Clear alert history | No | Yes | Yes |
| Create, disable, edit, delete users | No | No | Yes |
| View IAM audit log | No | No | Yes |
| Backup monitoring configuration including SNMP communities | No | No | Yes |
| Stop server | No | No | Yes |

The server enforces each permission on API routes. Account disable, role changes and admin password resets revoke prior browser sessions. The last enabled administrator is protected from deletion/disable/demotion.

## Security details

- Passwords are stored as **salted PBKDF2-HMAC-SHA256 (600,000 rounds)**; randomly generated first-run password. Passwords required to be 12–128 characters.
- HTTP-only, SameSite=Strict session cookies; the `Secure` attribute is enabled automatically when the HTTP request arrives via direct HTTPS. Session tokens expire after 12 hours; they are not stored across app restarts.
- CSRF protection for state-changing API calls via custom header, origin check and SameSite cookies.
- Simple per-IP login rate limit: 5 failures per 10 minutes. IAM admin log retains up to 500 recent events.
- IAM account data are stored separately at `%APPDATA%\MRTGByJALAM\iam-users.json` with private filesystem permissions (subject to Windows ACL inheritance).
- **Important:** LAN listener serves **unencrypted HTTP**, so passwords, session cookies and traffic information may be readable by someone able to observe the LAN. Do not use on public/untrusted networks. For enterprise/remote access, set up proper TLS, reverse proxy validation and firewall isolation. **No built-in MFA, LDAP, Entra ID/SSO, group-based or device-level ACLs** in this release.
- Config backups and original `config.json` may still contain plaintext SNMP community strings. Store them securely.

## Monitoring capabilities (retained from v1.2)

- Local Windows Ethernet/Wi-Fi traffic monitoring without SNMP, SNMPv1/v2c device monitoring, and conditional UPnP WAN counters (when a router actually exposes them).
- Real-time RX/TX, per-target graph, historical rollups, manual SNMP interface selection, alarms, CSV/PNG export, tray icon and data persistence.
- Archer C6 V4 stock firmware does **not** expose SNMP and may not provide UPnP WAN byte counters. Reliable whole-router traffic still requires compatible hardware or another measurement point.
- This is an MRTG-style app, not a drop-in replacement for original MRTG, and does not implement SNMPv3 or all MRTG plugins.

## Build and tests

Run `build-windows.cmd` from the project root on a Windows computer with Go 1.23+ installed. This runs `go test ./...` then compiles `dist\MRTG-By-Jobaer.exe`. The executable supplied here was cross-compiled from Linux for Windows amd64 with CGO disabled. Go unit and HTTP API integration tests pass, but the Windows tray, native adapter polling, and browser IAM user interface have **not been validated on your particular Windows machine**.

To create a classic installer, compile `installer\MRTG-By-Jobaer.iss` with Inno Setup 6 after running the build script; it outputs `dist\MRTG-By-Jobaer-Setup-win-x64.exe`.

## Firewall for trusted LAN users

On your monitoring PC, use Windows PowerShell as Administrator (when its address is `192.168.101.150`, and it is on a Private network):

```powershell
New-NetFirewallRule -DisplayName "MRTG By Jobaer LAN IAM" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 18976 -LocalAddress 192.168.101.150 -RemoteAddress LocalSubnet -Profile Private
```

Never port-forward TCP/18976 directly to the internet. Browser access from other devices is possible only while the server EXE is running and the LAN address is reachable.

## v2.1: Device/router alarms and optional remote mobile access

Choose **+ Watch device** (e.g. a printer/server LAN IP) and **+ Watch router & WAN** (default Archer C6 at `192.168.101.1`). Device alarms trigger after 3 consecutive failed ICMP checks and recover after 2 successful checks. Router and suspected WAN outages are reported separately. The WAN probe checks connectivity to two public TCP/443 endpoints from this PC, not the Archer C6 physical Ethernet carrier state.

To play audible sound in each browser, click **Enable alarm**. A 3-tone beep repeats every 15 seconds while an outage is active unless you click **Silence alarm**. Browsers restrict automatic audio, so enable sound manually once per open tab. The Windows server PC also plays a short audible alarm for newly confirmed outages by default (disable using `-local-alarm=false`). Keep the PC awake with an interactive Windows session and speakers configured.

For out-of-office access from a mobile phone, first deploy Tailscale on the Windows server and mobile, then run `Setup-Remote-Mobile.cmd` to make your existing **localhost** IAM dashboard accessible inside your private tailnet over HTTPS. This setup requires separate installation of Tailscale and tailnet access policies. It does not expose the dashboard publicly. See **REMOTE-MOBILE-SETUP.md** for setup, troubleshooting and limitations. **Mobile background push notifications are not included**, and an office-side internet outage makes this locally hosted server unreachable from outside.

**Upgrading:** Back up `%APPDATA%\MRTGByJALAM\config.json`, `iam-users.json` and `history` before replacing the executable. Stop all older MRTG versions before starting v2.1. Keep the same Windows user profile to retain IAM and monitoring data.


## v2.2: SMTP incident email notifications

An administrator can configure SMTP settings at **Settings & Help → Email incident notifications**. The new system emails Network/System Admin recipients when a monitored device, router, switch or selected SNMP interface becomes unreachable or reports its interface down. It can also email upon recovery. Email notifications complement, rather than replace, the existing audible alarms and dashboard warnings.

- Configure a sender mailbox and one or more recipient email addresses, one per line.
- Supported SMTP connection modes: **STARTTLS** (commonly port 587) and **implicit TLS** (commonly port 465); valid server TLS certificates are required. Port 25 is permitted only if the SMTP server supports and negotiates STARTTLS.
- Login with SMTP PLAIN authentication over TLS when a username is provided. Providers that require OAuth2 (for example, some Microsoft 365 configurations) will require a compatible SMTP relay or a future Microsoft Graph integration. SMTP basic authentication may be disabled by provider policy.
- The password is encrypted with **Windows DPAPI**, scoped to the Windows user running MRTG; the web API never returns the password. Changing Windows users or migrating to another computer requires re-entering it.
- An administrator can send a **test email** from the settings screen, which must be saved first.
- Every new incident includes: event type, severity, device name, host/IP, UTC timestamp, incident ID, observed message, and the device-specific **Related Note** configured when adding/editing a device.
- Detection still waits for 3 consecutive failures; recovery waits for 2 successes. Each incident is emailed once after successful SMTP acceptance; failures retry with bounded exponential backoff (15 seconds up to 15 minutes). Delivery status persists in `mail-deliveries.json`; pending emails survive restart while their events remain in alert history.
- For managed SNMP v1/v2c devices, ifOperStatus is probed on the configured ifIndex; down/notPresent/lowerLayerDown reports a separate **NETWORK INTERFACE LINK DOWN** incident. Devices without this standard OID continue with SNMP availability monitoring but not physical-port monitoring.
- **Important limitation:** Internet/WAN reachability is inferred by two outbound probes from the monitoring PC. Stock Archer C6 V4 firmware does not expose SNMP physical WAN link status. **If the office has lost its only internet connection, this same PC cannot send email to an internet mailbox until connectivity returns.** To receive immediate email during a complete outage, use an independent external monitor or redundant internet connection. The app cannot overcome that physical limitation.
- New email settings are stored in `%APPDATA%\MRTGByJALAM\mail-settings.json`; delivery status in `%APPDATA%\MRTGByJALAM\mail-deliveries.json`. Back up those files with your other user data and do not copy DPAPI encrypted secrets between users.
- Email configuration routes are server-side restricted to administrators; viewers/operators cannot see recipients or change SMTP settings.

**Security:** Do not disable Microsoft Defender if it flags an unsigned executable. Have the file and source checked before authorizing the application on business endpoints. The executable here is built using Go for Windows amd64 but could not be executed on a Windows machine in this environment.


## v2.2.2 — SMTP AUTH mechanism fix

The client now negotiates `AUTH PLAIN` or `AUTH LOGIN` only when advertised by the server after a verified TLS connection, rather than forcing `PLAIN`. This addresses `504 5.7.4 Unrecognized authentication type` when a server advertises only `LOGIN` and `XOAUTH2`. If SMTP AUTH is disabled by tenant policy, an additional 535 error may still result; migrate to Microsoft Graph / OAuth2 rather than weakening security settings. See `CHANGELOG-v2.2.2.md`.
