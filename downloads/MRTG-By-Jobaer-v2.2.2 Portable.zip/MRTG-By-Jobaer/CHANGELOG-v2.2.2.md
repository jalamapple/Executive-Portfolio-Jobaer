# MRTG By Jobaer v2.2.2 — SMTP AUTH compatibility update

- Fixed the v2.2.1 SMTP sender always attempting `AUTH PLAIN`, even when a TLS-protected SMTP server only advertises `AUTH LOGIN` and `XOAUTH2` (which can return `504 5.7.4 Unrecognized authentication type`).
- After the STARTTLS or implicit TLS handshake and certificate verification, the sender now chooses supported `PLAIN` first or `LOGIN` second from the server-advertised authentication list.
- Added unit tests for mechanism selection, LOGIN challenge/response sequence, and unsupported mechanisms.
- This does **not** bypass tenant SMTP AUTH policies or legacy-authentication restrictions. Microsoft 365 may reject password authentication even after negotiation is corrected. Long-term recommended integration is OAuth2 Microsoft Graph `Mail.Send` with carefully scoped application permissions, not legacy SMTP passwords.
- Windows Defender previously blocked a pre-release build of this software. Do not bypass antivirus alerts; this unsigned executable has not been security-audited or Windows runtime-tested.
- v2.2.1 encrypted password data and existing monitoring history are kept; leave SMTP password as-is for the first retry.
