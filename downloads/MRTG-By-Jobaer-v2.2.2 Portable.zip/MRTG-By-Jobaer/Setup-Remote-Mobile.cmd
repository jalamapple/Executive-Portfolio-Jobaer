@echo off
setlocal
cls
echo ==========================================================
echo   MRTG By Jobaer v2.1 - Private Mobile Access Setup
echo ==========================================================
echo.
echo REQUIREMENTS:
echo  1. MRTG By Jobaer running on this PC (127.0.0.1:18976).
echo  2. Official Tailscale client installed, running and signed in.
echo  3. Tailscale installed and signed in on your phone.
echo.
echo This enables PRIVATE tailnet HTTPS access, NOT public internet access.
echo Nothing is published via router port forwarding.
echo.
set "TAILSCALE=tailscale"
where tailscale >nul 2>&1
if errorlevel 1 (
 if exist "%ProgramFiles%\Tailscale\tailscale.exe" (
   set "TAILSCALE=%ProgramFiles%\Tailscale\tailscale.exe"
 ) else (
   echo Tailscale CLI not found.
   echo Install it from https://tailscale.com/download and sign in.
   echo Read REMOTE-MOBILE-SETUP.md for details.
   pause
   exit /b 1
 )
)
powershell -NoProfile -Command "if (-not (Test-NetConnection 127.0.0.1 -Port 18976 -InformationLevel Quiet)) { exit 1 }"
if errorlevel 1 (
 echo ERROR: MRTG dashboard is not listening at 127.0.0.1:18976.
 echo Start MRTG first and make sure no other version is occupying the port.
 pause
 exit /b 1
)
echo.
echo Running Tailscale Serve for localhost port 18976...
"%TAILSCALE%" serve --bg 18976
if errorlevel 1 (
 echo Tailscale Serve setup failed. See REMOTE-MOBILE-SETUP.md.
 pause
 exit /b 1
)
echo.
echo Your private access URL (https://...ts.net) is shown below:
"%TAILSCALE%" serve status
echo.
echo Open the HTTPS URL on the phone with Tailscale connected.
echo Use the app's individual IAM account to log in.
echo To disable: tailscale serve --https=443 off
echo.
pause
