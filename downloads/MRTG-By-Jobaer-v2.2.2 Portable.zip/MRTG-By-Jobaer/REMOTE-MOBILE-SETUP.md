# Remote mobile access: MRTG By Jobaer v2.1

Use **Tailscale Serve**, not router port forwarding or Tailscale Funnel. This method keeps the monitoring web server listening on Windows loopback `127.0.0.1:18976` and makes it available by HTTPS **only to authorized devices/users within your private Tailscale network**. All users still sign in with individual MRTG IAM credentials.

## Windows server (the monitoring Dell PC)

1. Obtain and install Tailscale from its official website <https://tailscale.com/download>. Sign in using your organization-approved account. Ensure its VPN is connected. Do not install clients from untrusted websites.
2. Start `MRTG-By-Jobaer.exe` (localhost mode); verify `http://127.0.0.1:18976` shows the IAM login. **Do not use** LAN mode for remote-only access. Do not run two MRTG versions simultaneously.
3. Run `Setup-Remote-Mobile.cmd` from the extracted folder (Windows may require an elevated terminal to configure Serve). Alternatively, in an authorized PowerShell terminal, run `tailscale serve --bg 18976`.
4. Tailscale may ask you to enable tailnet HTTPS certificates and consent via its admin web interface. Follow the official prompts.
5. Run `tailscale serve status` and record the `https://<machine>.<tailnet>.ts.net` URL printed. This is your **private** tailnet address, not `192.168.101.150`.
6. Test while the Dell PC is running and online. Restrict tailnet sharing using access policies to only authorized users/devices; protect Tailscale accounts with MFA.

## On your phone (off the office Wi-Fi)

1. Install the official Tailscale iOS/Android app and sign in with an identity authorized in the same tailnet. Turn on the VPN connection.
2. Disable office Wi-Fi (use mobile data), open the HTTPS URL from step 5 in Safari/Chrome, and sign in using a **MRTG IAM Viewer** account. Do not reuse admin credentials for routine viewing.
3. In the dashboard tap **Enable alarm** once to permit sound in that browser. The browser tab must remain open for browser audio. The Windows server's alarm can sound separately.
4. The dashboard layout adjusts on narrow screens. Mobile push notifications in the background are **not** included; an independent push notification service would be needed.

## Network and security considerations

- Do not forward port `18976` on your Archer C6 or expose MRTG to the public internet. Do not use Tailscale **Funnel** (public hosting) for MRTG.
- Tailscale Serve is a **separate dependency**; the `.exe` does not bundle Tailscale. Remote connectivity requires both the server and your phone to be online, connected to the tailnet, and authorized by Tailscale policy. Tailscale Serve provides HTTPS at the remote endpoint, then forwards to local loopback. The application handles the trusted local proxy's HTTPS header to mark session cookies `Secure`.
- If office internet/power fails, the on-premises MRTG server becomes unreachable from your phone. Offline warnings to phones during a full office outage require an **external** watchdog/notification service, which is not implemented here.
- Windows Defender previously blocked an earlier unsigned build. Do not disable Defender or add exclusions. Verify any executable's provenance and security scanning; a successful compilation is not a malware-clearance certificate.

## Troubleshooting

- If localhost doesn't work: run `netstat -ano | findstr :18976`; confirm one LISTENING entry and check the app log in `%APPDATA%\MRTGByJALAM`.
- If Tailscale URL doesn't work: run `tailscale status` and `tailscale serve status` and check tailnet access policy and HTTPS enablement.
- If mobile sign-in does not persist: ensure you're using the **HTTPS** Tailscale Serve URL, not plain `http://192.168.101.150`.
- To stop remote serving: `tailscale serve --https=443 off` (or `tailscale serve reset` if instructed by your Tailscale admin).

Official documentation: https://tailscale.com/docs/features/tailscale-serve and https://tailscale.com/docs/reference/tailscale-cli/serve
