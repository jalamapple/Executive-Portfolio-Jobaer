@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ==========================================================
echo  MRTG By Jobaer v2.1 -- IAM + availability alarms
 echo ==========================================================
echo.
echo IMPORTANT: Close MRTG By JALAM v1.2 from its tray icon first.
echo.
tasklist /FI "IMAGENAME eq MRTG-By-JALAM.exe" 2>nul | find /i "MRTG-By-JALAM.exe" >nul
if not errorlevel 1 (
 echo Old MRTG is still running. Quit it from the tray icon first.
 pause
 exit /b 1
)
tasklist /FI "IMAGENAME eq MRTG-By-Jobaer.exe" 2>nul | find /i "MRTG-By-Jobaer.exe" >nul
if not errorlevel 1 (
 echo MRTG is already running. Quit it from the tray icon and try again.
 pause
 exit /b 1
)
set "LAN_IP="
set /p "LAN_IP=Server LAN IPv4 address [192.168.101.150]: "
if not defined LAN_IP set "LAN_IP=192.168.101.150"
echo.
set "LOCAL_ALARM="
set /p "LOCAL_ALARM=Beep on THIS server PC for confirmed outages? [Y/n]: "
if /I "%LOCAL_ALARM%"=="N" (
 start "" "%~dp0MRTG-By-Jobaer.exe" -lan-ip "%LAN_IP%"
) else (
 start "" "%~dp0MRTG-By-Jobaer.exe" -lan-ip "%LAN_IP%" -local-alarm
)
echo.
echo Admin sign-in: http://127.0.0.1:18976
echo Other users:   http://%LAN_IP%:18976
echo.
echo INITIAL ADMIN ACCOUNT (on first run):
echo    Username: admin
echo    Read the generated password from:
echo    %%APPDATA%%\MRTGByJALAM\FIRST-RUN-ADMIN.txt
echo The file is removed after the initial password is changed.
echo.
echo If another PC cannot connect, allow TCP port 18976 from
 echo LocalSubnet on the Windows Private firewall profile.
echo WARNING: LAN access is HTTP, NOT encrypted. Do not open to internet.
pause
