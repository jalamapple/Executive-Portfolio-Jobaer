MRTG By Jobaer v2.0 — Identity and Access Management
====================================================

1. QUIT OLD MRTG
   Quit all previous MRTG By JALAM instances from the Windows tray.
   The new application reuses the same %APPDATA%\MRTGByJALAM data folder
   to preserve your existing monitoring targets and history.

2. START
   For a local-only dashboard, double-click MRTG-By-Jobaer.exe.
   For a dashboard open to authenticated LAN users, double-click
   Start-MRTG-LAN.cmd and enter your Dell PC's current LAN IPv4.
   Default example: 192.168.101.150; port 18976.

3. FIRST SIGN-IN
   The FIRST time the app creates IAM users, it generates a random admin
   password in %APPDATA%\MRTGByJALAM\FIRST-RUN-ADMIN.txt.
   Username: admin. Read the generated file on the server PC.
   You MUST change the password immediately through the login UI.
   The bootstrap file is removed after the password change succeeds.
   No password is embedded in the EXE or source code.

4. CREATE ACCOUNTS
   Sign in as admin, open "Identity & Access" in the left menu.
   Create viewers, operators and administrators with individual passwords.
   You can disable users, change their role, revoke sessions on changes,
   reset passwords (one-time temporary password), and delete accounts.
   The last enabled admin cannot be removed.

5. ROLES
   VIEWER: dashboard, history and alerts (read only).
   OPERATOR: viewer + manage monitoring targets and alert history.
   ADMIN: operator + IAM user administration, SNMP-secret backup, shutdown.
   EXPORT: per-user setting for CSV and PNG export.
   The server enforces permissions; hiding UI buttons is not protection.

6. SAFETY
   LAN HTTP sends passwords and cookies without transport encryption.
   Use ONLY on private/trusted LAN. For remote, public or untrusted users,
   use HTTPS via properly configured reverse proxy with TLS and limit access.
   This version does NOT provide MFA, SSO/Entra ID, AD sync, HTTPS or
   enterprise identity federation. Keep TCP/18976 closed to the internet.

7. NETWORK
   On host PC, use PowerShell (Run as Administrator) and only for a Private
   network interface (change IP if the server's IP changes):

   New-NetFirewallRule -DisplayName "MRTG By Jobaer LAN IAM" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 18976 -LocalAddress 192.168.101.150 -RemoteAddress LocalSubnet -Profile Private

8. STORAGE
   Existing config/history are preserved in %APPDATA%\MRTGByJALAM.
   IAM database is iam-users.json with salted PBKDF2 password hashes.
   Active sessions are stored in memory and end on app restart.
   Admin audit events (last 500) are persisted in the IAM database.
   Back up iam-users.json securely; it is not included in the normal
   monitoring-target configuration export.

9. DO NOT RUN OLD AND NEW AT ONCE
   Running two EXEs against the same local history may corrupt the data.


v2.2: Admin-only SMTP incident email configuration is under Settings & Help. Set SMTP server/port, STARTTLS or TLS, sender, Network/System Admin recipients, optional SMTP username/password and recovery flag. Save, then test. A note can be attached to each watched device and is included in email. SMTP password is Windows DPAPI protected. WAN-down email may be delayed until internet connectivity returns.
