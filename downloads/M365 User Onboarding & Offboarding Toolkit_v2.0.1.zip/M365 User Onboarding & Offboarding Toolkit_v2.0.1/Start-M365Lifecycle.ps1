<#
.SYNOPSIS
    M365 User Onboarding & Offboarding Toolkit (v2.0.1) — Created by Jobaer

.DESCRIPTION
    Zero-touch PowerShell & Microsoft Graph automation toolkit for standardized employee
    onboarding, license assignment, and secure offboarding.

    KEY FEATURES:
    - Automates Entra ID account creation, M365 group/license assignment, and Teams/SharePoint access.
    - One-command secure offboarding: revokes active sessions, blocks sign-in, converts mailbox
      to shared, removes licenses/groups, and exports compliance audit logs (HTML + CSV + JSON).
    - Supports bulk CSV processing with built-in dry-run (-WhatIf) safety mode.
    - Smart Department/Role template mapping via config\toolkit-config.json.
    - Built-in -DemoMode for offline testing and executive report previews.

    REQUIREMENTS:
    Windows 10/11 | PowerShell 7+ | Microsoft.Graph Modules | ExchangeOnlineManagement

.PARAMETER Action
    Lifecycle action to execute: Onboard, Offboard, or AuditStatus.

.PARAMETER UserPrincipalName
    Target user's UPN (e.g., user@domain.com) for single-user operations.

.PARAMETER DisplayName
    Full display name for single-user onboarding.

.PARAMETER FirstName
    First name (GivenName) for onboarding.

.PARAMETER LastName
    Last name (Surname) for onboarding.

.PARAMETER Department
    Department name used to auto-match role templates in config\toolkit-config.json (e.g., IT, Finance, Sales, HR).

.PARAMETER JobTitle
    Job title for onboarding.

.PARAMETER UsageLocation
    Two-letter ISO country code for M365 license assignment (default: US).

.PARAMETER ManagerUPN
    Manager's UPN. Assigned during onboarding; optionally granted shared mailbox delegation & mail forwarding during offboarding.

.PARAMETER LicenseSkus
    Optional array of M365 SKU Part Numbers (e.g., "SPE_E3", "O365_BUSINESS_PREMIUM"). Overrides department template if supplied.

.PARAMETER GroupNames
    Optional array of Entra ID / M365 Group or Teams display names to add the user to during onboarding.

.PARAMETER CsvPath
    Path to a Bulk Onboarding or Bulk Offboarding CSV file.

.PARAMETER ConfigPath
    Path to toolkit-config.json (defaults to .\config\toolkit-config.json).

.PARAMETER OutputPath
    Directory where audit logs, pre-change snapshots, and the HTML report are saved.

.PARAMETER SkipExchangeOnline
    Skips Exchange Online PowerShell operations (mailbox conversion, GAL hide, OOO, delegation).

.PARAMETER DelegateToManager
    During offboarding, grants FullAccess on the converted shared mailbox to the user's Manager (or -ManagerUPN).

.PARAMETER AutoReplyMessage
    Optional Out-of-Office auto-reply message configured during offboarding.

.PARAMETER DemoMode
    Runs the full lifecycle engine in offline simulation mode without connecting to Microsoft 365.

.PARAMETER OpenReport
    Automatically opens the generated HTML Execution & Audit Report upon completion.

.EXAMPLE
    .\Start-M365Lifecycle.ps1 -Action Offboard -UserPrincipalName "user@domain.com" -WhatIf

.EXAMPLE
    .\Start-M365Lifecycle.ps1 -Action Onboard -UserPrincipalName "j.doe@domain.com" -DisplayName "Jane Doe" -Department "IT" -JobTitle "Cloud Engineer" -WhatIf

.EXAMPLE
    .\Start-M365Lifecycle.ps1 -Action Onboard -CsvPath ".\Templates\Bulk-Onboard-Template.csv" -WhatIf

.EXAMPLE
    .\Start-M365Lifecycle.ps1 -Action Offboard -CsvPath ".\Templates\Bulk-Offboard-Template.csv" -DelegateToManager -OpenReport

.EXAMPLE
    .\Start-M365Lifecycle.ps1 -Action Offboard -UserPrincipalName "alex.morgan@contoso.com" -DemoMode -WhatIf -OpenReport

.NOTES
    Tool Name : M365 User Onboarding & Offboarding Toolkit
    Version   : 2.0.1
    Author    : S M Jobaer Alam
    Website   : https://www.jobaeralam.com
    Email     : hello@jobaeralam.com
    License   : Freeware / MIT
#>

[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("Onboard", "Offboard", "AuditStatus")]
    [string]$Action,

    [Parameter(Mandatory = $false)]
    [string]$UserPrincipalName = "",

    [Parameter(Mandatory = $false)]
    [string]$DisplayName = "",

    [Parameter(Mandatory = $false)]
    [string]$FirstName = "",

    [Parameter(Mandatory = $false)]
    [string]$LastName = "",

    [Parameter(Mandatory = $false)]
    [string]$Department = "Default",

    [Parameter(Mandatory = $false)]
    [string]$JobTitle = "",

    [Parameter(Mandatory = $false)]
    [string]$UsageLocation = "US",

    [Parameter(Mandatory = $false)]
    [string]$ManagerUPN = "",

    [Parameter(Mandatory = $false)]
    [string[]]$LicenseSkus = @(),

    [Parameter(Mandatory = $false)]
    [string[]]$GroupNames = @(),

    [Parameter(Mandatory = $false)]
    [string]$CsvPath = "",

    [Parameter(Mandatory = $false)]
    [string]$ConfigPath = "",

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "",

    [Parameter(Mandatory = $false)]
    [switch]$SkipExchangeOnline,

    [Parameter(Mandatory = $false)]
    [switch]$DelegateToManager,

    [Parameter(Mandatory = $false)]
    [string]$AutoReplyMessage = "",

    [Parameter(Mandatory = $false)]
    [switch]$DemoMode,

    [Parameter(Mandatory = $false)]
    [switch]$OpenReport
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

#region Constants & Branding
$ToolName    = "M365 User Onboarding & Offboarding Toolkit"
$ToolVersion = "2.0.1"
$AuthorName  = "S M Jobaer Alam"
$AuthorSite  = "https://www.jobaeralam.com"
$AuthorEmail = "hello@jobaeralam.com"
$RunDate     = Get-Date
$Timestamp   = $RunDate.ToString("yyyyMMdd_HHmmss")
$IsWhatIf    = [bool]$WhatIfPreference

if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path -Path $PSScriptRoot -ChildPath "config\toolkit-config.json"
}
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path -Path $PSScriptRoot -ChildPath "Logs\Lifecycle_${Action}_$Timestamp"
}

$script:AuditEntries      = [System.Collections.Generic.List[object]]::new()
$script:PreChangeSnapshot = [System.Collections.Generic.List[object]]::new()
$script:CreatedCreds      = [System.Collections.Generic.List[object]]::new()
#endregion

#region Banner & Console Logging
function Show-JobaerBanner {
    Write-Host ""
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host "    ____ ____  _____    _  _____ _____ ____    ______   __  " -ForegroundColor Cyan
    Write-Host "   / ___|  _ \| ____|  / \|_   _| ____|  _ \  | __ ) \ / /  " -ForegroundColor Cyan
    Write-Host "  | |   | |_) |  _|   / _ \ | | |  _| | | | | |  _ \\ V /   " -ForegroundColor Cyan
    Write-Host "  | |___|  _ <| |___ / ___ \| | | |___| |_| | | |_) || |    " -ForegroundColor Cyan
    Write-Host "   \____|_| \_\_____/_/   \_\_| |_____|____/  |____/ |_|    " -ForegroundColor Cyan
    Write-Host ""
    Write-Host "       _  ___  ____    _    _____ ____   " -ForegroundColor Yellow
    Write-Host "      | |/ _ \| __ )  / \  | ____|  _ \  " -ForegroundColor Yellow
    Write-Host "   _  | | | | |  _ \ / _ \ |  _| | |_) | " -ForegroundColor Yellow
    Write-Host "  | |_| | |_| | |_) / ___ \| |___|  _ <  " -ForegroundColor Yellow
    Write-Host "   \___/ \___/|____/_/   \_\_____|_| \_\ " -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  $ToolName (v$ToolVersion)" -ForegroundColor White
    Write-Host "  Author : $AuthorName | $AuthorSite | $AuthorEmail" -ForegroundColor Gray
    Write-Host "  License: Freeware / MIT" -ForegroundColor DarkGray
    Write-Host "============================================================================" -ForegroundColor Cyan
    $modeLabel = if ($DemoMode) { "DEMO SIMULATION" } else { "LIVE M365 TENANT" }
    $dryLabel  = if ($IsWhatIf) { "ON (-WhatIf Dry-Run Safety Mode)" } else { "OFF (Live Execution)" }
    Write-Host "  Action   : $Action" -ForegroundColor White
    Write-Host "  Mode     : $modeLabel" -ForegroundColor $(if ($DemoMode) { "Yellow" } else { "Green" })
    Write-Host "  Dry-Run  : $dryLabel" -ForegroundColor $(if ($IsWhatIf) { "Yellow" } else { "Cyan" })
    Write-Host "  Log Dir  : $OutputPath" -ForegroundColor DarkGray
    Write-Host "============================================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Add-AuditLog {
    param(
        [string]$UPN,
        [string]$Step,
        [ValidateSet("Success", "WhatIf", "Warning", "Failed", "Skipped", "Info")]
        [string]$Status,
        [string]$Details
    )

    $entry = [PSCustomObject]@{
        Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        Action    = $Action
        UPN       = $UPN
        Step      = $Step
        Status    = $Status
        Details   = $Details
        DryRun    = $IsWhatIf
    }
    $script:AuditEntries.Add($entry)

    $color = switch ($Status) {
        "Success" { "Green" }
        "WhatIf"  { "Yellow" }
        "Warning" { "DarkYellow" }
        "Failed"  { "Red" }
        "Skipped" { "DarkGray" }
        default   { "Cyan" }
    }
    $tag = $Status.ToUpper().PadRight(7)
    Write-Host "  [$tag] [$UPN] $Step -> $Details" -ForegroundColor $color
}
#endregion

#region Helper Utilities
function ConvertTo-HtmlSafe {
    param([AllowNull()][string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return "" }
    return [System.Net.WebUtility]::HtmlEncode($Text)
}

function New-SecureTempPassword {
    param([int]$Length = 16)
    $upper   = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    $lower   = "abcdefghijkmnopqrstuvwxyz"
    $digits  = "23456789"
    $symbols = "!@#$%^&*-_"
    $all     = $upper + $lower + $digits + $symbols

    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    function Get-RandomChar([string]$Pool) {
        $bytes = New-Object byte[] 4
        $rng.GetBytes($bytes)
        $idx = [BitConverter]::ToUInt32($bytes, 0) % $Pool.Length
        return $Pool[$idx]
    }

    $chars = @(
        (Get-RandomChar $upper),
        (Get-RandomChar $lower),
        (Get-RandomChar $digits),
        (Get-RandomChar $symbols)
    )
    for ($i = $chars.Count; $i -lt $Length; $i++) {
        $chars += (Get-RandomChar $all)
    }
    # Fisher-Yates shuffle
    for ($i = $chars.Count - 1; $i -gt 0; $i--) {
        $bytes = New-Object byte[] 4
        $rng.GetBytes($bytes)
        $j = [BitConverter]::ToUInt32($bytes, 0) % ($i + 1)
        $tmp = $chars[$i]; $chars[$i] = $chars[$j]; $chars[$j] = $tmp
    }
    $rng.Dispose()
    return (-join $chars)
}

function Load-ToolkitConfig {
    param([string]$Path)
    if (Test-Path $Path) {
        try {
            return (Get-Content -Path $Path -Raw -Encoding UTF8 | ConvertFrom-Json)
        }
        catch {
            Write-Warning "Failed to parse config at $Path. Using built-in defaults."
        }
    }
    return [PSCustomObject]@{
        DefaultUsageLocation = "US"
        PasswordLength       = 16
        OffboardingDefaults  = [PSCustomObject]@{
            ConvertToSharedMailbox = $true
            HideFromGAL            = $true
            RemoveAllLicenses      = $true
            RemoveAllGroups        = $true
            ResetPassword          = $true
            DefaultAutoReply       = "This employee is no longer with the organization. Please contact IT or your account representative for assistance."
        }
        DepartmentTemplates  = [PSCustomObject]@{
            Default = [PSCustomObject]@{
                LicenseSkus     = @("SPE_E3")
                SecurityGroups  = @("SG-All-Employees")
                TeamsGroups     = @("All Company")
                SharePointSites = @("Company Intranet")
            }
        }
    }
}

function Get-DepartmentTemplate {
    param($Config, [string]$DeptName)
    if (-not $Config -or -not $Config.DepartmentTemplates) { return $null }
    $props = $Config.DepartmentTemplates.PSObject.Properties
    foreach ($p in $props) {
        if ($p.Name -ieq $DeptName) { return $p.Value }
    }
    if ($props.Name -contains "Default") {
        return $Config.DepartmentTemplates.Default
    }
    return $null
}

function Test-ValidUpn {
    param([string]$Upn)
    return ($Upn -match '^[^@\s]+@[^@\s]+\.[^@\s]+$')
}
#endregion

#region Connection Management
function Initialize-M365Connections {
    param([string]$LifecycleAction, [switch]$SkipExo)

    $requiredGraphModules = @(
        "Microsoft.Graph.Authentication",
        "Microsoft.Graph.Users",
        "Microsoft.Graph.Groups",
        "Microsoft.Graph.Identity.DirectoryManagement"
    )
    $missing = @($requiredGraphModules | Where-Object { -not (Get-Module -ListAvailable -Name $_) })
    if ($missing.Count -gt 0) {
        throw "Missing Microsoft Graph modules: $($missing -join ', '). Run .\Install-Prerequisites.ps1 first, or test with -DemoMode."
    }

    $scopes = if ($LifecycleAction -eq "AuditStatus") {
        @("User.Read.All", "Group.Read.All", "Directory.Read.All")
    }
    else {
        @("User.ReadWrite.All", "Group.ReadWrite.All", "Directory.ReadWrite.All", "Organization.Read.All")
    }

    $ctx = Get-MgContext
    if (-not $ctx) {
        Write-Host "[*] Connecting to Microsoft Graph..." -ForegroundColor Cyan
        Connect-MgGraph -Scopes $scopes -NoWelcome
        $ctx = Get-MgContext
    }
    Write-Host "    [+] Connected to Microsoft Graph Tenant: $($ctx.TenantId) ($($ctx.Account))" -ForegroundColor Green

    $exoConnected = $false
    if (-not $SkipExo -and $LifecycleAction -in @("Offboard", "AuditStatus")) {
        if (Get-Module -ListAvailable -Name ExchangeOnlineManagement) {
            try {
                $existingExo = Get-ConnectionInformation -ErrorAction SilentlyContinue | Where-Object { $_.State -eq "Connected" }
                if (-not $existingExo) {
                    Write-Host "[*] Connecting to Exchange Online PowerShell..." -ForegroundColor Cyan
                    Connect-ExchangeOnline -ShowBanner:$false
                }
                $exoConnected = $true
                Write-Host "    [+] Exchange Online PowerShell connected." -ForegroundColor Green
            }
            catch {
                Write-Warning "Exchange Online connection failed: $($_.Exception.Message). Mailbox steps will be skipped."
            }
        }
        else {
            Write-Warning "ExchangeOnlineManagement module not installed. Run .\Install-Prerequisites.ps1 for mailbox automation."
        }
    }

    return [PSCustomObject]@{
        TenantId     = $ctx.TenantId
        Account      = $ctx.Account
        ExoConnected = $exoConnected
    }
}
#endregion

#region Onboarding Engine
function Invoke-UserOnboarding {
    param(
        [PSCustomObject]$Target,
        [PSCustomObject]$Config,
        [hashtable]$SkuCache
    )

    $upn = $Target.UserPrincipalName
    if (-not (Test-ValidUpn $upn)) {
        Add-AuditLog -UPN $upn -Step "Validate Input" -Status "Failed" -Details "Invalid UserPrincipalName format."
        return
    }

    $tpl = Get-DepartmentTemplate -Config $Config -DeptName $Target.Department

    $skusToAssign = @()
    if ($Target.LicenseSkus -and $Target.LicenseSkus.Count -gt 0) {
        $skusToAssign = @($Target.LicenseSkus | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    }
    elseif ($tpl -and $tpl.LicenseSkus) {
        $skusToAssign = @($tpl.LicenseSkus)
    }

    $groupsToJoin = [System.Collections.Generic.List[string]]::new()
    if ($Target.GroupNames -and $Target.GroupNames.Count -gt 0) {
        foreach ($g in $Target.GroupNames) { if (-not [string]::IsNullOrWhiteSpace($g)) { $groupsToJoin.Add($g.Trim()) } }
    }
    else {
        if ($tpl -and $tpl.SecurityGroups)  { foreach ($g in $tpl.SecurityGroups)  { $groupsToJoin.Add($g) } }
        if ($tpl -and $tpl.TeamsGroups)     { foreach ($g in $tpl.TeamsGroups)     { $groupsToJoin.Add($g) } }
        if ($tpl -and $tpl.SharePointSites) { foreach ($g in $tpl.SharePointSites) { $groupsToJoin.Add($g) } }
    }

    $tempPass     = New-SecureTempPassword -Length $(if ($Config.PasswordLength) { [int]$Config.PasswordLength } else { 16 })
    $mailNickname = ($upn -split '@')[0] -replace '[^a-zA-Z0-9._-]', ''
    $usageLoc     = if (-not [string]::IsNullOrWhiteSpace($Target.UsageLocation)) { $Target.UsageLocation } else { $Config.DefaultUsageLocation }

    # Step 1: Create Entra ID User
    $createdUserId = $null
    if ($DemoMode) {
        $status = if ($IsWhatIf) { "WhatIf" } else { "Success" }
        $createdUserId = [guid]::NewGuid().ToString()
        Add-AuditLog -UPN $upn -Step "Create Entra ID Account" -Status $status -Details "DisplayName='$($Target.DisplayName)', Dept='$($Target.Department)', Title='$($Target.JobTitle)', UsageLocation='$usageLoc'."
        if (-not $IsWhatIf) {
            $script:CreatedCreds.Add([PSCustomObject]@{ UserPrincipalName = $upn; DisplayName = $Target.DisplayName; TempPassword = $tempPass; ForceChangeAtSignIn = $true })
        }
    }
    else {
        $existing = Get-MgUser -Filter "userPrincipalName eq '$upn'" -ErrorAction SilentlyContinue
        if ($existing) {
            $createdUserId = $existing.Id
            Add-AuditLog -UPN $upn -Step "Create Entra ID Account" -Status "Skipped" -Details "Account already exists (ObjectId: $createdUserId). Proceeding with license/group sync."
        }
        elseif ($PSCmdlet.ShouldProcess($upn, "Create Entra ID user account ($($Target.DisplayName))")) {
            try {
                $userParams = @{
                    AccountEnabled    = $true
                    DisplayName       = $Target.DisplayName
                    GivenName         = $Target.FirstName
                    Surname           = $Target.LastName
                    MailNickname      = $mailNickname
                    UserPrincipalName = $upn
                    Department        = $Target.Department
                    JobTitle          = $Target.JobTitle
                    UsageLocation     = $usageLoc
                    PasswordProfile   = @{
                        ForceChangePasswordNextSignIn = $true
                        Password                      = $tempPass
                    }
                }
                $newUser = New-MgUser @userParams
                $createdUserId = $newUser.Id
                $script:CreatedCreds.Add([PSCustomObject]@{ UserPrincipalName = $upn; DisplayName = $Target.DisplayName; TempPassword = $tempPass; ForceChangeAtSignIn = $true })
                Add-AuditLog -UPN $upn -Step "Create Entra ID Account" -Status "Success" -Details "Created Entra ID user (ObjectId: $createdUserId)."
            }
            catch {
                Add-AuditLog -UPN $upn -Step "Create Entra ID Account" -Status "Failed" -Details $_.Exception.Message
                return
            }
        }
        else {
            Add-AuditLog -UPN $upn -Step "Create Entra ID Account" -Status "WhatIf" -Details "Would create Entra ID account for '$($Target.DisplayName)' in Dept '$($Target.Department)'."
        }
    }

    # Step 2: Assign Manager
    if (-not [string]::IsNullOrWhiteSpace($Target.ManagerUPN)) {
        if ($DemoMode) {
            $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
            Add-AuditLog -UPN $upn -Step "Assign Manager" -Status $st -Details "Manager set to $($Target.ManagerUPN)."
        }
        elseif ($PSCmdlet.ShouldProcess($upn, "Assign manager $($Target.ManagerUPN)")) {
            try {
                $mgr = Get-MgUser -Filter "userPrincipalName eq '$($Target.ManagerUPN)'" -ErrorAction Stop | Select-Object -First 1
                if ($mgr -and $createdUserId) {
                    $refBody = @{ "@odata.id" = "https://graph.microsoft.com/v1.0/users/$($mgr.Id)" }
                    Set-MgUserManagerByRef -UserId $createdUserId -BodyParameter $refBody
                    Add-AuditLog -UPN $upn -Step "Assign Manager" -Status "Success" -Details "Manager assigned: $($Target.ManagerUPN)."
                }
                else {
                    Add-AuditLog -UPN $upn -Step "Assign Manager" -Status "Warning" -Details "Manager '$($Target.ManagerUPN)' not found in Entra ID."
                }
            }
            catch {
                Add-AuditLog -UPN $upn -Step "Assign Manager" -Status "Failed" -Details $_.Exception.Message
            }
        }
        else {
            Add-AuditLog -UPN $upn -Step "Assign Manager" -Status "WhatIf" -Details "Would assign manager $($Target.ManagerUPN)."
        }
    }

    # Step 3: Assign M365 Licenses
    if ($skusToAssign.Count -gt 0) {
        if ($DemoMode) {
            $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
            Add-AuditLog -UPN $upn -Step "Assign M365 Licenses" -Status $st -Details "Licenses: $($skusToAssign -join ', ')."
        }
        elseif ($PSCmdlet.ShouldProcess($upn, "Assign M365 licenses: $($skusToAssign -join ', ')")) {
            $addLicenses = @()
            foreach ($skuName in $skusToAssign) {
                if ($SkuCache.ContainsKey($skuName.ToUpper())) {
                    $skuObj = $SkuCache[$skuName.ToUpper()]
                    $avail  = $skuObj.PrepaidUnits.Enabled - $skuObj.ConsumedUnits
                    if ($avail -le 0) {
                        Add-AuditLog -UPN $upn -Step "License Check ($skuName)" -Status "Warning" -Details "No available seats remaining ($($skuObj.ConsumedUnits)/$($skuObj.PrepaidUnits.Enabled))."
                    }
                    else {
                        $addLicenses += @{ SkuId = $skuObj.SkuId }
                    }
                }
                else {
                    Add-AuditLog -UPN $upn -Step "License Lookup ($skuName)" -Status "Warning" -Details "SKU '$skuName' not found in tenant subscribed SKUs."
                }
            }
            if ($addLicenses.Count -gt 0 -and $createdUserId) {
                try {
                    Set-MgUserLicense -UserId $createdUserId -AddLicenses $addLicenses -RemoveLicenses @() | Out-Null
                    Add-AuditLog -UPN $upn -Step "Assign M365 Licenses" -Status "Success" -Details "Assigned $($addLicenses.Count) SKU(s): $($skusToAssign -join ', ')."
                }
                catch {
                    Add-AuditLog -UPN $upn -Step "Assign M365 Licenses" -Status "Failed" -Details $_.Exception.Message
                }
            }
        }
        else {
            Add-AuditLog -UPN $upn -Step "Assign M365 Licenses" -Status "WhatIf" -Details "Would assign SKU(s): $($skusToAssign -join ', ')."
        }
    }

    # Step 4: Add to Entra ID Groups, Microsoft Teams & SharePoint M365 Groups
    foreach ($grpName in ($groupsToJoin | Select-Object -Unique)) {
        if ($DemoMode) {
            $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
            Add-AuditLog -UPN $upn -Step "Group / Teams / SharePoint Access" -Status $st -Details "Added to '$grpName'."
        }
        elseif ($PSCmdlet.ShouldProcess($upn, "Add user to group/Team '$grpName'")) {
            try {
                $escaped = $grpName -replace "'", "''"
                $grp = Get-MgGroup -Filter "displayName eq '$escaped'" -ErrorAction Stop | Select-Object -First 1
                if ($grp -and $createdUserId) {
                    New-MgGroupMember -GroupId $grp.Id -DirectoryObjectId $createdUserId -ErrorAction Stop
                    Add-AuditLog -UPN $upn -Step "Group / Teams / SharePoint Access" -Status "Success" -Details "Added to '$grpName' ($($grp.Id))."
                }
                else {
                    Add-AuditLog -UPN $upn -Step "Group / Teams / SharePoint Access" -Status "Warning" -Details "Group/Team '$grpName' not found."
                }
            }
            catch {
                if ($_.Exception.Message -match "added object references already exist") {
                    Add-AuditLog -UPN $upn -Step "Group / Teams / SharePoint Access" -Status "Skipped" -Details "User already a member of '$grpName'."
                }
                else {
                    Add-AuditLog -UPN $upn -Step "Group / Teams / SharePoint Access" -Status "Failed" -Details "Group '$grpName': $($_.Exception.Message)"
                }
            }
        }
        else {
            Add-AuditLog -UPN $upn -Step "Group / Teams / SharePoint Access" -Status "WhatIf" -Details "Would add user to group/Team '$grpName'."
        }
    }
}
#endregion

#region Offboarding Engine
function Invoke-UserOffboarding {
    param(
        [PSCustomObject]$Target,
        [PSCustomObject]$Config,
        [bool]$ExoConnected
    )

    $upn = $Target.UserPrincipalName
    if (-not (Test-ValidUpn $upn)) {
        Add-AuditLog -UPN $upn -Step "Validate Input" -Status "Failed" -Details "Invalid UserPrincipalName format."
        return
    }

    $defaults    = $Config.OffboardingDefaults
    $mgrUpn      = $Target.ManagerUPN
    $autoReply   = if (-not [string]::IsNullOrWhiteSpace($Target.AutoReplyMessage)) { $Target.AutoReplyMessage } else { $defaults.DefaultAutoReply }

    # Step 1: Capture Pre-Offboarding Snapshot
    $userObj      = $null
    $userGroups   = @()
    $userLicenses = @()

    if ($DemoMode) {
        $userObj = [PSCustomObject]@{ Id = "demo-uid-4491"; DisplayName = "Alex Morgan"; UserPrincipalName = $upn; AccountEnabled = $true; Department = "Finance"; JobTitle = "Senior Analyst" }
        $userLicenses = @("SPE_E3", "POWER_BI_PRO")
        $userGroups   = @(
            [PSCustomObject]@{ Id = "grp-01"; DisplayName = "SG-Finance-Team"; IsDynamic = $false },
            [PSCustomObject]@{ Id = "grp-02"; DisplayName = "All Company (Teams)"; IsDynamic = $false },
            [PSCustomObject]@{ Id = "grp-03"; DisplayName = "DG-All-Employees"; IsDynamic = $true }
        )
        if ([string]::IsNullOrWhiteSpace($mgrUpn)) { $mgrUpn = "manager@contoso.com" }
        Add-AuditLog -UPN $upn -Step "Pre-Offboarding Snapshot" -Status "Info" -Details "Captured $($userLicenses.Count) license(s) and $($userGroups.Count) group membership(s)."
    }
    else {
        try {
            $userObj = Get-MgUser -UserId $upn -Property Id, DisplayName, UserPrincipalName, AccountEnabled, Department, JobTitle, AssignedLicenses -ErrorAction Stop
        }
        catch {
            Add-AuditLog -UPN $upn -Step "Lookup Entra ID User" -Status "Failed" -Details "User not found or access denied: $($_.Exception.Message)"
            return
        }

        if ([string]::IsNullOrWhiteSpace($mgrUpn)) {
            try {
                $mgrRef = Get-MgUserManager -UserId $userObj.Id -ErrorAction SilentlyContinue
                if ($mgrRef -and $mgrRef.AdditionalProperties.ContainsKey("userPrincipalName")) {
                    $mgrUpn = $mgrRef.AdditionalProperties["userPrincipalName"]
                }
            }
            catch { }
        }

        $userLicenses = @($userObj.AssignedLicenses | ForEach-Object { $_.SkuId })
        $rawMemberOf  = @(Get-MgUserMemberOf -UserId $userObj.Id -All -ErrorAction SilentlyContinue)
        foreach ($m in $rawMemberOf) {
            if ($m.AdditionalProperties["@odata.type"] -eq "#microsoft.graph.group") {
                $gTypes = @($m.AdditionalProperties["groupTypes"])
                $userGroups += [PSCustomObject]@{
                    Id          = $m.Id
                    DisplayName = $m.AdditionalProperties["displayName"]
                    IsDynamic   = ($gTypes -contains "DynamicMembership")
                }
            }
        }
        Add-AuditLog -UPN $upn -Step "Pre-Offboarding Snapshot" -Status "Info" -Details "Captured $($userLicenses.Count) license(s) and $($userGroups.Count) group(s). Manager: $(if($mgrUpn){$mgrUpn}else{'None'})."
    }

    $script:PreChangeSnapshot.Add([PSCustomObject]@{
        CapturedAt        = (Get-Date).ToString("o")
        UserPrincipalName = $upn
        DisplayName       = $userObj.DisplayName
        Department        = $userObj.Department
        ManagerUPN        = $mgrUpn
        AssignedLicenses  = $userLicenses
        GroupMemberships  = @($userGroups | ForEach-Object { $_.DisplayName })
    })

    # Step 2: Block Sign-In & Scramble Password
    if ($DemoMode) {
        $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
        Add-AuditLog -UPN $upn -Step "Block Sign-In & Reset Password" -Status $st -Details "AccountEnabled set to False; password scrambled to 32-char random string."
    }
    elseif ($PSCmdlet.ShouldProcess($upn, "Block Entra ID sign-in and scramble password")) {
        try {
            $updateBody = @{ AccountEnabled = $false }
            if ($defaults.ResetPassword) {
                $updateBody["PasswordProfile"] = @{
                    ForceChangePasswordNextSignIn = $true
                    Password                      = (New-SecureTempPassword -Length 32)
                }
            }
            Update-MgUser -UserId $userObj.Id @updateBody
            Add-AuditLog -UPN $upn -Step "Block Sign-In & Reset Password" -Status "Success" -Details "Sign-in blocked and password scrambled."
        }
        catch {
            Add-AuditLog -UPN $upn -Step "Block Sign-In & Reset Password" -Status "Failed" -Details $_.Exception.Message
        }
    }
    else {
        Add-AuditLog -UPN $upn -Step "Block Sign-In & Reset Password" -Status "WhatIf" -Details "Would block Entra ID sign-in and scramble password."
    }

    # Step 3: Revoke Active Sign-In Sessions & Refresh Tokens
    if ($DemoMode) {
        $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
        Add-AuditLog -UPN $upn -Step "Revoke Active Sessions" -Status $st -Details "All M365 refresh tokens and active sessions invalidated."
    }
    elseif ($PSCmdlet.ShouldProcess($upn, "Revoke all active Entra ID sign-in sessions")) {
        try {
            Revoke-MgUserSignInSession -UserId $userObj.Id | Out-Null
            Add-AuditLog -UPN $upn -Step "Revoke Active Sessions" -Status "Success" -Details "All active refresh tokens invalidated immediately."
        }
        catch {
            Add-AuditLog -UPN $upn -Step "Revoke Active Sessions" -Status "Failed" -Details $_.Exception.Message
        }
    }
    else {
        Add-AuditLog -UPN $upn -Step "Revoke Active Sessions" -Status "WhatIf" -Details "Would revoke all active Entra ID refresh tokens & sessions."
    }

    # Step 4: Exchange Online — Convert Mailbox to Shared, Hide from GAL, OOO, Manager Delegation
    if (-not $SkipExchangeOnline -and ($DemoMode -or $ExoConnected)) {
        if ($defaults.ConvertToSharedMailbox) {
            if ($DemoMode) {
                $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
                Add-AuditLog -UPN $upn -Step "Convert Mailbox to Shared" -Status $st -Details "Mailbox converted to SharedMailbox (retains mail without paid license)."
            }
            elseif ($PSCmdlet.ShouldProcess($upn, "Convert Exchange Online mailbox to Shared")) {
                try {
                    Set-Mailbox -Identity $upn -Type Shared -ErrorAction Stop
                    Add-AuditLog -UPN $upn -Step "Convert Mailbox to Shared" -Status "Success" -Details "Mailbox successfully converted to Shared."
                }
                catch {
                    Add-AuditLog -UPN $upn -Step "Convert Mailbox to Shared" -Status "Failed" -Details $_.Exception.Message
                }
            }
            else {
                Add-AuditLog -UPN $upn -Step "Convert Mailbox to Shared" -Status "WhatIf" -Details "Would convert Exchange Online mailbox to Shared."
            }
        }

        if ($defaults.HideFromGAL) {
            if ($DemoMode) {
                $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
                Add-AuditLog -UPN $upn -Step "Hide from Global Address List" -Status $st -Details "HiddenFromAddressListsEnabled set to True."
            }
            elseif ($PSCmdlet.ShouldProcess($upn, "Hide mailbox from Global Address List (GAL)")) {
                try {
                    Set-Mailbox -Identity $upn -HiddenFromAddressListsEnabled $true -ErrorAction Stop
                    Add-AuditLog -UPN $upn -Step "Hide from Global Address List" -Status "Success" -Details "Hidden from GAL."
                }
                catch {
                    Add-AuditLog -UPN $upn -Step "Hide from Global Address List" -Status "Warning" -Details $_.Exception.Message
                }
            }
            else {
                Add-AuditLog -UPN $upn -Step "Hide from Global Address List" -Status "WhatIf" -Details "Would hide mailbox from Global Address List."
            }
        }

        if (-not [string]::IsNullOrWhiteSpace($autoReply)) {
            if ($DemoMode) {
                $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
                Add-AuditLog -UPN $upn -Step "Configure Offboarding Auto-Reply" -Status $st -Details "Internal & External Out-of-Office enabled."
            }
            elseif ($PSCmdlet.ShouldProcess($upn, "Enable Exchange Online Auto-Reply")) {
                try {
                    Set-MailboxAutoReplyConfiguration -Identity $upn -AutoReplyState Enabled -InternalMessage $autoReply -ExternalMessage $autoReply -ExternalAudience All -ErrorAction Stop
                    Add-AuditLog -UPN $upn -Step "Configure Offboarding Auto-Reply" -Status "Success" -Details "Auto-Reply enabled for internal & external senders."
                }
                catch {
                    Add-AuditLog -UPN $upn -Step "Configure Offboarding Auto-Reply" -Status "Warning" -Details $_.Exception.Message
                }
            }
            else {
                Add-AuditLog -UPN $upn -Step "Configure Offboarding Auto-Reply" -Status "WhatIf" -Details "Would enable Out-of-Office Auto-Reply."
            }
        }

        if ($Target.DelegateToManager -and -not [string]::IsNullOrWhiteSpace($mgrUpn)) {
            if ($DemoMode) {
                $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
                Add-AuditLog -UPN $upn -Step "Delegate Mailbox to Manager" -Status $st -Details "Granted FullAccess to $mgrUpn."
            }
            elseif ($PSCmdlet.ShouldProcess($upn, "Grant FullAccess on shared mailbox to $mgrUpn")) {
                try {
                    Add-MailboxPermission -Identity $upn -User $mgrUpn -AccessRights FullAccess -InheritanceType All -AutoMapping $true -ErrorAction Stop | Out-Null
                    Add-AuditLog -UPN $upn -Step "Delegate Mailbox to Manager" -Status "Success" -Details "FullAccess granted to $mgrUpn (AutoMapping enabled)."
                }
                catch {
                    Add-AuditLog -UPN $upn -Step "Delegate Mailbox to Manager" -Status "Warning" -Details $_.Exception.Message
                }
            }
            else {
                Add-AuditLog -UPN $upn -Step "Delegate Mailbox to Manager" -Status "WhatIf" -Details "Would grant FullAccess on shared mailbox to $mgrUpn."
            }
        }
    }
    elseif ($SkipExchangeOnline) {
        Add-AuditLog -UPN $upn -Step "Exchange Online Steps" -Status "Skipped" -Details "Skipped via -SkipExchangeOnline switch."
    }

    # Step 5: Remove Direct Group Memberships (Skipping Dynamic Groups)
    if ($defaults.RemoveAllGroups) {
        $staticGroups = @($userGroups | Where-Object { -not $_.IsDynamic })
        $dynCount     = @($userGroups | Where-Object { $_.IsDynamic }).Count
        if ($dynCount -gt 0) {
            Add-AuditLog -UPN $upn -Step "Dynamic Groups Detected" -Status "Skipped" -Details "Skipped $dynCount dynamic membership group(s) (managed by Entra ID rules)."
        }
        foreach ($g in $staticGroups) {
            if ($DemoMode) {
                $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
                Add-AuditLog -UPN $upn -Step "Remove Group Membership" -Status $st -Details "Removed from '$($g.DisplayName)'."
            }
            elseif ($PSCmdlet.ShouldProcess($upn, "Remove from group '$($g.DisplayName)'")) {
                try {
                    Remove-MgGroupMemberByRef -GroupId $g.Id -DirectoryObjectId $userObj.Id -ErrorAction Stop
                    Add-AuditLog -UPN $upn -Step "Remove Group Membership" -Status "Success" -Details "Removed from '$($g.DisplayName)'."
                }
                catch {
                    Add-AuditLog -UPN $upn -Step "Remove Group Membership" -Status "Warning" -Details "Could not remove from '$($g.DisplayName)': $($_.Exception.Message)"
                }
            }
            else {
                Add-AuditLog -UPN $upn -Step "Remove Group Membership" -Status "WhatIf" -Details "Would remove from '$($g.DisplayName)'."
            }
        }
    }

    # Step 6: Reclaim M365 Licenses
    if ($defaults.RemoveAllLicenses -and $userLicenses.Count -gt 0) {
        if ($DemoMode) {
            $st = if ($IsWhatIf) { "WhatIf" } else { "Success" }
            Add-AuditLog -UPN $upn -Step "Reclaim M365 Licenses" -Status $st -Details "Removed $($userLicenses.Count) license(s): $($userLicenses -join ', ')."
        }
        elseif ($PSCmdlet.ShouldProcess($upn, "Remove $($userLicenses.Count) assigned M365 license(s)")) {
            try {
                Set-MgUserLicense -UserId $userObj.Id -AddLicenses @() -RemoveLicenses $userLicenses | Out-Null
                Add-AuditLog -UPN $upn -Step "Reclaim M365 Licenses" -Status "Success" -Details "Reclaimed $($userLicenses.Count) M365 license(s)."
            }
            catch {
                Add-AuditLog -UPN $upn -Step "Reclaim M365 Licenses" -Status "Failed" -Details $_.Exception.Message
            }
        }
        else {
            Add-AuditLog -UPN $upn -Step "Reclaim M365 Licenses" -Status "WhatIf" -Details "Would reclaim $($userLicenses.Count) assigned M365 license(s)."
        }
    }
}
#endregion

#region AuditStatus Engine
function Invoke-UserAuditStatus {
    param([string]$Upn, [bool]$ExoConnected)
    if ($DemoMode) {
        Add-AuditLog -UPN $Upn -Step "Account Status" -Status "Info" -Details "AccountEnabled=True | Dept=Finance | Licenses=SPE_E3, POWER_BI_PRO | Groups=3 | MailboxType=UserMailbox"
        return
    }
    try {
        $u = Get-MgUser -UserId $Upn -Property Id, DisplayName, AccountEnabled, Department, JobTitle, AssignedLicenses -ErrorAction Stop
        $grps = @(Get-MgUserMemberOf -UserId $u.Id -All -ErrorAction SilentlyContinue).Count
        $mbxType = "Not Checked"
        if ($ExoConnected) {
            try { $mbxType = (Get-Mailbox -Identity $Upn -ErrorAction Stop).RecipientTypeDetails } catch { $mbxType = "No Mailbox" }
        }
        Add-AuditLog -UPN $Upn -Step "Account Status" -Status "Info" -Details "Enabled=$($u.AccountEnabled) | Dept=$($u.Department) | Licenses=$($u.AssignedLicenses.Count) | Groups=$grps | Mailbox=$mbxType"
    }
    catch {
        Add-AuditLog -UPN $Upn -Step "Account Status" -Status "Failed" -Details $_.Exception.Message
    }
}
#endregion

#region HTML Audit Report Generator
function Export-LifecycleHtmlReport {
    param(
        [string]$FilePath,
        [int]$TargetCount
    )

    $successCnt = @($script:AuditEntries | Where-Object { $_.Status -eq "Success" }).Count
    $whatIfCnt  = @($script:AuditEntries | Where-Object { $_.Status -eq "WhatIf" }).Count
    $warnCnt    = @($script:AuditEntries | Where-Object { $_.Status -eq "Warning" }).Count
    $failCnt    = @($script:AuditEntries | Where-Object { $_.Status -eq "Failed" }).Count

    $rows = ($script:AuditEntries | ForEach-Object {
        $badgeClass = switch ($_.Status) {
            "Success" { "badge-pass" }
            "WhatIf"  { "badge-whatif" }
            "Warning" { "badge-warn" }
            "Failed"  { "badge-fail" }
            default   { "badge-info" }
        }
        "<tr><td><code>$(ConvertTo-HtmlSafe $_.Timestamp)</code></td><td><strong>$(ConvertTo-HtmlSafe $_.UPN)</strong></td><td>$(ConvertTo-HtmlSafe $_.Step)</td><td><span class='badge $badgeClass'>$(ConvertTo-HtmlSafe $_.Status)</span></td><td>$(ConvertTo-HtmlSafe $_.Details)</td></tr>"
    }) -join "`n"

    $modeBanner = if ($IsWhatIf) { "DRY-RUN SAFETY MODE (-WhatIf) — NO LIVE CHANGES APPLIED" } elseif ($DemoMode) { "DEMO SIMULATION MODE" } else { "LIVE EXECUTION COMPLETE" }
    $modeColor  = if ($IsWhatIf -or $DemoMode) { "#f59e0b" } else { "#10b981" }

    $html = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>$ToolName (v$ToolVersion) — $Action Execution Report</title>
<style>
  :root { --bg:#0b1120; --surface:#111827; --border:#334155; --text:#f1f5f9; --muted:#94a3b8; --accent:#38bdf8; }
  * { box-sizing:border-box; }
  body { margin:0; font-family:'Segoe UI',system-ui,-apple-system,sans-serif; background:var(--bg); color:var(--text); line-height:1.5; }
  .container { max-width:1320px; margin:0 auto; padding:28px 24px 56px; }
  .jobaer-banner { background:linear-gradient(135deg,#0f172a 0%,#1e293b 100%); border:1px solid var(--border); border-left:5px solid #f59e0b; border-radius:14px; padding:22px 26px; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:16px; margin-bottom:22px; }
  .jobaer-pill { display:inline-block; background:rgba(245,158,11,0.16); color:#fbbf24; border:1px solid rgba(245,158,11,0.4); font-weight:700; font-size:0.78rem; padding:4px 12px; border-radius:99px; letter-spacing:0.06em; text-transform:uppercase; margin-bottom:8px; }
  .jobaer-banner h1 { margin:0; font-size:1.55rem; color:#fff; }
  .jobaer-banner p { margin:4px 0 0; color:var(--accent); font-size:0.9rem; }
  .meta { text-align:right; font-size:0.84rem; color:var(--muted); }
  .mode-bar { padding:10px 16px; border-radius:10px; font-weight:700; font-size:0.86rem; margin-bottom:20px; background:rgba(15,23,42,0.85); border:1px solid $modeColor; color:$modeColor; display:flex; justify-content:space-between; align-items:center; }
  .kpi-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(190px,1fr)); gap:14px; margin-bottom:22px; }
  .kpi { background:var(--surface); border:1px solid var(--border); border-radius:12px; padding:18px; }
  .kpi-label { font-size:0.75rem; text-transform:uppercase; letter-spacing:0.06em; color:var(--muted); }
  .kpi-val { font-size:1.9rem; font-weight:700; margin-top:4px; color:#fff; }
  section { background:var(--surface); border:1px solid var(--border); border-radius:14px; padding:20px 22px; }
  h2 { margin:0 0 14px; font-size:1.12rem; color:#fff; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border); padding-bottom:10px; }
  .filter { background:#0f172a; border:1px solid var(--border); color:var(--text); padding:6px 12px; border-radius:8px; font-size:0.84rem; width:240px; }
  table { width:100%; border-collapse:collapse; font-size:0.85rem; }
  th { text-align:left; padding:10px 12px; background:#0f172a; color:var(--muted); font-size:0.74rem; text-transform:uppercase; border-bottom:1px solid var(--border); }
  td { padding:10px 12px; border-bottom:1px solid rgba(51,65,85,0.55); vertical-align:top; }
  .badge { display:inline-block; padding:3px 9px; border-radius:99px; font-size:0.72rem; font-weight:700; text-transform:uppercase; }
  .badge-pass { background:rgba(16,185,129,0.16); color:#34d399; border:1px solid rgba(16,185,129,0.35); }
  .badge-whatif { background:rgba(245,158,11,0.16); color:#fbbf24; border:1px solid rgba(245,158,11,0.35); }
  .badge-warn { background:rgba(251,146,60,0.16); color:#fb923c; border:1px solid rgba(251,146,60,0.35); }
  .badge-fail { background:rgba(239,68,68,0.16); color:#f87171; border:1px solid rgba(239,68,68,0.35); }
  .badge-info { background:rgba(56,189,248,0.16); color:#38bdf8; border:1px solid rgba(56,189,248,0.35); }
  .btn-print { background:var(--accent); color:#0f172a; border:none; padding:7px 14px; border-radius:8px; font-weight:700; cursor:pointer; font-size:0.82rem; }
  footer { text-align:center; color:var(--muted); font-size:0.82rem; margin-top:28px; padding-top:16px; border-top:1px solid var(--border); }
  footer a { color:var(--accent); text-decoration:none; }
  @media print { body{background:#fff;color:#111;} .jobaer-banner,section,.kpi{background:#fff;border-color:#cbd5e1;color:#111;} .btn-print,.filter{display:none;} }
</style>
</head>
<body>
<div class="container">
  <div class="jobaer-banner">
    <div>
      <span class="jobaer-pill">Created by Jobaer</span>
      <h1>$ToolName <span style="font-size:0.88rem;color:#94a3b8;font-weight:400;">v$ToolVersion</span></h1>
      <p>Zero-Touch PowerShell &amp; Microsoft Graph Lifecycle Automation Report</p>
    </div>
    <div class="meta">
      <div>Action: <strong style="color:#fff">$Action</strong></div>
      <div>Run Time: <strong style="color:#fff">$($RunDate.ToString("yyyy-MM-dd HH:mm:ss"))</strong></div>
      <div>License: <strong>Freeware / MIT</strong></div>
      <div style="margin-top:8px;"><button class="btn-print" onclick="window.print()">Print / Save PDF</button></div>
    </div>
  </div>

  <div class="mode-bar">
    <span>$modeBanner</span>
    <span>Targets Processed: $TargetCount</span>
  </div>

  <div class="kpi-grid">
    <div class="kpi"><div class="kpi-label">Users Processed</div><div class="kpi-val">$TargetCount</div></div>
    <div class="kpi"><div class="kpi-label">Completed Steps</div><div class="kpi-val" style="color:#34d399">$successCnt</div></div>
    <div class="kpi"><div class="kpi-label">Simulated (-WhatIf)</div><div class="kpi-val" style="color:#fbbf24">$whatIfCnt</div></div>
    <div class="kpi"><div class="kpi-label">Warnings</div><div class="kpi-val" style="color:#fb923c">$warnCnt</div></div>
    <div class="kpi"><div class="kpi-label">Failures</div><div class="kpi-val" style="color:#f87171">$failCnt</div></div>
  </div>

  <section>
    <h2>Lifecycle Execution &amp; Compliance Audit Log <input class="filter" type="text" placeholder="Filter by UPN or step..." onkeyup="filterRows(this)"></h2>
    <div style="overflow-x:auto;">
      <table id="audit-table">
        <thead><tr><th>Timestamp</th><th>UserPrincipalName</th><th>Lifecycle Step</th><th>Status</th><th>Execution Details</th></tr></thead>
        <tbody>$rows</tbody>
      </table>
    </div>
  </section>

  <footer>
    <strong>Created by Jobaer</strong> — <strong>$AuthorName</strong> |
    <a href="$AuthorSite" target="_blank">www.jobaeralam.com</a> |
    <a href="mailto:$AuthorEmail">$AuthorEmail</a> | License: Freeware / MIT
  </footer>
</div>
<script>
function filterRows(el){
  const q = el.value.toLowerCase();
  document.querySelectorAll('#audit-table tbody tr').forEach(r => {
    r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
</script>
</body>
</html>
"@
    $html | Out-File -FilePath $FilePath -Encoding UTF8
}
#endregion

#region Main Execution
Show-JobaerBanner

New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
$transcriptPath = Join-Path -Path $OutputPath -ChildPath "Transcript.log"
try { Start-Transcript -Path $transcriptPath -Force | Out-Null } catch { }

try {
    $config = Load-ToolkitConfig -Path $ConfigPath

    # Build Target List (Single User or Bulk CSV)
    $targets = [System.Collections.Generic.List[object]]::new()

    if (-not [string]::IsNullOrWhiteSpace($CsvPath)) {
        if (-not (Test-Path $CsvPath)) { throw "CSV file not found: $CsvPath" }
        $csvRows = @(Import-Csv -Path $CsvPath)
        if ($csvRows.Count -eq 0) { throw "CSV file is empty: $CsvPath" }
        Write-Host "[*] Loaded $($csvRows.Count) user(s) from CSV: $CsvPath" -ForegroundColor Cyan

        foreach ($row in $csvRows) {
            $rowLicenses = if ($row.PSObject.Properties.Name -contains "LicenseSkus" -and $row.LicenseSkus) { ($row.LicenseSkus -split ';') } else { @() }
            $rowGroups   = if ($row.PSObject.Properties.Name -contains "GroupNames"  -and $row.GroupNames)  { ($row.GroupNames  -split ';') } else { @() }
            $rowDelegate = if ($row.PSObject.Properties.Name -contains "DelegateToManager" -and $row.DelegateToManager) { ($row.DelegateToManager -match '^(true|yes|1)$') } else { [bool]$DelegateToManager }
            $rowAutoRep  = if ($row.PSObject.Properties.Name -contains "AutoReplyMessage" -and $row.AutoReplyMessage) { $row.AutoReplyMessage } else { $AutoReplyMessage }

            $targets.Add([PSCustomObject]@{
                UserPrincipalName = $row.UserPrincipalName
                DisplayName       = if ($row.PSObject.Properties.Name -contains "DisplayName")   { $row.DisplayName }   else { "" }
                FirstName         = if ($row.PSObject.Properties.Name -contains "FirstName")     { $row.FirstName }     else { "" }
                LastName          = if ($row.PSObject.Properties.Name -contains "LastName")      { $row.LastName }      else { "" }
                Department        = if ($row.PSObject.Properties.Name -contains "Department" -and $row.Department) { $row.Department } else { "Default" }
                JobTitle          = if ($row.PSObject.Properties.Name -contains "JobTitle")      { $row.JobTitle }      else { "" }
                UsageLocation     = if ($row.PSObject.Properties.Name -contains "UsageLocation") { $row.UsageLocation } else { $UsageLocation }
                ManagerUPN        = if ($row.PSObject.Properties.Name -contains "ManagerUPN")    { $row.ManagerUPN }    else { $ManagerUPN }
                LicenseSkus       = $rowLicenses
                GroupNames        = $rowGroups
                DelegateToManager = $rowDelegate
                AutoReplyMessage  = $rowAutoRep
            })
        }
    }
    elseif (-not [string]::IsNullOrWhiteSpace($UserPrincipalName)) {
        $autoDisplay = if (-not [string]::IsNullOrWhiteSpace($DisplayName)) { $DisplayName } elseif ($FirstName -or $LastName) { "$FirstName $LastName".Trim() } else { ($UserPrincipalName -split '@')[0] }
        $targets.Add([PSCustomObject]@{
            UserPrincipalName = $UserPrincipalName
            DisplayName       = $autoDisplay
            FirstName         = $FirstName
            LastName          = $LastName
            Department        = $Department
            JobTitle          = $JobTitle
            UsageLocation     = $UsageLocation
            ManagerUPN        = $ManagerUPN
            LicenseSkus       = $LicenseSkus
            GroupNames        = $GroupNames
            DelegateToManager = [bool]$DelegateToManager
            AutoReplyMessage  = $AutoReplyMessage
        })
    }
    else {
        throw "Provide either -UserPrincipalName or -CsvPath."
    }

    # Connect to M365 unless DemoMode
    $exoConnected = $false
    $skuCache     = @{}
    if (-not $DemoMode) {
        $conn = Initialize-M365Connections -LifecycleAction $Action -SkipExo:$SkipExchangeOnline
        $exoConnected = $conn.ExoConnected
        if ($Action -eq "Onboard") {
            foreach ($sku in (Get-MgSubscribedSku -All)) {
                $skuCache[$sku.SkuPartNumber.ToUpper()] = $sku
            }
        }
    }

    # Process each target
    foreach ($t in $targets) {
        Write-Host ""
        Write-Host "----------------------------------------------------------------------------" -ForegroundColor DarkCyan
        Write-Host "  Processing [$Action] -> $($t.UserPrincipalName)" -ForegroundColor White
        Write-Host "----------------------------------------------------------------------------" -ForegroundColor DarkCyan
        switch ($Action) {
            "Onboard"     { Invoke-UserOnboarding   -Target $t -Config $config -SkuCache $skuCache }
            "Offboard"    { Invoke-UserOffboarding  -Target $t -Config $config -ExoConnected $exoConnected }
            "AuditStatus" { Invoke-UserAuditStatus  -Upn $t.UserPrincipalName -ExoConnected $exoConnected }
        }
    }

    # Export Audit Trail & Artifacts
    $csvAuditPath = Join-Path -Path $OutputPath -ChildPath "Audit-Action-Log.csv"
    $script:AuditEntries | Export-Csv -Path $csvAuditPath -NoTypeInformation -Encoding UTF8

    if ($script:PreChangeSnapshot.Count -gt 0) {
        $snapPath = Join-Path -Path $OutputPath -ChildPath "PreChange-Snapshot.json"
        $script:PreChangeSnapshot | ConvertTo-Json -Depth 6 | Out-File -FilePath $snapPath -Encoding UTF8
    }

    if ($script:CreatedCreds.Count -gt 0) {
        $credPath = Join-Path -Path $OutputPath -ChildPath "Onboarding-TempCredentials.csv"
        $script:CreatedCreds | Export-Csv -Path $credPath -NoTypeInformation -Encoding UTF8
        Write-Host ""
        Write-Host "  [!] Temporary credentials saved to: $credPath (Share securely & delete after handoff)" -ForegroundColor Yellow
    }

    $htmlPath = Join-Path -Path $OutputPath -ChildPath "Lifecycle-Execution-Report.html"
    Export-LifecycleHtmlReport -FilePath $htmlPath -TargetCount $targets.Count

    Write-Host ""
    Write-Host "============================================================================" -ForegroundColor Green
    Write-Host "  EXECUTION COMPLETE — CREATED BY JOBAER (v$ToolVersion)" -ForegroundColor Green
    Write-Host "  HTML Report : $htmlPath" -ForegroundColor White
    Write-Host "  CSV Audit   : $csvAuditPath" -ForegroundColor White
    Write-Host "============================================================================" -ForegroundColor Green
    Write-Host ""

    if ($OpenReport) {
        Start-Process $htmlPath
    }
}
catch {
    Write-Host ""
    Write-Host "  [ERROR] $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
finally {
    try { Stop-Transcript | Out-Null } catch { }
}
#endregion
