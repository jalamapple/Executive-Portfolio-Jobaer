<#
.SYNOPSIS
    Installs required PowerShell modules for M365 User Onboarding & Offboarding Toolkit (v2.0.1).
    Created by S M Jobaer Alam | www.jobaeralam.com
#>

Write-Host ""
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "  CREATED BY JOBAER — Prerequisite Installer (v2.0.1)" -ForegroundColor Yellow
Write-Host "  M365 User Onboarding & Offboarding Toolkit" -ForegroundColor White
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host ""

$modules = @(
    "Microsoft.Graph.Authentication",
    "Microsoft.Graph.Users",
    "Microsoft.Graph.Groups",
    "Microsoft.Graph.Identity.DirectoryManagement",
    "ExchangeOnlineManagement"
)

if (-not (Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction SilentlyContinue)) {
    Write-Host "[*] Installing NuGet package provider..." -ForegroundColor Cyan
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force
}

foreach ($m in $modules) {
    if (Get-Module -ListAvailable -Name $m) {
        Write-Host "[+] Already installed: $m" -ForegroundColor Green
    }
    else {
        Write-Host "[*] Installing $m (CurrentUser scope)..." -ForegroundColor Yellow
        Install-Module -Name $m -Scope CurrentUser -Force -AllowClobber
        Write-Host "[+] Installed: $m" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "All prerequisites ready! Try a safe dry-run:" -ForegroundColor Green
Write-Host '  .\Start-M365Lifecycle.ps1 -Action Offboard -UserPrincipalName "user@domain.com" -WhatIf' -ForegroundColor Cyan
Write-Host ""
