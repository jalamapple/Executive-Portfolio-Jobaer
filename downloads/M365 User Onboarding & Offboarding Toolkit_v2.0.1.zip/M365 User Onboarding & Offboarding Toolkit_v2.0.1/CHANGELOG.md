# Changelog — M365 User Onboarding & Offboarding Toolkit

## [2.0.1] - 2026-10-26
- Added prominent **Created by Jobaer** ASCII console banner & branded HTML Execution Report.
- Added unified `Start-M365Lifecycle.ps1` entry point supporting `Onboard`, `Offboard`, and `AuditStatus`.
- Added native PowerShell `-WhatIf` safety dry-run mode across all Entra ID, Microsoft Graph, and Exchange Online operations.
- Added smart department-based provisioning templates (`config\toolkit-config.json`) for M365 license SKUs, Security Groups, Teams, and SharePoint sites.
- Added one-command secure offboarding: sign-in block, 32-char password scramble, session/token revocation, shared mailbox conversion, GAL hide, Auto-Reply, manager FullAccess delegation, static group cleanup, license reclamation, and JSON/CSV/HTML compliance audit exports.
- Added Bulk CSV onboarding/offboarding templates, `-DemoMode` offline simulation, `Install-Prerequisites.ps1`, and `Run-M365-Lifecycle.bat` (PowerShell 7+ aware).
