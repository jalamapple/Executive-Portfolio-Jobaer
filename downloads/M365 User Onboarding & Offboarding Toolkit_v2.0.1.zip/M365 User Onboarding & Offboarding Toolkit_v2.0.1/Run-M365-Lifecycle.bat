@echo off
title M365 User Onboarding ^& Offboarding Toolkit v2.0.1 - Created by Jobaer
color 0B

where pwsh.exe >nul 2>&1
if %errorlevel%==0 (
    set "PS_EXE=pwsh.exe"
) else (
    set "PS_EXE=powershell.exe"
)

:MENU
cls
echo ============================================================================
echo    ____ ____  _____    _  _____ _____ ____    ______   __
echo   / ___^|  _ \^| ____^|  / \^|_   _^| ____^|  _ \  ^| __ ) \ / /
echo  ^| ^|   ^| ^|_) ^|  _^|   / _ \ ^| ^| ^|  _^| ^| ^| ^| ^| ^|  _ \\ V /
echo  ^| ^|___^|  _ ^<^| ^|___ / ___ \^| ^| ^| ^|___^| ^|_^| ^| ^| ^|_) ^|^| ^|
echo   \____^|_^| \_\_____/_/   \_\_^| ^|_____^|____/  ^|____/ ^|_^|   JOBAER
echo.
echo   M365 User Onboarding ^& Offboarding Toolkit (v2.0.1)
echo   Author: S M Jobaer Alam ^| www.jobaeralam.com ^| hello@jobaeralam.com
echo ============================================================================
echo.
echo   [1] Single User Offboarding (Dry-Run -WhatIf Safety Mode)
echo   [2] Single User Offboarding (LIVE Execution)
echo   [3] Single User Onboarding  (Dry-Run -WhatIf Safety Mode)
echo   [4] Bulk CSV Onboarding     (Templates\Bulk-Onboard-Template.csv -WhatIf)
echo   [5] Bulk CSV Offboarding    (Templates\Bulk-Offboard-Template.csv -WhatIf)
echo   [6] Run Demo Simulation     (Preview HTML ^& CSV Audit Report - No Login)
echo   [7] Install Required Modules (Graph + ExchangeOnlineManagement)
echo   [8] Exit
echo.
set /p choice="Select an option [1-8]: "

if "%choice%"=="1" goto OFFBOARD_WHATIF
if "%choice%"=="2" goto OFFBOARD_LIVE
if "%choice%"=="3" goto ONBOARD_WHATIF
if "%choice%"=="4" goto BULK_ONBOARD
if "%choice%"=="5" goto BULK_OFFBOARD
if "%choice%"=="6" goto DEMO
if "%choice%"=="7" goto INSTALL
if "%choice%"=="8" exit /b 0
goto MENU

:OFFBOARD_WHATIF
set /p upn="Enter UserPrincipalName to offboard (e.g. user@domain.com): "
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-M365Lifecycle.ps1" -Action Offboard -UserPrincipalName "%upn%" -WhatIf -OpenReport
pause
goto MENU

:OFFBOARD_LIVE
set /p upn="Enter UserPrincipalName for LIVE offboarding: "
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-M365Lifecycle.ps1" -Action Offboard -UserPrincipalName "%upn%" -DelegateToManager -OpenReport
pause
goto MENU

:ONBOARD_WHATIF
set /p upn="Enter new UserPrincipalName (e.g. jane.doe@domain.com): "
set /p dname="Enter Display Name (e.g. Jane Doe): "
set /p dept="Enter Department (IT / Finance / Sales / HR / Default): "
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-M365Lifecycle.ps1" -Action Onboard -UserPrincipalName "%upn%" -DisplayName "%dname%" -Department "%dept%" -WhatIf -OpenReport
pause
goto MENU

:BULK_ONBOARD
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-M365Lifecycle.ps1" -Action Onboard -CsvPath "%~dp0Templates\Bulk-Onboard-Template.csv" -WhatIf -OpenReport
pause
goto MENU

:BULK_OFFBOARD
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-M365Lifecycle.ps1" -Action Offboard -CsvPath "%~dp0Templates\Bulk-Offboard-Template.csv" -WhatIf -OpenReport
pause
goto MENU

:DEMO
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-M365Lifecycle.ps1" -Action Offboard -UserPrincipalName "alex.morgan@contoso.com" -DemoMode -WhatIf -DelegateToManager -OpenReport
pause
goto MENU

:INSTALL
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Prerequisites.ps1"
pause
goto MENU
