====================================================================
M365 User Onboarding & Offboarding Toolkit (v2.0.1)
Author: S M Jobaer Alam | www.jobaeralam.com | hello@jobaeralam.com
License: Freeware / MIT
====================================================================

## OVERVIEW
Zero-touch PowerShell & Microsoft Graph automation toolkit for standardized employee onboarding, license assignment, and secure offboarding.

## KEY FEATURES
- **Standardized Zero-Touch Onboarding:** Automates Entra ID account creation, secure temporary password generation, manager assignment, M365 license assignment (with seat availability check), and Security Group / Microsoft Teams / SharePoint access via role-based templates (`config\toolkit-config.json`).
- **One-Command Secure Offboarding:** Captures a pre-offboarding JSON snapshot, blocks sign-in, scrambles password, revokes all active Entra ID refresh tokens/sessions, converts the Exchange Online mailbox to Shared, hides from GAL, enables Out-of-Office auto-reply, delegates FullAccess to the manager, strips static group memberships, reclaims M365 licenses, and exports compliance audit logs (HTML + CSV + Transcript).
- **Bulk CSV Processing & `-WhatIf` Safety Mode:** Process single users or entire HR onboarding/offboarding batches from CSV with native PowerShell `-WhatIf` dry-run validation.
- **Created by Jobaer Banner & Executive HTML Reports:** Displays the `Created by Jobaer` banner on every run and exports a print-to-PDF ready HTML audit report.

## REQUIREMENTS
- Windows 10/11
- PowerShell 7+ *(backward-compatible with Windows PowerShell 5.1)*
- `Microsoft.Graph` Modules (`Authentication`, `Users`, `Groups`, `Identity.DirectoryManagement`)
- `ExchangeOnlineManagement`

## QUICK START
```powershell
# 1. Install prerequisites (one-time, CurrentUser scope)
.\Install-Prerequisites.ps1

# 2. Safe Dry-Run Offboarding (-WhatIf)
.\Start-M365Lifecycle.ps1 -Action Offboard -UserPrincipalName "user@domain.com" -WhatIf

# 3. Preview offline Demo Mode (no M365 sign-in required)
.\Start-M365Lifecycle.ps1 -Action Offboard -UserPrincipalName "alex.morgan@contoso.com" -DemoMode -WhatIf -OpenReport

# 4. Bulk Onboarding from CSV (Dry-Run)
.\Start-M365Lifecycle.ps1 -Action Onboard -CsvPath ".\Templates\Bulk-Onboard-Template.csv" -WhatIf -OpenReport

# 5. Live Offboarding with Manager Mailbox Delegation
.\Start-M365Lifecycle.ps1 -Action Offboard -UserPrincipalName "user@domain.com" -DelegateToManager -OpenReport
```

Or double-click **`Run-M365-Lifecycle.bat`** for the interactive Windows menu launcher.

## OUTPUT ARTIFACTS
Each execution creates a timestamped audit directory under `.\Logs\Lifecycle_<Action>_<YYYYMMDD_HHMMSS>\`:
- `Lifecycle-Execution-Report.html` — Executive HTML Audit Report (print-to-PDF ready)
- `Audit-Action-Log.csv` — Step-by-step compliance log
- `PreChange-Snapshot.json` — Pre-offboarding licenses, groups, and manager snapshot
- `Onboarding-TempCredentials.csv` — Generated during live onboarding (handle securely)
- `Transcript.log` — Full PowerShell console transcript
