@echo off
title M365 ESPA By Jobaer (v1.2.0) - M365 ^& Entra ID Security Posture Auditor
color 0B

where pwsh.exe >nul 2>&1
if %errorlevel%==0 (
    set "PS_EXE=pwsh.exe"
) else (
    set "PS_EXE=powershell.exe"
)

:MENU
cls
echo ========================================================================
echo    M365 ESPA By Jobaer (v1.2.0)
echo    Microsoft 365 ^& Entra ID Security Posture Auditor (ISO 27001 Ready)
echo    Author: S M Jobaer Alam ^| www.jobaeralam.com
echo ========================================================================
echo.
echo   [1] Run Live Tenant Security Audit (Graph + Exchange Online)
echo   [2] Run Live Tenant Audit (Skip Exchange Online / DNS-only DKIM)
echo   [3] Run Demo Mode (Preview Sample ISO 27001 HTML ^& CSV Reports)
echo   [4] Install / Verify Required PowerShell Modules
echo   [5] Exit
echo.
set /p choice="Select an option [1-5]: "

if "%choice%"=="1" goto LIVE
if "%choice%"=="2" goto LIVE_NO_EXO
if "%choice%"=="3" goto DEMO
if "%choice%"=="4" goto INSTALL
if "%choice%"=="5" exit /b 0
goto MENU

:LIVE
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Invoke-M365SecurityAudit.ps1" -ExportHtml -OpenReport
pause
goto MENU

:LIVE_NO_EXO
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Invoke-M365SecurityAudit.ps1" -SkipExchangeOnline -ExportHtml -OpenReport
pause
goto MENU

:DEMO
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Invoke-M365SecurityAudit.ps1" -DemoMode -ExportHtml -OpenReport
pause
goto MENU

:INSTALL
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Prerequisites.ps1"
pause
goto MENU
