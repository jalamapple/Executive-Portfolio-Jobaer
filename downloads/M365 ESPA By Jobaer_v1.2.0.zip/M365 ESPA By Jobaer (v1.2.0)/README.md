# M365 ESPA By Jobaer (v1.2.0)

**OVERVIEW**  
Automated Microsoft 365 & Entra ID security checklist exporting MFA coverage, Conditional Access gaps, PIM roles, and Exchange SPF/DKIM/DMARC status to HTML/CSV.

> **Author:** S M Jobaer Alam — Microsoft 365 & Cloud Engineer | Microsoft Security Specialist  
> **Website:** https://www.jobaeralam.com | **Email:** hello@jobaeralam.com | **LinkedIn:** https://www.linkedin.com/in/smjobaeralam

---

## KEY FEATURES

- **Audits Entra ID MFA enforcement, legacy authentication, and standing Global Admin accounts.**
- **Checks Exchange Online SPF, DKIM, and DMARC DNS alignment across all accepted domains.**
- **Generates an executive HTML + CSV compliance report ready for ISO 27001 evidence.**

---

## REQUIREMENTS

- **Windows 10/11**
- **PowerShell 7+** *(backward compatible with Windows PowerShell 5.1)*
- **Microsoft Graph Module** *(+ optional `ExchangeOnlineManagement` for live EXO accepted domains & DKIM)*

---

## QUICK START

```powershell
Connect-MgGraph -Scopes "Directory.Read.All"; .\Invoke-M365SecurityAudit.ps1 -ExportHtml
```

### Additional Usage Examples
```powershell
# 1. Install required modules (one-time, CurrentUser scope)
.\Install-Prerequisites.ps1

# 2. Preview ISO 27001 HTML & CSV reports offline (no sign-in required)
.\Invoke-M365SecurityAudit.ps1 -DemoMode -ExportHtml -OpenReport

# 3. Full live audit with automatic browser launch
.\Invoke-M365SecurityAudit.ps1 -ExportHtml -OpenReport

# 4. Live audit with DNS-only DKIM (skip Exchange Online sign-in)
.\Invoke-M365SecurityAudit.ps1 -SkipExchangeOnline -ExportHtml -OpenReport
```

Or double-click **`Run-M365-ESPA.bat`** for the interactive Windows menu.

---

## OUTPUT FILES (ISO 27001 EVIDENCE)

Each run generates a timestamped folder under `.\Reports\M365-ESPA_<YYYYMMDD_HHMMSS>\`:
- `M365-ESPA-ISO27001-Report.html` — Executive HTML Compliance Dashboard (print-to-PDF ready)
- `CSV\01_MFA_Coverage_Users.csv`
- `CSV\02_Conditional_Access_Policies.csv`
- `CSV\03_Conditional_Access_Gaps.csv`
- `CSV\04_PIM_Privileged_Roles.csv`
- `CSV\05_Exchange_SPF_DKIM_DMARC.csv`
- `CSV\06_ISO27001_Compliance_Evidence.csv`
