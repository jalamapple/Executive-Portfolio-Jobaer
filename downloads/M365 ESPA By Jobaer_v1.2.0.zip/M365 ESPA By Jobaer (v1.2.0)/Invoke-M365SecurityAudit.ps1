<#
.SYNOPSIS
    M365 ESPA By Jobaer (v1.2.0) — Microsoft 365 & Entra ID Security Posture Auditor

.DESCRIPTION
    Automated Microsoft 365 & Entra ID security checklist exporting MFA coverage,
    Conditional Access gaps, PIM roles, and Exchange SPF/DKIM/DMARC status to HTML/CSV.

    KEY FEATURES:
    - Audits Entra ID MFA enforcement, legacy authentication, and standing Global Admin accounts.
    - Checks Exchange Online SPF, DKIM, and DMARC DNS alignment across all accepted domains.
    - Generates an executive HTML + CSV compliance report ready for ISO 27001:2022 evidence.

    REQUIREMENTS:
    Windows 10/11 | PowerShell 7+ (compatible with 5.1) | Microsoft Graph Module

.PARAMETER ExportHtml
    Generates the Executive HTML Compliance Report (M365-ESPA-ISO27001-Report.html).

.PARAMETER OutputPath
    Directory where HTML and CSV compliance reports will be saved. Defaults to .\Reports\M365-ESPA_<timestamp>.

.PARAMETER Domains
    Optional array of custom domains to audit for SPF/DKIM/DMARC. If omitted, all Exchange Online accepted domains (or Entra ID verified domains) are auto-discovered.

.PARAMETER SkipExchangeOnline
    Skips Exchange Online PowerShell authentication and performs DNS-only SPF/DKIM/DMARC checks.

.PARAMETER IncludeDisabledUsers
    Includes disabled Entra ID accounts in the MFA coverage analysis.

.PARAMETER DemoMode
    Runs the full audit engine with realistic enterprise sample data (no Microsoft 365 sign-in required).

.PARAMETER OpenReport
    Automatically opens the generated HTML report in the default browser upon completion.

.EXAMPLE
    Connect-MgGraph -Scopes "Directory.Read.All"; .\Invoke-M365SecurityAudit.ps1 -ExportHtml

.EXAMPLE
    .\Invoke-M365SecurityAudit.ps1 -ExportHtml -OpenReport

.EXAMPLE
    .\Invoke-M365SecurityAudit.ps1 -DemoMode -ExportHtml -OpenReport

.NOTES
    Tool Name : M365 ESPA By Jobaer
    Script    : Invoke-M365SecurityAudit.ps1
    Version   : 1.2.0
    Author    : S M Jobaer Alam (Microsoft 365 & Cloud Engineer | Microsoft Security Specialist)
    Website   : https://www.jobaeralam.com
    Email     : hello@jobaeralam.com
    LinkedIn  : https://www.linkedin.com/in/smjobaeralam
    License   : MIT License
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [switch]$ExportHtml,

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "",

    [Parameter(Mandatory = $false)]
    [string[]]$Domains = @(),

    [Parameter(Mandatory = $false)]
    [switch]$SkipExchangeOnline,

    [Parameter(Mandatory = $false)]
    [switch]$IncludeDisabledUsers,

    [Parameter(Mandatory = $false)]
    [switch]$DemoMode,

    [Parameter(Mandatory = $false)]
    [switch]$OpenReport
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

#region Constants & Branding
$ToolName    = "M365 ESPA By Jobaer"
$ToolFull    = "Microsoft 365 & Entra ID Security Posture Auditor"
$ToolVersion = "1.2.0"
$AuthorName  = "S M Jobaer Alam"
$AuthorSite  = "https://www.jobaeralam.com"
$AuthorEmail = "hello@jobaeralam.com"
$AuditDate   = Get-Date
$Timestamp   = $AuditDate.ToString("yyyyMMdd_HHmmss")

# Default to exporting HTML if -OpenReport is specified
if ($OpenReport -and -not $ExportHtml) { $ExportHtml = $true }

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path -Path $PSScriptRoot -ChildPath "Reports\M365-ESPA_$Timestamp"
}
$CsvFolder = Join-Path -Path $OutputPath -ChildPath "CSV"
#endregion

#region Console Helpers
function Show-Banner {
    Write-Host ""
    Write-Host "========================================================================" -ForegroundColor Cyan
    Write-Host "   __  __ _____ __  _____   _____ ____  ____   _    " -ForegroundColor Cyan
    Write-Host "  |  \/  |___ // /_| ____| | ____/ ___||  _ \ / \   " -ForegroundColor Cyan
    Write-Host "  | |\/| | |_ \ '_ \___ \  |  _| \___ \| |_) / _ \  " -ForegroundColor Cyan
    Write-Host "  | |  | |___) | (_) |__) | | |___ ___) |  __/ ___ \ " -ForegroundColor Cyan
    Write-Host "  |_|  |_|____/ \___/____/  |_____|____/|_| /_/   \_\" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  $ToolName (v$ToolVersion) — ISO 27001 Evidence Ready" -ForegroundColor White
    Write-Host "  $ToolFull" -ForegroundColor Gray
    Write-Host "  Author: $AuthorName | $AuthorSite" -ForegroundColor DarkGray
    Write-Host "========================================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step { param([string]$Message) Write-Host "[*] $Message" -ForegroundColor Cyan }
function Write-Ok   { param([string]$Message) Write-Host "    [+] $Message" -ForegroundColor Green }
function Write-Warn { param([string]$Message) Write-Host "    [!] $Message" -ForegroundColor Yellow }
function Write-Fail { param([string]$Message) Write-Host "    [-] $Message" -ForegroundColor Red }
#endregion

#region HTML Encoding Helper
function ConvertTo-HtmlSafe {
    param([AllowNull()][string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return "" }
    return [System.Net.WebUtility]::HtmlEncode($Text)
}
#endregion

#region DNS & Mail Authentication Helpers
function Resolve-DnsTxtSafe {
    param([string]$Name)
    $results = @()
    try {
        if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
            $records = Resolve-DnsName -Name $Name -Type TXT -ErrorAction Stop
            foreach ($r in $records) {
                if ($r.Strings) { $results += ($r.Strings -join "") }
            }
        }
        else {
            $raw = & nslookup -type=txt $Name 2>$null
            foreach ($line in $raw) {
                if ($line -match '"(.+)"') { $results += $Matches[1] }
            }
        }
    }
    catch { }
    return $results
}

function Resolve-DnsCnameSafe {
    param([string]$Name)
    try {
        if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
            $rec = Resolve-DnsName -Name $Name -Type CNAME -ErrorAction Stop | Select-Object -First 1
            if ($rec -and $rec.NameHost) { return $rec.NameHost }
        }
        else {
            $raw = & nslookup -type=cname $Name 2>$null
            foreach ($line in $raw) {
                if ($line -match 'canonical name\s*=\s*(\S+)') { return $Matches[1].TrimEnd('.') }
            }
        }
    }
    catch { return $null }
    return $null
}

function Get-SpfAudit {
    param([string]$Domain)
    $txtRecords = @(Resolve-DnsTxtSafe -Name $Domain)
    $spfRecords = @($txtRecords | Where-Object { $_ -match '^v=spf1\b' })

    if ($spfRecords.Count -eq 0) {
        return [PSCustomObject]@{ Status = "Fail"; Record = "Missing"; Lookups = 0; Notes = "No SPF record found. Domain is vulnerable to direct spoofing." }
    }
    if ($spfRecords.Count -gt 1) {
        return [PSCustomObject]@{ Status = "Fail"; Record = ($spfRecords -join " | "); Lookups = 0; Notes = "Multiple SPF records found ($($spfRecords.Count)). RFC 7208 allows only one v=spf1 record." }
    }

    $spf = $spfRecords[0]
    $lookupCount = ([regex]::Matches($spf, '(?i)\b(include:|a\b|a:|mx\b|mx:|ptr\b|exists:|redirect=)')).Count
    $status = "Pass"
    $notes  = @()

    if ($spf -match '\+all\b')     { $status = "Fail";    $notes += "Uses +all (permits any server to send mail)." }
    elseif ($spf -match '\?all\b') { $status = "Warning"; $notes += "Uses ?all (neutral). Recommend -all or ~all." }
    elseif ($spf -match '~all\b')  { $status = "Warning"; $notes += "Uses ~all (softfail). Harden to -all once all senders are verified." }
    elseif ($spf -match '-all\b')  { $notes += "Hardfail (-all) configured." }
    else                           { $status = "Warning"; $notes += "No explicit 'all' mechanism found." }

    if ($lookupCount -gt 10) { $status = "Fail"; $notes += "Exceeds 10 DNS lookup limit ($lookupCount mechanisms)." }
    else                     { $notes += "Estimated top-level DNS lookups: $lookupCount/10." }

    return [PSCustomObject]@{ Status = $status; Record = $spf; Lookups = $lookupCount; Notes = ($notes -join " ") }
}

function Get-DkimAudit {
    param([string]$Domain, [hashtable]$ExoDkimLookup)

    if ($ExoDkimLookup -and $ExoDkimLookup.ContainsKey($Domain.ToLower())) {
        $cfg = $ExoDkimLookup[$Domain.ToLower()]
        if ($cfg.Enabled -eq $true) {
            return [PSCustomObject]@{ Status = "Pass"; Record = "EXO DKIM Enabled (Selector1/Selector2)"; Notes = "Active in Exchange Online. Key status: $($cfg.Status)." }
        }
        else {
            return [PSCustomObject]@{ Status = "Fail"; Record = "EXO DKIM Disabled"; Notes = "DKIM signing is configured in Exchange Online but Disabled." }
        }
    }

    $s1 = Resolve-DnsCnameSafe -Name "selector1._domainkey.$Domain"
    $s2 = Resolve-DnsCnameSafe -Name "selector2._domainkey.$Domain"

    if ($s1 -and $s2) {
        return [PSCustomObject]@{ Status = "Pass"; Record = "selector1 -> $s1; selector2 -> $s2"; Notes = "Both M365 DKIM CNAME selectors resolved in DNS." }
    }
    elseif ($s1 -or $s2) {
        $found = if ($s1) { "selector1 ($s1)" } else { "selector2 ($s2)" }
        return [PSCustomObject]@{ Status = "Warning"; Record = $found; Notes = "Only one DKIM selector found. Publish both selector1 and selector2." }
    }
    else {
        return [PSCustomObject]@{ Status = "Fail"; Record = "Missing (selector1/selector2)"; Notes = "No M365 DKIM CNAME records found for selector1/selector2._domainkey.$Domain." }
    }
}

function Get-DmarcAudit {
    param([string]$Domain)
    $txtRecords   = @(Resolve-DnsTxtSafe -Name "_dmarc.$Domain")
    $dmarcRecords = @($txtRecords | Where-Object { $_ -match '^v=DMARC1\b' })

    if ($dmarcRecords.Count -eq 0) {
        return [PSCustomObject]@{ Status = "Fail"; Policy = "None (Missing)"; Record = "Missing"; Notes = "No DMARC record found at _dmarc.$Domain." }
    }

    $rec    = $dmarcRecords[0]
    $policy = if ($rec -match '(?i)\bp=(none|quarantine|reject)\b') { $Matches[1].ToLower() } else { "unknown" }
    $hasRua = $rec -match '(?i)\brua=mailto:'

    $status = "Fail"
    $notes  = @()
    switch ($policy) {
        "reject"     { $status = "Pass";    $notes += "Enforced policy (p=reject)." }
        "quarantine" { $status = "Pass";    $notes += "Quarantine policy (p=quarantine). Consider moving to p=reject." }
        "none"       { $status = "Warning"; $notes += "Monitoring-only policy (p=none). Does not block spoofed email." }
        default      { $status = "Fail";    $notes += "Invalid or missing DMARC p= tag." }
    }

    if (-not $hasRua) {
        if ($status -eq "Pass") { $status = "Warning" }
        $notes += "Missing aggregate reporting address (rua=mailto:...)."
    }

    return [PSCustomObject]@{ Status = $status; Policy = $policy; Record = $rec; Notes = ($notes -join " ") }
}
#endregion

#region Conditional Access Gap Analysis Engine (ISO 27001 Mapped)
function Invoke-ConditionalAccessGapAnalysis {
    param([array]$Policies)

    $enabledPolicies = @($Policies | Where-Object { $_.State -eq "enabled" })
    $reportOnlyCount = @($Policies | Where-Object { $_.State -eq "enabledForReportingButNotEnforced" }).Count
    $disabledCount   = @($Policies | Where-Object { $_.State -eq "disabled" }).Count

    $gaps = [System.Collections.Generic.List[object]]::new()

    function Test-PolicyMatch {
        param([scriptblock]$Predicate)
        foreach ($p in $enabledPolicies) {
            if (& $Predicate $p) { return $p.DisplayName }
        }
        return $null
    }

    $matchLegacy = Test-PolicyMatch { param($p) ($p.ClientAppTypes -match "exchangeActiveSync|other") -and ($p.GrantControls -match "block") }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-01"
        Iso27001Ref    = "A.8.5 / A.5.15"
        ControlName    = "Block Legacy Authentication"
        Severity       = "Critical"
        Status         = if ($matchLegacy) { "Pass" } else { "Fail" }
        MatchedPolicy  = if ($matchLegacy) { $matchLegacy } else { "None" }
        Recommendation = "Create an enabled CA policy targeting All Users & Client Apps (Exchange ActiveSync, Other clients) with Grant = Block."
    })

    $matchMfaAll = Test-PolicyMatch { param($p) ($p.IncludeUsers -match "All") -and ($p.GrantControls -match "mfa|AuthenticationStrength") }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-02"
        Iso27001Ref    = "A.8.5"
        ControlName    = "Require MFA for All Users"
        Severity       = "Critical"
        Status         = if ($matchMfaAll) { "Pass" } else { "Fail" }
        MatchedPolicy  = if ($matchMfaAll) { $matchMfaAll } else { "None" }
        Recommendation = "Enforce MFA (or Phishing-Resistant Authentication Strength) for All Users across All Cloud Apps (excluding break-glass accounts)."
    })

    $matchMfaAdmin = Test-PolicyMatch { param($p) (($p.IncludeRoles -ne "None" -and -not [string]::IsNullOrWhiteSpace($p.IncludeRoles)) -or ($p.DisplayName -match "(?i)admin|privileged")) -and ($p.GrantControls -match "mfa|AuthenticationStrength") }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-03"
        Iso27001Ref    = "A.8.2 / A.8.5"
        ControlName    = "Require Strong MFA for Administrators"
        Severity       = "Critical"
        Status         = if ($matchMfaAdmin) { "Pass" } else { "Fail" }
        MatchedPolicy  = if ($matchMfaAdmin) { $matchMfaAdmin } else { "None" }
        Recommendation = "Enforce Phishing-Resistant MFA (FIDO2 / WHfB / Passkey) for all privileged Entra ID directory roles."
    })

    $matchDevice = Test-PolicyMatch { param($p) $p.GrantControls -match "compliantDevice|domainJoinedDevice" }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-04"
        Iso27001Ref    = "A.8.1 / A.5.15"
        ControlName    = "Require Compliant or Hybrid Joined Device"
        Severity       = "High"
        Status         = if ($matchDevice) { "Pass" } else { "Warning" }
        MatchedPolicy  = if ($matchDevice) { $matchDevice } else { "None" }
        Recommendation = "Enforce Intune device compliance or Hybrid Entra ID join for corporate M365 access."
    })

    $matchSignInRisk = Test-PolicyMatch { param($p) ($p.SignInRiskLevels -ne "None" -and -not [string]::IsNullOrWhiteSpace($p.SignInRiskLevels)) -and ($p.GrantControls -match "mfa|block|AuthenticationStrength") }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-05"
        Iso27001Ref    = "A.8.16 / A.8.5"
        ControlName    = "Sign-In Risk Protection (Entra ID P2)"
        Severity       = "High"
        Status         = if ($matchSignInRisk) { "Pass" } else { "Warning" }
        MatchedPolicy  = if ($matchSignInRisk) { $matchSignInRisk } else { "None" }
        Recommendation = "Require MFA or Block for Medium/High sign-in risk events (requires Entra ID P2)."
    })

    $matchUserRisk = Test-PolicyMatch { param($p) ($p.UserRiskLevels -ne "None" -and -not [string]::IsNullOrWhiteSpace($p.UserRiskLevels)) -and ($p.GrantControls -match "passwordChange|block") }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-06"
        Iso27001Ref    = "A.5.17 / A.8.16"
        ControlName    = "User Risk Protection (Compromised Credentials)"
        Severity       = "High"
        Status         = if ($matchUserRisk) { "Pass" } else { "Warning" }
        MatchedPolicy  = if ($matchUserRisk) { $matchUserRisk } else { "None" }
        Recommendation = "Require secure password change + MFA (or Block) for High-risk users."
    })

    $matchLocation = Test-PolicyMatch { param($p) ($p.Locations -ne "None" -and -not [string]::IsNullOrWhiteSpace($p.Locations)) -and ($p.GrantControls -match "block|mfa") }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-07"
        Iso27001Ref    = "A.5.15"
        ControlName    = "Location-Based Access Controls (Named Locations)"
        Severity       = "Medium"
        Status         = if ($matchLocation) { "Pass" } else { "Warning" }
        MatchedPolicy  = if ($matchLocation) { $matchLocation } else { "None" }
        Recommendation = "Block sign-ins from unauthorized countries/regions using Entra ID Named Locations."
    })

    $staleStatus = if ($reportOnlyCount -eq 0 -and $disabledCount -eq 0) { "Pass" } else { "Warning" }
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-08"
        Iso27001Ref    = "A.5.18"
        ControlName    = "Policy Hygiene (Report-Only / Disabled Policies)"
        Severity       = "Low"
        Status         = $staleStatus
        MatchedPolicy  = "Report-Only: $reportOnlyCount | Disabled: $disabledCount"
        Recommendation = "Review and promote validated Report-Only policies to Enabled; clean up obsolete Disabled policies."
    })

    $hasExclusions = @($enabledPolicies | Where-Object { $_.ExcludeUsers -ne "None" -or $_.ExcludeGroups -ne "None" }).Count -gt 0
    $gaps.Add([PSCustomObject]@{
        ControlId      = "CA-09"
        Iso27001Ref    = "A.5.30"
        ControlName    = "Break-Glass / Emergency Access Exclusions"
        Severity       = "High"
        Status         = if ($hasExclusions) { "Pass" } else { "Warning" }
        MatchedPolicy  = if ($hasExclusions) { "Exclusions detected on enabled policies" } else { "No exclusions detected" }
        Recommendation = "Ensure at least two cloud-only emergency access (break-glass) accounts are excluded from CA policies to prevent tenant lockout."
    })

    return $gaps
}
#endregion

#region Demo Data Generator
function Get-DemoAuditData {
    Write-Step "Running in DEMO MODE (generating realistic enterprise M365 & Entra ID dataset)..."

    $tenantInfo = [PSCustomObject]@{
        TenantName    = "Contoso Global Holdings (Demo Tenant)"
        TenantId      = "8a4f2c19-7b3d-4e91-a210-9c5e71d0f4ab"
        PrimaryDomain = "contoso-demo.com"
        AuditMode     = "Demo Simulation"
    }

    $mfaUsers = @(
        [PSCustomObject]@{ DisplayName="Sarah Jenkins"; UserPrincipalName="s.jenkins@contoso-demo.com"; AccountEnabled=$true; IsAdmin=$true;  IsMfaRegistered=$true;  IsSsprRegistered=$true;  Methods="fido2, microsoftAuthenticatorPush"; Strength="Phishing-Resistant"; Status="Pass" },
        [PSCustomObject]@{ DisplayName="David Chen";    UserPrincipalName="d.chen@contoso-demo.com";    AccountEnabled=$true; IsAdmin=$true;  IsMfaRegistered=$true;  IsSsprRegistered=$true;  Methods="microsoftAuthenticatorPush, softwareOneTimePasscode"; Strength="Strong"; Status="Pass" },
        [PSCustomObject]@{ DisplayName="Legacy Admin";  UserPrincipalName="svc.admin@contoso-demo.com"; AccountEnabled=$true; IsAdmin=$true;  IsMfaRegistered=$false; IsSsprRegistered=$false; Methods="None"; Strength="None"; Status="Fail" },
        [PSCustomObject]@{ DisplayName="Maria Garcia";  UserPrincipalName="m.garcia@contoso-demo.com";  AccountEnabled=$true; IsAdmin=$false; IsMfaRegistered=$true;  IsSsprRegistered=$true;  Methods="microsoftAuthenticatorPush"; Strength="Strong"; Status="Pass" },
        [PSCustomObject]@{ DisplayName="James Wilson";  UserPrincipalName="j.wilson@contoso-demo.com";  AccountEnabled=$true; IsAdmin=$false; IsMfaRegistered=$true;  IsSsprRegistered=$false; Methods="mobilePhone"; Strength="Weak (SMS/Voice)"; Status="Warning" },
        [PSCustomObject]@{ DisplayName="Amina Rahman";  UserPrincipalName="a.rahman@contoso-demo.com";  AccountEnabled=$true; IsAdmin=$true;  IsMfaRegistered=$true;  IsSsprRegistered=$true;  Methods="windowsHelloForBusiness, microsoftAuthenticatorPush"; Strength="Phishing-Resistant"; Status="Pass" },
        [PSCustomObject]@{ DisplayName="Robert Taylor"; UserPrincipalName="r.taylor@contoso-demo.com";  AccountEnabled=$true; IsAdmin=$false; IsMfaRegistered=$false; IsSsprRegistered=$false; Methods="None"; Strength="None"; Status="Fail" },
        [PSCustomObject]@{ DisplayName="Priya Patel";   UserPrincipalName="p.patel@contoso-demo.com";   AccountEnabled=$true; IsAdmin=$false; IsMfaRegistered=$true;  IsSsprRegistered=$true;  Methods="microsoftAuthenticatorPush"; Strength="Strong"; Status="Pass" },
        [PSCustomObject]@{ DisplayName="Liam O'Connor"; UserPrincipalName="l.oconnor@contoso-demo.com"; AccountEnabled=$true; IsAdmin=$false; IsMfaRegistered=$true;  IsSsprRegistered=$true;  Methods="mobilePhone"; Strength="Weak (SMS/Voice)"; Status="Warning" },
        [PSCustomObject]@{ DisplayName="Chloe Martin";  UserPrincipalName="c.martin@contoso-demo.com";  AccountEnabled=$true; IsAdmin=$false; IsMfaRegistered=$true;  IsSsprRegistered=$true;  Methods="passKeyDeviceBound, microsoftAuthenticatorPush"; Strength="Phishing-Resistant"; Status="Pass" }
    )

    $caPolicies = @(
        [PSCustomObject]@{ DisplayName="CA001 - Block Legacy Authentication"; State="enabled"; IncludeUsers="All"; ExcludeUsers="bg-admin-01"; ExcludeGroups="None"; IncludeRoles="None"; ClientAppTypes="exchangeActiveSync, other"; GrantControls="block"; SignInRiskLevels="None"; UserRiskLevels="None"; Locations="None" },
        [PSCustomObject]@{ DisplayName="CA002 - Require MFA for All Users"; State="enabled"; IncludeUsers="All"; ExcludeUsers="bg-admin-01"; ExcludeGroups="SG-BreakGlass"; IncludeRoles="None"; ClientAppTypes="all"; GrantControls="mfa"; SignInRiskLevels="None"; UserRiskLevels="None"; Locations="None" },
        [PSCustomObject]@{ DisplayName="CA003 - Phishing-Resistant MFA for Admins"; State="enabled"; IncludeUsers="None"; ExcludeUsers="bg-admin-01"; ExcludeGroups="None"; IncludeRoles="Global Administrator, Security Administrator, Exchange Administrator"; ClientAppTypes="all"; GrantControls="AuthenticationStrength"; SignInRiskLevels="None"; UserRiskLevels="None"; Locations="None" },
        [PSCustomObject]@{ DisplayName="CA004 - Require Compliant Device for M365"; State="enabledForReportingButNotEnforced"; IncludeUsers="All"; ExcludeUsers="None"; ExcludeGroups="SG-BreakGlass"; IncludeRoles="None"; ClientAppTypes="browser, mobileAppsAndDesktopClients"; GrantControls="compliantDevice"; SignInRiskLevels="None"; UserRiskLevels="None"; Locations="None" },
        [PSCustomObject]@{ DisplayName="CA005 - Block High-Risk Sign-Ins"; State="enabled"; IncludeUsers="All"; ExcludeUsers="None"; ExcludeGroups="SG-BreakGlass"; IncludeRoles="None"; ClientAppTypes="all"; GrantControls="block"; SignInRiskLevels="high"; UserRiskLevels="None"; Locations="None" },
        [PSCustomObject]@{ DisplayName="CA006 - Block Unauthorized Countries"; State="disabled"; IncludeUsers="All"; ExcludeUsers="None"; ExcludeGroups="SG-BreakGlass"; IncludeRoles="None"; ClientAppTypes="all"; GrantControls="block"; SignInRiskLevels="None"; UserRiskLevels="None"; Locations="Blocked-Countries" }
    )

    $pimRoles = @(
        [PSCustomObject]@{ RoleName="Global Administrator";   PrincipalName="Sarah Jenkins"; PrincipalUPN="s.jenkins@contoso-demo.com"; AssignmentType="Eligible (PIM JIT)"; MfaRegistered=$true;  RiskLevel="Low";      Notes="Properly managed via PIM Eligible assignment." },
        [PSCustomObject]@{ RoleName="Global Administrator";   PrincipalName="Legacy Admin";  PrincipalUPN="svc.admin@contoso-demo.com"; AssignmentType="Active (Permanent)"; MfaRegistered=$false; RiskLevel="Critical"; Notes="Standing Global Admin without MFA!" },
        [PSCustomObject]@{ RoleName="Global Administrator";   PrincipalName="BreakGlass-01"; PrincipalUPN="bg01@contoso-demo.onmicrosoft.com"; AssignmentType="Active (Permanent)"; MfaRegistered=$true; RiskLevel="Medium"; Notes="Verify this is a monitored break-glass account." },
        [PSCustomObject]@{ RoleName="Security Administrator"; PrincipalName="Amina Rahman";  PrincipalUPN="a.rahman@contoso-demo.com";  AssignmentType="Eligible (PIM JIT)"; MfaRegistered=$true;  RiskLevel="Low";      Notes="Properly managed via PIM Eligible assignment." },
        [PSCustomObject]@{ RoleName="Exchange Administrator"; PrincipalName="David Chen";    PrincipalUPN="d.chen@contoso-demo.com";    AssignmentType="Active (Permanent)"; MfaRegistered=$true;  RiskLevel="Medium";   Notes="Convert standing assignment to PIM Eligible." },
        [PSCustomObject]@{ RoleName="Intune Administrator";   PrincipalName="David Chen";    PrincipalUPN="d.chen@contoso-demo.com";    AssignmentType="Eligible (PIM JIT)"; MfaRegistered=$true;  RiskLevel="Low";      Notes="Properly managed via PIM Eligible assignment." }
    )

    $mailAuth = @(
        [PSCustomObject]@{
            Domain="contoso-demo.com"
            SpfStatus="Pass";    SpfRecord="v=spf1 include:spf.protection.outlook.com -all"; SpfLookups=1; SpfNotes="Hardfail (-all) configured. Estimated top-level DNS lookups: 1/10."
            DkimStatus="Pass";   DkimRecord="EXO DKIM Enabled (Selector1/Selector2)"; DkimNotes="Active in Exchange Online."
            DmarcStatus="Pass";  DmarcPolicy="reject"; DmarcRecord="v=DMARC1; p=reject; rua=mailto:dmarc@contoso-demo.com"; DmarcNotes="Enforced policy (p=reject)."
            OverallStatus="Pass"
        },
        [PSCustomObject]@{
            Domain="mail.contoso-demo.com"
            SpfStatus="Warning"; SpfRecord="v=spf1 include:spf.protection.outlook.com ~all"; SpfLookups=1; SpfNotes="Uses ~all (softfail). Harden to -all."
            DkimStatus="Fail";   DkimRecord="Missing (selector1/selector2)"; DkimNotes="No M365 DKIM CNAME records found."
            DmarcStatus="Warning"; DmarcPolicy="none"; DmarcRecord="v=DMARC1; p=none; rua=mailto:dmarc@contoso-demo.com"; DmarcNotes="Monitoring-only policy (p=none)."
            OverallStatus="Fail"
        }
    )

    return @{ TenantInfo = $tenantInfo; MfaUsers = $mfaUsers; CaPolicies = $caPolicies; PimRoles = $pimRoles; MailAuth = $mailAuth }
}
#endregion

#region Live Tenant Collectors
function Invoke-LiveTenantAudit {
    param([string[]]$CustomDomains, [switch]$SkipExo, [switch]$IncludeDisabled)

    $requiredModules = @(
        "Microsoft.Graph.Authentication",
        "Microsoft.Graph.Users",
        "Microsoft.Graph.Reports",
        "Microsoft.Graph.Identity.SignIns",
        "Microsoft.Graph.Identity.DirectoryManagement",
        "Microsoft.Graph.Identity.Governance"
    )

    Write-Step "Checking required Microsoft Graph PowerShell modules..."
    $missing = @($requiredModules | Where-Object { -not (Get-Module -ListAvailable -Name $_) })
    if ($missing.Count -gt 0) {
        Write-Fail "Missing Microsoft Graph modules: $($missing -join ', ')"
        Write-Warn "Run .\Install-Prerequisites.ps1 first, or run with -DemoMode to preview."
        throw "Required Microsoft Graph modules are not installed."
    }
    Write-Ok "All required Microsoft Graph modules found."

    $ctx = Get-MgContext
    $connectedByScript = $false
    if (-not $ctx) {
        $scopes = @(
            "Directory.Read.All",
            "User.Read.All",
            "UserAuthenticationMethod.Read.All",
            "AuditLog.Read.All",
            "Policy.Read.All",
            "RoleManagement.Read.Directory",
            "Domain.Read.All"
        )
        Write-Step "Connecting to Microsoft Graph (Read-Only Scopes)..."
        Connect-MgGraph -Scopes $scopes -NoWelcome
        $ctx = Get-MgContext
        $connectedByScript = $true
    }
    else {
        Write-Ok "Reusing active Microsoft Graph session ($($ctx.Account) | Scopes: $($ctx.Scopes -join ', '))"
    }

    $org = $null
    try { $org = Get-MgOrganization | Select-Object -First 1 } catch { }
    $verifiedDomains = @()
    try { $verifiedDomains = @(Get-MgDomain | Where-Object { $_.IsVerified -eq $true }) } catch { }
    $primaryDomain = ($verifiedDomains | Where-Object { $_.IsDefault -eq $true } | Select-Object -First 1).Id
    if (-not $primaryDomain -and $verifiedDomains.Count -gt 0) { $primaryDomain = ($verifiedDomains | Select-Object -First 1).Id }

    $tenantInfo = [PSCustomObject]@{
        TenantName    = if ($org) { $org.DisplayName } else { "Microsoft 365 Tenant" }
        TenantId      = $ctx.TenantId
        PrimaryDomain = if ($primaryDomain) { $primaryDomain } else { "Unknown" }
        AuditMode     = "Live Tenant Audit"
    }
    Write-Ok "Auditing tenant: $($tenantInfo.TenantName) ($($tenantInfo.TenantId))"

    # 1. MFA Coverage & Auth Methods
    Write-Step "Auditing Entra ID MFA coverage & authentication methods..."
    $allUsers = @(Get-MgUser -All -Property Id, DisplayName, UserPrincipalName, AccountEnabled, UserType)
    $userMap = @{}
    foreach ($u in $allUsers) { if ($u.UserPrincipalName) { $userMap[$u.UserPrincipalName.ToLower()] = $u } }

    $regDetails = @()
    try {
        $regDetails = @(Get-MgReportAuthenticationMethodUserRegistrationDetail -All)
    }
    catch {
        Write-Warn "MFA Registration Detail report skipped (requires AuditLog.Read.All / UserAuthenticationMethod.Read.All): $($_.Exception.Message)"
    }

    $mfaUsers = [System.Collections.Generic.List[object]]::new()
    foreach ($r in $regDetails) {
        $upnKey  = if ($r.UserPrincipalName) { $r.UserPrincipalName.ToLower() } else { "" }
        $uObj    = if ($userMap.ContainsKey($upnKey)) { $userMap[$upnKey] } else { $null }
        $enabled = if ($uObj) { [bool]$uObj.AccountEnabled } else { $true }
        if (-not $IncludeDisabled -and -not $enabled) { continue }
        if ($uObj -and $uObj.UserType -eq "Guest") { continue }

        $methodsArr = @($r.MethodsRegistered)
        $methodsStr = if ($methodsArr.Count -gt 0) { $methodsArr -join ", " } else { "None" }

        $strength = "None"
        $status   = "Fail"
        if ($r.IsMfaRegistered) {
            if ($methodsStr -match "fido2|windowsHelloForBusiness|passKey|x509Certificate") {
                $strength = "Phishing-Resistant"; $status = "Pass"
            }
            elseif ($methodsStr -match "microsoftAuthenticator|softwareOneTimePasscode|hardwareOneTimePasscode") {
                $strength = "Strong"; $status = "Pass"
            }
            else {
                $strength = "Weak (SMS/Voice)"; $status = "Warning"
            }
        }

        $mfaUsers.Add([PSCustomObject]@{
            DisplayName       = $r.UserDisplayName
            UserPrincipalName = $r.UserPrincipalName
            AccountEnabled    = $enabled
            IsAdmin           = [bool]$r.IsAdmin
            IsMfaRegistered   = [bool]$r.IsMfaRegistered
            IsSsprRegistered  = [bool]$r.IsSsprRegistered
            Methods           = $methodsStr
            Strength          = $strength
            Status            = $status
        })
    }
    Write-Ok "Audited $($mfaUsers.Count) member user accounts for MFA coverage."

    # 2. Conditional Access Policies
    Write-Step "Auditing Conditional Access policies & legacy auth blocking..."
    $caPolicies = [System.Collections.Generic.List[object]]::new()
    try {
        $rawPolicies = @(Get-MgIdentityConditionalAccessPolicy -All)
        foreach ($p in $rawPolicies) {
            $incUsers  = if ($p.Conditions.Users.IncludeUsers)  { ($p.Conditions.Users.IncludeUsers -join ", ") }  else { "None" }
            $excUsers  = if ($p.Conditions.Users.ExcludeUsers)  { ($p.Conditions.Users.ExcludeUsers -join ", ") }  else { "None" }
            $excGroups = if ($p.Conditions.Users.ExcludeGroups) { ($p.Conditions.Users.ExcludeGroups -join ", ") } else { "None" }
            $incRoles  = if ($p.Conditions.Users.IncludeRoles)  { ($p.Conditions.Users.IncludeRoles -join ", ") }  else { "None" }
            $clientApp = if ($p.Conditions.ClientAppTypes)      { ($p.Conditions.ClientAppTypes -join ", ") }      else { "all" }
            $sRisk     = if ($p.Conditions.SignInRiskLevels)    { ($p.Conditions.SignInRiskLevels -join ", ") }    else { "None" }
            $uRisk     = if ($p.Conditions.UserRiskLevels)      { ($p.Conditions.UserRiskLevels -join ", ") }      else { "None" }
            $locs      = if ($p.Conditions.Locations -and $p.Conditions.Locations.IncludeLocations) { ($p.Conditions.Locations.IncludeLocations -join ", ") } else { "None" }

            $grants = @()
            if ($p.GrantControls.BuiltInControls) { $grants += $p.GrantControls.BuiltInControls }
            if ($p.GrantControls.AuthenticationStrength -and $p.GrantControls.AuthenticationStrength.DisplayName) {
                $grants += "AuthenticationStrength:$($p.GrantControls.AuthenticationStrength.DisplayName)"
            }

            $caPolicies.Add([PSCustomObject]@{
                DisplayName      = $p.DisplayName
                State            = $p.State
                IncludeUsers     = $incUsers
                ExcludeUsers     = $excUsers
                ExcludeGroups    = $excGroups
                IncludeRoles     = $incRoles
                ClientAppTypes   = $clientApp
                GrantControls    = if ($grants.Count -gt 0) { $grants -join ", " } else { "None" }
                SignInRiskLevels = $sRisk
                UserRiskLevels   = $uRisk
                Locations        = $locs
            })
        }
        Write-Ok "Retrieved $($caPolicies.Count) Conditional Access policies."
    }
    catch {
        Write-Warn "Conditional Access query skipped (requires Policy.Read.All & Entra ID P1): $($_.Exception.Message)"
    }

    # 3. PIM & Standing Global Admin / Privileged Roles
    Write-Step "Auditing standing Global Admin accounts & PIM role assignments..."
    $mfaLookup = @{}
    foreach ($mu in $mfaUsers) { $mfaLookup[$mu.UserPrincipalName.ToLower()] = $mu.IsMfaRegistered }

    $pimRoles = [System.Collections.Generic.List[object]]::new()
    $dirRoles = @(Get-MgDirectoryRole -All)
    foreach ($role in $dirRoles) {
        $members = @(Get-MgDirectoryRoleMember -DirectoryRoleId $role.Id -All)
        foreach ($m in $members) {
            $props = $m.AdditionalProperties
            $upn   = if ($props.ContainsKey("userPrincipalName")) { $props["userPrincipalName"] } else { $m.Id }
            $name  = if ($props.ContainsKey("displayName"))       { $props["displayName"] }       else { $upn }
            $mfaOk = if ($upn -and $mfaLookup.ContainsKey($upn.ToLower())) { $mfaLookup[$upn.ToLower()] } else { $true }

            $risk  = "Medium"
            $notes = "Standing active role assignment. Convert to PIM Eligible."
            if (-not $mfaOk) {
                $risk = "Critical"; $notes = "Standing privileged role WITHOUT MFA registered!"
            }
            elseif ($role.DisplayName -eq "Global Administrator") {
                $risk = "High"; $notes = "Standing Global Administrator. Restrict to break-glass accounts only."
            }

            $pimRoles.Add([PSCustomObject]@{
                RoleName = $role.DisplayName; PrincipalName = $name; PrincipalUPN = $upn
                AssignmentType = "Active (Permanent)"; MfaRegistered = $mfaOk; RiskLevel = $risk; Notes = $notes
            })
        }
    }

    try {
        $roleDefs = @{}
        foreach ($rd in (Get-MgRoleManagementDirectoryRoleDefinition -All)) { $roleDefs[$rd.Id] = $rd.DisplayName }
        $eligibles = @(Get-MgRoleManagementDirectoryRoleEligibilitySchedule -All -ExpandProperty Principal)
        foreach ($el in $eligibles) {
            $rName  = if ($roleDefs.ContainsKey($el.RoleDefinitionId)) { $roleDefs[$el.RoleDefinitionId] } else { $el.RoleDefinitionId }
            $pProps = $el.Principal.AdditionalProperties
            $upn    = if ($pProps -and $pProps.ContainsKey("userPrincipalName")) { $pProps["userPrincipalName"] } else { $el.PrincipalId }
            $name   = if ($pProps -and $pProps.ContainsKey("displayName"))       { $pProps["displayName"] }       else { $upn }
            $mfaOk  = if ($upn -and $mfaLookup.ContainsKey($upn.ToLower()))      { $mfaLookup[$upn.ToLower()] }   else { $true }

            $pimRoles.Add([PSCustomObject]@{
                RoleName = $rName; PrincipalName = $name; PrincipalUPN = $upn
                AssignmentType = "Eligible (PIM JIT)"; MfaRegistered = $mfaOk
                RiskLevel = if ($mfaOk) { "Low" } else { "Critical" }
                Notes = if ($mfaOk) { "Managed via PIM Just-in-Time eligibility." } else { "PIM Eligible admin WITHOUT MFA registered!" }
            })
        }
    }
    catch {
        Write-Warn "PIM Eligibility query skipped (requires Entra ID P2 & RoleManagement.Read.Directory): $($_.Exception.Message)"
    }
    Write-Ok "Audited $($pimRoles.Count) privileged role assignments."

    # 4. Exchange Online Accepted Domains & SPF/DKIM/DMARC DNS Alignment
    Write-Step "Auditing Exchange Online accepted domains for SPF / DKIM / DMARC alignment..."
    $exoDkimLookup   = @{}
    $acceptedDomains = @()
    if (-not $SkipExo) {
        if (Get-Module -ListAvailable -Name ExchangeOnlineManagement) {
            try {
                Write-Step "Connecting to Exchange Online PowerShell (Read-Only Accepted Domains & DKIM)..."
                Connect-ExchangeOnline -ShowBanner:$false
                $acceptedDomains = @(Get-AcceptedDomain | Where-Object { $_.DomainName -notmatch '\.onmicrosoft\.com$' } | ForEach-Object { $_.DomainName })
                foreach ($dk in (Get-DkimSigningConfig)) { $exoDkimLookup[$dk.Domain.ToLower()] = $dk }
                Write-Ok "Retrieved $($acceptedDomains.Count) accepted domain(s) and DKIM configs from Exchange Online."
                Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue
            }
            catch {
                Write-Warn "Exchange Online connection skipped/failed. Falling back to Entra ID domains + DNS DKIM. ($($_.Exception.Message))"
            }
        }
        else {
            Write-Warn "ExchangeOnlineManagement module not installed. Falling back to Entra ID domains + DNS DKIM."
        }
    }

    $targetDomains = if ($CustomDomains -and $CustomDomains.Count -gt 0) {
        $CustomDomains
    }
    elseif ($acceptedDomains.Count -gt 0) {
        $acceptedDomains
    }
    else {
        @($verifiedDomains | Where-Object { $_.Id -notmatch '\.onmicrosoft\.com$' } | ForEach-Object { $_.Id })
    }
    if ($targetDomains.Count -eq 0 -and $primaryDomain) { $targetDomains = @($primaryDomain) }

    $mailAuth = [System.Collections.Generic.List[object]]::new()
    foreach ($dom in $targetDomains) {
        $spf   = Get-SpfAudit   -Domain $dom
        $dkim  = Get-DkimAudit  -Domain $dom -ExoDkimLookup $exoDkimLookup
        $dmarc = Get-DmarcAudit -Domain $dom

        $overall = "Pass"
        if ($spf.Status -eq "Fail" -or $dkim.Status -eq "Fail" -or $dmarc.Status -eq "Fail") { $overall = "Fail" }
        elseif ($spf.Status -eq "Warning" -or $dkim.Status -eq "Warning" -or $dmarc.Status -eq "Warning") { $overall = "Warning" }

        $mailAuth.Add([PSCustomObject]@{
            Domain = $dom
            SpfStatus = $spf.Status; SpfRecord = $spf.Record; SpfLookups = $spf.Lookups; SpfNotes = $spf.Notes
            DkimStatus = $dkim.Status; DkimRecord = $dkim.Record; DkimNotes = $dkim.Notes
            DmarcStatus = $dmarc.Status; DmarcPolicy = $dmarc.Policy; DmarcRecord = $dmarc.Record; DmarcNotes = $dmarc.Notes
            OverallStatus = $overall
        })
    }
    Write-Ok "Audited mail authentication for $($mailAuth.Count) domain(s)."

    if ($connectedByScript) {
        Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
    }

    return @{ TenantInfo = $tenantInfo; MfaUsers = $mfaUsers; CaPolicies = $caPolicies; PimRoles = $pimRoles; MailAuth = $mailAuth }
}
#endregion

#region Scoring & ISO 27001 Evidence Engine
function Build-SecurityScorecard {
    param([array]$MfaUsers, [array]$CaGaps, [array]$PimRoles, [array]$MailAuth)

    $totalUsers     = $MfaUsers.Count
    $mfaRegistered  = @($MfaUsers | Where-Object { $_.IsMfaRegistered }).Count
    $mfaCoveragePct = if ($totalUsers -gt 0) { [math]::Round(($mfaRegistered / $totalUsers) * 100, 1) } else { 0 }
    $adminsNoMfa    = @($MfaUsers | Where-Object { $_.IsAdmin -and -not $_.IsMfaRegistered }).Count
    $weakMfaCount   = @($MfaUsers | Where-Object { $_.Strength -match "Weak" }).Count
    $phishResCount  = @($MfaUsers | Where-Object { $_.Strength -eq "Phishing-Resistant" }).Count

    $mfaPillarPct = $mfaCoveragePct
    if ($adminsNoMfa -gt 0) { $mfaPillarPct = [math]::Max(0, $mfaPillarPct - 25) }
    $mfaScore = [math]::Round(($mfaPillarPct / 100) * 30, 1)

    $caTotal     = $CaGaps.Count
    $caPass      = @($CaGaps | Where-Object { $_.Status -eq "Pass" }).Count
    $caWarn      = @($CaGaps | Where-Object { $_.Status -eq "Warning" }).Count
    $caPillarPct = if ($caTotal -gt 0) { [math]::Round((($caPass + ($caWarn * 0.4)) / $caTotal) * 100, 1) } else { 0 }
    $caScore     = [math]::Round(($caPillarPct / 100) * 30, 1)

    $globalAdmins    = @($PimRoles | Where-Object { $_.RoleName -eq "Global Administrator" })
    $permGlobalAdmin = @($globalAdmins | Where-Object { $_.AssignmentType -match "Active" }).Count
    $totalRoles      = $PimRoles.Count
    $eligibleRoles   = @($PimRoles | Where-Object { $_.AssignmentType -match "Eligible" }).Count
    $pimCritical     = @($PimRoles | Where-Object { $_.RiskLevel -eq "Critical" }).Count

    $pimPillarPct = if ($totalRoles -gt 0) { [math]::Round(($eligibleRoles / $totalRoles) * 100, 1) } else { 100 }
    if ($pimCritical -gt 0) { $pimPillarPct = [math]::Max(0, $pimPillarPct - 30) }
    if ($globalAdmins.Count -gt 5) { $pimPillarPct = [math]::Max(0, $pimPillarPct - 15) }
    $pimScore = [math]::Round(($pimPillarPct / 100) * 20, 1)

    $mailChecksTotal = $MailAuth.Count * 3
    $mailPoints = 0
    foreach ($m in $MailAuth) {
        foreach ($st in @($m.SpfStatus, $m.DkimStatus, $m.DmarcStatus)) {
            if ($st -eq "Pass") { $mailPoints += 1 }
            elseif ($st -eq "Warning") { $mailPoints += 0.5 }
        }
    }
    $mailPillarPct = if ($mailChecksTotal -gt 0) { [math]::Round(($mailPoints / $mailChecksTotal) * 100, 1) } else { 0 }
    $mailScore     = [math]::Round(($mailPillarPct / 100) * 20, 1)

    $overallScore = [math]::Min(100, [math]::Round($mfaScore + $caScore + $pimScore + $mailScore, 0))
    $grade = switch ($overallScore) {
        { $_ -ge 90 } { "A"; break }
        { $_ -ge 80 } { "B"; break }
        { $_ -ge 70 } { "C"; break }
        { $_ -ge 60 } { "D"; break }
        default       { "F" }
    }

    # ISO 27001:2022 Mapped Compliance Checklist
    $checklist = [System.Collections.Generic.List[object]]::new()

    $checklist.Add([PSCustomObject]@{
        Iso27001Control = "A.8.5 (Secure Authentication)"
        Pillar          = "MFA & Identity"
        Check           = "Overall MFA Registration Coverage"
        Status          = if ($mfaCoveragePct -ge 95) { "Pass" } elseif ($mfaCoveragePct -ge 80) { "Warning" } else { "Fail" }
        Severity        = "Critical"
        Detail          = "$mfaRegistered of $totalUsers users registered ($mfaCoveragePct%). Phishing-resistant: $phishResCount, Weak SMS/Voice: $weakMfaCount."
        Recommendation  = "Enforce MFA registration campaign and migrate SMS/Voice users to Microsoft Authenticator or FIDO2."
    })

    $checklist.Add([PSCustomObject]@{
        Iso27001Control = "A.8.2 / A.8.5 (Privileged Auth)"
        Pillar          = "MFA & Identity"
        Check           = "Privileged Admins Protected by MFA"
        Status          = if ($adminsNoMfa -eq 0) { "Pass" } else { "Fail" }
        Severity        = "Critical"
        Detail          = if ($adminsNoMfa -eq 0) { "All audited admin accounts have MFA registered." } else { "$adminsNoMfa admin account(s) have NO MFA registered!" }
        Recommendation  = "Immediately enroll all admin accounts in phishing-resistant MFA."
    })

    foreach ($g in $CaGaps) {
        $checklist.Add([PSCustomObject]@{
            Iso27001Control = $g.Iso27001Ref
            Pillar          = "Conditional Access"
            Check           = "$($g.ControlId): $($g.ControlName)"
            Status          = $g.Status
            Severity        = $g.Severity
            Detail          = "Matched: $($g.MatchedPolicy)"
            Recommendation  = $g.Recommendation
        })
    }

    $checklist.Add([PSCustomObject]@{
        Iso27001Control = "A.8.2 (Privileged Access Rights)"
        Pillar          = "PIM & Roles"
        Check           = "Standing Global Administrator Hygiene"
        Status          = if ($globalAdmins.Count -ge 2 -and $globalAdmins.Count -le 5 -and $permGlobalAdmin -le 2) { "Pass" } elseif ($globalAdmins.Count -le 5) { "Warning" } else { "Fail" }
        Severity        = "High"
        Detail          = "Total Global Admins: $($globalAdmins.Count) (Standing/Permanent: $permGlobalAdmin). Recommended: 2-4 total, max 2 permanent break-glass."
        Recommendation  = "Reduce standing Global Administrators and enforce Just-in-Time activation via Entra ID PIM."
    })

    $checklist.Add([PSCustomObject]@{
        Iso27001Control = "A.8.2 / A.5.18 (Access Rights)"
        Pillar          = "PIM & Roles"
        Check           = "PIM Just-in-Time (Eligible vs Standing)"
        Status          = if ($pimPillarPct -ge 80 -and $pimCritical -eq 0) { "Pass" } elseif ($pimCritical -eq 0) { "Warning" } else { "Fail" }
        Severity        = "High"
        Detail          = "$eligibleRoles of $totalRoles privileged role assignments are PIM Eligible ($pimPillarPct%). Critical findings: $pimCritical."
        Recommendation  = "Convert standing privileged roles to PIM Eligible with approval workflow and MFA activation."
    })

    foreach ($m in $MailAuth) {
        $checklist.Add([PSCustomObject]@{
            Iso27001Control = "A.8.20 / A.5.14 (Info Transfer)"
            Pillar          = "Exchange Mail Auth"
            Check           = "SPF / DKIM / DMARC Alignment — $($m.Domain)"
            Status          = $m.OverallStatus
            Severity        = if ($m.OverallStatus -eq "Fail") { "High" } else { "Medium" }
            Detail          = "SPF: $($m.SpfStatus) | DKIM: $($m.DkimStatus) | DMARC: $($m.DmarcStatus) (p=$($m.DmarcPolicy))"
            Recommendation  = "Ensure SPF uses -all (<=10 lookups), Exchange Online DKIM is enabled, and DMARC enforces p=quarantine or p=reject with rua=."
        })
    }

    return [PSCustomObject]@{
        OverallScore = $overallScore; Grade = $grade
        MfaCoveragePct = $mfaCoveragePct; MfaPillarPct = $mfaPillarPct
        CaPillarPct = $caPillarPct; PimPillarPct = $pimPillarPct; MailPillarPct = $mailPillarPct
        TotalUsers = $totalUsers; MfaRegistered = $mfaRegistered; AdminsNoMfa = $adminsNoMfa
        GlobalAdminCnt = $globalAdmins.Count; EligibleRoles = $eligibleRoles; TotalRoles = $totalRoles
        Checklist = $checklist
    }
}
#endregion

#region HTML Report Generator
function Export-EspaHtmlReport {
    param(
        [string]$FilePath, [PSCustomObject]$TenantInfo, [PSCustomObject]$Scorecard,
        [array]$MfaUsers, [array]$CaPolicies, [array]$CaGaps, [array]$PimRoles, [array]$MailAuth
    )

    function Get-BadgeHtml {
        param([string]$Status)
        switch -Regex ($Status) {
            '^(Pass|Low|enabled)$'   { return "<span class='badge badge-pass'>$(ConvertTo-HtmlSafe $Status)</span>" }
            '^(Warning|Medium|enabledForReportingButNotEnforced)$' { return "<span class='badge badge-warn'>$(ConvertTo-HtmlSafe $Status)</span>" }
            '^(Fail|Critical|High|disabled)$' { return "<span class='badge badge-fail'>$(ConvertTo-HtmlSafe $Status)</span>" }
            default { return "<span class='badge badge-neutral'>$(ConvertTo-HtmlSafe $Status)</span>" }
        }
    }

    $scoreColor = if ($Scorecard.OverallScore -ge 80) { "#10b981" } elseif ($Scorecard.OverallScore -ge 60) { "#f59e0b" } else { "#ef4444" }

    $checklistRows = ($Scorecard.Checklist | ForEach-Object {
        "<tr><td><code>$(ConvertTo-HtmlSafe $_.Iso27001Control)</code></td><td><strong>$(ConvertTo-HtmlSafe $_.Pillar)</strong></td><td>$(ConvertTo-HtmlSafe $_.Check)</td><td>$(Get-BadgeHtml $_.Severity)</td><td>$(Get-BadgeHtml $_.Status)</td><td>$(ConvertTo-HtmlSafe $_.Detail)</td><td>$(ConvertTo-HtmlSafe $_.Recommendation)</td></tr>"
    }) -join "`n"

    $mfaRows = ($MfaUsers | Sort-Object @{Expression={$_.Status -eq 'Fail'}; Descending=$true}, IsAdmin -Descending | ForEach-Object {
        $adminTag = if ($_.IsAdmin) { "<span class='badge badge-admin'>Admin</span>" } else { "Member" }
        $mfaTag   = if ($_.IsMfaRegistered) { "Yes" } else { "<strong style='color:#ef4444'>No</strong>" }
        "<tr><td>$(ConvertTo-HtmlSafe $_.DisplayName)</td><td>$(ConvertTo-HtmlSafe $_.UserPrincipalName)</td><td>$adminTag</td><td>$mfaTag</td><td>$(ConvertTo-HtmlSafe $_.Strength)</td><td>$(ConvertTo-HtmlSafe $_.Methods)</td><td>$(Get-BadgeHtml $_.Status)</td></tr>"
    }) -join "`n"

    $caGapRows = ($CaGaps | ForEach-Object {
        "<tr><td><code>$(ConvertTo-HtmlSafe $_.ControlId)</code></td><td><code>$(ConvertTo-HtmlSafe $_.Iso27001Ref)</code></td><td><strong>$(ConvertTo-HtmlSafe $_.ControlName)</strong></td><td>$(Get-BadgeHtml $_.Severity)</td><td>$(Get-BadgeHtml $_.Status)</td><td>$(ConvertTo-HtmlSafe $_.MatchedPolicy)</td><td>$(ConvertTo-HtmlSafe $_.Recommendation)</td></tr>"
    }) -join "`n"

    $caPolicyRows = ($CaPolicies | ForEach-Object {
        "<tr><td><strong>$(ConvertTo-HtmlSafe $_.DisplayName)</strong></td><td>$(Get-BadgeHtml $_.State)</td><td>$(ConvertTo-HtmlSafe $_.IncludeUsers)</td><td>$(ConvertTo-HtmlSafe $_.ClientAppTypes)</td><td>$(ConvertTo-HtmlSafe $_.GrantControls)</td></tr>"
    }) -join "`n"

    $pimRows = ($PimRoles | ForEach-Object {
        $mfaTxt = if ($_.MfaRegistered) { "Yes" } else { "<strong style='color:#ef4444'>NO</strong>" }
        "<tr><td><strong>$(ConvertTo-HtmlSafe $_.RoleName)</strong></td><td>$(ConvertTo-HtmlSafe $_.PrincipalName)</td><td>$(ConvertTo-HtmlSafe $_.PrincipalUPN)</td><td>$(ConvertTo-HtmlSafe $_.AssignmentType)</td><td>$mfaTxt</td><td>$(Get-BadgeHtml $_.RiskLevel)</td><td>$(ConvertTo-HtmlSafe $_.Notes)</td></tr>"
    }) -join "`n"

    $mailRows = ($MailAuth | ForEach-Object {
        "<tr><td><strong>$(ConvertTo-HtmlSafe $_.Domain)</strong></td><td>$(Get-BadgeHtml $_.SpfStatus)<div class='sub-note'>$(ConvertTo-HtmlSafe $_.SpfNotes)</div></td><td>$(Get-BadgeHtml $_.DkimStatus)<div class='sub-note'>$(ConvertTo-HtmlSafe $_.DkimNotes)</div></td><td>$(Get-BadgeHtml $_.DmarcStatus)<div class='sub-note'>p=$(ConvertTo-HtmlSafe $_.DmarcPolicy) — $(ConvertTo-HtmlSafe $_.DmarcNotes)</div></td><td>$(Get-BadgeHtml $_.OverallStatus)</td></tr>"
    }) -join "`n"

    $html = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>$ToolName — ISO 27001 Security Posture Report ($(ConvertTo-HtmlSafe $TenantInfo.TenantName))</title>
<style>
  :root { --bg:#0b1120; --surface:#111827; --border:#334155; --text:#f1f5f9; --muted:#94a3b8; --accent:#38bdf8; }
  * { box-sizing:border-box; }
  body { margin:0; font-family:'Segoe UI',system-ui,-apple-system,sans-serif; background:var(--bg); color:var(--text); line-height:1.5; }
  .container { max-width:1380px; margin:0 auto; padding:28px 24px 60px; }
  header { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:16px; padding:24px 28px; background:linear-gradient(135deg,#0f172a 0%,#1e293b 100%); border:1px solid var(--border); border-radius:16px; margin-bottom:24px; }
  .brand h1 { margin:0; font-size:1.65rem; color:#fff; }
  .brand p { margin:4px 0 0; color:var(--accent); font-size:0.92rem; font-weight:500; }
  .iso-pill { display:inline-block; margin-top:8px; padding:3px 10px; border-radius:99px; font-size:0.75rem; font-weight:600; background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.35); }
  .meta { text-align:right; font-size:0.85rem; color:var(--muted); }
  .meta strong { color:var(--text); }
  .kpi-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:16px; margin-bottom:24px; }
  .kpi-card { background:var(--surface); border:1px solid var(--border); border-radius:14px; padding:20px; }
  .kpi-label { font-size:0.78rem; text-transform:uppercase; letter-spacing:0.06em; color:var(--muted); }
  .kpi-value { font-size:2rem; font-weight:700; margin:6px 0 4px; color:#fff; }
  .kpi-sub { font-size:0.82rem; color:var(--muted); }
  .progress-bar { height:8px; background:#0f172a; border-radius:99px; overflow:hidden; margin-top:10px; }
  .progress-fill { height:100%; border-radius:99px; }
  section { background:var(--surface); border:1px solid var(--border); border-radius:14px; padding:22px 24px; margin-bottom:24px; }
  h2 { margin:0 0 14px; font-size:1.18rem; color:#fff; display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid var(--border); padding-bottom:10px; }
  .table-wrap { overflow-x:auto; }
  table { width:100%; border-collapse:collapse; font-size:0.85rem; }
  th { text-align:left; padding:10px 12px; background:#0f172a; color:var(--muted); font-weight:600; text-transform:uppercase; font-size:0.74rem; letter-spacing:0.04em; border-bottom:1px solid var(--border); }
  td { padding:10px 12px; border-bottom:1px solid rgba(51,65,85,0.55); vertical-align:top; }
  tr:hover td { background:rgba(56,189,248,0.04); }
  .badge { display:inline-block; padding:3px 9px; border-radius:99px; font-size:0.73rem; font-weight:600; text-transform:uppercase; white-space:nowrap; }
  .badge-pass { background:rgba(16,185,129,0.16); color:#34d399; border:1px solid rgba(16,185,129,0.35); }
  .badge-warn { background:rgba(245,158,11,0.16); color:#fbbf24; border:1px solid rgba(245,158,11,0.35); }
  .badge-fail { background:rgba(239,68,68,0.16); color:#f87171; border:1px solid rgba(239,68,68,0.35); }
  .badge-admin { background:rgba(56,189,248,0.16); color:#38bdf8; border:1px solid rgba(56,189,248,0.35); }
  .badge-neutral { background:rgba(148,163,184,0.16); color:#cbd5e1; }
  .sub-note { font-size:0.78rem; color:var(--muted); margin-top:4px; }
  .filter-input { background:#0f172a; border:1px solid var(--border); color:var(--text); padding:6px 12px; border-radius:8px; font-size:0.84rem; width:240px; }
  .btn-print { background:var(--accent); color:#0f172a; border:none; padding:8px 16px; border-radius:8px; font-weight:600; cursor:pointer; font-size:0.85rem; }
  footer { text-align:center; color:var(--muted); font-size:0.82rem; margin-top:32px; padding-top:18px; border-top:1px solid var(--border); }
  footer a { color:var(--accent); text-decoration:none; }
  @media print {
    body { background:#fff; color:#111; }
    header, section, .kpi-card { background:#fff; border-color:#cbd5e1; color:#111; }
    th { background:#f1f5f9; color:#111; }
    .btn-print, .filter-input { display:none; }
  }
</style>
</head>
<body>
<div class="container">
  <header>
    <div class="brand">
      <h1>$ToolName <span style="font-size:0.85rem;color:#94a3b8;font-weight:400;">v$ToolVersion</span></h1>
      <p>$ToolFull</p>
      <span class="iso-pill">ISO/IEC 27001:2022 Annex A Evidence Ready</span>
    </div>
    <div class="meta">
      <div>Tenant: <strong>$(ConvertTo-HtmlSafe $TenantInfo.TenantName)</strong></div>
      <div>Tenant ID: <code>$(ConvertTo-HtmlSafe $TenantInfo.TenantId)</code></div>
      <div>Generated: <strong>$($AuditDate.ToString("yyyy-MM-dd HH:mm:ss"))</strong> | Mode: <strong>$(ConvertTo-HtmlSafe $TenantInfo.AuditMode)</strong></div>
      <div style="margin-top:8px;"><button class="btn-print" onclick="window.print()">Print / Save ISO 27001 PDF</button></div>
    </div>
  </header>

  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-label">Overall ESPA Posture Score</div>
      <div class="kpi-value" style="color:$scoreColor">$($Scorecard.OverallScore)<span style="font-size:1.1rem;color:#94a3b8">/100 (Grade $($Scorecard.Grade))</span></div>
      <div class="kpi-sub">Weighted across MFA, CA, PIM &amp; Mail Auth</div>
      <div class="progress-bar"><div class="progress-fill" style="width:$($Scorecard.OverallScore)%;background:$scoreColor;"></div></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">MFA Registration Coverage</div>
      <div class="kpi-value">$($Scorecard.MfaCoveragePct)%</div>
      <div class="kpi-sub">$($Scorecard.MfaRegistered) / $($Scorecard.TotalUsers) users | Admins w/o MFA: <strong style="color:$(if($Scorecard.AdminsNoMfa -gt 0){'#f87171'}else{'#34d399'})">$($Scorecard.AdminsNoMfa)</strong></div>
      <div class="progress-bar"><div class="progress-fill" style="width:$($Scorecard.MfaCoveragePct)%;background:#38bdf8;"></div></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Conditional Access Readiness</div>
      <div class="kpi-value">$($Scorecard.CaPillarPct)%</div>
      <div class="kpi-sub">$($CaPolicies.Count) policies audited against 9 Zero Trust controls</div>
      <div class="progress-bar"><div class="progress-fill" style="width:$($Scorecard.CaPillarPct)%;background:#818cf8;"></div></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">PIM &amp; Standing Admin Hygiene</div>
      <div class="kpi-value">$($Scorecard.PimPillarPct)%</div>
      <div class="kpi-sub">PIM Eligible: $($Scorecard.EligibleRoles)/$($Scorecard.TotalRoles) | Global Admins: $($Scorecard.GlobalAdminCnt)</div>
      <div class="progress-bar"><div class="progress-fill" style="width:$($Scorecard.PimPillarPct)%;background:#f59e0b;"></div></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Exchange Mail Auth (SPF/DKIM/DMARC)</div>
      <div class="kpi-value">$($Scorecard.MailPillarPct)%</div>
      <div class="kpi-sub">$($MailAuth.Count) accepted domain(s) audited</div>
      <div class="progress-bar"><div class="progress-fill" style="width:$($Scorecard.MailPillarPct)%;background:#10b981;"></div></div>
    </div>
  </div>

  <section>
    <h2>1. Executive ISO 27001 Compliance Checklist &amp; Remediation Roadmap</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>ISO 27001:2022</th><th>Pillar</th><th>Control / Check</th><th>Severity</th><th>Status</th><th>Audit Finding</th><th>Recommended Action</th></tr></thead>
        <tbody>$checklistRows</tbody>
      </table>
    </div>
  </section>

  <section>
    <h2>2. Entra ID MFA Coverage &amp; Authentication Methods <input class="filter-input" type="text" placeholder="Filter users..." onkeyup="filterTable(this, 'tbl-mfa')"></h2>
    <div class="table-wrap">
      <table id="tbl-mfa">
        <thead><tr><th>Display Name</th><th>UPN</th><th>Role</th><th>MFA Registered</th><th>Auth Strength</th><th>Registered Methods</th><th>Status</th></tr></thead>
        <tbody>$mfaRows</tbody>
      </table>
    </div>
  </section>

  <section>
    <h2>3. Conditional Access &amp; Legacy Authentication Gap Analysis</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>ID</th><th>ISO 27001</th><th>Zero Trust Control</th><th>Severity</th><th>Status</th><th>Matched Policy</th><th>Remediation Guidance</th></tr></thead>
        <tbody>$caGapRows</tbody>
      </table>
    </div>
    <h3 style="margin-top:20px;font-size:0.98rem;color:#cbd5e1;">Conditional Access Policy Inventory</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Policy Name</th><th>State</th><th>Include Users</th><th>Client Apps</th><th>Grant Controls</th></tr></thead>
        <tbody>$caPolicyRows</tbody>
      </table>
    </div>
  </section>

  <section>
    <h2>4. PIM Roles &amp; Standing Global Administrator Accounts</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Role Name</th><th>Principal</th><th>UPN</th><th>Assignment Type</th><th>MFA</th><th>Risk</th><th>Assessment Notes</th></tr></thead>
        <tbody>$pimRows</tbody>
      </table>
    </div>
  </section>

  <section>
    <h2>5. Exchange Online Accepted Domains — SPF / DKIM / DMARC Alignment</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Accepted Domain</th><th>SPF Status</th><th>DKIM Status</th><th>DMARC Status</th><th>Overall</th></tr></thead>
        <tbody>$mailRows</tbody>
      </table>
    </div>
  </section>

  <footer>
    Generated by <strong>$ToolName (v$ToolVersion)</strong> — Created by <strong>$AuthorName</strong><br>
    Microsoft 365 &amp; Cloud Engineer | Microsoft Security Specialist |
    <a href="$AuthorSite" target="_blank">www.jobaeralam.com</a> |
    <a href="mailto:$AuthorEmail">$AuthorEmail</a>
  </footer>
</div>
<script>
function filterTable(input, tableId) {
  const q = input.value.toLowerCase();
  const rows = document.getElementById(tableId).querySelectorAll('tbody tr');
  rows.forEach(r => { r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none'; });
}
</script>
</body>
</html>
"@

    $html | Out-File -FilePath $FilePath -Encoding UTF8
}
#endregion

#region Main Execution
Show-Banner

try {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
    New-Item -ItemType Directory -Path $CsvFolder  -Force | Out-Null

    if ($DemoMode) {
        $auditData = Get-DemoAuditData
    }
    else {
        $auditData = Invoke-LiveTenantAudit -CustomDomains $Domains -SkipExo:$SkipExchangeOnline -IncludeDisabled:$IncludeDisabledUsers
    }

    Write-Step "Running Conditional Access & legacy authentication gap analysis..."
    $caGaps = @(Invoke-ConditionalAccessGapAnalysis -Policies $auditData.CaPolicies)

    Write-Step "Calculating M365 ESPA Posture Score & ISO 27001 evidence..."
    $scorecard = Build-SecurityScorecard `
        -MfaUsers $auditData.MfaUsers `
        -CaGaps   $caGaps `
        -PimRoles $auditData.PimRoles `
        -MailAuth $auditData.MailAuth

    Write-Step "Exporting ISO 27001 CSV evidence datasets to $CsvFolder..."
    $auditData.MfaUsers   | Export-Csv -Path (Join-Path $CsvFolder "01_MFA_Coverage_Users.csv")         -NoTypeInformation -Encoding UTF8
    $auditData.CaPolicies | Export-Csv -Path (Join-Path $CsvFolder "02_Conditional_Access_Policies.csv") -NoTypeInformation -Encoding UTF8
    $caGaps               | Export-Csv -Path (Join-Path $CsvFolder "03_Conditional_Access_Gaps.csv")     -NoTypeInformation -Encoding UTF8
    $auditData.PimRoles   | Export-Csv -Path (Join-Path $CsvFolder "04_PIM_Privileged_Roles.csv")        -NoTypeInformation -Encoding UTF8
    $auditData.MailAuth   | Export-Csv -Path (Join-Path $CsvFolder "05_Exchange_SPF_DKIM_DMARC.csv")     -NoTypeInformation -Encoding UTF8
    $scorecard.Checklist  | Export-Csv -Path (Join-Path $CsvFolder "06_ISO27001_Compliance_Evidence.csv") -NoTypeInformation -Encoding UTF8
    Write-Ok "6 CSV compliance files exported successfully."

    $htmlPath = Join-Path $OutputPath "M365-ESPA-ISO27001-Report.html"
    if ($ExportHtml) {
        Write-Step "Generating Executive HTML Compliance Report..."
        Export-EspaHtmlReport `
            -FilePath   $htmlPath `
            -TenantInfo $auditData.TenantInfo `
            -Scorecard  $scorecard `
            -MfaUsers   $auditData.MfaUsers `
            -CaPolicies $auditData.CaPolicies `
            -CaGaps     $caGaps `
            -PimRoles   $auditData.PimRoles `
            -MailAuth   $auditData.MailAuth
        Write-Ok "HTML Compliance Report generated: $htmlPath"
    }

    Write-Host ""
    Write-Host "========================================================================" -ForegroundColor Green
    Write-Host "  AUDIT COMPLETE — ESPA SCORE: $($scorecard.OverallScore)/100 (Grade $($scorecard.Grade))" -ForegroundColor Green
    if ($ExportHtml) { Write-Host "  HTML Report : $htmlPath" -ForegroundColor White }
    Write-Host "  CSV Folder  : $CsvFolder" -ForegroundColor White
    Write-Host "========================================================================" -ForegroundColor Green
    Write-Host ""

    if ($OpenReport -and $ExportHtml) {
        Start-Process $htmlPath
    }
}
catch {
    Write-Fail "Audit halted: $($_.Exception.Message)"
    exit 1
}
#endregion
