<#
.SYNOPSIS
    Installs required PowerShell modules for M365 ESPA By Jobaer (CurrentUser scope, no local admin required).
#>

Write-Host "=== M365 ESPA By Jobaer (v1.2.0) — Prerequisite Installer ===" -ForegroundColor Cyan

$modules = @(
    "Microsoft.Graph.Authentication",
    "Microsoft.Graph.Users",
    "Microsoft.Graph.Reports",
    "Microsoft.Graph.Identity.SignIns",
    "Microsoft.Graph.Identity.DirectoryManagement",
    "Microsoft.Graph.Identity.Governance",
    "ExchangeOnlineManagement"
)

if (-not (Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction SilentlyContinue)) {
    Write-Host "[*] Installing NuGet package provider..." -ForegroundColor Cyan
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force
}

foreach ($m in $modules) {
    if (Get-Module -ListAvailable -Name $m) {
        Write-Host "[+] Already installed: $m" -ForegroundColor Green
    }
    else {
        Write-Host "[*] Installing $m (CurrentUser)..." -ForegroundColor Yellow
        Install-Module -Name $m -Scope CurrentUser -Force -AllowClobber
        Write-Host "[+] Installed: $m" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "All prerequisites are ready! Run Run-M365-ESPA.bat or Invoke-M365SecurityAudit.ps1 -ExportHtml." -ForegroundColor Green
