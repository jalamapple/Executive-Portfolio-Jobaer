# Windows Endpoint & Network Health Toolbox (v1.4.0)

**Created by Jobaer**  
**Author:** S M Jobaer Alam | [www.jobaeralam.com](https://www.jobaeralam.com) | hello@jobaeralam.com  
**License:** Freeware

---

## Overview

Portable all-in-one IT support utility for checking **BitLocker status**, **Intune/AD join health** (`dsregcmd /status`), **Microsoft Defender posture**, **network latency**, **DNS resolution**, **port reachability**, **FortiGate/Azure VPN routing**, and **Windows Update diagnostics**.

Zero installation required — run directly from a USB drive or during remote support sessions.

## Key Features

- **Single-Pane Endpoint Diagnostics:** Parses `dsregcmd /status` (Entra ID Joined, Hybrid Joined, AD Joined, PRT SSO token, Windows Hello `NGCSet`, Intune MDM enrollment & IME service), BitLocker volume protection + 48-digit recovery key readiness + TPM 2.0 / Secure Boot, and Microsoft Defender Real-Time / Tamper Protection / Firewall posture.
- **Built-in Network & VPN Route Tester:** Measures ICMP latency, jitter, and packet loss, benchmarks DNS resolution across resolvers, tests TCP port reachability (`443`, `53`, `445`, `3389`), detects active **FortiGate / FortiClient** and **Azure VPN** tunnels, classifies Split-Tunnel vs. Full-Tunnel routing, and probes internal VPN destinations.
- **Windows Update & Servicing Health:** Checks `wuauserv`, `bits`, `cryptsvc`, `trustedinstaller`, and `dosvc` services, inspects 4 registry pending-reboot flags, identifies WSUS vs. Windows Update for Business (WUfB) source policies, and lists recent installed KBs.
- **Executive Support Bundle Exports:** Exports self-contained **HTML**, **JSON**, and **CSV** diagnostic reports with the **Created by Jobaer** banner.

## Requirements

- Windows 10 / 11 / Windows Server 2019–2025
- Administrator Rights recommended (for full BitLocker/TPM/Servicing inspection)
- PowerShell 5.1 or PowerShell 7+ (`pwsh`)

## Quick Start

1. **Extract ZIP** to any folder or USB drive.
2. **Right-click `Run-SysAdminToolbox.ps1` -> Run with PowerShell (Admin)** *(or double-click `Launch-Toolbox-Admin.bat` for automatic UAC elevation)*.

### CLI & Unattended Examples

```powershell
# Interactive single-pane menu (default)
.\Run-SysAdminToolbox.ps1

# Run full single-pane diagnostics and open HTML report automatically
.\Run-SysAdminToolbox.ps1 -RunAll -ExportHtml -OpenReport

# Run full diagnostics with a specific FortiGate/Azure VPN internal target probe
.\Run-SysAdminToolbox.ps1 -RunAll -VpnTestTarget "10.10.0.10" -ExportHtml -ExportJson -ExportCsv

# Run offline Demo Mode to preview output and reports
.\Run-SysAdminToolbox.ps1 -DemoMode -ExportHtml -OpenReport
```
