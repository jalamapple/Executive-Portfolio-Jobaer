<#
.SYNOPSIS
    Windows Endpoint & Network Health Toolbox (v1.4.0) — Created by Jobaer

.DESCRIPTION
    Portable all-in-one IT support utility for checking BitLocker status, Intune/AD join health
    (dsregcmd /status), Microsoft Defender posture, network latency, DNS resolution, TCP port
    reachability, FortiGate/Azure VPN routing, and Windows Update diagnostics.
    Zero installation required — designed to run directly from USB or remote support sessions.

.PARAMETER RunAll
    Runs all endpoint, security, network, VPN routing, and Windows Update diagnostics in a
    single-pane execution without waiting at the interactive menu.

.PARAMETER ExportHtml
    Exports a clean, executive HTML diagnostic report with the "Created by Jobaer" banner.

.PARAMETER ExportJson
    Exports complete diagnostic results in machine-readable JSON format.

.PARAMETER ExportCsv
    Exports a flat CSV diagnostic checklist summary for RMM/PSA ticketing attachment.

.PARAMETER OutputPath
    Folder where exported reports are saved. Defaults to .\Reports.

.PARAMETER OpenReport
    Automatically opens the generated HTML report in the default browser.

.PARAMETER VpnTestTarget
    Optional internal IP or hostname (e.g., "10.10.1.10" or "dc01.corp.local") to test VPN route
    selection, next-hop interface, latency, and port reachability.

.PARAMETER DnsServers
    DNS resolvers to benchmark during DNS resolution tests. Defaults to @("1.1.1.1", "8.8.8.8").

.PARAMETER DemoMode
    Runs an offline enterprise simulation across sample hybrid-joined & VPN-connected data so
    you can preview console output and HTML/JSON/CSV reports without modifying anything.

.EXAMPLE
    .\Run-SysAdminToolbox.ps1

.EXAMPLE
    .\Run-SysAdminToolbox.ps1 -RunAll -ExportHtml -OpenReport

.EXAMPLE
    .\Run-SysAdminToolbox.ps1 -RunAll -VpnTestTarget "10.20.0.5" -ExportHtml -ExportJson -ExportCsv

.EXAMPLE
    .\Run-SysAdminToolbox.ps1 -DemoMode -ExportHtml -OpenReport

.NOTES
    Tool      : Windows Endpoint & Network Health Toolbox (v1.4.0)
    Author    : S M Jobaer Alam | www.jobaeralam.com | hello@jobaeralam.com
    License   : Freeware
    Requires  : Windows 10 / 11 / Server 2019-2025 (Admin Rights recommended)
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [switch]$RunAll,

    [Parameter(Mandatory = $false)]
    [switch]$ExportHtml,

    [Parameter(Mandatory = $false)]
    [switch]$ExportJson,

    [Parameter(Mandatory = $false)]
    [switch]$ExportCsv,

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "",

    [Parameter(Mandatory = $false)]
    [switch]$OpenReport,

    [Parameter(Mandatory = $false)]
    [string]$VpnTestTarget = "",

    [Parameter(Mandatory = $false)]
    [string[]]$DnsServers = @("1.1.1.1", "8.8.8.8"),

    [Parameter(Mandatory = $false)]
    [switch]$DemoMode
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

#region Metadata & Environment Context
$ToolTitle   = "Windows Endpoint & Network Health Toolbox (v1.4.0)"
$AuthorLine  = "Author: S M Jobaer Alam | www.jobaeralam.com | hello@jobaeralam.com"
$LicenseLine = "License: Freeware"
$RunDate     = Get-Date
$Timestamp   = $RunDate.ToString("yyyyMMdd_HHmmss")

if ($OpenReport -and -not $ExportHtml) { $ExportHtml = $true }
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $baseDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
    $OutputPath = Join-Path -Path $baseDir -ChildPath "Reports"
}

function Test-IsAdministrator {
    try {
        $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

$IsAdmin      = Test-IsAdministrator
$ComputerName = $env:COMPUTERNAME
$CurrentUser  = "$env:USERDOMAIN\$env:USERNAME"
$PSVer        = $PSVersionTable.PSVersion.ToString()

$OsCaption = "Windows 10/11 / Server"
$OsBuild   = ""
try {
    $osObj = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    $OsCaption = $osObj.Caption.Trim()
    $OsBuild   = "$($osObj.Version) (Build $($osObj.BuildNumber))"
}
catch {
    $OsBuild = [System.Environment]::OSVersion.Version.ToString()
}
#endregion

#region Banner ("Created by Jobaer")
function Show-JobaerBanner {
    param([switch]$ClearScreen)
    if ($ClearScreen) { Clear-Host }
    $adminBadge = if ($IsAdmin) { "ADMINISTRATOR (ELEVATED)" } else { "STANDARD USER (Run as Admin for full BitLocker/TPM/Update checks)" }
    $adminColor = if ($IsAdmin) { "Green" } else { "Yellow" }

    Write-Host ""
    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host "   ____                _           _   _             _       _                  " -ForegroundColor Cyan
    Write-Host "  / ___|_ __ ___  __ _| |_ ___  __| | | |__  _   _  | | ___ | |__   __ _  ___ _ __ " -ForegroundColor Cyan
    Write-Host " | |   | '__/ _ \/ _`` | __/ _ \/ _`` | | '_ \| | | | | |/ _ \| '_ \ / _`` |/ _ \ '__|" -ForegroundColor Cyan
    Write-Host " | |___| | |  __/ (_| | ||  __/ (_| | | |_) | |_| | | | (_) | |_) | (_| |  __/ |   " -ForegroundColor Cyan
    Write-Host "  \____|_|  \___|\__,_|\__\___|\__,_| |_.__/ \__, | |_|\___/|_.__/ \__,_|\___|_|   " -ForegroundColor Cyan
    Write-Host "                                             |___/                                 " -ForegroundColor Cyan
    Write-Host "  *** CREATED BY JOBAER ***" -ForegroundColor Yellow
    Write-Host "  $ToolTitle" -ForegroundColor White
    Write-Host "  $AuthorLine" -ForegroundColor Gray
    Write-Host "  $LicenseLine" -ForegroundColor DarkGray
    Write-Host "--------------------------------------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host ("  Host: {0}  |  User: {1}  |  PS: v{2}" -f $ComputerName, $CurrentUser, $PSVer) -ForegroundColor Gray
    Write-Host ("  OS  : {0} [{1}]" -f $OsCaption, $OsBuild) -ForegroundColor Gray
    Write-Host "  Priv: " -NoNewline -ForegroundColor Gray
    Write-Host $adminBadge -ForegroundColor $adminColor
    Write-Host "================================================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-SectionHeader {
    param([string]$Title)
    Write-Host ""
    Write-Host "================================================================================" -ForegroundColor DarkCyan
    Write-Host "  $Title" -ForegroundColor Cyan
    Write-Host "================================================================================" -ForegroundColor DarkCyan
}

function Write-StatusLine {
    param(
        [string]$Label,
        [string]$Value,
        [ValidateSet("Pass", "Warning", "Fail", "Info")]
        [string]$State = "Info"
    )
    $color = switch ($State) {
        "Pass"    { "Green" }
        "Warning" { "Yellow" }
        "Fail"    { "Red" }
        default   { "White" }
    }
    $tag = switch ($State) {
        "Pass"    { "[PASS]" }
        "Warning" { "[WARN]" }
        "Fail"    { "[FAIL]" }
        default   { "[INFO]" }
    }
    Write-Host ("  {0,-7} {1,-32}: " -f $tag, $Label) -NoNewline -ForegroundColor $color
    Write-Host $Value -ForegroundColor $color
}

function ConvertTo-HtmlSafe {
    param([AllowNull()][string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return "" }
    return [System.Net.WebUtility]::HtmlEncode($Text)
}
#endregion

#region 1. Identity, AD / Entra Join & Intune MDM Diagnostics (dsregcmd /status)
function Get-IdentityJoinDiagnostics {
    $dsMap = @{}
    $dsRawAvailable = $false

    try {
        if (Get-Command dsregcmd.exe -ErrorAction SilentlyContinue) {
            $rawLines = & dsregcmd.exe /status 2>$null
            if ($rawLines) {
                $dsRawAvailable = $true
                foreach ($line in $rawLines) {
                    if ($line -match '^\s*([A-Za-z0-9_]+)\s*:\s*(.+?)\s*$') {
                        $k = $Matches[1].Trim()
                        $v = $Matches[2].Trim()
                        if (-not $dsMap.ContainsKey($k)) {
                            $dsMap[$k] = $v
                        }
                    }
                }
            }
        }
    }
    catch { }

    function Get-DsVal {
        param([string]$Key, [string]$Default = "N/A")
        if ($dsMap.ContainsKey($Key) -and -not [string]::IsNullOrWhiteSpace($dsMap[$Key])) {
            return $dsMap[$Key]
        }
        return $Default
    }

    $azureJoined      = Get-DsVal "AzureAdJoined" "NO"
    $domainJoined     = Get-DsVal "DomainJoined" "NO"
    $enterpriseJoined = Get-DsVal "EnterpriseJoined" "NO"
    $deviceId         = Get-DsVal "DeviceId" "N/A"
    $tenantName       = Get-DsVal "TenantName" "N/A"
    $tenantId         = Get-DsVal "TenantId" "N/A"
    $azurePrt         = Get-DsVal "AzureAdPrt" "NO"
    $prtUpdateTime    = Get-DsVal "AzureAdPrtUpdateTime" "N/A"
    $ngcSet           = Get-DsVal "NGCSet" "NO"
    $mdmUrl           = Get-DsVal "MdmUrl" "None"
    $mdmComplianceUrl = Get-DsVal "MdmComplianceUrl" "None"
    $domainName       = Get-DsVal "DomainName" "N/A"

    # Determine effective join topology
    $joinTopology = "Workgroup (Unjoined)"
    if ($azureJoined -eq "YES" -and $domainJoined -eq "YES") {
        $joinTopology = "Microsoft Entra Hybrid Joined (AD + Entra ID)"
    }
    elseif ($azureJoined -eq "YES") {
        $joinTopology = "Microsoft Entra Joined (Cloud-Native)"
    }
    elseif ($domainJoined -eq "YES") {
        $joinTopology = "On-Premises Active Directory Joined Only"
    }
    elseif ($enterpriseJoined -eq "YES") {
        $joinTopology = "On-Premises Workplace / DRS Joined"
    }

    # Check Intune Enrollment Registry & IME Service
    $intuneEnrolled = $false
    $intuneUpn      = "N/A"
    $imeServiceState = "Not Installed"
    try {
        $enrollRoot = "HKLM:\SOFTWARE\Microsoft\Enrollments"
        if (Test-Path $enrollRoot) {
            foreach ($sub in (Get-ChildItem -Path $enrollRoot -ErrorAction SilentlyContinue)) {
                $props = Get-ItemProperty -Path $sub.PSPath -ErrorAction SilentlyContinue
                if ($props -and $props.PSObject.Properties["ProviderID"] -and $props.ProviderID -eq "MS DM Server") {
                    $intuneEnrolled = $true
                    if ($props.PSObject.Properties["UPN"]) { $intuneUpn = $props.UPN }
                    break
                }
            }
        }
        $imeSvc = Get-Service -Name "IntuneManagementExtension" -ErrorAction SilentlyContinue
        if ($imeSvc) {
            $imeServiceState = "$($imeSvc.Status) ($($imeSvc.StartType))"
        }
    }
    catch { }

    if ($mdmUrl -ne "None" -and $mdmUrl -match "manage\.microsoft\.com") {
        $intuneEnrolled = $true
    }

    # Evaluate health state
    $status = "Pass"
    $notes  = [System.Collections.Generic.List[string]]::new()

    if (-not $dsRawAvailable) {
        $status = "Warning"
        $notes.Add("dsregcmd.exe did not return output.")
    }
    elseif ($joinTopology -eq "Workgroup (Unjoined)") {
        $status = "Warning"
        $notes.Add("Device is neither AD nor Entra ID joined.")
    }
    else {
        $notes.Add("Topology: $joinTopology.")
    }

    if ($azureJoined -eq "YES" -and $azurePrt -ne "YES") {
        if ($status -eq "Pass") { $status = "Warning" }
        $notes.Add("AzureAdPrt is NO — user may experience SSO or Conditional Access prompts (run dsregcmd /forcerecovery if broken).")
    }
    elseif ($azurePrt -eq "YES") {
        $notes.Add("Primary Refresh Token (PRT) active.")
    }

    if ($azureJoined -eq "YES" -and -not $intuneEnrolled) {
        if ($status -eq "Pass") { $status = "Warning" }
        $notes.Add("Entra joined without active Intune MDM enrollment.")
    }

    return [PSCustomObject]@{
        Status           = $status
        JoinTopology     = $joinTopology
        AzureAdJoined    = $azureJoined
        DomainJoined     = $domainJoined
        DomainName       = $domainName
        DeviceId         = $deviceId
        TenantName       = $tenantName
        TenantId         = $tenantId
        AzureAdPrt       = $azurePrt
        PrtUpdateTime    = $prtUpdateTime
        NgcWhfbSet       = $ngcSet
        IntuneEnrolled   = if ($intuneEnrolled) { "Yes ($intuneUpn)" } else { "No" }
        MdmUrl           = $mdmUrl
        ImeService       = $imeServiceState
        Summary          = ($notes -join " ")
    }
}
#endregion

#region 2. BitLocker & TPM Recovery Readiness Diagnostics
function Get-BitLockerDiagnostics {
    $volumes = [System.Collections.Generic.List[object]]::new()
    $osDrive = if ($env:SystemDrive) { $env:SystemDrive } else { "C:" }
    $overallStatus = "Pass"
    $issues = [System.Collections.Generic.List[string]]::new()

    # Check TPM & Secure Boot first
    $tpmStatus = "Unknown"
    try {
        if (Get-Command Get-Tpm -ErrorAction SilentlyContinue) {
            $tpm = Get-Tpm -ErrorAction Stop
            if ($tpm.TpmPresent -and $tpm.TpmReady) {
                $tpmStatus = "Ready (Present: True, Enabled: $($tpm.TpmEnabled), Activated: $($tpm.TpmActivated))"
            }
            elseif ($tpm.TpmPresent) {
                $tpmStatus = "Present but NOT Ready (Enabled: $($tpm.TpmEnabled), Activated: $($tpm.TpmActivated))"
                $overallStatus = "Warning"
                $issues.Add("TPM is present but not ready.")
            }
            else {
                $tpmStatus = "Not Present"
                $overallStatus = "Warning"
                $issues.Add("No TPM chip detected.")
            }
        }
    }
    catch {
        $tpmStatus = if (-not $IsAdmin) { "Requires Admin Rights to query TPM" } else { "Unavailable" }
    }

    $secureBoot = "Unknown"
    try {
        if (Get-Command Confirm-SecureBootUEFI -ErrorAction SilentlyContinue) {
            $sb = Confirm-SecureBootUEFI -ErrorAction Stop
            $secureBoot = if ($sb) { "Enabled (UEFI)" } else { "Disabled" }
            if (-not $sb) {
                $overallStatus = "Warning"
                $issues.Add("Secure Boot is disabled.")
            }
        }
    }
    catch {
        $secureBoot = "Legacy BIOS or Requires Admin"
    }

    # Query BitLocker Volumes
    $blQueried = $false
    try {
        if (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue) {
            $blVols = @(Get-BitLockerVolume -ErrorAction Stop)
            $blQueried = $true
            foreach ($v in $blVols) {
                $protectors = @($v.KeyProtector | ForEach-Object { $_.KeyProtectorType })
                $recKeyObj  = @($v.KeyProtector | Where-Object { $_.KeyProtectorType -eq "RecoveryPassword" } | Select-Object -First 1)
                $hasRecKey  = ($recKeyObj.Count -gt 0)
                $recKeyId   = if ($hasRecKey) { $recKeyObj[0].KeyProtectorId } else { "MISSING" }

                $volState = "Pass"
                if ($v.MountPoint -eq $osDrive) {
                    if ($v.ProtectionStatus -ne "On") {
                        $volState = "Fail"
                        $overallStatus = "Fail"
                        $issues.Add("OS drive ($osDrive) BitLocker Protection is $($v.ProtectionStatus) ($($v.VolumeStatus)).")
                    }
                    elseif (-not $hasRecKey) {
                        $volState = "Warning"
                        if ($overallStatus -eq "Pass") { $overallStatus = "Warning" }
                        $issues.Add("OS drive ($osDrive) is encrypted but lacks a 48-digit RecoveryPassword protector!")
                    }
                }
                else {
                    if ($v.ProtectionStatus -ne "On") {
                        $volState = "Warning"
                        if ($overallStatus -eq "Pass") { $overallStatus = "Warning" }
                        $issues.Add("Data drive ($($v.MountPoint)) BitLocker Protection is $($v.ProtectionStatus).")
                    }
                }

                $volumes.Add([PSCustomObject]@{
                    MountPoint           = $v.MountPoint
                    VolumeType           = $v.VolumeType
                    VolumeStatus         = $v.VolumeStatus
                    ProtectionStatus     = $v.ProtectionStatus
                    EncryptionPercentage = "$($v.EncryptionPercentage)%"
                    EncryptionMethod     = if ($v.EncryptionMethod) { $v.EncryptionMethod } else { "None" }
                    Protectors           = if ($protectors.Count -gt 0) { $protectors -join ", " } else { "None" }
                    RecoveryKeyReady     = if ($hasRecKey) { "Yes ($recKeyId)" } else { "No (Missing RecoveryPassword)" }
                    Status               = $volState
                })
            }
        }
    }
    catch {
        $blQueried = $false
    }

    # Fallback to manage-bde.exe if Get-BitLockerVolume unavailable
    if (-not $blQueried) {
        try {
            $bdeOut = & manage-bde.exe -status 2>$null
            if ($bdeOut -and ($bdeOut -join "`n") -match 'Volume\s+([A-Z]:)') {
                $blQueried = $true
                $rawText = $bdeOut -join "`n"
                $blocks = $rawText -split '(?=Volume\s+[A-Z]:)'
                foreach ($b in $blocks) {
                    if ($b -match 'Volume\s+([A-Z]:)') {
                        $mp   = $Matches[1]
                        $pct  = if ($b -match 'Percentage Encrypted:\s*([\d.,]+%)') { $Matches[1] } else { "0%" }
                        $conv = if ($b -match 'Conversion Status:\s*(.+)') { $Matches[1].Trim() } else { "Unknown" }
                        $prot = if ($b -match 'Protection Status:\s*(.+)') { $Matches[1].Trim() } else { "Unknown" }
                        $meth = if ($b -match 'Encryption Method:\s*(.+)') { $Matches[1].Trim() } else { "None" }
                        $hasRec = $b -match 'Numerical Password'
                        $vSt = if ($prot -match 'Protection On' -and $hasRec) { "Pass" } elseif ($prot -match 'Protection On') { "Warning" } else { "Fail" }
                        if ($mp -eq $osDrive -and $vSt -eq "Fail") { $overallStatus = "Fail"; $issues.Add("OS drive ($mp) BitLocker protection is OFF.") }

                        $volumes.Add([PSCustomObject]@{
                            MountPoint           = $mp
                            VolumeType           = if ($mp -eq $osDrive) { "OperatingSystem" } else { "Data" }
                            VolumeStatus         = $conv
                            ProtectionStatus     = $prot
                            EncryptionPercentage = $pct
                            EncryptionMethod     = $meth
                            Protectors           = if ($hasRec) { "Numerical Password (48-digit)" } else { "Check manage-bde -protectors" }
                            RecoveryKeyReady     = if ($hasRec) { "Yes" } else { "No" }
                            Status               = $vSt
                        })
                    }
                }
            }
        }
        catch { }
    }

    if (-not $blQueried) {
        $overallStatus = "Warning"
        $msg = if (-not $IsAdmin) { "Run PowerShell as Administrator to inspect BitLocker volume protectors." } else { "BitLocker feature/module not available on this OS edition." }
        $issues.Add($msg)
        $volumes.Add([PSCustomObject]@{
            MountPoint           = $osDrive
            VolumeType           = "OperatingSystem"
            VolumeStatus         = "Unavailable"
            ProtectionStatus     = "Unknown"
            EncryptionPercentage = "N/A"
            EncryptionMethod     = "N/A"
            Protectors           = "N/A"
            RecoveryKeyReady     = $msg
            Status               = "Warning"
        })
    }

    $summaryText = if ($issues.Count -gt 0) { $issues -join " " } else { "All volumes encrypted with BitLocker ON and 48-digit recovery protector verified." }

    return [PSCustomObject]@{
        Status      = $overallStatus
        TpmStatus   = $tpmStatus
        SecureBoot  = $secureBoot
        Volumes     = $volumes
        Summary     = $summaryText
    }
}
#endregion

#region 3. Microsoft Defender & Endpoint Security Posture
function Get-DefenderSecurityDiagnostics {
    $status = "Pass"
    $notes  = [System.Collections.Generic.List[string]]::new()

    $amEnabled       = "Unknown"
    $avEnabled       = "Unknown"
    $rtpEnabled      = "Unknown"
    $behaviorMon     = "Unknown"
    $tamperProtected = "Unknown"
    $sigVersion      = "Unknown"
    $sigAgeDays      = -1
    $quickScanAge    = -1

    try {
        if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) {
            $mp = Get-MpComputerStatus -ErrorAction Stop
            $amEnabled       = [string]$mp.AMServiceEnabled
            $avEnabled       = [string]$mp.AntivirusEnabled
            $rtpEnabled      = [string]$mp.RealTimeProtectionEnabled
            $behaviorMon     = [string]$mp.BehaviorMonitorEnabled
            $tamperProtected = [string]$mp.IsTamperProtected
            $sigVersion      = $mp.AntivirusSignatureVersion
            $sigAgeDays      = [int]$mp.AntivirusSignatureAge
            $quickScanAge    = [int]$mp.QuickScanAge

            if (-not $mp.RealTimeProtectionEnabled -or -not $mp.AntivirusEnabled) {
                $status = "Fail"
                $notes.Add("Microsoft Defender Antivirus or Real-Time Protection is DISABLED.")
            }
            if (-not $mp.IsTamperProtected) {
                if ($status -eq "Pass") { $status = "Warning" }
                $notes.Add("Defender Tamper Protection is OFF.")
            }
            if ($sigAgeDays -gt 3) {
                if ($status -eq "Pass") { $status = "Warning" }
                $notes.Add("Antivirus definitions are $sigAgeDays days old (stale > 3 days).")
            }
        }
        else {
            $status = "Warning"
            $notes.Add("Get-MpComputerStatus unavailable (third-party AV or Server Core without Defender).")
        }
    }
    catch {
        $status = "Warning"
        $notes.Add("Unable to query Defender status (verify Defender service is running or third-party EDR is active).")
    }

    # Windows Firewall Profiles
    $fwSummary = "Unknown"
    try {
        if (Get-Command Get-NetFirewallProfile -ErrorAction SilentlyContinue) {
            $fwProfiles = @(Get-NetFirewallProfile -ErrorAction Stop)
            $fwParts = @()
            foreach ($fp in $fwProfiles) {
                $fwParts += "$($fp.Name)=$($fp.Enabled)"
                if (-not $fp.Enabled) {
                    if ($status -eq "Pass") { $status = "Warning" }
                    $notes.Add("Windows Firewall $($fp.Name) profile is DISABLED.")
                }
            }
            $fwSummary = $fwParts -join ", "
        }
    }
    catch { }

    # UAC Check
    $uacStatus = "Unknown"
    try {
        $uacVal = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -ErrorAction Stop).EnableLUA
        $uacStatus = if ($uacVal -eq 1) { "Enabled" } else { "Disabled" }
        if ($uacVal -ne 1) {
            if ($status -eq "Pass") { $status = "Warning" }
            $notes.Add("User Account Control (UAC) is disabled.")
        }
    }
    catch { }

    if ($notes.Count -eq 0) {
        $notes.Add("Defender Real-Time Protection, Tamper Protection, fresh signatures ($sigAgeDays d), and all Firewall profiles are active.")
    }

    return [PSCustomObject]@{
        Status              = $status
        AMServiceEnabled    = $amEnabled
        AntivirusEnabled    = $avEnabled
        RealTimeProtection  = $rtpEnabled
        BehaviorMonitor     = $behaviorMon
        TamperProtection    = $tamperProtected
        SignatureVersion    = $sigVersion
        SignatureAgeDays    = if ($sigAgeDays -ge 0) { "$sigAgeDays day(s)" } else { "N/A" }
        QuickScanAgeDays    = if ($quickScanAge -ge 0) { "$quickScanAge day(s)" } else { "N/A" }
        FirewallProfiles    = $fwSummary
        UacStatus           = $uacStatus
        Summary             = ($notes -join " ")
    }
}
#endregion

#region 4. Network Latency, DNS Resolution & TCP Port Reachability
function Test-TcpPortFast {
    param(
        [string]$HostName,
        [int]$Port,
        [int]$TimeoutMs = 1500
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect($HostName, $Port, $null, $null)
        $wait = $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
        if (-not $wait) {
            $client.Close()
            return [PSCustomObject]@{ Open = $false; LatencyMs = $TimeoutMs; Note = "Timeout" }
        }
        $client.EndConnect($iar)
        $sw.Stop()
        $client.Close()
        return [PSCustomObject]@{ Open = $true; LatencyMs = [math]::Round($sw.Elapsed.TotalMilliseconds, 1); Note = "Open" }
    }
    catch {
        $sw.Stop()
        try { $client.Close() } catch { }
        return [PSCustomObject]@{ Open = $false; LatencyMs = [math]::Round($sw.Elapsed.TotalMilliseconds, 1); Note = "Refused/Blocked" }
    }
}

function Invoke-NetworkDiagnostics {
    param([string[]]$Resolvers = @("1.1.1.1", "8.8.8.8"))

    # 1. Active IP Configuration & Gateway
    $adapters = [System.Collections.Generic.List[object]]::new()
    $defaultGateway = $null
    try {
        $ipConfigs = @(Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.NetAdapter.Status -eq "Up" })
        foreach ($cfg in $ipConfigs) {
            $ipv4 = ($cfg.IPv4Address | ForEach-Object { "$($_.IPAddress)/$($_.PrefixLength)" }) -join ", "
            $gw   = ($cfg.IPv4DefaultGateway | ForEach-Object { $_.NextHop }) -join ", "
            $dns  = ($cfg.DNSServer | Where-Object { $_.AddressFamily -eq 2 } | ForEach-Object { $_.ServerAddresses }) -join ", "
            if (-not $defaultGateway -and $cfg.IPv4DefaultGateway) {
                $defaultGateway = ($cfg.IPv4DefaultGateway | Select-Object -First 1).NextHop
            }
            $adapters.Add([PSCustomObject]@{
                InterfaceAlias = $cfg.InterfaceAlias
                Description    = $cfg.InterfaceDescription
                IPv4Address    = if ($ipv4) { $ipv4 } else { "None" }
                DefaultGateway = if ($gw) { $gw } else { "None" }
                DnsServers     = if ($dns) { $dns } else { "None" }
            })
        }
    }
    catch { }

    # 2. ICMP Latency, Jitter & Packet Loss
    $pingTargets = [System.Collections.Generic.List[object]]::new()
    if ($defaultGateway) {
        $pingTargets.Add([PSCustomObject]@{ Label = "Default Gateway"; Target = $defaultGateway })
    }
    $pingTargets.Add([PSCustomObject]@{ Label = "Cloudflare Anycast"; Target = "1.1.1.1" })
    $pingTargets.Add([PSCustomObject]@{ Label = "Google Public DNS"; Target = "8.8.8.8" })
    $pingTargets.Add([PSCustomObject]@{ Label = "Microsoft 365 Edge"; Target = "outlook.office365.com" })

    $latencyResults = [System.Collections.Generic.List[object]]::new()
    $pingSender = New-Object System.Net.NetworkInformation.Ping

    foreach ($pt in $pingTargets) {
        $rtts = [System.Collections.Generic.List[double]]::new()
        $sent = 4
        for ($i = 0; $i -lt $sent; $i++) {
            try {
                $reply = $pingSender.Send($pt.Target, 1500)
                if ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
                    $rtts.Add([double]$reply.RoundtripTime)
                }
            }
            catch { }
            Start-Sleep -Milliseconds 80
        }

        $recv = $rtts.Count
        $lossPct = [math]::Round((($sent - $recv) / $sent) * 100, 0)
        if ($recv -gt 0) {
            $minMs = [math]::Round(($rtts | Measure-Object -Minimum).Minimum, 1)
            $avgMs = [math]::Round(($rtts | Measure-Object -Average).Average, 1)
            $maxMs = [math]::Round(($rtts | Measure-Object -Maximum).Maximum, 1)
            $jitter = [math]::Round($maxMs - $minMs, 1)
            $pState = if ($lossPct -gt 0 -or $avgMs -gt 180) { "Warning" } else { "Pass" }
        }
        else {
            $minMs = 0; $avgMs = 0; $maxMs = 0; $jitter = 0
            $pState = if ($pt.Target -eq "outlook.office365.com") { "Warning" } else { "Fail" }
        }

        $latencyResults.Add([PSCustomObject]@{
            Label      = $pt.Label
            Target     = $pt.Target
            PacketLoss = "$lossPct%"
            MinMs      = if ($recv -gt 0) { "$minMs ms" } else { "Timeout" }
            AvgMs      = if ($recv -gt 0) { "$avgMs ms" } else { "Timeout" }
            MaxMs      = if ($recv -gt 0) { "$maxMs ms" } else { "Timeout" }
            JitterMs   = if ($recv -gt 0) { "$jitter ms" } else { "N/A" }
            Status     = $pState
        })
    }

    # 3. DNS Resolution Benchmark
    $dnsQueries = @("login.microsoftonline.com", "endpoint.microsoft.com", "www.jobaeralam.com")
    $dnsResults = [System.Collections.Generic.List[object]]::new()
    $serversToTest = @("System Default") + $Resolvers

    foreach ($srv in $serversToTest) {
        foreach ($fqdn in $dnsQueries) {
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            $resolvedIp = ""
            $dState = "Fail"
            try {
                if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
                    $params = @{ Name = $fqdn; Type = "A"; ErrorAction = "Stop"; QuickTimeout = $true }
                    if ($srv -ne "System Default") { $params["Server"] = $srv }
                    $ans = @(Resolve-DnsName @params | Where-Object { $_.PSObject.Properties["IPAddress"] } | Select-Object -First 2)
                    $sw.Stop()
                    if ($ans.Count -gt 0) {
                        $resolvedIp = ($ans | ForEach-Object { $_.IPAddress }) -join ", "
                        $dState = "Pass"
                    }
                }
                else {
                    $ips = [System.Net.Dns]::GetHostAddresses($fqdn)
                    $sw.Stop()
                    if ($ips.Count -gt 0) {
                        $resolvedIp = ($ips | Select-Object -First 2 | ForEach-Object { $_.IPAddressToString }) -join ", "
                        $dState = "Pass"
                    }
                }
            }
            catch {
                $sw.Stop()
                $resolvedIp = "Resolution Failed"
            }

            $dnsResults.Add([PSCustomObject]@{
                Resolver   = $srv
                QueryName  = $fqdn
                Result     = $resolvedIp
                DurationMs = "$([math]::Round($sw.Elapsed.TotalMilliseconds, 1)) ms"
                Status     = $dState
            })
        }
    }

    # 4. TCP Port Reachability Matrix
    $portChecks = @(
        [PSCustomObject]@{ Service = "Entra ID Auth (HTTPS)";    Host = "login.microsoftonline.com"; Port = 443; Required = $true },
        [PSCustomObject]@{ Service = "Intune MDM Endpoint";      Host = "endpoint.microsoft.com";    Port = 443; Required = $true },
        [PSCustomObject]@{ Service = "Exchange Online (HTTPS)";  Host = "outlook.office365.com";     Port = 443; Required = $true },
        [PSCustomObject]@{ Service = "Cloudflare DNS (TCP/53)";  Host = "1.1.1.1";                   Port = 53;  Required = $false }
    )
    if ($defaultGateway) {
        $portChecks += [PSCustomObject]@{ Service = "Local Gateway Web/Mgmt"; Host = $defaultGateway; Port = 443; Required = $false }
        $portChecks += [PSCustomObject]@{ Service = "Local Gateway DNS";      Host = $defaultGateway; Port = 53;  Required = $false }
    }

    $portResults = [System.Collections.Generic.List[object]]::new()
    foreach ($pc in $portChecks) {
        $res = Test-TcpPortFast -HostName $pc.Host -Port $pc.Port -TimeoutMs 1500
        $pSt = if ($res.Open) { "Pass" } elseif ($pc.Required) { "Fail" } else { "Info" }
        $portResults.Add([PSCustomObject]@{
            Service   = $pc.Service
            Target    = "$($pc.Host):$($pc.Port)"
            State     = if ($res.Open) { "OPEN" } else { $res.Note.ToUpper() }
            LatencyMs = "$($res.LatencyMs) ms"
            Status    = $pSt
        })
    }

    $netStatus = "Pass"
    if (@($portResults | Where-Object { $_.Status -eq "Fail" }).Count -gt 0 -or @($dnsResults | Where-Object { $_.Status -eq "Fail" }).Count -gt 2) {
        $netStatus = "Fail"
    }
    elseif (@($latencyResults | Where-Object { $_.Status -ne "Pass" }).Count -gt 0 -or @($dnsResults | Where-Object { $_.Status -eq "Fail" }).Count -gt 0) {
        $netStatus = "Warning"
    }

    return [PSCustomObject]@{
        Status         = $netStatus
        DefaultGateway = if ($defaultGateway) { $defaultGateway } else { "None" }
        Adapters       = $adapters
        Latency        = $latencyResults
        Dns            = $dnsResults
        Ports          = $portResults
        Summary        = "Gateway: $(if($defaultGateway){$defaultGateway}else{'None'}) | Active NICs: $($adapters.Count) | Cloud Port 443 & DNS checks completed."
    }
}
#endregion

#region 5. FortiGate & Azure VPN Route Tester
function Test-VpnRoutingDiagnostics {
    param([string]$TargetHost = "")

    # 1. Detect VPN Network Adapters & Windows Built-In VPN Profiles
    $vpnAdapters = [System.Collections.Generic.List[object]]::new()
    try {
        $allNics = @(Get-NetAdapter -ErrorAction Stop)
        foreach ($nic in $allNics) {
            $desc = "$($nic.Name) $($nic.InterfaceDescription)"
            if ($desc -match '(?i)forti|ssl|azure|vpn|tap-|tun|wireguard|openvpn|cisco|anyconnect|globalprotect|wan miniport.*(ikev2|sstp|l2tp|pptp)') {
                $vendor = "Generic / Windows VPN"
                if ($desc -match '(?i)forti') { $vendor = "FortiGate / FortiClient VPN" }
                elseif ($desc -match '(?i)azure|tap-|wan miniport.*(ikev2|sstp)') { $vendor = "Azure VPN / S2S / P2S" }
                elseif ($desc -match '(?i)wireguard') { $vendor = "WireGuard VPN" }
                elseif ($desc -match '(?i)openvpn') { $vendor = "OpenVPN" }
                elseif ($desc -match '(?i)globalprotect') { $vendor = "Palo Alto GlobalProtect" }
                elseif ($desc -match '(?i)anyconnect|cisco') { $vendor = "Cisco AnyConnect" }

                $ipInfo = Get-NetIPAddress -InterfaceIndex $nic.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1
                $vpnAdapters.Add([PSCustomObject]@{
                    Name        = $nic.Name
                    Vendor      = $vendor
                    Description = $nic.InterfaceDescription
                    Status      = $nic.Status
                    IPv4        = if ($ipInfo) { "$($ipInfo.IPAddress)/$($ipInfo.PrefixLength)" } else { "Unassigned" }
                    IfIndex     = $nic.ifIndex
                })
            }
        }
    }
    catch { }

    # Also check Get-VpnConnection profiles (Windows Native / Azure VPN)
    try {
        if (Get-Command Get-VpnConnection -ErrorAction SilentlyContinue) {
            foreach ($vc in @(Get-VpnConnection -ErrorAction Stop)) {
                $already = @($vpnAdapters | Where-Object { $_.Name -eq $vc.Name }).Count -gt 0
                if (-not $already) {
                    $vpnAdapters.Add([PSCustomObject]@{
                        Name        = $vc.Name
                        Vendor      = "Windows / Azure VPN Profile ($($vc.TunnelType))"
                        Description = "Server: $($vc.ServerAddress) | SplitTunnel: $($vc.SplitTunneling)"
                        Status      = $vc.ConnectionStatus
                        IPv4        = "Profile"
                        IfIndex     = 0
                    })
                }
            }
        }
    }
    catch { }

    # 2. Inspect IPv4 Routing Table (Default 0.0.0.0/0 + RFC1918 / VPN Subnets)
    $keyRoutes = [System.Collections.Generic.List[object]]::new()
    $tunnelMode = "No Active VPN Tunnel Detected"
    $activeVpnIndices = @($vpnAdapters | Where-Object { $_.Status -eq "Up" -or $_.Status -eq "Connected" } | ForEach-Object { $_.IfIndex })

    try {
        $routes = @(Get-NetRoute -AddressFamily IPv4 -ErrorAction Stop | Where-Object {
            $_.DestinationPrefix -eq "0.0.0.0/0" -or
            $_.DestinationPrefix -match '^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.)' -or
            ($activeVpnIndices -contains $_.InterfaceIndex)
        } | Sort-Object RouteMetric, InterfaceMetric)

        $hasVpnDefault = $false
        $hasVpnSplit   = $false

        foreach ($rt in $routes) {
            $isVpnIf = ($activeVpnIndices -contains $rt.InterfaceIndex) -or ($rt.InterfaceAlias -match '(?i)forti|ssl|azure|vpn|tap-|tun|wireguard')
            if ($isVpnIf -and $rt.DestinationPrefix -eq "0.0.0.0/0") { $hasVpnDefault = $true }
            if ($isVpnIf -and $rt.DestinationPrefix -ne "0.0.0.0/0") { $hasVpnSplit   = $true }

            # Skip local link broadcast / host /32 noise unless on VPN interface
            if (-not $isVpnIf -and $rt.NextHop -eq "0.0.0.0" -and $rt.DestinationPrefix -ne "0.0.0.0/0") { continue }

            $effMetric = $rt.RouteMetric + $rt.InterfaceMetric
            $keyRoutes.Add([PSCustomObject]@{
                Destination     = $rt.DestinationPrefix
                NextHop         = $rt.NextHop
                InterfaceAlias  = $rt.InterfaceAlias
                EffectiveMetric = $effMetric
                IsVpnRoute      = if ($isVpnIf) { "Yes (VPN Tunnel)" } else { "No (Local LAN/WAN)" }
            })
        }

        if ($hasVpnDefault) {
            $tunnelMode = "Full Tunnel Active (0.0.0.0/0 routed via VPN)"
        }
        elseif ($hasVpnSplit -or $activeVpnIndices.Count -gt 0) {
            $tunnelMode = "Split Tunnel Active (Corporate/Azure subnets via VPN, Internet via Local WAN)"
        }
    }
    catch { }

    # 3. Optional Specific VPN Target Route & Port Probe
    $targetProbe = $null
    if (-not [string]::IsNullOrWhiteSpace($TargetHost)) {
        $targetProbe = Test-SingleVpnTarget -Target $TargetHost
    }

    $vpnStatus = if ($activeVpnIndices.Count -gt 0) { "Pass" } elseif ($vpnAdapters.Count -gt 0) { "Warning" } else { "Info" }
    $summary = if ($activeVpnIndices.Count -gt 0) {
        "Active VPN tunnel detected ($tunnelMode). $($keyRoutes.Count) key route(s) analyzed."
    }
    elseif ($vpnAdapters.Count -gt 0) {
        "$($vpnAdapters.Count) VPN adapter/profile(s) installed (currently Disconnected)."
    }
    else {
        "No active FortiGate/Azure VPN adapter connected; local LAN/WAN routing table verified."
    }

    return [PSCustomObject]@{
        Status      = $vpnStatus
        TunnelMode  = $tunnelMode
        Adapters    = $vpnAdapters
        Routes      = @($keyRoutes | Select-Object -First 20)
        TargetProbe = $targetProbe
        Summary     = $summary
    }
}

function Test-SingleVpnTarget {
    param([string]$Target)
    $cleanTarget = $Target.Trim()
    $resolvedIp  = $cleanTarget

    # Resolve hostname if needed
    if ($cleanTarget -notmatch '^\d{1,3}(\.\d{1,3}){3}$') {
        try {
            $ips = [System.Net.Dns]::GetHostAddresses($cleanTarget) | Where-Object { $_.AddressFamily -eq "InterNetwork" } | Select-Object -First 1
            if ($ips) { $resolvedIp = $ips.IPAddressToString }
        }
        catch {
            return [PSCustomObject]@{
                Target         = $cleanTarget
                ResolvedIP     = "DNS Resolution Failed"
                EgressNIC      = "N/A"
                NextHop        = "N/A"
                PingResult     = "Failed"
                Port443        = "N/A"
                Port445        = "N/A"
                Port3389       = "N/A"
                Status         = "Fail"
            }
        }
    }

    # Find exact Windows route selection (Find-NetRoute)
    $egressNic = "Unknown"
    $nextHop   = "Unknown"
    try {
        if (Get-Command Find-NetRoute -ErrorAction SilentlyContinue) {
            $nr = Find-NetRoute -RemoteIPAddress $resolvedIp -ErrorAction Stop | Select-Object -First 1
            if ($nr) {
                $egressNic = $nr.InterfaceAlias
                $nextHop   = $nr.NextHop
            }
        }
    }
    catch { }

    # Ping test
    $pingText = "Timeout"
    $pingOk   = $false
    try {
        $p = New-Object System.Net.NetworkInformation.Ping
        $rep = $p.Send($resolvedIp, 1500)
        if ($rep.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
            $pingText = "Reply ($($rep.RoundtripTime) ms)"
            $pingOk   = $true
        }
    }
    catch { }

    $p443  = Test-TcpPortFast -HostName $resolvedIp -Port 443  -TimeoutMs 1200
    $p445  = Test-TcpPortFast -HostName $resolvedIp -Port 445  -TimeoutMs 1200
    $p3389 = Test-TcpPortFast -HostName $resolvedIp -Port 3389 -TimeoutMs 1200

    $anyReachable = $pingOk -or $p443.Open -or $p445.Open -or $p3389.Open
    return [PSCustomObject]@{
        Target     = $cleanTarget
        ResolvedIP = $resolvedIp
        EgressNIC  = $egressNic
        NextHop    = $nextHop
        PingResult = $pingText
        Port443    = if ($p443.Open)  { "OPEN ($($p443.LatencyMs)ms)" }  else { "Closed/Filtered" }
        Port445    = if ($p445.Open)  { "OPEN ($($p445.LatencyMs)ms)" }  else { "Closed/Filtered" }
        Port3389   = if ($p3389.Open) { "OPEN ($($p3389.LatencyMs)ms)" } else { "Closed/Filtered" }
        Status     = if ($anyReachable) { "Pass" } else { "Warning" }
    }
}
#endregion

#region 6. Windows Update & Servicing Diagnostics
function Get-WindowsUpdateDiagnostics {
    $status = "Pass"
    $issues = [System.Collections.Generic.List[string]]::new()

    # 1. Core Servicing Services
    $svcNames = @("wuauserv", "bits", "cryptsvc", "trustedinstaller", "dosvc")
    $services = [System.Collections.Generic.List[object]]::new()
    foreach ($sn in $svcNames) {
        $s = Get-Service -Name $sn -ErrorAction SilentlyContinue
        if ($s) {
            $sSt = "Pass"
            if ($s.StartType -eq "Disabled") {
                $sSt = "Fail"
                $status = "Fail"
                $issues.Add("Service '$($s.Name)' ($($s.DisplayName)) is DISABLED.")
            }
            $services.Add([PSCustomObject]@{
                Name        = $s.Name
                DisplayName = $s.DisplayName
                Status      = [string]$s.Status
                StartType   = [string]$s.StartType
                Health      = $sSt
            })
        }
    }

    # 2. Pending Reboot Checks (4 Registry Locations)
    $rebootReasons = [System.Collections.Generic.List[string]]::new()
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") {
        $rebootReasons.Add("CBS RebootPending")
    }
    if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") {
        $rebootReasons.Add("Windows Update RebootRequired")
    }
    try {
        $sm = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name "PendingFileRenameOperations" -ErrorAction Stop
        if ($sm.PendingFileRenameOperations) {
            $rebootReasons.Add("PendingFileRenameOperations")
        }
    }
    catch { }
    try {
        $upd = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Updates" -Name "UpdateExeVolatile" -ErrorAction Stop
        if ($upd.UpdateExeVolatile -and $upd.UpdateExeVolatile -ne 0) {
            $rebootReasons.Add("UpdateExeVolatile")
        }
    }
    catch { }

    $pendingReboot = ($rebootReasons.Count -gt 0)
    if ($pendingReboot) {
        if ($status -eq "Pass") { $status = "Warning" }
        $issues.Add("System has a pending reboot ($($rebootReasons -join ', ')).")
    }

    # 3. WSUS vs. Windows Update for Business (WUfB) Source
    $updateSource = "Microsoft Windows Update / WUfB (Cloud)"
    $targetVersion = "Default (Latest)"
    try {
        $auPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
        $wuPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
        if (Test-Path $auPath) {
            $auProps = Get-ItemProperty -Path $auPath -ErrorAction SilentlyContinue
            if ($auProps -and $auProps.PSObject.Properties["UseWUServer"] -and $auProps.UseWUServer -eq 1) {
                $wuProps = Get-ItemProperty -Path $wuPath -ErrorAction SilentlyContinue
                $wsusUrl = if ($wuProps -and $wuProps.PSObject.Properties["WUServer"]) { $wuProps.WUServer } else { "Configured" }
                $updateSource = "Internal WSUS Server ($wsusUrl)"
            }
        }
        if (Test-Path $wuPath) {
            $wuProps = Get-ItemProperty -Path $wuPath -ErrorAction SilentlyContinue
            if ($wuProps -and $wuProps.PSObject.Properties["TargetReleaseVersionInfo"] -and $wuProps.TargetReleaseVersionInfo) {
                $targetVersion = $wuProps.TargetReleaseVersionInfo
            }
        }
    }
    catch { }

    # 4. Recent Installed Patches (Get-HotFix)
    $hotfixes = [System.Collections.Generic.List[object]]::new()
    $daysSinceLastPatch = -1
    try {
        $hfList = @(Get-HotFix -ErrorAction Stop | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 5)
        if ($hfList.Count -gt 0) {
            $daysSinceLastPatch = [math]::Round(((Get-Date) - $hfList[0].InstalledOn).TotalDays, 0)
            if ($daysSinceLastPatch -gt 45) {
                if ($status -eq "Pass") { $status = "Warning" }
                $issues.Add("Last installed security patch is $daysSinceLastPatch days old (> 45 days).")
            }
        }
        foreach ($hf in $hfList) {
            $hotfixes.Add([PSCustomObject]@{
                HotFixID    = $hf.HotFixID
                Description = $hf.Description
                InstalledOn = $hf.InstalledOn.ToString("yyyy-MM-dd")
                InstalledBy = $hf.InstalledBy
            })
        }
    }
    catch { }

    $summaryText = if ($issues.Count -gt 0) {
        $issues -join " "
    }
    else {
        "Update services healthy, no pending reboot, last patch installed $daysSinceLastPatch day(s) ago."
    }

    return [PSCustomObject]@{
        Status             = $status
        UpdateSource       = $updateSource
        TargetRelease      = $targetVersion
        PendingReboot      = if ($pendingReboot) { "YES ($($rebootReasons -join ', '))" } else { "No" }
        DaysSinceLastPatch = if ($daysSinceLastPatch -ge 0) { "$daysSinceLastPatch day(s)" } else { "Unknown" }
        Services           = $services
        RecentHotfixes     = $hotfixes
        Summary            = $summaryText
    }
}
#endregion

#region Demo Mode Dataset
function Get-DemoDiagnosticsData {
    $identity = [PSCustomObject]@{
        Status         = "Pass"
        JoinTopology   = "Microsoft Entra Hybrid Joined (AD + Entra ID)"
        AzureAdJoined  = "YES"
        DomainJoined   = "YES"
        DomainName     = "corp.jobaeralam.com"
        DeviceId       = "7f92c41a-3b8d-4910-b5e2-81c904fa12d9"
        TenantName     = "Jobaer Alam Cloud Lab"
        TenantId       = "a1b2c3d4-5678-90ab-cdef-112233445566"
        AzureAdPrt     = "YES"
        PrtUpdateTime  = (Get-Date).AddHours(-1).ToString("yyyy-MM-dd HH:mm:ss")
        NgcWhfbSet     = "YES"
        IntuneEnrolled = "Yes (jobaer@jobaeralam.com)"
        MdmUrl         = "https://enrollment.manage.microsoft.com/enrollmentserver/discovery.svc"
        ImeService     = "Running (Automatic)"
        Summary        = "Topology: Microsoft Entra Hybrid Joined (AD + Entra ID). Primary Refresh Token (PRT) active. Intune MDM enrolled."
    }

    $bitlocker = [PSCustomObject]@{
        Status     = "Pass"
        TpmStatus  = "Ready (Present: True, Enabled: True, Activated: True)"
        SecureBoot = "Enabled (UEFI)"
        Volumes    = @(
            [PSCustomObject]@{ MountPoint="C:"; VolumeType="OperatingSystem"; VolumeStatus="FullyEncrypted"; ProtectionStatus="On"; EncryptionPercentage="100%"; EncryptionMethod="XtsAes256"; Protectors="Tpm, RecoveryPassword"; RecoveryKeyReady="Yes ({94A2B1C0-8812-4F31-9B10-44C21190E812})"; Status="Pass" },
            [PSCustomObject]@{ MountPoint="D:"; VolumeType="Data"; VolumeStatus="FullyEncrypted"; ProtectionStatus="On"; EncryptionPercentage="100%"; EncryptionMethod="XtsAes256"; Protectors="RecoveryPassword, ExternalKey"; RecoveryKeyReady="Yes ({12D8F9A1-4421-4098-8E22-77B19022C410})"; Status="Pass" }
        )
        Summary    = "All volumes encrypted with BitLocker ON (XtsAes256) and 48-digit recovery protector verified."
    }

    $defender = [PSCustomObject]@{
        Status             = "Pass"
        AMServiceEnabled   = "True"
        AntivirusEnabled   = "True"
        RealTimeProtection = "True"
        BehaviorMonitor    = "True"
        TamperProtection   = "True"
        SignatureVersion   = "1.421.842.0"
        SignatureAgeDays   = "0 day(s)"
        QuickScanAgeDays   = "1 day(s)"
        FirewallProfiles   = "Domain=True, Private=True, Public=True"
        UacStatus          = "Enabled"
        Summary            = "Defender Real-Time Protection, Tamper Protection, fresh signatures (0 d), and all Firewall profiles are active."
    }

    $network = [PSCustomObject]@{
        Status         = "Pass"
        DefaultGateway = "192.168.10.1"
        Adapters       = @(
            [PSCustomObject]@{ InterfaceAlias="Wi-Fi 6E"; Description="Intel(R) Wi-Fi 6E AX211 160MHz"; IPv4Address="192.168.10.45/24"; DefaultGateway="192.168.10.1"; DnsServers="10.10.0.10, 1.1.1.1" }
        )
        Latency        = @(
            [PSCustomObject]@{ Label="Default Gateway"; Target="192.168.10.1"; PacketLoss="0%"; MinMs="1.2 ms"; AvgMs="1.8 ms"; MaxMs="2.6 ms"; JitterMs="1.4 ms"; Status="Pass" },
            [PSCustomObject]@{ Label="Cloudflare Anycast"; Target="1.1.1.1"; PacketLoss="0%"; MinMs="8.4 ms"; AvgMs="9.1 ms"; MaxMs="10.3 ms"; JitterMs="1.9 ms"; Status="Pass" },
            [PSCustomObject]@{ Label="Google Public DNS"; Target="8.8.8.8"; PacketLoss="0%"; MinMs="11.0 ms"; AvgMs="12.4 ms"; MaxMs="14.1 ms"; JitterMs="3.1 ms"; Status="Pass" },
            [PSCustomObject]@{ Label="Microsoft 365 Edge"; Target="outlook.office365.com"; PacketLoss="0%"; MinMs="18.2 ms"; AvgMs="19.7 ms"; MaxMs="21.5 ms"; JitterMs="3.3 ms"; Status="Pass" }
        )
        Dns            = @(
            [PSCustomObject]@{ Resolver="System Default"; QueryName="login.microsoftonline.com"; Result="20.190.159.0, 40.126.31.132"; DurationMs="6.4 ms"; Status="Pass" },
            [PSCustomObject]@{ Resolver="1.1.1.1"; QueryName="endpoint.microsoft.com"; Result="13.107.246.40"; DurationMs="9.2 ms"; Status="Pass" },
            [PSCustomObject]@{ Resolver="8.8.8.8"; QueryName="www.jobaeralam.com"; Result="20.212.84.115"; DurationMs="11.5 ms"; Status="Pass" }
        )
        Ports          = @(
            [PSCustomObject]@{ Service="Entra ID Auth (HTTPS)"; Target="login.microsoftonline.com:443"; State="OPEN"; LatencyMs="18.4 ms"; Status="Pass" },
            [PSCustomObject]@{ Service="Intune MDM Endpoint"; Target="endpoint.microsoft.com:443"; State="OPEN"; LatencyMs="19.1 ms"; Status="Pass" },
            [PSCustomObject]@{ Service="Exchange Online (HTTPS)"; Target="outlook.office365.com:443"; State="OPEN"; LatencyMs="20.2 ms"; Status="Pass" }
        )
        Summary        = "Gateway: 192.168.10.1 | Active NICs: 1 | Cloud Port 443 & DNS checks completed."
    }

    $vpn = [PSCustomObject]@{
        Status      = "Pass"
        TunnelMode  = "Split Tunnel Active (Corporate/Azure subnets via VPN, Internet via Local WAN)"
        Adapters    = @(
            [PSCustomObject]@{ Name="fortissl"; Vendor="FortiGate / FortiClient VPN"; Description="Fortinet Virtual Ethernet Adapter (NDIS 6.30)"; Status="Up"; IPv4="10.212.134.18/32"; IfIndex=24 },
            [PSCustomObject]@{ Name="Azure-Hub-VNet"; Vendor="Azure VPN / S2S / P2S"; Description="WAN Miniport (IKEv2)"; Status="Up"; IPv4="172.16.250.14/32"; IfIndex=28 }
        )
        Routes      = @(
            [PSCustomObject]@{ Destination="0.0.0.0/0"; NextHop="192.168.10.1"; InterfaceAlias="Wi-Fi 6E"; EffectiveMetric=35; IsVpnRoute="No (Local LAN/WAN)" },
            [PSCustomObject]@{ Destination="10.10.0.0/16"; NextHop="10.212.134.19"; InterfaceAlias="fortissl"; EffectiveMetric=26; IsVpnRoute="Yes (VPN Tunnel)" },
            [PSCustomObject]@{ Destination="172.16.0.0/16"; NextHop="172.16.250.1"; InterfaceAlias="Azure-Hub-VNet"; EffectiveMetric=26; IsVpnRoute="Yes (VPN Tunnel)" }
        )
        TargetProbe = [PSCustomObject]@{
            Target="10.10.0.10"; ResolvedIP="10.10.0.10"; EgressNIC="fortissl"; NextHop="10.212.134.19"
            PingResult="Reply (24 ms)"; Port443="OPEN (25.1ms)"; Port445="OPEN (24.8ms)"; Port3389="OPEN (25.4ms)"; Status="Pass"
        }
        Summary     = "Active VPN tunnel detected (Split Tunnel Active). FortiGate & Azure VPN routes verified."
    }

    $winUpdate = [PSCustomObject]@{
        Status             = "Pass"
        UpdateSource       = "Microsoft Windows Update / WUfB (Cloud)"
        TargetRelease      = "24H2"
        PendingReboot      = "No"
        DaysSinceLastPatch = "9 day(s)"
        Services           = @(
            [PSCustomObject]@{ Name="wuauserv"; DisplayName="Windows Update"; Status="Running"; StartType="Manual"; Health="Pass" },
            [PSCustomObject]@{ Name="bits"; DisplayName="Background Intelligent Transfer Service"; Status="Running"; StartType="Automatic"; Health="Pass" },
            [PSCustomObject]@{ Name="cryptsvc"; DisplayName="Cryptographic Services"; Status="Running"; StartType="Automatic"; Health="Pass" },
            [PSCustomObject]@{ Name="trustedinstaller"; DisplayName="Windows Modules Installer"; Status="Stopped"; StartType="Manual"; Health="Pass" }
        )
        RecentHotfixes     = @(
            [PSCustomObject]@{ HotFixID="KB5046617"; Description="Security Update"; InstalledOn=(Get-Date).AddDays(-9).ToString("yyyy-MM-dd"); InstalledBy="NT AUTHORITY\SYSTEM" },
            [PSCustomObject]@{ HotFixID="KB5045934"; Description="Update"; InstalledOn=(Get-Date).AddDays(-38).ToString("yyyy-MM-dd"); InstalledBy="NT AUTHORITY\SYSTEM" }
        )
        Summary            = "Update services healthy, no pending reboot, last patch installed 9 day(s) ago."
    }

    return [PSCustomObject]@{
        Identity   = $identity
        BitLocker  = $bitlocker
        Defender   = $defender
        Network    = $network
        VpnRouting = $vpn
        WinUpdate  = $winUpdate
    }
}
#endregion

#region Console Renderers
function Show-IdentityConsole {
    param($Data)
    Write-SectionHeader "1. IDENTITY, ENTRA / AD JOIN & INTUNE MDM HEALTH (dsregcmd /status)"
    Write-StatusLine "Overall Join Posture" $Data.JoinTopology $Data.Status
    Write-StatusLine "AzureAdJoined / DomainJoined" "AzureAdJoined=$($Data.AzureAdJoined) | DomainJoined=$($Data.DomainJoined) ($($Data.DomainName))" "Info"
    Write-StatusLine "Tenant Name & ID" "$($Data.TenantName) [$($Data.TenantId)]" "Info"
    Write-StatusLine "Device ID" $Data.DeviceId "Info"
    Write-StatusLine "Azure AD PRT (SSO Token)" "$($Data.AzureAdPrt) (Last Update: $($Data.PrtUpdateTime))" $(if($Data.AzureAdPrt -eq "YES"){"Pass"}else{"Warning"})
    Write-StatusLine "Windows Hello (NGCSet)" $Data.NgcWhfbSet "Info"
    Write-StatusLine "Intune MDM Enrollment" $Data.IntuneEnrolled $(if($Data.IntuneEnrolled -match "^Yes"){"Pass"}else{"Warning"})
    Write-StatusLine "Intune Management Ext (IME)" $Data.ImeService "Info"
    Write-StatusLine "Diagnostic Note" $Data.Summary $Data.Status
}

function Show-BitLockerConsole {
    param($Data)
    Write-SectionHeader "2. BITLOCKER & TPM RECOVERY READINESS"
    Write-StatusLine "Overall BitLocker Readiness" $Data.Summary $Data.Status
    Write-StatusLine "TPM 2.0 Hardware Status" $Data.TpmStatus "Info"
    Write-StatusLine "Secure Boot State" $Data.SecureBoot "Info"
    Write-Host ""
    Write-Host ("  {0,-6} {1,-16} {2,-15} {3,-10} {4,-12} {5}" -f "Drive", "Status", "Protection", "Encrypted", "Method", "Recovery Key Readiness") -ForegroundColor Gray
    Write-Host ("  {0,-6} {1,-16} {2,-15} {3,-10} {4,-12} {5}" -f "-----", "------", "----------", "---------", "------", "----------------------") -ForegroundColor DarkGray
    foreach ($v in $Data.Volumes) {
        $c = switch ($v.Status) { "Pass" {"Green"} "Warning" {"Yellow"} default {"Red"} }
        Write-Host ("  {0,-6} {1,-16} {2,-15} {3,-10} {4,-12} {5}" -f $v.MountPoint, $v.VolumeStatus, $v.ProtectionStatus, $v.EncryptionPercentage, $v.EncryptionMethod, $v.RecoveryKeyReady) -ForegroundColor $c
    }
}

function Show-DefenderConsole {
    param($Data)
    Write-SectionHeader "3. MICROSOFT DEFENDER & ENDPOINT SECURITY POSTURE"
    Write-StatusLine "Overall Security Posture" $Data.Summary $Data.Status
    Write-StatusLine "Antivirus / Real-Time Prot." "AV=$($Data.AntivirusEnabled) | RealTime=$($Data.RealTimeProtection) | Behavior=$($Data.BehaviorMonitor)" $(if($Data.RealTimeProtection -eq "True"){"Pass"}else{"Fail"})
    Write-StatusLine "Tamper Protection" $Data.TamperProtection $(if($Data.TamperProtection -eq "True"){"Pass"}else{"Warning"})
    Write-StatusLine "Signature Version & Age" "$($Data.SignatureVersion) (Age: $($Data.SignatureAgeDays) | QuickScan: $($Data.QuickScanAgeDays))" "Info"
    Write-StatusLine "Windows Defender Firewall" $Data.FirewallProfiles "Info"
    Write-StatusLine "User Account Control (UAC)" $Data.UacStatus $(if($Data.UacStatus -eq "Enabled"){"Pass"}else{"Warning"})
}

function Show-NetworkConsole {
    param($Data)
    Write-SectionHeader "4. NETWORK LATENCY, DNS RESOLUTION & TCP PORT REACHABILITY"
    Write-StatusLine "Overall Network Health" $Data.Summary $Data.Status
    foreach ($nic in $Data.Adapters) {
        Write-StatusLine "NIC [$($nic.InterfaceAlias)]" "IP: $($nic.IPv4Address) | GW: $($nic.DefaultGateway) | DNS: $($nic.DnsServers)" "Info"
    }

    Write-Host "`n  [Latency, Jitter & Packet Loss]" -ForegroundColor Cyan
    Write-Host ("  {0,-22} {1,-24} {2,-8} {3,-10} {4,-10} {5}" -f "Endpoint", "Host/IP", "Loss", "Avg RTT", "Jitter", "State") -ForegroundColor Gray
    foreach ($l in $Data.Latency) {
        $c = switch ($l.Status) { "Pass" {"Green"} "Warning" {"Yellow"} default {"Red"} }
        Write-Host ("  {0,-22} {1,-24} {2,-8} {3,-10} {4,-10} {5}" -f $l.Label, $l.Target, $l.PacketLoss, $l.AvgMs, $l.JitterMs, $l.Status.ToUpper()) -ForegroundColor $c
    }

    Write-Host "`n  [DNS Resolution Benchmark]" -ForegroundColor Cyan
    Write-Host ("  {0,-18} {1,-28} {2,-28} {3}" -f "Resolver", "Query", "Resolved IP", "Time") -ForegroundColor Gray
    foreach ($d in $Data.Dns) {
        $c = if ($d.Status -eq "Pass") { "Green" } else { "Red" }
        Write-Host ("  {0,-18} {1,-28} {2,-28} {3}" -f $d.Resolver, $d.QueryName, $d.Result, $d.DurationMs) -ForegroundColor $c
    }

    Write-Host "`n  [TCP Port Reachability]" -ForegroundColor Cyan
    Write-Host ("  {0,-26} {1,-30} {2,-16} {3}" -f "Service", "Target:Port", "State", "Connect Time") -ForegroundColor Gray
    foreach ($p in $Data.Ports) {
        $c = switch ($p.Status) { "Pass" {"Green"} "Fail" {"Red"} default {"Yellow"} }
        Write-Host ("  {0,-26} {1,-30} {2,-16} {3}" -f $p.Service, $p.Target, $p.State, $p.LatencyMs) -ForegroundColor $c
    }
}

function Show-VpnConsole {
    param($Data)
    Write-SectionHeader "5. FORTIGATE & AZURE VPN ROUTE TESTER"
    Write-StatusLine "VPN Tunnel Posture" $Data.TunnelMode $Data.Status
    if ($Data.Adapters.Count -gt 0) {
        foreach ($va in $Data.Adapters) {
            $c = if ($va.Status -eq "Up" -or $va.Status -eq "Connected") { "Pass" } else { "Warning" }
            Write-StatusLine "VPN Adapter [$($va.Name)]" "$($va.Vendor) | Status: $($va.Status) | IP: $($va.IPv4)" $c
        }
    }
    else {
        Write-StatusLine "VPN Adapters" "No FortiGate, Azure VPN, or third-party VPN adapters detected." "Info"
    }

    Write-Host "`n  [Active IPv4 Default & Private Subnet Routes]" -ForegroundColor Cyan
    Write-Host ("  {0,-20} {1,-18} {2,-22} {3,-8} {4}" -f "Destination", "Next Hop", "Interface", "Metric", "Tunnel Classification") -ForegroundColor Gray
    foreach ($rt in $Data.Routes) {
        $c = if ($rt.IsVpnRoute -match "^Yes") { "Green" } else { "White" }
        Write-Host ("  {0,-20} {1,-18} {2,-22} {3,-8} {4}" -f $rt.Destination, $rt.NextHop, $rt.InterfaceAlias, $rt.EffectiveMetric, $rt.IsVpnRoute) -ForegroundColor $c
    }

    if ($Data.TargetProbe) {
        $tp = $Data.TargetProbe
        Write-Host "`n  [VPN Target Route & Reachability Probe: $($tp.Target)]" -ForegroundColor Cyan
        Write-StatusLine "Resolved IP & Egress" "$($tp.ResolvedIP) via NIC '$($tp.EgressNIC)' (NextHop: $($tp.NextHop))" $tp.Status
        Write-StatusLine "ICMP & Service Ports" "Ping: $($tp.PingResult) | TCP/443: $($tp.Port443) | TCP/445: $($tp.Port445) | TCP/3389: $($tp.Port3389)" $tp.Status
    }
}

function Show-WinUpdateConsole {
    param($Data)
    Write-SectionHeader "6. WINDOWS UPDATE & SERVICING DIAGNOSTICS"
    Write-StatusLine "Overall Update Health" $Data.Summary $Data.Status
    Write-StatusLine "Update Source Policy" "$($Data.UpdateSource) | Target Release: $($Data.TargetRelease)" "Info"
    Write-StatusLine "Pending System Reboot" $Data.PendingReboot $(if($Data.PendingReboot -eq "No"){"Pass"}else{"Warning"})
    Write-StatusLine "Last Security Patch Age" $Data.DaysSinceLastPatch "Info"

    Write-Host "`n  [Servicing Stack Services]" -ForegroundColor Cyan
    foreach ($s in $Data.Services) {
        $c = if ($s.Health -eq "Pass") { "Green" } else { "Red" }
        Write-Host ("  {0,-18} ({1,-38}) : {2} [{3}]" -f $s.Name, $s.DisplayName, $s.Status, $s.StartType) -ForegroundColor $c
    }

    if ($Data.RecentHotfixes.Count -gt 0) {
        Write-Host "`n  [Recent Installed Updates (Last 5)]" -ForegroundColor Cyan
        foreach ($hf in $Data.RecentHotfixes) {
            Write-Host ("  {0,-12} | {1,-12} | {2}" -f $hf.HotFixID, $hf.InstalledOn, $hf.Description) -ForegroundColor Gray
        }
    }
}
#endregion

#region Health Score & Report Exporters (HTML / JSON / CSV)
function Get-OverallHealthScore {
    param($Bundle)
    $score = 0
    $weights = @(
        @{ Obj = $Bundle.Identity;   Pass = 20; Warn = 12 },
        @{ Obj = $Bundle.BitLocker;  Pass = 20; Warn = 10 },
        @{ Obj = $Bundle.Defender;   Pass = 20; Warn = 10 },
        @{ Obj = $Bundle.Network;    Pass = 15; Warn = 8  },
        @{ Obj = $Bundle.VpnRouting; Pass = 10; Warn = 7  },
        @{ Obj = $Bundle.WinUpdate;  Pass = 15; Warn = 8  }
    )
    foreach ($w in $weights) {
        $st = $w.Obj.Status
        if ($st -eq "Pass" -or $st -eq "Info") { $score += $w.Pass }
        elseif ($st -eq "Warning") { $score += $w.Warn }
    }
    $grade = switch ($score) {
        { $_ -ge 90 } { "A"; break }
        { $_ -ge 80 } { "B"; break }
        { $_ -ge 70 } { "C"; break }
        { $_ -ge 60 } { "D"; break }
        default       { "F" }
    }
    return [PSCustomObject]@{ Score = $score; Grade = $grade }
}

function Export-DiagnosticReports {
    param(
        $Bundle,
        [switch]$DoHtml,
        [switch]$DoJson,
        [switch]$DoCsv,
        [switch]$DoOpen
    )

    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
    $scoreObj = Get-OverallHealthScore -Bundle $Bundle

    if ($DoJson) {
        $jsonPath = Join-Path -Path $OutputPath -ChildPath "SysAdminToolbox_${ComputerName}_$Timestamp.json"
        $payload = [PSCustomObject]@{
            Banner      = "Created by Jobaer"
            Tool        = $ToolTitle
            Author      = $AuthorLine
            License     = $LicenseLine
            GeneratedAt = $RunDate.ToString("o")
            Hostname    = $ComputerName
            OS          = "$OsCaption ($OsBuild)"
            AdminRights = $IsAdmin
            HealthScore = $scoreObj
            Diagnostics = $Bundle
        }
        $payload | ConvertTo-Json -Depth 6 | Out-File -FilePath $jsonPath -Encoding UTF8
        Write-Host "[+] JSON Report exported: $jsonPath" -ForegroundColor Green
    }

    if ($DoCsv) {
        $csvPath = Join-Path -Path $OutputPath -ChildPath "SysAdminToolbox_${ComputerName}_$Timestamp.csv"
        $rows = @(
            [PSCustomObject]@{ Hostname=$ComputerName; Pillar="Identity & Join"; Status=$Bundle.Identity.Status; Finding=$Bundle.Identity.JoinTopology; Details=$Bundle.Identity.Summary },
            [PSCustomObject]@{ Hostname=$ComputerName; Pillar="BitLocker & TPM"; Status=$Bundle.BitLocker.Status; Finding=$Bundle.BitLocker.TpmStatus; Details=$Bundle.BitLocker.Summary },
            [PSCustomObject]@{ Hostname=$ComputerName; Pillar="Microsoft Defender"; Status=$Bundle.Defender.Status; Finding="RTP=$($Bundle.Defender.RealTimeProtection), Tamper=$($Bundle.Defender.TamperProtection)"; Details=$Bundle.Defender.Summary },
            [PSCustomObject]@{ Hostname=$ComputerName; Pillar="Network & DNS"; Status=$Bundle.Network.Status; Finding="Gateway=$($Bundle.Network.DefaultGateway)"; Details=$Bundle.Network.Summary },
            [PSCustomObject]@{ Hostname=$ComputerName; Pillar="FortiGate / Azure VPN"; Status=$Bundle.VpnRouting.Status; Finding=$Bundle.VpnRouting.TunnelMode; Details=$Bundle.VpnRouting.Summary },
            [PSCustomObject]@{ Hostname=$ComputerName; Pillar="Windows Update"; Status=$Bundle.WinUpdate.Status; Finding="PendingReboot=$($Bundle.WinUpdate.PendingReboot)"; Details=$Bundle.WinUpdate.Summary }
        )
        $rows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
        Write-Host "[+] CSV Summary exported: $csvPath" -ForegroundColor Green
    }

    if ($DoHtml) {
        $htmlPath = Join-Path -Path $OutputPath -ChildPath "SysAdminToolbox_${ComputerName}_$Timestamp.html"
        function Get-HtmlBadge {
            param([string]$St)
            switch ($St) {
                "Pass"    { return "<span class='badge pass'>PASS</span>" }
                "Warning" { return "<span class='badge warn'>WARNING</span>" }
                "Fail"    { return "<span class='badge fail'>FAIL</span>" }
                default   { return "<span class='badge info'>INFO</span>" }
            }
        }

        $scColor = if ($scoreObj.Score -ge 80) { "#10b981" } elseif ($scoreObj.Score -ge 60) { "#f59e0b" } else { "#ef4444" }

        $blRows = ($Bundle.BitLocker.Volumes | ForEach-Object {
            "<tr><td><strong>$(ConvertTo-HtmlSafe $_.MountPoint)</strong></td><td>$(ConvertTo-HtmlSafe $_.VolumeStatus)</td><td>$(ConvertTo-HtmlSafe $_.ProtectionStatus)</td><td>$(ConvertTo-HtmlSafe $_.EncryptionPercentage) ($(ConvertTo-HtmlSafe $_.EncryptionMethod))</td><td>$(ConvertTo-HtmlSafe $_.RecoveryKeyReady)</td><td>$(Get-HtmlBadge $_.Status)</td></tr>"
        }) -join "`n"

        $latRows = ($Bundle.Network.Latency | ForEach-Object {
            "<tr><td><strong>$(ConvertTo-HtmlSafe $_.Label)</strong></td><td><code>$(ConvertTo-HtmlSafe $_.Target)</code></td><td>$(ConvertTo-HtmlSafe $_.PacketLoss)</td><td>$(ConvertTo-HtmlSafe $_.AvgMs)</td><td>$(ConvertTo-HtmlSafe $_.JitterMs)</td><td>$(Get-HtmlBadge $_.Status)</td></tr>"
        }) -join "`n"

        $dnsRows = ($Bundle.Network.Dns | ForEach-Object {
            "<tr><td>$(ConvertTo-HtmlSafe $_.Resolver)</td><td><code>$(ConvertTo-HtmlSafe $_.QueryName)</code></td><td><code>$(ConvertTo-HtmlSafe $_.Result)</code></td><td>$(ConvertTo-HtmlSafe $_.DurationMs)</td><td>$(Get-HtmlBadge $_.Status)</td></tr>"
        }) -join "`n"

        $portRows = ($Bundle.Network.Ports | ForEach-Object {
            "<tr><td>$(ConvertTo-HtmlSafe $_.Service)</td><td><code>$(ConvertTo-HtmlSafe $_.Target)</code></td><td><strong>$(ConvertTo-HtmlSafe $_.State)</strong></td><td>$(ConvertTo-HtmlSafe $_.LatencyMs)</td><td>$(Get-HtmlBadge $_.Status)</td></tr>"
        }) -join "`n"

        $vpnAdapterRows = if ($Bundle.VpnRouting.Adapters.Count -gt 0) {
            ($Bundle.VpnRouting.Adapters | ForEach-Object {
                "<tr><td><strong>$(ConvertTo-HtmlSafe $_.Name)</strong></td><td>$(ConvertTo-HtmlSafe $_.Vendor)</td><td>$(ConvertTo-HtmlSafe $_.Status)</td><td><code>$(ConvertTo-HtmlSafe $_.IPv4)</code></td><td>$(ConvertTo-HtmlSafe $_.Description)</td></tr>"
            }) -join "`n"
        } else {
            "<tr><td colspan='5'>No FortiGate, Azure VPN, or third-party VPN interfaces detected on this endpoint.</td></tr>"
        }

        $routeRows = ($Bundle.VpnRouting.Routes | ForEach-Object {
            "<tr><td><code>$(ConvertTo-HtmlSafe $_.Destination)</code></td><td><code>$(ConvertTo-HtmlSafe $_.NextHop)</code></td><td>$(ConvertTo-HtmlSafe $_.InterfaceAlias)</td><td>$($_.EffectiveMetric)</td><td>$(ConvertTo-HtmlSafe $_.IsVpnRoute)</td></tr>"
        }) -join "`n"

        $svcRows = ($Bundle.WinUpdate.Services | ForEach-Object {
            "<tr><td><code>$(ConvertTo-HtmlSafe $_.Name)</code></td><td>$(ConvertTo-HtmlSafe $_.DisplayName)</td><td>$(ConvertTo-HtmlSafe $_.Status)</td><td>$(ConvertTo-HtmlSafe $_.StartType)</td><td>$(Get-HtmlBadge $_.Health)</td></tr>"
        }) -join "`n"

        $hfRows = if ($Bundle.WinUpdate.RecentHotfixes.Count -gt 0) {
            ($Bundle.WinUpdate.RecentHotfixes | ForEach-Object {
                "<tr><td><strong>$(ConvertTo-HtmlSafe $_.HotFixID)</strong></td><td>$(ConvertTo-HtmlSafe $_.Description)</td><td>$(ConvertTo-HtmlSafe $_.InstalledOn)</td><td>$(ConvertTo-HtmlSafe $_.InstalledBy)</td></tr>"
            }) -join "`n"
        } else {
            "<tr><td colspan='4'>No hotfix records returned.</td></tr>"
        }

        $htmlDoc = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>$ToolTitle — Created by Jobaer ($ComputerName)</title>
<style>
  body { margin:0; font-family:'Segoe UI',system-ui,sans-serif; background:#0b1120; color:#f1f5f9; padding:26px 20px 56px; }
  .wrap { max-width:1240px; margin:0 auto; }
  .banner { background:linear-gradient(135deg,#0f172a,#1e293b); border:1px solid #334155; border-radius:14px; padding:22px 26px; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:16px; margin-bottom:22px; }
  .creator-pill { display:inline-block; background:rgba(56,189,248,0.16); color:#38bdf8; border:1px solid rgba(56,189,248,0.4); padding:4px 12px; border-radius:99px; font-size:0.76rem; font-weight:700; letter-spacing:0.06em; text-transform:uppercase; margin-bottom:6px; }
  h1 { margin:0; font-size:1.45rem; color:#fff; }
  .sub { margin:4px 0 0; font-size:0.85rem; color:#94a3b8; }
  .score-box { text-align:right; }
  .score-num { font-size:1.85rem; font-weight:700; color:$scColor; }
  .btn { background:#38bdf8; color:#0f172a; border:none; padding:8px 14px; border-radius:8px; font-weight:600; cursor:pointer; margin-top:6px; }
  .kpi-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(190px,1fr)); gap:12px; margin-bottom:22px; }
  .kpi { background:#111827; border:1px solid #334155; border-radius:12px; padding:14px 16px; }
  .kpi-t { font-size:0.74rem; text-transform:uppercase; color:#94a3b8; letter-spacing:0.05em; }
  .kpi-v { font-size:1.05rem; font-weight:700; margin-top:6px; color:#fff; }
  section { background:#111827; border:1px solid #334155; border-radius:14px; padding:18px 22px; margin-bottom:18px; }
  h2 { margin:0 0 12px; font-size:1.08rem; color:#38bdf8; border-bottom:1px solid #1e293b; padding-bottom:8px; display:flex; justify-content:space-between; align-items:center; }
  table { width:100%; border-collapse:collapse; font-size:0.84rem; margin-bottom:10px; }
  th { text-align:left; padding:8px 10px; background:#0f172a; color:#94a3b8; font-size:0.73rem; text-transform:uppercase; border-bottom:1px solid #334155; }
  td { padding:9px 10px; border-bottom:1px solid rgba(51,65,85,0.45); vertical-align:top; }
  code { background:#0f172a; color:#e2e8f0; padding:2px 6px; border-radius:5px; font-size:0.79rem; }
  .badge { display:inline-block; padding:2px 9px; border-radius:99px; font-size:0.72rem; font-weight:700; }
  .pass { background:rgba(16,185,129,0.16); color:#34d399; border:1px solid rgba(16,185,129,0.35); }
  .warn { background:rgba(245,158,11,0.16); color:#fbbf24; border:1px solid rgba(245,158,11,0.35); }
  .fail { background:rgba(239,68,68,0.16); color:#f87171; border:1px solid rgba(239,68,68,0.35); }
  .info { background:rgba(56,189,248,0.16); color:#38bdf8; border:1px solid rgba(56,189,248,0.35); }
  .note { background:#0f172a; border-left:3px solid #38bdf8; padding:9px 12px; border-radius:6px; font-size:0.84rem; color:#cbd5e1; margin-top:8px; }
  footer { text-align:center; color:#94a3b8; font-size:0.82rem; margin-top:26px; }
  footer a { color:#38bdf8; text-decoration:none; }
  @media print { body { background:#fff; color:#111; } .banner, .kpi, section, code, .note { background:#fff; color:#111; border-color:#cbd5e1; } .btn { display:none; } }
</style>
</head>
<body>
<div class="wrap">
  <div class="banner">
    <div>
      <div class="creator-pill">Created by Jobaer</div>
      <h1>$ToolTitle</h1>
      <p class="sub">$AuthorLine &bull; $LicenseLine</p>
      <p class="sub">Host: <strong>$(ConvertTo-HtmlSafe $ComputerName)</strong> &bull; OS: $(ConvertTo-HtmlSafe $OsCaption) &bull; Generated: $($RunDate.ToString("yyyy-MM-dd HH:mm:ss"))</p>
    </div>
    <div class="score-box">
      <div style="font-size:0.75rem;color:#94a3b8;text-transform:uppercase;">Health Score</div>
      <div class="score-num">$($scoreObj.Score)/100 (Grade $($scoreObj.Grade))</div>
      <button class="btn" onclick="window.print()">Print / Save PDF</button>
    </div>
  </div>

  <div class="kpi-grid">
    <div class="kpi"><div class="kpi-t">Identity &amp; Join</div><div class="kpi-v">$(Get-HtmlBadge $Bundle.Identity.Status)</div></div>
    <div class="kpi"><div class="kpi-t">BitLocker &amp; TPM</div><div class="kpi-v">$(Get-HtmlBadge $Bundle.BitLocker.Status)</div></div>
    <div class="kpi"><div class="kpi-t">Microsoft Defender</div><div class="kpi-v">$(Get-HtmlBadge $Bundle.Defender.Status)</div></div>
    <div class="kpi"><div class="kpi-t">Network &amp; DNS</div><div class="kpi-v">$(Get-HtmlBadge $Bundle.Network.Status)</div></div>
    <div class="kpi"><div class="kpi-t">FortiGate / Azure VPN</div><div class="kpi-v">$(Get-HtmlBadge $Bundle.VpnRouting.Status)</div></div>
    <div class="kpi"><div class="kpi-t">Windows Update</div><div class="kpi-v">$(Get-HtmlBadge $Bundle.WinUpdate.Status)</div></div>
  </div>

  <section>
    <h2>1. Identity, Entra ID / AD Join &amp; Intune MDM Health $(Get-HtmlBadge $Bundle.Identity.Status)</h2>
    <table>
      <tbody>
        <tr><td style="width:240px;"><strong>Join Topology</strong></td><td>$(ConvertTo-HtmlSafe $Bundle.Identity.JoinTopology)</td></tr>
        <tr><td><strong>AzureAdJoined / DomainJoined</strong></td><td>AzureAdJoined = <code>$(ConvertTo-HtmlSafe $Bundle.Identity.AzureAdJoined)</code> | DomainJoined = <code>$(ConvertTo-HtmlSafe $Bundle.Identity.DomainJoined)</code> ($(ConvertTo-HtmlSafe $Bundle.Identity.DomainName))</td></tr>
        <tr><td><strong>Tenant &amp; Device ID</strong></td><td>$(ConvertTo-HtmlSafe $Bundle.Identity.TenantName) &bull; DeviceId: <code>$(ConvertTo-HtmlSafe $Bundle.Identity.DeviceId)</code></td></tr>
        <tr><td><strong>Azure AD PRT (SSO Token)</strong></td><td><code>$(ConvertTo-HtmlSafe $Bundle.Identity.AzureAdPrt)</code> (Updated: $(ConvertTo-HtmlSafe $Bundle.Identity.PrtUpdateTime))</td></tr>
        <tr><td><strong>Intune MDM &amp; IME Service</strong></td><td>$(ConvertTo-HtmlSafe $Bundle.Identity.IntuneEnrolled) &bull; IME: $(ConvertTo-HtmlSafe $Bundle.Identity.ImeService)</td></tr>
      </tbody>
    </table>
    <div class="note">$(ConvertTo-HtmlSafe $Bundle.Identity.Summary)</div>
  </section>

  <section>
    <h2>2. BitLocker &amp; TPM Recovery Readiness $(Get-HtmlBadge $Bundle.BitLocker.Status)</h2>
    <p style="font-size:0.84rem;color:#cbd5e1;"><strong>TPM:</strong> $(ConvertTo-HtmlSafe $Bundle.BitLocker.TpmStatus) &nbsp;|&nbsp; <strong>Secure Boot:</strong> $(ConvertTo-HtmlSafe $Bundle.BitLocker.SecureBoot)</p>
    <table>
      <thead><tr><th>Drive</th><th>Volume Status</th><th>Protection</th><th>Encryption</th><th>Recovery Key Readiness</th><th>Status</th></tr></thead>
      <tbody>$blRows</tbody>
    </table>
  </section>

  <section>
    <h2>3. Microsoft Defender &amp; Endpoint Security Posture $(Get-HtmlBadge $Bundle.Defender.Status)</h2>
    <table>
      <tbody>
        <tr><td style="width:240px;"><strong>Real-Time &amp; Behavior Protection</strong></td><td>Antivirus: <code>$(ConvertTo-HtmlSafe $Bundle.Defender.AntivirusEnabled)</code> | Real-Time: <code>$(ConvertTo-HtmlSafe $Bundle.Defender.RealTimeProtection)</code> | Behavior Monitor: <code>$(ConvertTo-HtmlSafe $Bundle.Defender.BehaviorMonitor)</code></td></tr>
        <tr><td><strong>Tamper Protection &amp; UAC</strong></td><td>Tamper Protection: <code>$(ConvertTo-HtmlSafe $Bundle.Defender.TamperProtection)</code> | UAC: <code>$(ConvertTo-HtmlSafe $Bundle.Defender.UacStatus)</code></td></tr>
        <tr><td><strong>Signature Version &amp; Scan Age</strong></td><td>$(ConvertTo-HtmlSafe $Bundle.Defender.SignatureVersion) (Age: $(ConvertTo-HtmlSafe $Bundle.Defender.SignatureAgeDays) | Quick Scan: $(ConvertTo-HtmlSafe $Bundle.Defender.QuickScanAgeDays))</td></tr>
        <tr><td><strong>Windows Defender Firewall</strong></td><td>$(ConvertTo-HtmlSafe $Bundle.Defender.FirewallProfiles)</td></tr>
      </tbody>
    </table>
  </section>

  <section>
    <h2>4. Network Latency, DNS Resolution &amp; Port Reachability $(Get-HtmlBadge $Bundle.Network.Status)</h2>
    <table>
      <thead><tr><th>Endpoint</th><th>Target</th><th>Packet Loss</th><th>Avg Latency</th><th>Jitter</th><th>Status</th></tr></thead>
      <tbody>$latRows</tbody>
    </table>
    <table>
      <thead><tr><th>DNS Resolver</th><th>Query</th><th>Resolved IP</th><th>Duration</th><th>Status</th></tr></thead>
      <tbody>$dnsRows</tbody>
    </table>
    <table>
      <thead><tr><th>Service</th><th>Target:Port</th><th>Port State</th><th>Connect Time</th><th>Status</th></tr></thead>
      <tbody>$portRows</tbody>
    </table>
  </section>

  <section>
    <h2>5. FortiGate &amp; Azure VPN Route Tester $(Get-HtmlBadge $Bundle.VpnRouting.Status)</h2>
    <p style="font-size:0.84rem;color:#cbd5e1;"><strong>Tunnel Mode:</strong> $(ConvertTo-HtmlSafe $Bundle.VpnRouting.TunnelMode)</p>
    <table>
      <thead><tr><th>Interface / Profile</th><th>VPN Vendor / Type</th><th>Status</th><th>Tunnel IP</th><th>Details</th></tr></thead>
      <tbody>$vpnAdapterRows</tbody>
    </table>
    <table>
      <thead><tr><th>Destination Prefix</th><th>Next Hop</th><th>Interface</th><th>Metric</th><th>Classification</th></tr></thead>
      <tbody>$routeRows</tbody>
    </table>
  </section>

  <section>
    <h2>6. Windows Update &amp; Servicing Diagnostics $(Get-HtmlBadge $Bundle.WinUpdate.Status)</h2>
    <p style="font-size:0.84rem;color:#cbd5e1;"><strong>Update Source:</strong> $(ConvertTo-HtmlSafe $Bundle.WinUpdate.UpdateSource) &nbsp;|&nbsp; <strong>Pending Reboot:</strong> $(ConvertTo-HtmlSafe $Bundle.WinUpdate.PendingReboot) &nbsp;|&nbsp; <strong>Last Patch Age:</strong> $(ConvertTo-HtmlSafe $Bundle.WinUpdate.DaysSinceLastPatch)</p>
    <table>
      <thead><tr><th>Service</th><th>Display Name</th><th>Status</th><th>Startup Type</th><th>Health</th></tr></thead>
      <tbody>$svcRows</tbody>
    </table>
    <table>
      <thead><tr><th>KB ID</th><th>Description</th><th>Installed On</th><th>Installed By</th></tr></thead>
      <tbody>$hfRows</tbody>
    </table>
  </section>

  <footer>
    <strong>Created by Jobaer</strong> &mdash; $ToolTitle<br>
    Author: S M Jobaer Alam | <a href="https://www.jobaeralam.com">www.jobaeralam.com</a> | <a href="mailto:hello@jobaeralam.com">hello@jobaeralam.com</a> | License: Freeware
  </footer>
</div>
</body>
</html>
"@
        $htmlDoc | Out-File -FilePath $htmlPath -Encoding UTF8
        Write-Host "[+] HTML Report exported: $htmlPath" -ForegroundColor Green
        if ($DoOpen) {
            Start-Process $htmlPath
        }
    }
}
#endregion

#region Execution Orchestrator
function Invoke-FullDiagnostics {
    param([switch]$UseDemo, [string]$VpnTarget = "")
    if ($UseDemo) {
        Write-Host "[*] Running in DEMO MODE (offline enterprise diagnostic simulation)..." -ForegroundColor Yellow
        return Get-DemoDiagnosticsData
    }

    Write-Host "[*] Running single-pane endpoint & network health diagnostics..." -ForegroundColor Cyan
    $idData  = Get-IdentityJoinDiagnostics
    $blData  = Get-BitLockerDiagnostics
    $defData = Get-DefenderSecurityDiagnostics
    $netData = Invoke-NetworkDiagnostics -Resolvers $DnsServers
    $vpnData = Test-VpnRoutingDiagnostics -TargetHost $VpnTarget
    $wuData  = Get-WindowsUpdateDiagnostics

    return [PSCustomObject]@{
        Identity   = $idData
        BitLocker  = $blData
        Defender   = $defData
        Network    = $netData
        VpnRouting = $vpnData
        WinUpdate  = $wuData
    }
}

function Show-FullSinglePaneReport {
    param($Bundle)
    $scoreObj = Get-OverallHealthScore -Bundle $Bundle
    Show-IdentityConsole  -Data $Bundle.Identity
    Show-BitLockerConsole -Data $Bundle.BitLocker
    Show-DefenderConsole  -Data $Bundle.Defender
    Show-NetworkConsole   -Data $Bundle.Network
    Show-VpnConsole       -Data $Bundle.VpnRouting
    Show-WinUpdateConsole -Data $Bundle.WinUpdate

    $scColor = if ($scoreObj.Score -ge 80) { "Green" } elseif ($scoreObj.Score -ge 60) { "Yellow" } else { "Red" }
    Write-Host ""
    Write-Host "================================================================================" -ForegroundColor $scColor
    Write-Host ("  SINGLE-PANE HEALTH SCORE: {0}/100 (Grade {1})   |   Created by Jobaer" -f $scoreObj.Score, $scoreObj.Grade) -ForegroundColor $scColor
    Write-Host "================================================================================" -ForegroundColor $scColor
    Write-Host ""
}

# Main Entry Point
Show-JobaerBanner

if (-not $IsAdmin -and -not $DemoMode) {
    Write-Host "[!] TIP: Running without Administrator privileges. Some BitLocker/TPM/Update checks may be restricted." -ForegroundColor Yellow
    Write-Host "    Right-click Run-SysAdminToolbox.ps1 -> Run with PowerShell (Admin) for full diagnostics." -ForegroundColor Gray
    Write-Host ""
}

if ($RunAll -or $DemoMode) {
    $bundle = Invoke-FullDiagnostics -UseDemo:$DemoMode -VpnTarget $VpnTestTarget
    Show-FullSinglePaneReport -Bundle $bundle
    if ($ExportHtml -or $ExportJson -or $ExportCsv) {
        Export-DiagnosticReports -Bundle $bundle -DoHtml:$ExportHtml -DoJson:$ExportJson -DoCsv:$ExportCsv -DoOpen:$OpenReport
    }
    exit 0
}

# Interactive Single-Pane Menu Loop
while ($true) {
    Write-Host "  SELECT DIAGNOSTIC MODULE:" -ForegroundColor Cyan
    Write-Host "  [1] Single-Pane Full Health Check (All Modules)" -ForegroundColor White
    Write-Host "  [2] Identity, Entra/AD Join & Intune MDM Health (dsregcmd /status)" -ForegroundColor White
    Write-Host "  [3] BitLocker & TPM Recovery Readiness" -ForegroundColor White
    Write-Host "  [4] Microsoft Defender & Endpoint Security Posture" -ForegroundColor White
    Write-Host "  [5] Network Latency, DNS Resolution & TCP Port Reachability" -ForegroundColor White
    Write-Host "  [6] FortiGate & Azure VPN Route Tester (+ Custom Target Probe)" -ForegroundColor White
    Write-Host "  [7] Windows Update & Servicing Diagnostics" -ForegroundColor White
    Write-Host "  [8] Export Full HTML + JSON + CSV Support Bundle (Open Report)" -ForegroundColor Green
    Write-Host "  [9] Run Demo Mode (Offline Enterprise Simulation + Export HTML)" -ForegroundColor Yellow
    Write-Host "  [0] Exit" -ForegroundColor Gray
    Write-Host ""

    $choice = Read-Host "  Enter choice [0-9]"
    switch ($choice.Trim()) {
        "1" {
            $bundle = Invoke-FullDiagnostics -VpnTarget $VpnTestTarget
            Show-FullSinglePaneReport -Bundle $bundle
            $exp = Read-Host "  Export HTML + JSON report to .\Reports? [Y/N]"
            if ($exp -match '^[Yy]') {
                Export-DiagnosticReports -Bundle $bundle -DoHtml -DoJson -DoOpen
            }
        }
        "2" {
            $d = Get-IdentityJoinDiagnostics
            Show-IdentityConsole -Data $d
        }
        "3" {
            $d = Get-BitLockerDiagnostics
            Show-BitLockerConsole -Data $d
        }
        "4" {
            $d = Get-DefenderSecurityDiagnostics
            Show-DefenderConsole -Data $d
        }
        "5" {
            $d = Invoke-NetworkDiagnostics -Resolvers $DnsServers
            Show-NetworkConsole -Data $d
        }
        "6" {
            $customTarget = Read-Host "  Optional internal VPN IP/hostname to probe (or press Enter to inspect VPN adapters & routes)"
            $d = Test-VpnRoutingDiagnostics -TargetHost $customTarget
            Show-VpnConsole -Data $d
        }
        "7" {
            $d = Get-WindowsUpdateDiagnostics
            Show-WinUpdateConsole -Data $d
        }
        "8" {
            $bundle = Invoke-FullDiagnostics -VpnTarget $VpnTestTarget
            Show-FullSinglePaneReport -Bundle $bundle
            Export-DiagnosticReports -Bundle $bundle -DoHtml -DoJson -DoCsv -DoOpen
        }
        "9" {
            $bundle = Invoke-FullDiagnostics -UseDemo
            Show-FullSinglePaneReport -Bundle $bundle
            Export-DiagnosticReports -Bundle $bundle -DoHtml -DoJson -DoCsv -DoOpen
        }
        "0" {
            Write-Host "`n  Thank you for using $ToolTitle — Created by Jobaer!`n" -ForegroundColor Cyan
            exit 0
        }
        default {
            Write-Host "  [!] Invalid selection. Please enter a number between 0 and 9." -ForegroundColor Yellow
        }
    }
    Write-Host ""
}
