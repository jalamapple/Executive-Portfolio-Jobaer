# Changelog

## v1.4.0 (2026)
- Added **"Created by Jobaer"** ASCII console banner and HTML/JSON report branding.
- Added single-pane diagnostics for `dsregcmd /status`, Entra/AD/Hybrid join topology, Azure AD PRT, Intune MDM enrollment, BitLocker recovery key readiness, TPM 2.0, and Microsoft Defender posture.
- Added built-in network latency/jitter/loss tester, multi-resolver DNS benchmark, fast async TCP port reachability scanner, and FortiGate / Azure VPN route & split-tunnel analyzer.
- Added Windows Update servicing stack, 4-point pending reboot detector, WUfB/WSUS policy check, and recent KB hotfix audit.
- Added interactive menu mode, `-RunAll` unattended CLI mode, `-DemoMode`, and HTML/JSON/CSV report exporters.
