@echo off
title Windows Endpoint & Network Health Toolbox (v1.4.0) - Created by Jobaer
color 0B

:: Check for Administrator privileges and auto-elevate via UAC if needed
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges for Windows Endpoint ^& Network Health Toolbox...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

where pwsh.exe >nul 2>&1 && (set "PS_EXE=pwsh.exe") || (set "PS_EXE=powershell.exe")
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-SysAdminToolbox.ps1"
pause
