'use strict';
(() => {
  // =====================================================================
  // Safe HTML templating: every interpolated value is escaped unless raw()
  // =====================================================================
  class Raw { constructor(s) { this.s = s; } }
  const raw = (s) => new Raw(String(s));
  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ESC[c]);
  const val = (v) => (v instanceof Raw ? v.s : Array.isArray(v) ? v.map(val).join('')
    : v === null || v === undefined || v === false ? '' : esc(v));
  const html = (strings, ...vals) => {
    let out = strings[0];
    for (let i = 0; i < vals.length; i++) out += val(vals[i]) + strings[i + 1];
    return raw(out);
  };
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];

  // =====================================================================
  // State, formatting, API
  // =====================================================================
  const PRODUCT = { name: 'Enterprise Inventory', author: 'Jobaer Alam' };
  const S = { user: null, settings: { currency: 'USD', companyName: PRODUCT.name }, lookups: null, navSeq: 0, refocus: null };
  const can = (p) => Boolean(S.user && S.user.permissions.includes(p));

  let moneyFmt;
  const fmt = {
    num: (n) => (n === null || n === undefined ? '—' : Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 })),
    money: (n) => {
      if (n === null || n === undefined) return '—';
      if (!moneyFmt) {
        try { moneyFmt = new Intl.NumberFormat(undefined, { style: 'currency', currency: S.settings.currency }); }
        catch { moneyFmt = new Intl.NumberFormat(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
      }
      return moneyFmt.format(n);
    },
    date: (iso) => (iso ? new Date(iso.length === 10 ? iso + 'T00:00:00' : iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—'),
    dt: (iso) => (iso ? new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—'),
  };

  class ApiError extends Error {
    constructor(message, status, details) { super(message); this.status = status; this.details = details; }
  }

  async function api(method, url, body) {
    const headers = { Accept: 'application/json', 'X-Requested-With': 'fetch' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const res = await fetch(url, { method, headers, credentials: 'same-origin', body: body !== undefined ? JSON.stringify(body) : undefined });
    let data = null;
    try { data = await res.json(); } catch { /* empty body */ }
    if (res.status === 401 && !url.startsWith('/api/auth/login')) {
      const hadSession = Boolean(S.user);
      S.user = null;
      closeModal();
      renderLogin(hadSession ? 'Your session has expired. Please sign in again.' : '');
      throw new ApiError('Authentication required', 401);
    }
    if (!res.ok) throw new ApiError((data && data.error) || `Request failed (${res.status})`, res.status, data && data.details);
    return data;
  }
  const GET = (u) => api('GET', u);
  const POST = (u, b) => api('POST', u, b);
  const PUT = (u, b) => api('PUT', u, b);
  const DEL = (u) => api('DELETE', u);

  const qs = (obj) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(obj)) if (v !== '' && v !== null && v !== undefined) p.set(k, v);
    return p.toString();
  };

  async function lookups(force = false) {
    if (!S.lookups || force) S.lookups = await GET('/api/lookups');
    return S.lookups;
  }
  const KIND_LABEL = { WAREHOUSE: 'Warehouse', SALES_CENTER: 'Sales center' };
  const locLabel = (w) => `${w.code} — ${w.name}${w.kind === 'SALES_CENTER' ? ' (sales center)' : ''}`;
  const whOptions = (all = false, kind = null) => S.lookups.warehouses
    .filter((w) => (all || w.active) && (!kind || w.kind === kind)).map((w) => ({ value: w.id, label: locLabel(w) }));
  const productOptions = () => S.lookups.products.filter((p) => p.active).map((p) => ({ value: p.id, label: `${p.sku} — ${p.name}` }));
  const nameOptions = (list, all = false) => list.filter((x) => all || x.active === undefined || x.active).map((x) => ({ value: x.id, label: x.name }));

  // =====================================================================
  // Icons
  // =====================================================================
  const ICONS = {
    home: 'M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
    box: 'M21 8 12 3 3 8v8l9 5 9-5zM3 8l9 5 9-5M12 13v8',
    layers: 'M12 2 2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
    swap: 'M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7',
    alert: 'M12 3 2 20h20zM12 10v4M12 17h.01',
    truck: 'M3 6h11v10H3zM14 10h4l3 3v3h-7zM6.5 19.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM17.5 19.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z',
    cart: 'M3 4h2l2.4 11h11l2-8H6.2M9.5 20a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM18 20a1 1 0 1 0 0-2 1 1 0 0 0 0 2z',
    factory: 'M3 21V10l6 4V10l6 4V4h6v17zM3 21h18',
    users: 'M16 20v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1M9.5 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM21 20v-1a4 4 0 0 0-3-3.9M16 4.1a3.5 3.5 0 0 1 0 6.8',
    building: 'M4 21V5l8-3 8 3v16M4 21h16M9 9h.01M15 9h.01M9 13h.01M15 13h.01M10 21v-4h4v4',
    tag: 'M3 12V3h9l9 9-9 9zM7.5 7.5h.01',
    chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
    shield: 'M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6zM9 12l2 2 4-4',
    key: 'M14.5 4a5.5 5.5 0 1 1-4.9 8L3 18.6V21h3v-2h2v-2h2l1.4-1.4A5.5 5.5 0 0 1 14.5 4zM16 8h.01',
    search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-5-5',
    menu: 'M4 6h16M4 12h16M4 18h16',
    logout: 'M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 17l5-5-5-5M15 12H3',
    plus: 'M12 5v14M5 12h14',
    download: 'M12 4v12M7 11l5 5 5-5M4 20h16',
    print: 'M6 9V3h12v6M6 18H4v-7h16v7h-2M8 14h8v7H8z',
    pdf: 'M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8zM14 3v5h5M9 13h6M9 17h6',
    upload: 'M12 16V4M7 9l5-5 5 5M4 20h16',
    undo: 'M9 14 4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3',
    store: 'M4 10v10h16V10M3 4h18l-1 6H4zM9 20v-5h6v5',
    palette: 'M12 3a9 9 0 1 0 0 18c1 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1 0-.8.7-1.5 1.5-1.5H16a5 5 0 0 0 5-5c0-4.4-4-7.8-9-7.8zM7.5 12.5h.01M9.5 8h.01M14.5 8h.01M17 11.5h.01',
  };
  const icon = (name) => raw(`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${ICONS[name]}"/></svg>`);

  // =====================================================================
  // UI primitives: toast, modal, form fields, tables, badges
  // =====================================================================
  function toast(message, type = '') {
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.textContent = message;
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), type === 'error' ? 6000 : 3500);
  }

  let modalClose = null;
  function closeModal() { if (modalClose) modalClose(false); modalClose = null; }

  function openModal({ title, body, submitLabel = 'Save', onSubmit, wide = false, danger = false, onClose }) {
    closeModal();
    const root = $('#modal-root');
    root.innerHTML = html`<div class="modal-backdrop"><form class="modal${wide ? ' wide' : ''}" novalidate autocomplete="off">
      <header><h2>${title}</h2><button type="button" class="icon-btn" data-close aria-label="Close">×</button></header>
      <div class="modal-body">${body}</div>
      <div class="form-error" hidden></div>
      <footer><button type="button" class="btn" data-close>${onSubmit ? 'Cancel' : 'Close'}</button>
        ${onSubmit ? html`<button type="submit" class="btn ${danger ? 'danger' : 'primary'}">${submitLabel}</button>` : ''}</footer>
    </form></div>`.s;
    const backdrop = root.firstElementChild;
    const form = $('form', root);
    const onKey = (e) => { if (e.key === 'Escape') close(false); };
    function close(result) {
      if (!root.contains(form)) return;
      root.innerHTML = '';
      document.removeEventListener('keydown', onKey);
      if (modalClose === close) modalClose = null;
      if (onClose) onClose(result);
    }
    document.addEventListener('keydown', onKey);
    $$('[data-close]', form).forEach((b) => b.addEventListener('click', () => close(false)));
    backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop) close(false); });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!onSubmit) return;
      const btn = $('button[type=submit]', form);
      btn.disabled = true;
      clearFormErrors(form);
      try {
        const r = await onSubmit(form);
        if (r !== false) close(true);
      } catch (err) {
        if (err.status !== 401) showFormError(form, err);
      } finally { btn.disabled = false; }
    });
    setTimeout(() => { const f = $('input:not([type=checkbox]):not([readonly]), select, textarea', form); if (f) f.focus(); }, 30);
    modalClose = close;
    return { form, close };
  }

  function confirmDialog(title, message, { label = 'Confirm', danger = false } = {}) {
    return new Promise((resolve) => {
      openModal({ title, body: html`<p>${message}</p>`, submitLabel: label, danger, onSubmit: async () => {}, onClose: (r) => resolve(Boolean(r)) });
    });
  }

  function clearFormErrors(form) {
    $$('.invalid', form).forEach((el) => el.classList.remove('invalid'));
    $$('.field-error', form).forEach((el) => { el.textContent = ''; });
    $('.form-error', form).hidden = true;
  }

  function showFormError(form, err) {
    const box = $('.form-error', form);
    const extra = [];
    if (err.details && typeof err.details === 'object' && !Array.isArray(err.details)) {
      for (const [k, msg] of Object.entries(err.details)) {
        if (typeof msg !== 'string') continue;
        const el = form.elements[k];
        const fe = el && el.classList ? el.closest('.field') && el.closest('.field').querySelector('.field-error') : null;
        if (fe) { el.classList.add('invalid'); fe.textContent = msg; }
        else extra.push(`${k.replace(/_/g, ' ')} ${msg}`);
      }
    }
    box.textContent = err.message + (extra.length ? ` — ${extra.join('; ')}` : '');
    box.hidden = false;
  }

  function field(f, v) {
    const id = `f_${f.name}`;
    const req = f.required ? raw(' required') : '';
    let input;
    if (f.type === 'checkbox') {
      return html`<div class="field ${f.full ? 'full' : ''}"><label class="check"><input type="checkbox" name="${f.name}" ${v ? raw('checked') : ''}> ${f.label}</label></div>`;
    }
    if (f.type === 'select') {
      input = html`<select id="${id}" name="${f.name}"${req}>
        ${f.placeholder !== false ? html`<option value="">${f.placeholder || (f.required ? 'Select…' : '—')}</option>` : ''}
        ${f.options.map((o) => html`<option value="${o.value}"${String(o.value) === String(v ?? '') ? raw(' selected') : ''}>${o.label}</option>`)}
      </select>`;
    } else if (f.type === 'textarea') {
      input = html`<textarea id="${id}" name="${f.name}" rows="3"${req}>${v ?? ''}</textarea>`;
    } else {
      input = html`<input id="${id}" name="${f.name}" type="${f.type || 'text'}" value="${v ?? ''}"${req}
        ${f.step ? raw(`step="${esc(f.step)}"`) : ''} ${f.min !== undefined ? raw(`min="${esc(f.min)}"`) : ''}
        ${f.placeholder ? raw(`placeholder="${esc(f.placeholder)}"`) : ''} ${f.readonly ? raw('readonly') : ''}
        ${f.type === 'password' ? raw('autocomplete="new-password"') : ''}>`;
    }
    return html`<div class="field ${f.full ? 'full' : ''}">
      <label for="${id}">${f.label}${f.required ? html`<span class="req">*</span>` : ''}</label>
      ${input}${f.hint ? html`<small>${f.hint}</small>` : ''}<div class="field-error"></div></div>`;
  }

  function readForm(form, fields) {
    const out = {};
    for (const f of fields) {
      const el = form.elements[f.name];
      if (!el || f.readonly) continue;
      if (f.type === 'checkbox') out[f.name] = el.checked;
      else if (f.type === 'number') out[f.name] = el.value === '' ? null : Number(el.value);
      else if (f.type === 'select' && /^\d+$/.test(el.value)) out[f.name] = Number(el.value);
      else out[f.name] = el.value.trim() === '' ? null : el.value;
    }
    return out;
  }

  function table(cols, rows, { empty = 'No records found', href, foot } = {}) {
    if (!rows.length) return html`<div class="empty">${empty}</div>`;
    return html`<div class="table-wrap"><table>
      <thead><tr>${cols.map((c) => html`<th class="${c.cls || ''}">${c.label}</th>`)}</tr></thead>
      <tbody>${rows.map((r) => html`<tr${href ? html` class="clickable" data-href="${href(r)}"` : ''}>
        ${cols.map((c) => html`<td class="${c.cls || ''}">${c.render ? c.render(r) : r[c.key]}</td>`)}</tr>`)}</tbody>
      ${foot ? html`<tfoot>${foot}</tfoot>` : ''}
    </table></div>`;
  }

  function pager(d) {
    const from = d.total ? d.offset + 1 : 0;
    const to = Math.min(d.offset + d.limit, d.total);
    if (d.total <= d.limit && d.offset === 0) return html`<div class="pager"><span>${fmt.num(d.total)} record${d.total === 1 ? '' : 's'}</span></div>`;
    return html`<div class="pager"><span>Showing ${fmt.num(from)}–${fmt.num(to)} of ${fmt.num(d.total)}</span><div class="actions">
      <button class="btn sm" data-offset="${Math.max(0, d.offset - d.limit)}"${d.offset === 0 ? raw(' disabled') : ''}>Previous</button>
      <button class="btn sm" data-offset="${d.offset + d.limit}"${to >= d.total ? raw(' disabled') : ''}>Next</button></div></div>`;
  }

  /** CSV + PDF download buttons for any export endpoint (base must already contain a "?"). */
  const exportButtons = (base, { compact = false } = {}) => html`<span class="btn-group">
    <a class="btn${compact ? ' sm' : ''}" href="${base}&format=csv" download title="Download as CSV (Excel)">${icon('download')}CSV</a>
    <a class="btn${compact ? ' sm' : ''}" href="${base}&format=pdf" download title="Download a branded PDF report">${icon('pdf')}PDF</a></span>`;
  const kindBadge = (k) => (k === 'SALES_CENTER' ? html`<span class="badge purple">Sales center</span>` : html`<span class="badge blue">Warehouse</span>`);

  const STATUS_COLORS = { DRAFT: '', ORDERED: 'blue', PARTIAL: 'amber', RECEIVED: 'green', CANCELLED: 'red', CONFIRMED: 'purple', SHIPPED: 'green', DISPATCHED: 'amber' };
  const statusBadge = (s) => html`<span class="badge ${STATUS_COLORS[s] || ''}">${s}</span>`;
  const MOVE_COLORS = { RECEIPT: 'green', PO_RECEIPT: 'green', ISSUE: 'amber', SALE: 'blue', ADJUSTMENT: 'red', COUNT: 'purple', TRANSFER_IN: '', TRANSFER_OUT: '' };
  const moveBadge = (t) => html`<span class="badge ${MOVE_COLORS[t] || ''}">${t.replace('_', ' ')}</span>`;
  const activeBadge = (r) => (r.active ? html`<span class="badge green">Active</span>` : html`<span class="badge">Inactive</span>`);
  const ROLE_COLORS = { admin: 'red', manager: 'purple', clerk: 'blue', viewer: '' };
  const roleBadge = (role) => html`<span class="badge ${ROLE_COLORS[role]}">${role}</span>`;
  const qtyCell = (q) => html`<span class="${q > 0 ? 'qty-pos' : 'qty-neg'}">${q > 0 ? '+' : ''}${fmt.num(q)}</span>`;
  const stockBadge = (p) => {
    if (!p.active) return html`<span class="badge">Inactive</span>`;
    if (p.available <= 0) return html`<span class="badge red">Out of stock</span>`;
    if (p.reorder_point > 0 && p.available <= p.reorder_point) return html`<span class="badge amber">Low</span>`;
    return html`<span class="badge green">In stock</span>`;
  };
  const refLink = (m) => {
    if (!m.ref_id) return '—';
    const n = parseInt(String(m.ref_id).split('-')[1], 10);
    if (m.ref_type === 'PO') return html`<a href="#/purchase-orders/${n}">${m.ref_id}</a>`;
    if (m.ref_type === 'SO') return html`<a href="#/sales-orders/${n}">${m.ref_id}</a>`;
    if (m.ref_type === 'RETURN') return html`<a href="#/returns/${n}">${m.ref_id}</a>`;
    if (m.ref_type === 'TRANSFER' || m.ref_type === 'IMPORT') return html`<a href="#/movements?ref=${encodeURIComponent(m.ref_id)}">${m.ref_id}</a>`;
    return m.ref_id;
  };
  const kpi = (label, value, sub, { alert = false, href } = {}) => {
    const inner = html`<div class="label">${label}</div><div class="value">${value}</div>${sub ? html`<div class="sub">${sub}</div>` : ''}`;
    return html`<div class="card kpi${alert ? ' alert' : ''}">${href ? html`<a href="${href}">${inner}</a>` : inner}</div>`;
  };

  // =====================================================================
  // Charts
  // =====================================================================
  function niceMax(n) {
    if (n <= 5) return 5;
    const mag = 10 ** Math.floor(Math.log10(n));
    return [1, 2, 2.5, 5, 10].map((m) => m * mag).find((m) => m >= n);
  }

  function trendChart(data) {
    const W = 640; const H = 220; const L = 40; const R = 8; const T = 10; const B = 26;
    const iw = W - L - R; const ih = H - T - B;
    const max = niceMax(Math.max(1, ...data.flatMap((d) => [d.qty_in, d.qty_out])));
    const gw = iw / data.length; const bw = Math.max(3, (gw - 8) / 2);
    const y = (v) => T + ih - (v / max) * ih;
    const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(max * f));
    return html`<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Inbound and outbound units per day">
      ${ticks.map((t) => html`<line class="grid-line" x1="${L}" x2="${W - R}" y1="${y(t)}" y2="${y(t)}"/><text x="${L - 6}" y="${y(t) + 3}" text-anchor="end">${fmt.num(t)}</text>`)}
      ${data.map((d, i) => {
        const x = L + i * gw + 4;
        const label = new Date(d.day + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
        return html`<rect class="bar-in" x="${x}" y="${y(d.qty_in)}" width="${bw}" height="${ih - (y(d.qty_in) - T)}" rx="2"><title>${label}: ${fmt.num(d.qty_in)} in</title></rect>
          <rect class="bar-out" x="${x + bw}" y="${y(d.qty_out)}" width="${bw}" height="${ih - (y(d.qty_out) - T)}" rx="2"><title>${label}: ${fmt.num(d.qty_out)} out</title></rect>
          ${i % 2 === 0 ? html`<text x="${x + bw}" y="${H - 8}" text-anchor="middle">${label}</text>` : ''}`;
      })}
    </svg>`;
  }

  function bars(list, format = fmt.money) {
    if (!list.length) return html`<div class="empty">No data yet</div>`;
    const max = Math.max(1, ...list.map((x) => x.value));
    return html`<div class="bars">${list.map((x) => html`<div class="bar-row">
      <span class="label" title="${x.name || x.label}">${x.label}</span>
      <div class="track"><div class="fill" style="width:${Math.max(1, (x.value / max) * 100).toFixed(1)}%"></div></div>
      <span class="num">${format(x.value)}</span></div>`)}</div>`;
  }

  // =====================================================================
  // Router
  // =====================================================================
  const parseHash = () => {
    const h = location.hash.slice(1) || '/dashboard';
    const i = h.indexOf('?');
    return { path: i >= 0 ? h.slice(0, i) : h, query: new URLSearchParams(i >= 0 ? h.slice(i + 1) : '') };
  };

  function setQuery(ctx, changes) {
    const q = new URLSearchParams(ctx.query);
    for (const [k, v] of Object.entries(changes)) {
      if (v === '' || v === null || v === undefined) q.delete(k); else q.set(k, v);
    }
    const s = q.toString();
    const target = `#${ctx.path}${s ? `?${s}` : ''}`;
    if (location.hash === target) navigate(); else location.hash = target;
  }

  function bindFilters(ctx) {
    $$('[data-filter]', ctx.view).forEach((el) => {
      const key = el.dataset.filter;
      if (el.type === 'search') {
        let t;
        el.addEventListener('input', () => {
          clearTimeout(t);
          t = setTimeout(() => { S.refocus = key; setQuery(ctx, { [key]: el.value.trim(), offset: '' }); }, 350);
        });
      } else if (el.type === 'checkbox') {
        el.addEventListener('change', () => setQuery(ctx, { [key]: el.checked ? '1' : '', offset: '' }));
      } else {
        el.addEventListener('change', () => setQuery(ctx, { [key]: el.value, offset: '' }));
      }
    });
    $$('[data-offset]', ctx.view).forEach((b) => b.addEventListener('click', () => setQuery(ctx, { offset: b.dataset.offset })));
  }

  const ROUTES = [];
  const route = (re, fn, title) => ROUTES.push({ re, fn, title });

  async function navigate() {
    if (!S.user) return;
    const { path, query } = parseHash();
    const seq = ++S.navSeq;
    const view = $('#view');
    const section = path.split('/')[1];
    $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.section === section));
    $('.app').classList.remove('nav-open');

    const r = ROUTES.find((x) => x.re.test(path));
    if (!r) { location.hash = '#/dashboard'; return; }
    const ctx = {
      path, query, view, params: path.match(r.re).slice(1),
      q: (k, d = '') => query.get(k) ?? d,
      render(h) {
        if (seq !== S.navSeq) return false;
        view.innerHTML = h.s;
        if (S.refocus) {
          const el = $(`[data-filter="${S.refocus}"]`, view);
          S.refocus = null;
          if (el) { el.focus(); const n = el.value.length; el.setSelectionRange(n, n); }
        }
        return true;
      },
    };
    document.title = `${r.title} · ${S.settings.companyName}`;
    if (!view.innerHTML.trim()) view.innerHTML = '<div class="empty">Loading…</div>';
    try {
      await r.fn(ctx);
    } catch (err) {
      if (err.status === 401) return;
      ctx.render(html`<div class="card"><div class="empty"><h2>Something went wrong</h2><p>${err.message}</p><a class="btn" href="#/dashboard">Back to dashboard</a></div></div>`);
    }
  }

  // =====================================================================
  // Shell & login
  // =====================================================================
  const NAV = [
    { group: 'Overview', items: [['dashboard', 'Dashboard', 'home']] },
    { group: 'Inventory', items: [['products', 'Products', 'box'], ['stock', 'Stock levels', 'layers'], ['movements', 'Movements', 'swap'], ['reorder', 'Replenishment', 'alert']] },
    { group: 'Orders', items: [['purchase-orders', 'Purchase orders', 'truck'], ['sales-orders', 'Sales orders', 'cart'], ['returns', 'Returns to warehouse', 'undo'], ['approvals', 'Approvals', 'shield']] },
    { group: 'Master data', items: [['suppliers', 'Suppliers', 'factory'], ['customers', 'Customers', 'users'], ['warehouses', 'Warehouses & sales centers', 'store'], ['categories', 'Categories', 'tag']] },
    { group: 'Insights', items: [['reports', 'Reports', 'chart'], ['audit', 'Audit log', 'shield', 'audit:read']] },
    { group: 'Administration', items: [['import', 'Import data', 'upload', ['master:write', 'stock:write']], ['branding', 'Company branding', 'palette', 'settings:manage'], ['users', 'Users & roles', 'key', 'users:manage']] },
  ];

  // ---- Branding: colours derived from the company's brand colour --------------
  const hexRgb = (h) => { const v = parseInt(h.slice(1), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; };
  const rgbHex = (c) => '#' + c.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mixHex = (a, b, t) => { const x = hexRgb(a); const y = hexRgb(b); return rgbHex(x.map((v, i) => v + (y[i] - v) * t)); };
  const lum = (h) => { const [r, g, b] = hexRgb(h).map((v) => { const c = v / 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
  const contrastOf = (a, b) => { const [h, l] = [lum(a), lum(b)].sort((p, q) => q - p); return (h + 0.05) / (l + 0.05); };
  const isHex = (h) => /^#[0-9a-f]{6}$/i.test(h || '');

  function applyBranding(st) {
    const brand = isHex(st.brandColor) ? st.brandColor : '#2f5bea';
    let light = isHex(st.primary) ? st.primary : brand;
    for (let i = 0; i < 20 && contrastOf(light, '#ffffff') < 4.5; i++) light = mixHex(light, '#000000', 0.08);
    let dark = brand;
    for (let i = 0; i < 20 && contrastOf(dark, '#161e30') < 4.5; i++) dark = mixHex(dark, '#ffffff', 0.1);
    const heroEnd = lum(brand) > 0.3 ? mixHex(brand, '#000000', 0.35) : brand;
    const css = `:root{--primary:${light};--primary-hover:${mixHex(light, '#000000', 0.15)};--primary-soft:${mixHex(light, '#ffffff', 0.88)};--chart-in:${light};--brand:${heroEnd};--brand-deep:${mixHex(brand, '#0b1020', 0.72)}}
@media (prefers-color-scheme: dark){:root{--primary:${dark};--primary-hover:${mixHex(dark, '#ffffff', 0.15)};--primary-soft:${mixHex(dark, '#161e30', 0.8)};--chart-in:${dark}}}`;
    let el = document.getElementById('brand-style');
    if (!el) { el = document.createElement('style'); el.id = 'brand-style'; document.head.appendChild(el); }
    el.textContent = css;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = light;
  }
  const brandMark = (st, cls = '') => (st.logoUrl
    ? html`<img class="logo ${cls}" src="${st.logoUrl}" alt="">`
    : html`<img src="/favicon.svg" alt="">`);

  function renderShell() {
    const u = S.user;
    const initials = u.name.split(/\s+/).map((p) => p[0]).slice(0, 2).join('').toUpperCase();
    $('#root').innerHTML = html`<div class="app">
      <aside class="sidebar">
        <div class="brand">${brandMark(S.settings)}<span>${S.settings.companyName}${S.settings.tagline ? html`<small>${S.settings.tagline}</small>` : ''}</span></div>
        <nav class="nav">${NAV.map((g) => {
          const items = g.items.filter((i) => !i[3] || [].concat(i[3]).some(can));
          if (!items.length) return '';
          return html`<div class="nav-group"><div class="nav-label">${g.group}</div>
            ${items.map(([key, label, ic]) => html`<a href="#/${key}" data-section="${key}">${icon(ic)}<span>${label}</span>${key === 'reorder' ? html`<span class="count" data-low-count hidden></span>` : ''}${key === 'approvals' ? html`<span class="count" data-approval-count hidden></span>` : ''}</a>`)}</div>`;
        })}</nav>
        <div class="credit">${PRODUCT.name}<br>Created by ${PRODUCT.author}</div>
      </aside>
      <div class="main">
        <header class="topbar">
          <button class="icon-btn menu-btn" data-menu aria-label="Open navigation">${icon('menu')}</button>
          <form class="global-search" data-global-search role="search">${icon('search')}<input type="search" name="q" placeholder="Search SKU, product name or scan a barcode…" aria-label="Search products"></form>
          <div class="spacer"></div>
          <button class="btn sm" data-change-pw title="Change password">
            <span class="user-chip"><span class="avatar">${initials}</span><span class="user-meta">${u.name}<br><small>${u.role}</small></span></span>
          </button>
          <button class="icon-btn" data-logout title="Sign out" aria-label="Sign out">${icon('logout')}</button>
        </header>
        <main class="view" id="view"></main>
      </div>
    </div>`.s;

    $('[data-menu]').addEventListener('click', () => $('.app').classList.toggle('nav-open'));
    $('[data-logout]').addEventListener('click', async () => {
      try { await POST('/api/auth/logout'); } catch { /* ignore */ }
      S.user = null; S.lookups = null;
      renderLogin('You have been signed out.');
    });
    $('[data-change-pw]').addEventListener('click', passwordDialog);
    $('[data-global-search]').addEventListener('submit', (e) => {
      e.preventDefault();
      const q = e.target.elements.q.value.trim();
      location.hash = `#/products?${qs({ q, active: 'all' })}`;
      e.target.elements.q.value = '';
    });
    // Clickable table rows
    $('#view').addEventListener('click', (e) => {
      if (e.target.closest('a, button, input, select, label, textarea')) return;
      const tr = e.target.closest('tr[data-href]');
      if (tr) location.hash = tr.dataset.href;
    });
    refreshLowCount();
  }

  /** Sidebar badge: requests waiting for me (approvers) or my own open requests (agents). */
  async function refreshApprovalCount() {
    try {
      const s = await GET('/api/approvals/summary');
      const n = can('approvals:decide') ? s.to_decide : s.my_pending;
      const el = $('[data-approval-count]');
      if (el) {
        el.textContent = n; el.hidden = n === 0;
        el.classList.toggle('info', !can('approvals:decide'));
        el.title = can('approvals:decide') ? `${n} request(s) waiting for your approval` : `${n} of your request(s) awaiting approval`;
      }
    } catch { /* non-critical */ }
  }

  /** Ask for a reason (required unless optional) before an action. Resolves to the text, or null if cancelled. */
  function reasonDialog({ title, message, label = 'Submit', danger = false, optional = false, placeholder = '' }) {
    return new Promise((resolve) => {
      let value = null;
      openModal({
        title, danger, submitLabel: label,
        body: html`<p>${message}</p><div class="field full"><label for="f_reason">Reason${optional ? '' : html`<span class="req">*</span>`}</label>
          <textarea id="f_reason" name="reason" rows="3" maxlength="500" placeholder="${placeholder}"></textarea><div class="field-error"></div></div>`,
        onSubmit: async (form) => {
          const v = form.elements.reason.value.trim();
          if (!v && !optional) throw new ApiError('Please give a reason', 422, { reason: 'is required' });
          value = v;
        },
        onClose: (ok) => resolve(ok ? value : null),
      });
    });
  }

  /** Toast for an action that may have been applied or sent for approval (HTTP 202). */
  function approvalToast(res, appliedMsg) {
    if (res && res.pending_approval) {
      const p = res.pending_approval;
      toast(`${p.number} sent to ${p.approver_name || 'a manager'} for approval`, 'success');
      refreshApprovalCount();
      return true;
    }
    toast(appliedMsg, 'success');
    return false;
  }

  /** Banner shown on a document that has an open approval request. */
  const pendingBanner = (p) => (p ? html`<div class="notice pending"><strong>Awaiting approval:</strong>
    <a href="#/approvals/${p.id}">${p.number}</a> — ${p.summary || p.type}. Other changes are locked until a manager decides.</div>` : '');

  async function refreshLowCount() {
    refreshApprovalCount();
    try {
      // Same rule as the Replenishment page: below reorder point after counting stock already on order.
      const n = (await GET('/api/reorder-suggestions')).items.length;
      const el = $('[data-low-count]');
      if (el) { el.textContent = n; el.hidden = n === 0; el.title = `${n} product(s) need reordering`; }
    } catch { /* non-critical */ }
  }

  async function renderLogin(message = '') {
    closeModal();
    let cfg = { ...S.settings, demo: false };
    try { cfg = await GET('/api/auth/config'); S.settings = { ...S.settings, ...cfg }; } catch { /* use defaults */ }
    applyBranding(cfg);
    const welcome = cfg.welcome || { title: '', text: '', points: [] };
    document.title = `Sign in · ${cfg.companyName}`;
    $('#root').innerHTML = html`<div class="login-wrap">
      <section class="login-hero">
        <div class="brand">${brandMark(cfg, 'on-dark')}<span>${cfg.companyName}${cfg.tagline ? html`<small>${cfg.tagline}</small>` : ''}</span></div>
        <div>
          <h1>${welcome.title}</h1>
          ${welcome.text ? html`<p>${welcome.text}</p>` : ''}
          ${welcome.points && welcome.points.length ? html`<ul>${welcome.points.map((p) => html`<li>${p}</li>`)}</ul>` : ''}
        </div>
        <small>© ${new Date().getFullYear()} ${cfg.companyName} · Powered by ${PRODUCT.name}, created by ${PRODUCT.author}</small>
      </section>
      <section class="login-panel"><div class="login-card">
        <div class="login-brand-mobile">${brandMark(cfg)}<strong>${cfg.companyName}</strong></div>
        <h2>Sign in</h2><p class="muted">Use your ${cfg.companyName} account to continue.</p>
        ${message ? html`<div class="form-error">${message}</div>` : ''}
        <form data-login novalidate>
          <div class="field"><label for="l_email">Email</label><input id="l_email" name="email" type="email" autocomplete="username" required></div>
          <div class="field"><label for="l_pw">Password</label><input id="l_pw" name="password" type="password" autocomplete="current-password" required></div>
          <div class="form-error" data-login-error hidden></div>
          <button class="btn primary" type="submit">Sign in</button>
        </form>
        ${cfg.demo ? html`<div class="demo-box"><strong>Demo accounts</strong> — click to fill:
          <button class="link-btn" data-demo="admin@inventory.local|Admin@123456">Administrator · admin@inventory.local</button>
          <button class="link-btn" data-demo="manager@inventory.local|Password123!">Manager · manager@inventory.local</button>
          <button class="link-btn" data-demo="clerk@inventory.local|Password123!">Warehouse clerk · clerk@inventory.local</button>
          <button class="link-btn" data-demo="viewer@inventory.local|Password123!">Read-only viewer · viewer@inventory.local</button></div>` : ''}
      </div></section></div>`.s;
    const form = $('[data-login]');
    $$('[data-demo]').forEach((b) => b.addEventListener('click', () => {
      const [e, p] = b.dataset.demo.split('|');
      form.elements.email.value = e; form.elements.password.value = p; form.requestSubmit();
    }));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const err = $('[data-login-error]');
      const btn = $('button[type=submit]', form);
      err.hidden = true; btn.disabled = true;
      try {
        const res = await POST('/api/auth/login', { email: form.elements.email.value, password: form.elements.password.value });
        await startSession(res);
      } catch (ex) {
        err.textContent = ex.message; err.hidden = false;
      } finally { btn.disabled = false; }
    });
    setTimeout(() => form.elements.email.focus(), 30);
  }

  async function startSession(res) {
    S.user = res.user;
    S.settings = res.settings;
    applyBranding(S.settings);
    moneyFmt = null;
    await lookups(true);
    renderShell();
    if (!location.hash || location.hash === '#/') location.hash = '#/dashboard';
    navigate();
  }

  function passwordDialog() {
    const F = [
      { name: 'current_password', label: 'Current password', type: 'password', required: true, full: true },
      { name: 'new_password', label: 'New password', type: 'password', required: true, full: true, hint: 'At least 10 characters, including letters and numbers.' },
    ];
    openModal({
      title: 'Change password',
      body: html`<p class="muted">Signed in as ${S.user.email}. Changing your password signs out your other sessions.</p><div class="form-grid">${F.map((f) => field(f))}</div>`,
      submitLabel: 'Update password',
      onSubmit: async (form) => { await POST('/api/auth/password', readForm(form, F)); toast('Password updated', 'success'); },
    });
  }

  // =====================================================================
  // Dashboard
  // =====================================================================
  route(/^\/dashboard$/, async (ctx) => {
    const d = await GET('/api/dashboard');
    const k = d.kpi;
    const hour = new Date().getHours();
    const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    if (!ctx.render(html`
      <div class="page-head"><div><h1>${greet}, ${S.user.name.split(' ')[0]}</h1><p>${S.settings.companyName} · inventory position across ${k.warehouses} active location${k.warehouses === 1 ? '' : 's'}.</p></div>
        <div class="actions">
          ${can('stock:write') ? html`<button class="btn" data-stock="receipt">${icon('plus')}Receive stock</button>` : ''}
          ${can('orders:write') ? html`<button class="btn" data-new="po">New purchase order</button><button class="btn primary" data-new="so">New sales order</button>` : ''}
        </div></div>
      <div class="grid kpis">
        ${kpi('Inventory value', fmt.money(k.value), `${fmt.num(k.units)} units on hand`, { href: '#/reports' })}
        ${kpi('Active products', fmt.num(k.products), 'SKUs in catalogue', { href: '#/products' })}
        ${kpi('Low stock', fmt.num(k.low_stock), `${k.out_of_stock} out of stock`, { alert: k.low_stock > 0, href: '#/reorder' })}
        ${kpi('Open purchase orders', fmt.num(k.open_pos), `${k.draft_pos} awaiting approval`, { href: '#/purchase-orders' })}
        ${kpi('Orders to ship', fmt.num(k.to_ship), `${k.draft_sos} draft order${k.draft_sos === 1 ? '' : 's'}`, { href: '#/sales-orders?status=CONFIRMED' })}
      </div>
      <div class="grid two">
        <div class="card"><div class="card-head"><h2>Stock flow · last 14 days</h2>
          <div class="legend"><span style="--c:var(--chart-in)">Inbound</span><span style="--c:var(--chart-out)">Outbound</span></div></div>
          <div class="card-body">${trendChart(d.trend)}</div></div>
        <div class="card"><div class="card-head"><h2>Value by location</h2></div><div class="card-body">${bars(d.value_by_warehouse)}</div></div>
      </div>
      <div class="grid two">
        <div class="card"><div class="card-head"><h2>Needs attention</h2><a href="#/reorder">Replenishment →</a></div>
          ${table([
            { label: 'Product', render: (p) => html`<strong>${p.name}</strong><div class="sub mono">${p.sku}</div>` },
            { label: 'Available', cls: 'num', render: (p) => html`<span class="${p.available <= 0 ? 'qty-neg' : ''}">${fmt.num(p.available)}</span> ${p.unit}` },
            { label: 'Reorder at', cls: 'num', render: (p) => fmt.num(p.reorder_point) },
            { label: '', render: (p) => stockBadge({ ...p, active: 1 }) },
          ], d.low_stock, { empty: 'All products are above their reorder points', href: (p) => `#/products/${p.id}` })}</div>
        <div class="card"><div class="card-head"><h2>Value by category</h2></div><div class="card-body">${bars(d.value_by_category)}</div></div>
      </div>
      <div class="card"><div class="card-head"><h2>Recent activity</h2><a href="#/movements">All movements →</a></div>
        ${table([
          { label: 'When', render: (m) => html`<span class="nowrap">${fmt.dt(m.created_at)}</span>` },
          { label: 'Type', render: (m) => moveBadge(m.type) },
          { label: 'Product', render: (m) => html`${m.product_name} <span class="sub mono">${m.sku}</span>` },
          { label: 'Warehouse', key: 'warehouse_code' },
          { label: 'Qty', cls: 'num', render: (m) => qtyCell(m.qty) },
          { label: 'Reference', render: refLink },
        ], d.recent_movements, { empty: 'No stock movements yet' })}</div>`)) return;
    bindStockButtons(ctx.view);
    $$('[data-new]', ctx.view).forEach((b) => b.addEventListener('click', () => orderDialog(b.dataset.new)));
  }, 'Dashboard');

  function bindStockButtons(scope, preset = {}) {
    $$('[data-stock]', scope).forEach((b) => b.addEventListener('click', () => stockDialog(b.dataset.stock, {
      ...preset, warehouse_id: b.dataset.wh ? Number(b.dataset.wh) : preset.warehouse_id,
    })));
  }

  // =====================================================================
  // Products
  // =====================================================================
  route(/^\/products$/, async (ctx) => {
    await lookups();
    const f = { q: ctx.q('q'), category_id: ctx.q('category_id'), active: ctx.q('active', '1'), low_stock: ctx.q('low_stock'), sort: ctx.q('sort', 'name'), offset: ctx.q('offset', '0') };
    const apiQ = qs({ ...f, active: f.active === 'all' ? '' : f.active });
    const d = await GET(`/api/products?${apiQ}`);
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Products</h1><p>Catalogue, costing and stock position for every SKU.</p></div>
        <div class="actions">${exportButtons(`/api/products?${apiQ}`)}
          ${can('master:write') ? html`<button class="btn primary" data-new>${icon('plus')}New product</button>` : ''}</div></div>
      <div class="card">
        <div class="toolbar">
          <input class="search" type="search" data-filter="q" value="${f.q}" placeholder="Search SKU, name or barcode">
          <select data-filter="category_id" aria-label="Category"><option value="">All categories</option>
            ${S.lookups.categories.map((c) => html`<option value="${c.id}"${String(c.id) === f.category_id ? raw(' selected') : ''}>${c.name}</option>`)}</select>
          <select data-filter="active" aria-label="Status">
            ${[['1', 'Active'], ['0', 'Inactive'], ['all', 'All statuses']].map(([v, l]) => html`<option value="${v}"${v === f.active ? raw(' selected') : ''}>${l}</option>`)}</select>
          <select data-filter="sort" aria-label="Sort">
            ${[['name', 'Sort: Name'], ['sku', 'Sort: SKU'], ['on_hand', 'Sort: On hand'], ['value', 'Sort: Stock value'], ['updated', 'Sort: Recently updated']].map(([v, l]) => html`<option value="${v}"${v === f.sort ? raw(' selected') : ''}>${l}</option>`)}</select>
          <label class="check"><input type="checkbox" data-filter="low_stock"${f.low_stock === '1' ? raw(' checked') : ''}> Low stock only</label>
        </div>
        ${table([
          { label: 'SKU', render: (p) => html`<span class="mono">${p.sku}</span>` },
          { label: 'Product', render: (p) => html`<strong>${p.name}</strong><div class="sub">${p.category_name || 'Uncategorised'}</div>` },
          { label: 'On hand', cls: 'num', render: (p) => html`${fmt.num(p.on_hand)} <span class="sub">${p.unit}</span>` },
          { label: 'Available', cls: 'num', render: (p) => fmt.num(p.available) },
          { label: 'Reorder pt', cls: 'num', render: (p) => fmt.num(p.reorder_point) },
          { label: 'Avg cost', cls: 'num', render: (p) => fmt.money(p.avg_cost) },
          { label: 'Price', cls: 'num', render: (p) => fmt.money(p.price) },
          { label: 'Value', cls: 'num', render: (p) => fmt.money(p.stock_value) },
          { label: 'Status', render: stockBadge },
        ], d.items, { empty: 'No products match your filters', href: (p) => `#/products/${p.id}` })}
        ${pager(d)}
      </div>`)) return;
    bindFilters(ctx);
    const nb = $('[data-new]', ctx.view);
    if (nb) nb.addEventListener('click', () => productDialog());
  }, 'Products');

  function productDialog(p) {
    const F = [
      { name: 'sku', label: 'SKU', required: true, hint: 'Unique stock-keeping unit code' },
      { name: 'name', label: 'Product name', required: true },
      { name: 'category_id', label: 'Category', type: 'select', options: nameOptions(S.lookups.categories) },
      { name: 'supplier_id', label: 'Preferred supplier', type: 'select', options: nameOptions(S.lookups.suppliers, true) },
      { name: 'unit', label: 'Unit of measure', placeholder: 'ea, box, kg…' },
      { name: 'barcode', label: 'Barcode / GTIN' },
      { name: 'cost', label: 'Standard cost', type: 'number', step: '0.01', min: 0, hint: p ? 'Average cost is maintained automatically from receipts.' : 'Used as the opening average cost.' },
      { name: 'price', label: 'Selling price', type: 'number', step: '0.01', min: 0 },
      { name: 'reorder_point', label: 'Reorder point', type: 'number', step: '1', min: 0, hint: 'Alert when available stock falls to this level' },
      { name: 'reorder_qty', label: 'Reorder quantity', type: 'number', step: '1', min: 0 },
      { name: 'description', label: 'Description', type: 'textarea', full: true },
      ...(p ? [{ name: 'active', label: 'Active (available for new orders)', type: 'checkbox', full: true }] : []),
    ];
    openModal({
      title: p ? `Edit ${p.sku}` : 'New product', wide: true,
      body: html`<div class="form-grid">${F.map((f) => field(f, p ? p[f.name] : f.name === 'unit' ? 'ea' : undefined))}</div>`,
      submitLabel: p ? 'Save changes' : 'Create product',
      onSubmit: async (form) => {
        const v = readForm(form, F);
        const saved = p ? await PUT(`/api/products/${p.id}`, v) : await POST('/api/products', v);
        await lookups(true);
        toast(p ? 'Product updated' : 'Product created', 'success');
        if (p) navigate(); else location.hash = `#/products/${saved.id}`;
      },
    });
  }

  route(/^\/products\/(\d+)$/, async (ctx) => {
    await lookups();
    const p = await GET(`/api/products/${ctx.params[0]}`);
    const onHand = p.stock.reduce((s, x) => s + x.on_hand, 0);
    const reserved = p.stock.reduce((s, x) => s + x.reserved, 0);
    const avail = onHand - reserved;
    const margin = p.price > 0 ? ((p.price - p.avg_cost) / p.price) * 100 : null;
    if (!ctx.render(html`
      <div class="page-head"><div><div class="crumbs"><a href="#/products">Products</a> / <span class="mono">${p.sku}</span></div>
        <h1>${p.name} ${stockBadge({ ...p, available: avail })}</h1><p>${p.category_name || 'Uncategorised'}${p.supplier_name ? ` · Preferred supplier: ${p.supplier_name}` : ''}</p></div>
        <div class="actions">
          ${can('stock:write') && p.active ? html`<button class="btn" data-stock="receipt">Receive</button><button class="btn" data-stock="issue">Issue</button>
            <button class="btn" data-stock="transfer">Transfer</button><button class="btn" data-stock="count">Count</button><button class="btn" data-stock="adjust">Adjust</button>` : ''}
          ${can('master:write') ? html`<button class="btn primary" data-edit>Edit</button><button class="btn danger" data-delete>Delete</button>` : ''}
        </div></div>
      <div class="grid kpis">
        ${kpi('On hand', `${fmt.num(onHand)} ${p.unit}`, `${p.stock.filter((s) => s.on_hand > 0).length} location(s)`)}
        ${kpi('Available', fmt.num(avail), `${fmt.num(reserved)} reserved for orders`, { alert: p.reorder_point > 0 && avail <= p.reorder_point })}
        ${kpi('On order', fmt.num(p.open_po_qty), 'Open purchase orders')}
        ${kpi('Average cost', fmt.money(p.avg_cost), `Standard ${fmt.money(p.cost)}`)}
        ${kpi('Stock value', fmt.money(onHand * p.avg_cost), margin === null ? 'No price set' : `${margin.toFixed(1)}% gross margin at ${fmt.money(p.price)}`)}
      </div>
      <div class="grid two">
        <div class="card"><div class="card-head"><h2>Stock by warehouse</h2></div>
          ${table([
            { label: 'Warehouse', render: (s) => html`<strong>${s.warehouse_code}</strong> <span class="sub">${s.warehouse_name}</span>` },
            { label: 'Bin', render: (s) => html`${s.bin || '—'} ${can('stock:write') ? html`<button class="link-btn" data-bin="${s.warehouse_id}" data-bin-val="${s.bin || ''}">edit</button>` : ''}` },
            { label: 'On hand', cls: 'num', render: (s) => fmt.num(s.on_hand) },
            { label: 'Reserved', cls: 'num', render: (s) => fmt.num(s.reserved) },
            { label: 'Available', cls: 'num', render: (s) => html`<strong>${fmt.num(s.available)}</strong>` },
            { label: 'Value', cls: 'num', render: (s) => fmt.money(s.value) },
          ], p.stock, { empty: 'No stock has been received for this product yet' })}</div>
        <div class="card"><div class="card-head"><h2>Details</h2></div><div class="card-body"><dl class="info-grid">
          <div><dt>SKU</dt><dd class="mono">${p.sku}</dd></div>
          <div><dt>Barcode</dt><dd class="mono">${p.barcode || '—'}</dd></div>
          <div><dt>Unit</dt><dd>${p.unit}</dd></div>
          <div><dt>Selling price</dt><dd>${fmt.money(p.price)}</dd></div>
          <div><dt>Reorder point</dt><dd>${fmt.num(p.reorder_point)}</dd></div>
          <div><dt>Reorder qty</dt><dd>${fmt.num(p.reorder_qty)}</dd></div>
          <div><dt>Created</dt><dd>${fmt.date(p.created_at)}</dd></div>
          <div><dt>Last updated</dt><dd>${fmt.dt(p.updated_at)}</dd></div>
        </dl>${p.description ? html`<p>${p.description}</p>` : ''}</div></div>
      </div>
      <div class="card"><div class="card-head"><h2>Movement history</h2><a href="#/movements?product_id=${p.id}">Full ledger →</a></div>
        ${table([
          { label: 'When', render: (m) => html`<span class="nowrap">${fmt.dt(m.created_at)}</span>` },
          { label: 'Type', render: (m) => moveBadge(m.type) },
          { label: 'Warehouse', key: 'warehouse_code' },
          { label: 'Qty', cls: 'num', render: (m) => qtyCell(m.qty) },
          { label: 'Balance', cls: 'num', render: (m) => fmt.num(m.balance_after) },
          { label: 'Unit cost', cls: 'num', render: (m) => fmt.money(m.unit_cost) },
          { label: 'Reference', render: refLink },
          { label: 'Note', render: (m) => m.note || '' },
          { label: 'User', render: (m) => m.user_name || '—' },
        ], p.movements, { empty: 'No movements yet' })}</div>`)) return;

    bindStockButtons(ctx.view, { product_id: p.id });
    const eb = $('[data-edit]', ctx.view);
    if (eb) eb.addEventListener('click', () => productDialog(p));
    const db = $('[data-delete]', ctx.view);
    if (db) db.addEventListener('click', async () => {
      if (!await confirmDialog('Delete product', `Delete ${p.sku} — ${p.name}? Products with history will be deactivated instead.`, { label: 'Delete', danger: true })) return;
      try {
        const r = await DEL(`/api/products/${p.id}`);
        await lookups(true);
        toast(r.message || 'Product deleted', 'success');
        if (r.deleted) location.hash = '#/products'; else navigate();
      } catch (err) { toast(err.message, 'error'); }
    });
    $$('[data-bin]', ctx.view).forEach((b) => b.addEventListener('click', () => {
      const F = [{ name: 'bin', label: 'Bin / shelf location', full: true, placeholder: 'e.g. A-03-2' }];
      openModal({
        title: 'Set bin location', body: html`<div class="form-grid">${field(F[0], b.dataset.binVal)}</div>`,
        onSubmit: async (form) => {
          await POST(`/api/products/${p.id}/bin`, { warehouse_id: Number(b.dataset.bin), ...readForm(form, F) });
          toast('Bin location saved', 'success'); navigate();
        },
      });
    }));
  }, 'Product');

  // =====================================================================
  // Stock operations dialog
  // =====================================================================
  async function stockDialog(kind, preset = {}) {
    await lookups();
    const whs = whOptions();
    const TITLES = { receipt: 'Receive stock', issue: 'Issue stock', adjust: 'Adjust stock', count: 'Cycle count', transfer: 'Transfer between locations' };
    const F = [{ name: 'product_id', label: 'Product', type: 'select', options: productOptions(), required: true, full: true }];
    if (kind === 'transfer') {
      F.push({ name: 'from_warehouse_id', label: 'From location', type: 'select', options: whs, required: true },
        { name: 'to_warehouse_id', label: 'To location', type: 'select', options: whs, required: true, hint: 'Use Transfer to restock a sales center. Returns from a sales center have their own workflow.' });
    } else F.push({ name: 'warehouse_id', label: 'Location', type: 'select', options: whs, required: true });
    if (kind === 'count') F.push({ name: 'counted', label: 'Counted quantity', type: 'number', step: '1', min: 0, required: true, hint: 'The variance against the system quantity is posted automatically.' });
    else if (kind === 'adjust') F.push({ name: 'qty', label: 'Adjustment (+/−)', type: 'number', step: '1', required: true, hint: 'Use a negative number to write stock off (damage, loss, expiry).' });
    else F.push({ name: 'qty', label: 'Quantity', type: 'number', step: '1', min: 1, required: true });
    if (kind === 'receipt') F.push({ name: 'unit_cost', label: 'Unit cost', type: 'number', step: '0.01', min: 0, hint: 'Updates the weighted-average cost. Leave blank to keep the current average.' });
    F.push({ name: 'note', label: kind === 'adjust' ? 'Reason' : 'Note / reference', required: kind === 'adjust', full: kind !== 'receipt' });

    const values = { product_id: preset.product_id, warehouse_id: preset.warehouse_id, from_warehouse_id: preset.warehouse_id };
    if (whs.length === 1) { values.warehouse_id = values.warehouse_id || whs[0].value; }
    openModal({
      title: TITLES[kind],
      body: html`<div class="form-grid">${F.map((f) => field(f, values[f.name]))}</div>`,
      submitLabel: { receipt: 'Receive', issue: 'Issue', adjust: 'Post adjustment', count: 'Post count', transfer: 'Transfer' }[kind],
      onSubmit: async (form) => {
        const v = readForm(form, F);
        let res;
        if (kind === 'transfer') res = await POST('/api/stock/transfer', v);
        else if (kind === 'count') res = await POST('/api/stock/count', v);
        else res = await POST('/api/stock/movements', { ...v, type: { receipt: 'RECEIPT', issue: 'ISSUE', adjust: 'ADJUSTMENT' }[kind] });
        if (kind === 'count') toast(res.qty === 0 ? 'Count matches the system — no variance posted' : `Variance of ${res.qty > 0 ? '+' : ''}${res.qty} posted`, 'success');
        else if (kind === 'transfer') toast(`Transfer ${res.reference} completed`, 'success');
        else toast(`Stock updated — new balance ${fmt.num(res.balance_after)}`, 'success');
        refreshLowCount();
        navigate();
      },
    });
  }

  // =====================================================================
  // Stock levels
  // =====================================================================
  route(/^\/stock$/, async (ctx) => {
    await lookups();
    const f = { q: ctx.q('q'), warehouse_id: ctx.q('warehouse_id'), nonzero: ctx.q('nonzero', '1'), offset: ctx.q('offset', '0') };
    const apiQ = qs({ ...f, nonzero: f.nonzero === '1' ? '1' : '' });
    const d = await GET(`/api/stock?${apiQ}`);
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Stock levels</h1><p>On-hand, reserved and available quantity by location.</p></div>
        <div class="actions">${exportButtons(`/api/stock?${apiQ}`)}
          ${can('stock:write') ? html`<button class="btn" data-stock="transfer">Transfer</button><button class="btn" data-stock="count">Cycle count</button><button class="btn primary" data-stock="receipt">${icon('plus')}Receive stock</button>` : ''}</div></div>
      <div class="grid kpis">
        ${kpi('Units in view', fmt.num(d.totals.units))}
        ${kpi('Value in view', fmt.money(d.totals.value))}
        ${kpi('Stock lines', fmt.num(d.total))}
      </div>
      <div class="card">
        <div class="toolbar">
          <input class="search" type="search" data-filter="q" value="${f.q}" placeholder="Search SKU, name or barcode">
          <select data-filter="warehouse_id" aria-label="Warehouse"><option value="">All warehouses</option>
            ${whOptions(true).map((w) => html`<option value="${w.value}"${String(w.value) === f.warehouse_id ? raw(' selected') : ''}>${w.label}</option>`)}</select>
          <select data-filter="nonzero" aria-label="Zero stock"><option value="1"${f.nonzero === '1' ? raw(' selected') : ''}>Hide zero stock</option><option value="0"${f.nonzero !== '1' ? raw(' selected') : ''}>Show zero stock</option></select>
        </div>
        ${table([
          { label: 'SKU', render: (s) => html`<span class="mono">${s.sku}</span>` },
          { label: 'Product', render: (s) => html`<strong>${s.name}</strong>` },
          { label: 'Warehouse', render: (s) => html`${s.warehouse_code}<div class="sub">${s.warehouse_name}</div>` },
          { label: 'Bin', render: (s) => s.bin || '—' },
          { label: 'On hand', cls: 'num', render: (s) => html`${fmt.num(s.on_hand)} <span class="sub">${s.unit}</span>` },
          { label: 'Reserved', cls: 'num', render: (s) => fmt.num(s.reserved) },
          { label: 'Available', cls: 'num', render: (s) => html`<strong>${fmt.num(s.available)}</strong>` },
          { label: 'Avg cost', cls: 'num', render: (s) => fmt.money(s.avg_cost) },
          { label: 'Value', cls: 'num', render: (s) => fmt.money(s.value) },
        ], d.items, { empty: 'No stock matches your filters', href: (s) => `#/products/${s.product_id}` })}
        ${pager(d)}
      </div>`)) return;
    bindFilters(ctx);
    bindStockButtons(ctx.view, { warehouse_id: f.warehouse_id ? Number(f.warehouse_id) : undefined });
  }, 'Stock levels');

  // =====================================================================
  // Movements ledger
  // =====================================================================
  const MOVE_TYPES = ['RECEIPT', 'PO_RECEIPT', 'ISSUE', 'SALE', 'ADJUSTMENT', 'COUNT', 'TRANSFER_IN', 'TRANSFER_OUT'];
  route(/^\/movements$/, async (ctx) => {
    await lookups();
    const f = { q: ctx.q('q'), type: ctx.q('type'), warehouse_id: ctx.q('warehouse_id'), from: ctx.q('from'), to: ctx.q('to'), product_id: ctx.q('product_id'), ref: ctx.q('ref'), offset: ctx.q('offset', '0') };
    const apiQ = qs(f);
    const d = await GET(`/api/movements?${apiQ}`);
    const prod = f.product_id ? S.lookups.products.find((p) => String(p.id) === f.product_id) : null;
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Stock movements</h1><p>Immutable ledger of every change to inventory. Corrections are posted as new entries.</p></div>
        <div class="actions">${exportButtons(`/api/movements?${apiQ}`)}
          ${can('stock:write') ? html`<button class="btn" data-stock="issue">Issue</button><button class="btn" data-stock="adjust">Adjust</button><button class="btn primary" data-stock="receipt">${icon('plus')}Receive</button>` : ''}</div></div>
      <div class="card">
        <div class="toolbar">
          <input class="search" type="search" data-filter="q" value="${f.q}" placeholder="Search SKU or product">
          <select data-filter="type" aria-label="Type"><option value="">All types</option>${MOVE_TYPES.map((t) => html`<option value="${t}"${t === f.type ? raw(' selected') : ''}>${t.replace('_', ' ')}</option>`)}</select>
          <select data-filter="warehouse_id" aria-label="Warehouse"><option value="">All warehouses</option>
            ${whOptions(true).map((w) => html`<option value="${w.value}"${String(w.value) === f.warehouse_id ? raw(' selected') : ''}>${w.label}</option>`)}</select>
          <input type="date" data-filter="from" value="${f.from}" aria-label="From date">
          <input type="date" data-filter="to" value="${f.to}" aria-label="To date">
          ${prod ? html`<span class="badge purple">Product: ${prod.sku}</span><button class="link-btn" data-clear="product_id">clear</button>` : ''}
          ${f.ref ? html`<span class="badge purple">Ref: ${f.ref}</span><button class="link-btn" data-clear="ref">clear</button>` : ''}
        </div>
        ${table([
          { label: 'When', render: (m) => html`<span class="nowrap">${fmt.dt(m.created_at)}</span>` },
          { label: 'Type', render: (m) => moveBadge(m.type) },
          { label: 'Product', render: (m) => html`<a href="#/products/${m.product_id}">${m.product_name}</a><div class="sub mono">${m.sku}</div>` },
          { label: 'Whse', key: 'warehouse_code' },
          { label: 'Qty', cls: 'num', render: (m) => qtyCell(m.qty) },
          { label: 'Balance', cls: 'num', render: (m) => fmt.num(m.balance_after) },
          { label: 'Unit cost', cls: 'num', render: (m) => fmt.money(m.unit_cost) },
          { label: 'Reference', render: refLink },
          { label: 'Note', render: (m) => m.note || '' },
          { label: 'User', render: (m) => m.user_name || '—' },
        ], d.items, { empty: 'No movements match your filters' })}
        ${pager(d)}
      </div>`)) return;
    bindFilters(ctx);
    bindStockButtons(ctx.view, { product_id: f.product_id ? Number(f.product_id) : undefined });
    $$('[data-clear]', ctx.view).forEach((b) => b.addEventListener('click', () => setQuery(ctx, { [b.dataset.clear]: '', offset: '' })));
  }, 'Movements');

  // =====================================================================
  // Replenishment
  // =====================================================================
  route(/^\/reorder$/, async (ctx) => {
    await lookups();
    const d = await GET('/api/reorder-suggestions');
    const groups = new Map();
    for (const it of d.items) {
      const key = it.supplier_id || 0;
      if (!groups.has(key)) groups.set(key, { supplier_id: it.supplier_id, name: it.supplier_name || 'No preferred supplier', items: [] });
      groups.get(key).items.push(it);
    }
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Replenishment</h1><p>Products at or below their reorder point, after counting stock already on order. Suggestions are grouped by preferred supplier.</p></div></div>
      ${!d.items.length ? html`<div class="card"><div class="empty"><h2>Everything is well stocked</h2><p>No product is at or below its reorder point.</p></div></div>` : ''}
      ${[...groups.values()].map((g) => html`<div class="card" data-group="${g.supplier_id || ''}">
        <div class="card-head"><h2>${g.name} <span class="muted">· ${g.items.length} item${g.items.length === 1 ? '' : 's'}</span></h2>
          ${can('orders:write') && g.supplier_id ? html`<button class="btn primary sm" data-create-po="${g.supplier_id}">Create draft PO</button>` : g.supplier_id ? '' : html`<span class="muted">Assign a preferred supplier to these products to create POs</span>`}</div>
        ${table([
          { label: '', render: (it) => html`<input type="checkbox" data-pick="${it.product_id}" checked aria-label="Include ${it.sku}">` },
          { label: 'Product', render: (it) => html`<a href="#/products/${it.product_id}"><strong>${it.name}</strong></a><div class="sub mono">${it.sku}</div>` },
          { label: 'Available', cls: 'num', render: (it) => html`<span class="${it.available <= 0 ? 'qty-neg' : ''}">${fmt.num(it.available)}</span>` },
          { label: 'On order', cls: 'num', render: (it) => fmt.num(it.on_order) },
          { label: 'Reorder pt', cls: 'num', render: (it) => fmt.num(it.reorder_point) },
          { label: 'Order qty', cls: 'num', render: (it) => html`<input type="number" min="1" step="1" value="${it.suggested_qty}" data-qty="${it.product_id}" class="w-qty" style="max-width:110px">` },
          { label: 'Unit cost', cls: 'num', render: (it) => fmt.money(it.cost) },
        ], g.items)}
      </div>`)}`)) return;

    $$('[data-create-po]', ctx.view).forEach((b) => b.addEventListener('click', () => {
      const card = b.closest('[data-group]');
      const lines = $$('[data-pick]', card).filter((c) => c.checked).map((c) => ({
        product_id: Number(c.dataset.pick), qty: Number($(`[data-qty="${c.dataset.pick}"]`, card).value),
      }));
      if (!lines.length) { toast('Select at least one product', 'error'); return; }
      const F = [{ name: 'warehouse_id', label: 'Deliver to warehouse', type: 'select', options: whOptions(), required: true, full: true },
        { name: 'expected_date', label: 'Expected delivery', type: 'date', full: true }];
      openModal({
        title: 'Create draft purchase order',
        body: html`<p>${lines.length} line${lines.length === 1 ? '' : 's'} will be added to a new draft PO.</p><div class="form-grid">${F.map((f) => field(f, f.name === 'warehouse_id' ? whOptions()[0] && whOptions()[0].value : ''))}</div>`,
        submitLabel: 'Create PO',
        onSubmit: async (form) => {
          const po = await POST('/api/purchase-orders', { supplier_id: Number(b.dataset.createPo), ...readForm(form, F), lines });
          toast(`${po.number} created as draft`, 'success');
          location.hash = `#/purchase-orders/${po.id}`;
        },
      });
    }));
  }, 'Replenishment');

  // =====================================================================
  // Orders (shared list + editor)
  // =====================================================================
  const ORDER = {
    po: {
      api: '/api/purchase-orders', path: 'purchase-orders', title: 'Purchase orders', singular: 'purchase order',
      statuses: ['DRAFT', 'ORDERED', 'PARTIAL', 'RECEIVED', 'CANCELLED'],
      party: 'supplier_id', partyLabel: 'Supplier', partyList: () => S.lookups.suppliers, priceKey: 'unit_cost', priceLabel: 'Unit cost',
      qtyKey: 'qty_ordered', defaultPrice: (p) => p.cost,
    },
    so: {
      api: '/api/sales-orders', path: 'sales-orders', title: 'Sales orders', singular: 'sales order',
      statuses: ['DRAFT', 'CONFIRMED', 'SHIPPED', 'CANCELLED'],
      party: 'customer_id', partyLabel: 'Customer', partyList: () => S.lookups.customers, priceKey: 'unit_price', priceLabel: 'Unit price',
      qtyKey: 'qty', defaultPrice: (p) => p.price,
    },
  };

  function orderList(kind) {
    const O = ORDER[kind];
    return async (ctx) => {
      await lookups();
      const f = { q: ctx.q('q'), status: ctx.q('status'), offset: ctx.q('offset', '0') };
      const d = await GET(`${O.api}?${qs(f)}`);
      const tabLink = (s, label) => {
        const q = qs({ q: f.q, status: s });
        return html`<a href="#/${O.path}${q ? `?${q}` : ''}" class="${f.status === s ? 'active' : ''}">${label}</a>`;
      };
      const cols = kind === 'po' ? [
        { label: 'PO', render: (o) => html`<strong class="mono">${o.number}</strong>` },
        { label: 'Supplier', key: 'supplier_name' },
        { label: 'Deliver to', key: 'warehouse_code' },
        { label: 'Status', render: (o) => statusBadge(o.status) },
        { label: 'Expected', render: (o) => fmt.date(o.expected_date) },
        { label: 'Received', render: (o) => html`<div class="progress" title="${o.qty_received} of ${o.qty_ordered}"><div style="width:${o.qty_ordered ? Math.round((o.qty_received / o.qty_ordered) * 100) : 0}%"></div></div>` },
        { label: 'Lines', cls: 'num', key: 'line_count' },
        { label: 'Total', cls: 'num', render: (o) => fmt.money(o.total) },
        { label: 'Created', render: (o) => fmt.date(o.created_at) },
      ] : [
        { label: 'SO', render: (o) => html`<strong class="mono">${o.number}</strong>` },
        { label: 'Customer', key: 'customer_name' },
        { label: 'Ship from', key: 'warehouse_code' },
        { label: 'Status', render: (o) => statusBadge(o.status) },
        { label: 'Lines', cls: 'num', key: 'line_count' },
        { label: 'Total', cls: 'num', render: (o) => fmt.money(o.total) },
        { label: 'Created', render: (o) => fmt.date(o.created_at) },
        { label: 'Shipped', render: (o) => fmt.date(o.shipped_at) },
      ];
      if (!ctx.render(html`
        <div class="page-head"><div><h1>${O.title}</h1><p>${kind === 'po' ? 'Draft → approved → received. Partial receipts are supported.' : 'Draft → confirmed (stock reserved) → shipped (stock issued).'}</p></div>
          <div class="actions">${exportButtons(`${O.api}?${qs({ ...f, offset: '' })}`)}
            ${can('orders:write') ? html`<button class="btn primary" data-new>${icon('plus')}New ${O.singular}</button>` : ''}</div></div>
        <div class="card">
          <nav class="tabs">${tabLink('', 'All')}${O.statuses.map((s) => tabLink(s, s[0] + s.slice(1).toLowerCase()))}</nav>
          <div class="toolbar"><input class="search" type="search" data-filter="q" value="${f.q}" placeholder="Search number or ${O.partyLabel.toLowerCase()}"></div>
          ${table(cols, d.items, { empty: `No ${O.singular}s found`, href: (o) => `#/${O.path}/${o.id}` })}
          ${pager(d)}
        </div>`)) return;
      bindFilters(ctx);
      const nb = $('[data-new]', ctx.view);
      if (nb) nb.addEventListener('click', () => orderDialog(kind));
    };
  }

  async function orderDialog(kind, existing) {
    const O = ORDER[kind];
    await lookups();
    const products = S.lookups.products.filter((p) => p.active);
    const byId = new Map(S.lookups.products.map((p) => [p.id, p]));
    let lines = existing
      ? existing.lines.map((l) => ({ product_id: l.product_id, qty: l[O.qtyKey], price: l[O.priceKey] }))
      : [{ product_id: '', qty: 1, price: '' }];
    const H = [
      { name: O.party, label: O.partyLabel, type: 'select', options: nameOptions(O.partyList()), required: true },
      { name: 'warehouse_id', label: kind === 'po' ? 'Deliver to location' : 'Sell / ship from', type: 'select', options: whOptions(), required: true,
        hint: kind === 'so' ? 'Pick a sales center to sell from its stock, or a warehouse for direct shipments.' : undefined },
      ...(kind === 'po' ? [{ name: 'expected_date', label: 'Expected delivery', type: 'date' }] : []),
      { name: 'notes', label: 'Notes', type: 'textarea', full: true },
    ];
    const hv = existing || { warehouse_id: whOptions()[0] && whOptions()[0].value };
    const { form } = openModal({
      title: existing ? `Edit ${existing.number}` : `New ${O.singular}`, wide: true,
      submitLabel: existing ? 'Save changes' : 'Create draft',
      body: html`<div class="form-grid">${H.map((f) => field(f, hv[f.name]))}</div>
        <h3 style="margin:20px 0 8px">Line items</h3>
        <div class="table-wrap"><table class="lines-table"><thead><tr><th>Product</th><th class="num">Qty</th><th class="num">${O.priceLabel}</th><th class="num">Total</th><th></th></tr></thead><tbody data-lines></tbody></table></div>
        <button type="button" class="btn sm" data-add-line style="margin-top:8px">${icon('plus')}Add line</button>
        <div class="order-total" data-total></div>`,
      onSubmit: async (f) => {
        const payload = {
          ...readForm(f, H),
          lines: lines.filter((l) => l.product_id).map((l) => ({ product_id: Number(l.product_id), qty: Number(l.qty), [O.priceKey]: l.price === '' || l.price === null ? null : Number(l.price) })),
        };
        const saved = existing ? await PUT(`${O.api}/${existing.id}`, payload) : await POST(O.api, payload);
        toast(`${saved.number} ${existing ? 'updated' : 'created'}`, 'success');
        const target = `#/${O.path}/${saved.id}`;
        if (location.hash === target) navigate(); else location.hash = target;
      },
    });
    const tbody = $('[data-lines]', form);
    const total = $('[data-total]', form);
    const updateTotals = () => {
      let sum = 0;
      $$('tr', tbody).forEach((tr, i) => {
        const l = lines[i];
        const t = (Number(l.qty) || 0) * (Number(l.price) || 0);
        sum += t;
        $('[data-line-total]', tr).textContent = fmt.money(t);
      });
      total.textContent = `Order total: ${fmt.money(sum)}`;
    };
    const renderLines = () => {
      tbody.innerHTML = lines.map((l) => html`<tr>
        <td><select data-k="product_id" aria-label="Product"><option value="">Select product…</option>
          ${products.map((p) => html`<option value="${p.id}"${String(p.id) === String(l.product_id) ? raw(' selected') : ''}>${p.sku} — ${p.name}</option>`)}</select></td>
        <td class="w-qty"><input data-k="qty" type="number" min="1" step="1" value="${l.qty}" aria-label="Quantity"></td>
        <td class="w-price"><input data-k="price" type="number" min="0" step="0.01" value="${l.price ?? ''}" aria-label="${O.priceLabel}"></td>
        <td class="num" data-line-total></td>
        <td><button type="button" class="icon-btn" data-remove aria-label="Remove line">×</button></td></tr>`.s).join('');
      updateTotals();
    };
    tbody.addEventListener('input', (e) => {
      const tr = e.target.closest('tr');
      const i = $$('tr', tbody).indexOf(tr);
      const k = e.target.dataset.k;
      if (!k || i < 0) return;
      lines[i][k] = e.target.value;
      if (k === 'product_id' && e.target.value) {
        const p = byId.get(Number(e.target.value));
        if (p) { lines[i].price = O.defaultPrice(p); $('[data-k="price"]', tr).value = lines[i].price; }
      }
      updateTotals();
    });
    tbody.addEventListener('click', (e) => {
      if (!e.target.closest('[data-remove]')) return;
      const i = $$('tr', tbody).indexOf(e.target.closest('tr'));
      lines.splice(i, 1);
      if (!lines.length) lines = [{ product_id: '', qty: 1, price: '' }];
      renderLines();
    });
    $('[data-add-line]', form).addEventListener('click', () => { lines.push({ product_id: '', qty: 1, price: '' }); renderLines(); });
    renderLines();
  }

  async function orderAction(url, okMsg, confirmText, opts) {
    if (confirmText && !await confirmDialog(confirmText[0], confirmText[1], opts)) return;
    try {
      await POST(url);
      toast(okMsg, 'success');
      refreshLowCount();
      navigate();
    } catch (err) { toast(err.message, 'error'); }
  }

  async function historyCard(entity, id) {
    if (!can('audit:read')) return '';
    const h = await GET(`/api/audit?${qs({ entity, entity_id: id, limit: 50 })}`);
    return html`<div class="card"><div class="card-head"><h2>History</h2></div>
      ${table([
        { label: 'When', render: (a) => html`<span class="nowrap">${fmt.dt(a.created_at)}</span>` },
        { label: 'Action', render: (a) => html`<span class="mono">${a.action}</span>` },
        { label: 'User', render: (a) => a.user_email || 'system' },
      ], h.items, { empty: 'No history' })}</div>`;
  }

  // ---- Purchase order detail --------------------------------------------
  route(/^\/purchase-orders$/, orderList('po'), 'Purchase orders');
  route(/^\/purchase-orders\/(\d+)$/, async (ctx) => {
    const po = await GET(`/api/purchase-orders/${ctx.params[0]}`);
    const history = await historyCard('purchase_order', po.id);
    const s = po.status;
    const outstanding = po.lines.reduce((t, l) => t + (l.qty_ordered - l.qty_received), 0);
    if (!ctx.render(html`
      <div class="page-head"><div><div class="crumbs"><a href="#/purchase-orders">Purchase orders</a> / ${po.number}</div>
        <h1>${po.number} ${statusBadge(s)}</h1><p>${po.supplier_name} → ${po.warehouse_code} · ${po.warehouse_name}</p></div>
        <div class="actions">
          <a class="btn" href="/api/purchase-orders/${po.id}/pdf" download>${icon('pdf')}Download PDF</a>
          ${s === 'DRAFT' && can('orders:write') ? html`<button class="btn" data-edit>Edit</button><button class="btn danger" data-delete>Delete</button>` : ''}
          ${['DRAFT', 'ORDERED'].includes(s) && can('orders:approve') ? html`<button class="btn danger" data-cancel>Cancel order</button>` : ''}
          ${s === 'DRAFT' && can('orders:approve') ? html`<button class="btn primary" data-approve>Approve &amp; send</button>` : ''}
          ${['ORDERED', 'PARTIAL'].includes(s) && can('stock:write') ? html`<button class="btn primary" data-receive>Receive goods</button>` : ''}
        </div></div>
      ${s === 'DRAFT' && !can('orders:approve') ? html`<div class="card"><div class="card-body muted">This draft is waiting for approval by a manager.</div></div>` : ''}
      <div class="grid kpis">
        ${kpi('Order total', fmt.money(po.total), `${po.lines.length} line${po.lines.length === 1 ? '' : 's'}`)}
        ${kpi('Outstanding units', fmt.num(outstanding), s === 'RECEIVED' ? 'Fully received' : 'Still to be received')}
        ${kpi('Expected', fmt.date(po.expected_date), po.ordered_at ? `Ordered ${fmt.date(po.ordered_at)}` : 'Not yet ordered')}
      </div>
      <div class="card"><div class="card-head"><h2>Lines</h2></div>
        ${table([
          { label: 'SKU', render: (l) => html`<a class="mono" href="#/products/${l.product_id}">${l.sku}</a>` },
          { label: 'Product', key: 'product_name' },
          { label: 'Ordered', cls: 'num', render: (l) => html`${fmt.num(l.qty_ordered)} <span class="sub">${l.unit}</span>` },
          { label: 'Received', cls: 'num', render: (l) => fmt.num(l.qty_received) },
          { label: 'Outstanding', cls: 'num', render: (l) => html`<strong>${fmt.num(l.qty_ordered - l.qty_received)}</strong>` },
          { label: 'Unit cost', cls: 'num', render: (l) => fmt.money(l.unit_cost) },
          { label: 'Line total', cls: 'num', render: (l) => fmt.money(l.line_total) },
        ], po.lines, { foot: html`<tr><td colspan="6">Total</td><td class="num">${fmt.money(po.total)}</td></tr>` })}</div>
      <div class="grid halves">
        <div class="card"><div class="card-head"><h2>Details</h2></div><div class="card-body"><dl class="info-grid">
          <div><dt>Supplier</dt><dd>${po.supplier_name}${po.supplier_email ? html`<div class="sub">${po.supplier_email}</div>` : ''}</dd></div>
          <div><dt>Deliver to</dt><dd>${po.warehouse_code} — ${po.warehouse_name}</dd></div>
          <div><dt>Created by</dt><dd>${po.created_by_name || '—'}<div class="sub">${fmt.dt(po.created_at)}</div></dd></div>
          <div><dt>Approved by</dt><dd>${po.approved_by_name || '—'}${po.ordered_at ? html`<div class="sub">${fmt.dt(po.ordered_at)}</div>` : ''}</dd></div>
        </dl>${po.notes ? html`<p><strong>Notes:</strong> ${po.notes}</p>` : ''}</div></div>
        ${history}
      </div>`)) return;

    const on = (sel, fn) => { const el = $(sel, ctx.view); if (el) el.addEventListener('click', fn); };
    on('[data-edit]', () => orderDialog('po', po));
    on('[data-approve]', () => orderAction(`/api/purchase-orders/${po.id}/submit`, `${po.number} approved and ordered`,
      ['Approve purchase order', `Approve ${po.number} for ${fmt.money(po.total)} and mark it as ordered from ${po.supplier_name}?`], { label: 'Approve' }));
    on('[data-cancel]', () => orderAction(`/api/purchase-orders/${po.id}/cancel`, `${po.number} cancelled`,
      ['Cancel purchase order', `Cancel ${po.number}? This cannot be undone.`], { label: 'Cancel order', danger: true }));
    on('[data-delete]', async () => {
      if (!await confirmDialog('Delete draft', `Permanently delete draft ${po.number}?`, { label: 'Delete', danger: true })) return;
      try { await DEL(`/api/purchase-orders/${po.id}`); toast(`${po.number} deleted`, 'success'); location.hash = '#/purchase-orders'; }
      catch (err) { toast(err.message, 'error'); }
    });
    on('[data-receive]', () => receiveDialog(po));
  }, 'Purchase order');

  function receiveDialog(po) {
    const open = po.lines.filter((l) => l.qty_ordered > l.qty_received);
    openModal({
      title: `Receive against ${po.number}`, wide: true, submitLabel: 'Post receipt',
      body: html`<p class="muted">Goods will be booked into <strong>${po.warehouse_code} — ${po.warehouse_name}</strong> at the PO unit cost. Enter 0 to skip a line.</p>
        <div class="table-wrap"><table class="lines-table"><thead><tr><th>Product</th><th class="num">Outstanding</th><th class="num">Receive now</th></tr></thead><tbody>
          ${open.map((l) => html`<tr><td><strong>${l.product_name}</strong><div class="sub mono">${l.sku}</div></td>
            <td class="num">${fmt.num(l.qty_ordered - l.qty_received)}</td>
            <td class="w-qty"><input type="number" min="0" max="${l.qty_ordered - l.qty_received}" step="1" value="${l.qty_ordered - l.qty_received}" data-line="${l.id}" aria-label="Quantity to receive"></td></tr>`)}
        </tbody></table></div>
        <div class="field full" style="margin-top:14px"><label for="r_note">Delivery note / reference</label><input id="r_note" name="note" placeholder="e.g. supplier delivery note number"></div>`,
      onSubmit: async (form) => {
        const lines = $$('[data-line]', form).map((i) => ({ line_id: Number(i.dataset.line), qty: Number(i.value) || 0 }));
        const res = await POST(`/api/purchase-orders/${po.id}/receive`, { lines, note: form.elements.note.value.trim() || null });
        toast(res.status === 'RECEIVED' ? `${po.number} fully received` : `Partial receipt posted for ${po.number}`, 'success');
        refreshLowCount();
        navigate();
      },
    });
  }

  // ---- Sales order detail ----------------------------------------------
  route(/^\/sales-orders$/, orderList('so'), 'Sales orders');
  route(/^\/sales-orders\/(\d+)$/, async (ctx) => {
    const so = await GET(`/api/sales-orders/${ctx.params[0]}`);
    const history = await historyCard('sales_order', so.id);
    const s = so.status;
    const short = s === 'DRAFT' ? so.lines.filter((l) => l.available < l.qty) : [];
    const pending = so.pending_approval;
    const approver = can('approvals:decide');
    if (!ctx.render(html`
      <div class="page-head"><div><div class="crumbs"><a href="#/sales-orders">Sales orders</a> / ${so.number}</div>
        <h1>${so.number} ${statusBadge(s)}</h1><p>${so.customer_name} · ships from ${so.warehouse_code} — ${so.warehouse_name}</p></div>
        <div class="actions">
          <span class="btn-group">
            <a class="btn" href="/api/sales-orders/${so.id}/pdf?doc=confirmation" download title="Order confirmation (PDF)">${icon('pdf')}Order PDF</a>
            ${['CONFIRMED', 'SHIPPED'].includes(s) ? html`<a class="btn" href="/api/sales-orders/${so.id}/pdf?doc=packing" download title="Packing slip without prices (PDF)">${icon('pdf')}Packing slip</a>` : ''}
            ${s === 'SHIPPED' ? html`<a class="btn" href="/api/sales-orders/${so.id}/pdf?doc=invoice" download title="Invoice (PDF)">${icon('pdf')}Invoice</a>` : ''}
          </span>
          ${s === 'DRAFT' && can('orders:write') ? html`<button class="btn" data-edit>Edit</button><button class="btn danger" data-delete>Delete</button>` : ''}
          ${!pending && ['CONFIRMED', 'SHIPPED'].includes(s) && can('orders:write') ? html`<button class="btn" data-amend>${approver ? (s === 'SHIPPED' ? 'Amend invoice / return' : 'Change order') : (s === 'SHIPPED' ? 'Request invoice change / return' : 'Request change')}</button>` : ''}
          ${!pending && ['DRAFT', 'CONFIRMED'].includes(s) && can('orders:write') ? html`<button class="btn danger" data-cancel>${s === 'CONFIRMED' && !approver ? 'Request cancellation' : 'Cancel order'}</button>` : ''}
          ${s === 'DRAFT' && can('orders:write') ? html`<button class="btn primary" data-confirm${short.length ? raw(' title="Some lines are short of stock"') : ''}>Confirm &amp; reserve</button>` : ''}
          ${!pending && s === 'CONFIRMED' && can('stock:write') ? html`<button class="btn success" data-ship>Ship order</button>` : ''}
        </div></div>
      ${pendingBanner(pending)}
      ${!approver && ['CONFIRMED', 'SHIPPED'].includes(s) && !pending && can('orders:write') ? html`<p class="muted small">This order is ${s === 'SHIPPED' ? 'invoiced' : 'confirmed'}. Changes, customer returns and cancellations are sent to your manager for approval.</p>` : ''}
      ${short.length ? html`<div class="card"><div class="card-body"><span class="badge red">Stock shortage</span> ${short.map((l) => `${l.sku} (need ${l.qty}, ${l.available} available)`).join(' · ')}. The order cannot be confirmed until stock is available in ${so.warehouse_code}.</div></div>` : ''}
      <div class="grid kpis">
        ${kpi('Order total', fmt.money(so.total), `${so.lines.length} line${so.lines.length === 1 ? '' : 's'}`)}
        ${s === 'SHIPPED' ? kpi('Cost of goods', fmt.money(so.cogs), 'At moving-average cost') : ''}
        ${s === 'SHIPPED' ? kpi('Gross margin', fmt.money(so.margin), so.total ? `${((so.margin / so.total) * 100).toFixed(1)}%` : '') : ''}
        ${s === 'CONFIRMED' ? kpi('Reserved', fmt.num(so.lines.reduce((t, l) => t + l.qty, 0)), 'Units held for this order') : ''}
        ${so.returned_qty ? kpi('Customer returns', fmt.num(so.returned_qty), `${fmt.money(so.returned_value)} credited`, { alert: true }) : ''}
      </div>
      <div class="card"><div class="card-head"><h2>Lines</h2></div>
        ${table([
          { label: 'SKU', render: (l) => html`<a class="mono" href="#/products/${l.product_id}">${l.sku}</a>` },
          { label: 'Product', key: 'product_name' },
          { label: 'Qty', cls: 'num', render: (l) => html`${fmt.num(l.qty)} <span class="sub">${l.unit}</span>` },
          ...(s === 'DRAFT' ? [{ label: 'Available', cls: 'num', render: (l) => html`<span class="${l.available < l.qty ? 'qty-neg' : ''}">${fmt.num(l.available)}</span>` }] : []),
          ...(so.returned_qty ? [{ label: 'Returned', cls: 'num', render: (l) => (l.qty_returned ? html`<span class="qty-neg">${fmt.num(l.qty_returned)}</span>` : '—') }] : []),
          { label: 'Unit price', cls: 'num', render: (l) => fmt.money(l.unit_price) },
          { label: 'Line total', cls: 'num', render: (l) => fmt.money(l.line_total) },
        ], so.lines, { foot: html`<tr><td colspan="${(s === 'DRAFT' ? 5 : 4) + (so.returned_qty ? 1 : 0)}">Total${so.returned_qty ? ' (after returns)' : ''}</td><td class="num">${fmt.money(so.total)}</td></tr>` })}</div>
      <div class="grid halves">
        <div class="card"><div class="card-head"><h2>Details</h2></div><div class="card-body"><dl class="info-grid">
          <div><dt>Customer</dt><dd>${so.customer_name}${so.customer_email ? html`<div class="sub">${so.customer_email}</div>` : ''}</dd></div>
          <div><dt>Ship to</dt><dd>${so.customer_address || '—'}</dd></div>
          <div><dt>Created by</dt><dd>${so.created_by_name || '—'}<div class="sub">${fmt.dt(so.created_at)}</div></dd></div>
          <div><dt>Confirmed</dt><dd>${fmt.dt(so.confirmed_at)}</dd></div>
          <div><dt>Shipped</dt><dd>${fmt.dt(so.shipped_at)}</dd></div>
        </dl>${so.notes ? html`<p><strong>Notes:</strong> ${so.notes}</p>` : ''}</div></div>
        ${history}
      </div>`)) return;

    const on = (sel, fn) => { const el = $(sel, ctx.view); if (el) el.addEventListener('click', fn); };
    on('[data-edit]', () => orderDialog('so', so));
    on('[data-confirm]', () => orderAction(`/api/sales-orders/${so.id}/confirm`, `${so.number} confirmed — stock reserved`));
    on('[data-ship]', () => orderAction(`/api/sales-orders/${so.id}/ship`, `${so.number} shipped`,
      ['Ship order', `Mark ${so.number} as shipped? Reserved stock will be issued from ${so.warehouse_code}.`], { label: 'Ship' }));
    on('[data-amend]', () => amendDialog(so));
    on('[data-cancel]', async () => {
      if (s !== 'CONFIRMED') {
        orderAction(`/api/sales-orders/${so.id}/cancel`, `${so.number} cancelled`, ['Cancel sales order', `Cancel ${so.number}?`], { label: 'Cancel order', danger: true });
        return;
      }
      const reason = await reasonDialog({
        title: approver ? 'Cancel sales order' : 'Request cancellation',
        message: approver ? `Cancel ${so.number}? Reserved stock will be released.` : `Your manager must approve cancelling ${so.number}. Reserved stock stays held until then.`,
        label: approver ? 'Cancel order' : 'Send for approval', danger: true, placeholder: 'e.g. Customer withdrew the order',
      });
      if (reason === null) return;
      try {
        const res = await POST(`/api/sales-orders/${so.id}/cancel`, { reason });
        approvalToast(res, `${so.number} cancelled`);
        navigate();
      } catch (err) { toast(err.message, 'error'); }
    });
    on('[data-delete]', async () => {
      if (!await confirmDialog('Delete draft', `Permanently delete draft ${so.number}?`, { label: 'Delete', danger: true })) return;
      try { await DEL(`/api/sales-orders/${so.id}`); toast(`${so.number} deleted`, 'success'); location.hash = '#/sales-orders'; }
      catch (err) { toast(err.message, 'error'); }
    });
  }, 'Sales order');

  /**
   * Change a confirmed order, or amend a shipped invoice (price corrections and customer returns).
   * Managers/admins apply immediately; sales agents send it to their manager for approval.
   */
  async function amendDialog(so) {
    await lookups();
    const approver = can('approvals:decide');
    const shipped = so.status === 'SHIPPED';
    const products = S.lookups.products.filter((p) => p.active);
    const byId = new Map(S.lookups.products.map((p) => [p.id, p]));
    let lines = so.lines.map((l) => ({ product_id: l.product_id, qty: l.qty, price: l.unit_price }));
    const body = shipped
      ? html`<p class="muted">Enter quantities the customer is returning and/or corrected prices. Returned items are credited on the invoice.</p>
        <div class="table-wrap"><table class="lines-table"><thead><tr><th>Product</th><th class="num">Sold</th><th class="num">Already returned</th><th class="num">Return now</th><th class="num">Unit price</th></tr></thead><tbody>
        ${so.lines.map((l) => html`<tr data-line="${l.id}"><td><strong>${l.product_name}</strong><div class="sub mono">${l.sku}</div></td>
          <td class="num">${fmt.num(l.qty)}</td><td class="num">${fmt.num(l.qty_returned)}</td>
          <td class="w-qty"><input type="number" min="0" max="${l.qty - l.qty_returned}" step="1" value="0" data-k="return_qty" aria-label="Return quantity for ${l.sku}"${l.qty - l.qty_returned ? '' : raw(' disabled')}></td>
          <td class="w-price"><input type="number" min="0" step="0.01" value="${l.unit_price}" data-k="unit_price" aria-label="Unit price for ${l.sku}"></td></tr>`)}
        </tbody></table></div>
        <div class="form-grid" style="margin-top:14px">
          ${field({ name: 'restock_location_id', label: 'Returned goods go to', type: 'select', options: whOptions(), placeholder: false }, so.warehouse_id)}
          ${field({ name: 'condition', label: 'Condition of returned goods', type: 'select', placeholder: false, options: [{ value: 'GOOD', label: 'Good: put back into stock' }, { value: 'DAMAGED', label: 'Damaged: write off' }] }, 'GOOD')}
        </div>`
      : html`<p class="muted">Edit quantities, prices or products. Stock is re-reserved in ${so.warehouse_code} when the change is applied.</p>
        <div class="table-wrap"><table class="lines-table"><thead><tr><th>Product</th><th class="num">Qty</th><th class="num">Unit price</th><th></th></tr></thead><tbody data-lines></tbody></table></div>
        <button type="button" class="btn sm" data-add-line style="margin-top:8px">${icon('plus')}Add line</button>`;
    const { form } = openModal({
      title: shipped ? `Amend invoice ${so.number}` : `Change ${so.number}`, wide: true,
      submitLabel: approver ? 'Apply change' : 'Send for approval',
      body: html`${body}
        <div class="form-grid" style="margin-top:14px">
          ${field({ name: 'notes', label: 'Order notes', type: 'textarea', full: true }, so.notes)}
          ${field({ name: 'reason', label: approver ? 'Reason for the change' : 'Reason (shown to your manager)', type: 'textarea', full: true, required: true, placeholder: 'e.g. Customer returned 2 damaged units' })}
        </div>
        ${approver ? '' : html`<p class="notice pending small">Nothing changes until your manager approves this request.</p>`}`,
      onSubmit: async (f) => {
        const reason = f.elements.reason.value.trim();
        if (!reason) throw new ApiError('Please give a reason', 422, { reason: 'is required' });
        const payload = { reason, notes: f.elements.notes.value.trim() || null };
        if (shipped) {
          payload.lines = $$('tr[data-line]', f).map((tr) => ({
            line_id: Number(tr.dataset.line),
            return_qty: Number($('[data-k="return_qty"]', tr).value || 0),
            unit_price: $('[data-k="unit_price"]', tr).value === '' ? null : Number($('[data-k="unit_price"]', tr).value),
          }));
          payload.restock_location_id = Number(f.elements.restock_location_id.value);
          payload.condition = f.elements.condition.value;
        } else {
          payload.lines = lines.filter((l) => l.product_id).map((l) => ({ product_id: Number(l.product_id), qty: Number(l.qty), unit_price: l.price === '' || l.price === null ? null : Number(l.price) }));
        }
        const res = await POST(`/api/sales-orders/${so.id}/amend`, payload);
        approvalToast(res, `${so.number} updated`);
        refreshLowCount();
        navigate();
      },
    });
    if (shipped) return;
    const tbody = $('[data-lines]', form);
    const render = () => {
      tbody.innerHTML = lines.map((l) => html`<tr>
        <td><select data-k="product_id" aria-label="Product"><option value="">Select product…</option>
          ${products.map((p) => html`<option value="${p.id}"${String(p.id) === String(l.product_id) ? raw(' selected') : ''}>${p.sku} — ${p.name}</option>`)}</select></td>
        <td class="w-qty"><input data-k="qty" type="number" min="1" step="1" value="${l.qty}" aria-label="Quantity"></td>
        <td class="w-price"><input data-k="price" type="number" min="0" step="0.01" value="${l.price ?? ''}" aria-label="Unit price"></td>
        <td><button type="button" class="icon-btn" data-remove aria-label="Remove line">×</button></td></tr>`.s).join('');
    };
    tbody.addEventListener('input', (e) => {
      const i = $$('tr', tbody).indexOf(e.target.closest('tr'));
      const k = e.target.dataset.k;
      if (!k || i < 0) return;
      lines[i][k] = e.target.value;
      if (k === 'product_id' && e.target.value) {
        const p = byId.get(Number(e.target.value));
        if (p) { lines[i].price = p.price; $('[data-k="price"]', e.target.closest('tr')).value = p.price; }
      }
    });
    tbody.addEventListener('click', (e) => {
      if (!e.target.closest('[data-remove]')) return;
      lines.splice($$('tr', tbody).indexOf(e.target.closest('tr')), 1);
      if (!lines.length) lines = [{ product_id: '', qty: 1, price: '' }];
      render();
    });
    $('[data-add-line]', form).addEventListener('click', () => { lines.push({ product_id: '', qty: 1, price: '' }); render(); });
    render();
  }

  // =====================================================================
  // Generic master-data pages
  // =====================================================================
  function crudPage(cfg) {
    return async (ctx) => {
      await lookups();
      if (cfg.load) await cfg.load();
      const f = { q: ctx.q('q'), active: ctx.q('active', cfg.hasActive ? '1' : ''), offset: ctx.q('offset', '0') };
      if (cfg.tabs) f[cfg.tabs.key] = ctx.q(cfg.tabs.key);
      const d = await GET(`/api/${cfg.endpoint}?${qs({ ...f, active: f.active === 'all' ? '' : f.active })}`);
      const tabs = cfg.tabs ? html`<nav class="tabs">${cfg.tabs.options.map(([v, l]) => {
        const q = qs({ q: f.q, active: f.active === '1' ? '' : f.active, [cfg.tabs.key]: v });
        return html`<a href="#${ctx.path}${q ? `?${q}` : ''}" class="${f[cfg.tabs.key] === v ? 'active' : ''}">${l}</a>`;
      })}</nav>` : '';
      const canWrite = can(cfg.perm || 'master:write');
      const cols = [...cfg.columns];
      if (canWrite) {
        cols.push({ label: '', cls: 'num', render: (r) => html`<button class="btn sm" data-edit="${r.id}">Edit</button>
          ${cfg.noDelete ? '' : html` <button class="btn sm danger" data-del="${r.id}">Delete</button>`}` });
      }
      if (!ctx.render(html`
        <div class="page-head"><div><h1>${cfg.title}</h1><p>${cfg.desc}</p></div>
          ${canWrite ? html`<div class="actions"><button class="btn primary" data-new>${icon('plus')}New ${cfg.singular}</button></div>` : ''}</div>
        <div class="card">${tabs}
          <div class="toolbar"><input class="search" type="search" data-filter="q" value="${f.q}" placeholder="Search ${cfg.title.toLowerCase()}">
            ${cfg.hasActive ? html`<select data-filter="active" aria-label="Status">${[['1', 'Active'], ['0', 'Inactive'], ['all', 'All']].map(([v, l]) => html`<option value="${v}"${v === f.active ? raw(' selected') : ''}>${l}</option>`)}</select>` : ''}
          </div>
          ${table(cols, d.items, { empty: `No ${cfg.title.toLowerCase()} found` })}
          ${pager(d)}
        </div>
        ${cfg.extra ? cfg.extra() : ''}`)) return;
      bindFilters(ctx);
      const nb = $('[data-new]', ctx.view);
      if (nb) nb.addEventListener('click', () => crudDialog(cfg));
      $$('[data-edit]', ctx.view).forEach((b) => b.addEventListener('click', () => crudDialog(cfg, d.items.find((x) => String(x.id) === b.dataset.edit))));
      $$('[data-del]', ctx.view).forEach((b) => b.addEventListener('click', async () => {
        const item = d.items.find((x) => String(x.id) === b.dataset.del);
        if (!await confirmDialog(`Delete ${cfg.singular}`, `Delete "${item.name || item.code}"?${cfg.hasActive ? ' Records already in use will be deactivated instead.' : ''}`, { label: 'Delete', danger: true })) return;
        try {
          const r = await DEL(`/api/${cfg.endpoint}/${item.id}`);
          await lookups(true);
          toast(r.message || `${cfg.singular[0].toUpperCase() + cfg.singular.slice(1)} deleted`, 'success');
          navigate();
        } catch (err) { toast(err.message, 'error'); }
      }));
    };
  }

  function crudDialog(cfg, item) {
    const F = cfg.fields(item);
    openModal({
      title: item ? `Edit ${cfg.singular}` : `New ${cfg.singular}`,
      wide: F.length > 5,
      body: html`<div class="form-grid">${F.map((f) => field(f, item ? item[f.name] : f.type === 'checkbox' ? true : f.default))}</div>`,
      submitLabel: item ? 'Save changes' : `Create ${cfg.singular}`,
      onSubmit: async (form) => {
        const v = readForm(form, F);
        if (item) await PUT(`/api/${cfg.endpoint}/${item.id}`, v); else await POST(`/api/${cfg.endpoint}`, v);
        await lookups(true);
        toast(item ? 'Changes saved' : `${cfg.singular[0].toUpperCase() + cfg.singular.slice(1)} created`, 'success');
        navigate();
      },
    });
  }

  const activeField = (item) => (item ? [{ name: 'active', label: 'Active', type: 'checkbox', full: true }] : []);

  route(/^\/suppliers$/, crudPage({
    title: 'Suppliers', singular: 'supplier', endpoint: 'suppliers', hasActive: true,
    desc: 'Vendors you purchase from. Lead times help plan replenishment.',
    columns: [
      { label: 'Supplier', render: (s) => html`<strong>${s.name}</strong>${s.contact_name ? html`<div class="sub">${s.contact_name}</div>` : ''}` },
      { label: 'Email', render: (s) => (s.email ? html`<a href="mailto:${s.email}">${s.email}</a>` : '—') },
      { label: 'Phone', render: (s) => s.phone || '—' },
      { label: 'Lead time', cls: 'num', render: (s) => (s.lead_time_days !== null ? `${s.lead_time_days} days` : '—') },
      { label: 'Status', render: activeBadge },
    ],
    fields: (s) => [
      { name: 'name', label: 'Company name', required: true, full: true },
      { name: 'contact_name', label: 'Contact person' }, { name: 'email', label: 'Email', type: 'email' },
      { name: 'phone', label: 'Phone' }, { name: 'lead_time_days', label: 'Lead time (days)', type: 'number', step: '1', min: 0 },
      { name: 'address', label: 'Address', type: 'textarea', full: true }, ...activeField(s),
    ],
  }), 'Suppliers');

  route(/^\/customers$/, crudPage({
    title: 'Customers', singular: 'customer', endpoint: 'customers', hasActive: true,
    desc: 'Accounts you sell and ship to.',
    columns: [
      { label: 'Customer', render: (c) => html`<strong>${c.name}</strong>` },
      { label: 'Email', render: (c) => (c.email ? html`<a href="mailto:${c.email}">${c.email}</a>` : '—') },
      { label: 'Phone', render: (c) => c.phone || '—' },
      { label: 'Address', render: (c) => c.address || '—' },
      { label: 'Status', render: activeBadge },
    ],
    fields: (c) => [
      { name: 'name', label: 'Customer name', required: true, full: true },
      { name: 'email', label: 'Email', type: 'email' }, { name: 'phone', label: 'Phone' },
      { name: 'address', label: 'Shipping address', type: 'textarea', full: true }, ...activeField(c),
    ],
  }), 'Customers');

  route(/^\/warehouses$/, crudPage({
    title: 'Warehouses & sales centers', singular: 'location', endpoint: 'warehouses', hasActive: true,
    desc: 'Every place that holds stock. Warehouses store and replenish; sales centers sell to customers and return unsold or damaged goods to a warehouse.',
    tabs: { key: 'kind', options: [['', 'All locations'], ['WAREHOUSE', 'Warehouses'], ['SALES_CENTER', 'Sales centers']] },
    columns: [
      { label: 'Code', render: (w) => html`<strong class="mono">${w.code}</strong>` },
      { label: 'Name', render: (w) => html`${w.name}${w.manager_name ? html`<div class="sub">Manager: ${w.manager_name}</div>` : ''}` },
      { label: 'Type', render: (w) => kindBadge(w.kind) },
      { label: 'Address', render: (w) => w.address || '—' },
      { label: 'Phone', render: (w) => w.phone || '—' },
      { label: 'Status', render: activeBadge },
      { label: '', render: (w) => html`<a href="#/stock?warehouse_id=${w.id}">Stock →</a>${w.kind === 'SALES_CENTER' ? html` · <a href="#/returns?from_location_id=${w.id}">Returns →</a>` : ''}` },
    ],
    fields: (w) => [
      { name: 'code', label: 'Code', required: true, hint: 'Short unique code, e.g. CWH or SC-01' }, { name: 'name', label: 'Name', required: true },
      { name: 'kind', label: 'Type', type: 'select', required: true, placeholder: false, default: 'WAREHOUSE',
        options: [{ value: 'WAREHOUSE', label: 'Warehouse' }, { value: 'SALES_CENTER', label: 'Sales center' }] },
      { name: 'manager_name', label: 'Manager' }, { name: 'phone', label: 'Phone' },
      { name: 'address', label: 'Address', type: 'textarea', full: true }, ...activeField(w),
    ],
  }), 'Locations');

  route(/^\/categories$/, crudPage({
    title: 'Categories', singular: 'category', endpoint: 'categories',
    desc: 'Group products for reporting and filtering.',
    columns: [
      { label: 'Name', render: (c) => html`<strong>${c.name}</strong>` },
      { label: 'Description', render: (c) => c.description || '—' },
      { label: '', render: (c) => html`<a href="#/products?category_id=${c.id}">View products →</a>` },
    ],
    fields: () => [{ name: 'name', label: 'Name', required: true, full: true }, { name: 'description', label: 'Description', type: 'textarea', full: true }],
  }), 'Categories');

  const ROLE_INFO = [
    ['admin', 'Full access, including user management and all approvals.'],
    ['manager', 'Manage master data, approve and cancel purchase orders, approve sales agents\' change requests, view the audit log.'],
    ['clerk', 'Sales agent / warehouse clerk: receive, issue, count and transfer stock; create, confirm and ship orders. Changing a confirmed order or invoice, customer returns, and dispatching or cancelling returns need approval from their manager.'],
    ['viewer', 'Read-only access to all inventory data and reports.'],
  ];
  route(/^\/users$/, crudPage({
    title: 'Users & roles', singular: 'user', endpoint: 'users', perm: 'users:manage', noDelete: true,
    desc: 'Manage who can sign in and what they can do. Users are deactivated, never deleted, to preserve the audit trail.',
    columns: [
      { label: 'User', render: (u) => html`<strong>${u.name}</strong><div class="sub">${u.email}</div>` },
      { label: 'Role', render: (u) => roleBadge(u.role) },
      { label: 'Reports to', render: (u) => u.manager_name || html`<span class="muted">${u.role === 'clerk' ? 'Any manager' : '—'}</span>` },
      { label: 'Status', render: activeBadge },
      { label: 'Last sign-in', render: (u) => fmt.dt(u.last_login_at) },
    ],
    // Managers/admins who can approve, for the "Reports to" picker.
    load: async () => { S.approvers = (await GET('/api/users?limit=500')).items.filter((x) => x.active && ['admin', 'manager'].includes(x.role)); },
    fields: (u) => [
      ...(u ? [{ name: 'email', label: 'Email', readonly: true }] : [{ name: 'email', label: 'Email', type: 'email', required: true }]),
      { name: 'name', label: 'Full name', required: true },
      { name: 'role', label: 'Role', type: 'select', required: true, options: ROLE_INFO.map(([r]) => ({ value: r, label: r === 'clerk' ? 'Clerk / sales agent' : r[0].toUpperCase() + r.slice(1) })) },
      { name: 'manager_id', label: 'Reports to (approving manager)', type: 'select', placeholder: 'Any manager or administrator',
        options: (S.approvers || []).filter((m) => !u || m.id !== u.id).map((m) => ({ value: m.id, label: `${m.name} (${m.role})` })),
        hint: 'Change requests from this user go to this manager. Administrators can always approve.' },
      { name: 'password', label: u ? 'Reset password' : 'Initial password', type: 'password', required: !u, hint: u ? 'Leave blank to keep the current password.' : 'At least 10 characters with letters and numbers.' },
      ...(u ? [{ name: 'active', label: 'Account active', type: 'checkbox', full: true }] : []),
    ],
    extra: () => html`<div class="card"><div class="card-head"><h2>Role permissions</h2></div>
      ${table([{ label: 'Role', render: (r) => roleBadge(r[0]) }, { label: 'Can do', render: (r) => r[1] }], ROLE_INFO)}</div>`,
  }), 'Users');

  // =====================================================================
  // Audit log
  // =====================================================================
  const ENTITIES = ['product', 'purchase_order', 'sales_order', 'stock_return', 'approval', 'user', 'warehouse', 'supplier', 'customer', 'category', 'import', 'settings', 'system'];
  route(/^\/audit$/, async (ctx) => {
    const f = { q: ctx.q('q'), entity: ctx.q('entity'), offset: ctx.q('offset', '0') };
    const d = await GET(`/api/audit?${qs(f)}`);
    const entityLink = (a) => {
      if (!a.entity_id) return a.entity || '—';
      const map = { product: 'products', purchase_order: 'purchase-orders', sales_order: 'sales-orders', stock_return: 'returns', approval: 'approvals' };
      return map[a.entity] ? html`<a href="#/${map[a.entity]}/${a.entity_id}">${a.entity} #${a.entity_id}</a>` : `${a.entity} #${a.entity_id}`;
    };
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Audit log</h1><p>Who did what, and when. Entries cannot be edited or removed through the application.</p></div>
        <div class="actions">${exportButtons(`/api/audit?${qs({ ...f, offset: '' })}`)}</div></div>
      <div class="card">
        <div class="toolbar"><input class="search" type="search" data-filter="q" value="${f.q}" placeholder="Search action or user email">
          <select data-filter="entity" aria-label="Entity"><option value="">All entities</option>${ENTITIES.map((e) => html`<option value="${e}"${e === f.entity ? raw(' selected') : ''}>${e.replace('_', ' ')}</option>`)}</select></div>
        ${table([
          { label: 'When', render: (a) => html`<span class="nowrap">${fmt.dt(a.created_at)}</span>` },
          { label: 'User', render: (a) => a.user_email || html`<span class="muted">anonymous</span>` },
          { label: 'Action', render: (a) => html`<span class="mono">${a.action}</span>` },
          { label: 'Entity', render: entityLink },
          { label: 'Details', render: (a) => (a.details ? html`<details><summary>view</summary><pre class="json">${JSON.stringify(JSON.parse(a.details), null, 2)}</pre></details>` : '') },
          { label: 'IP', render: (a) => html`<span class="mono">${a.ip || ''}</span>` },
        ], d.items, { empty: 'No audit entries match' })}
        ${pager(d)}
      </div>`)) return;
    bindFilters(ctx);
  }, 'Audit log');

  // =====================================================================
  // Reports
  // =====================================================================
  route(/^\/reports$/, async (ctx) => {
    const tab = ctx.q('tab', 'valuation');
    const group = ctx.q('group', 'warehouse');
    const today = new Date().toISOString().slice(0, 10);
    const monthAgo = new Date(Date.now() - 29 * 86400000).toISOString().slice(0, 10);
    const from = ctx.q('from', monthAgo);
    const to = ctx.q('to', today);
    const tabs = html`<nav class="tabs">
      <a href="#/reports?tab=valuation" class="${tab === 'valuation' ? 'active' : ''}">Inventory valuation</a>
      <a href="#/reports?tab=sales" class="${tab === 'sales' ? 'active' : ''}">Sales &amp; margin</a>
      <a href="#/reports?tab=exports" class="${tab === 'exports' ? 'active' : ''}">Data exports</a></nav>`;
    let body;
    if (tab === 'valuation') {
      const d = await GET(`/api/reports/valuation?group=${group}`);
      body = html`<div class="toolbar"><select data-filter="group" aria-label="Group by">
          ${[['warehouse', 'Group by warehouse'], ['category', 'Group by category'], ['product', 'Group by product']].map(([v, l]) => html`<option value="${v}"${v === group ? raw(' selected') : ''}>${l}</option>`)}</select>
          <div style="flex:1"></div>${exportButtons(`/api/reports/valuation?group=${group}`)}</div>
        ${table([
          { label: group[0].toUpperCase() + group.slice(1), render: (r) => html`<strong>${r.key}</strong>${r.label ? html`<div class="sub">${r.label}</div>` : ''}` },
          { label: 'SKUs', cls: 'num', render: (r) => fmt.num(r.skus) },
          { label: 'Units', cls: 'num', render: (r) => fmt.num(r.units) },
          { label: 'Cost value', cls: 'num', render: (r) => fmt.money(r.value) },
          { label: 'Retail value', cls: 'num', render: (r) => fmt.money(r.retail_value) },
          { label: 'Share', cls: 'num', render: (r) => (d.totals.value ? `${((r.value / d.totals.value) * 100).toFixed(1)}%` : '—') },
        ], d.items, { foot: html`<tr><td colspan="2">Total</td><td class="num">${fmt.num(d.totals.units)}</td><td class="num">${fmt.money(d.totals.value)}</td><td class="num">${fmt.money(d.totals.retail_value)}</td><td></td></tr>` })}`;
    } else if (tab === 'sales') {
      const d = await GET(`/api/reports/sales?${qs({ from, to })}`);
      body = html`<div class="toolbar"><label class="muted">From</label><input type="date" data-filter="from" value="${from}"><label class="muted">To</label><input type="date" data-filter="to" value="${to}">
          <div style="flex:1"></div>${exportButtons(`/api/reports/sales?${qs({ from, to })}`)}</div>
        <div class="card-body"><div class="grid kpis">
          ${kpi('Revenue', fmt.money(d.totals.revenue))}${kpi('Cost of goods', fmt.money(d.totals.cogs))}
          ${kpi('Gross margin', fmt.money(d.totals.margin), d.totals.revenue ? `${((d.totals.margin / d.totals.revenue) * 100).toFixed(1)}% of revenue` : '')}
          ${kpi('Units shipped', fmt.num(d.totals.units))}</div></div>
        ${table([
          { label: 'Product', render: (r) => html`<strong>${r.name}</strong><div class="sub mono">${r.sku}</div>` },
          { label: 'Units', cls: 'num', render: (r) => fmt.num(r.units) },
          { label: 'Revenue', cls: 'num', render: (r) => fmt.money(r.revenue) },
          { label: 'COGS', cls: 'num', render: (r) => fmt.money(r.cogs) },
          { label: 'Margin', cls: 'num', render: (r) => fmt.money(r.margin) },
          { label: 'Margin %', cls: 'num', render: (r) => (r.revenue ? `${((r.margin / r.revenue) * 100).toFixed(1)}%` : '—') },
        ], d.items, { empty: 'No shipped orders in this period' })}`;
    } else {
      const exp = [
        ['Product catalogue', 'All products with stock position and costing', '/api/products?active='],
        ['Low stock products', 'Products at or below their reorder point', '/api/products?low_stock=1&active=1'],
        ['Stock levels', 'On-hand, reserved and available by warehouse and sales center', '/api/stock?nonzero=1'],
        ['Replenishment', 'Suggested reorder quantities grouped by supplier', '/api/reorder-suggestions?'],
        ['Movement ledger', 'Every stock movement (CSV up to 100,000 rows; PDF first 5,000)', '/api/movements?'],
        ['Purchase orders', 'All POs with receipt progress', '/api/purchase-orders?'],
        ['Sales orders', 'All sales orders with totals', '/api/sales-orders?'],
        ['Returns to warehouse', 'Stock returned from sales centers', '/api/returns?'],
        ...(can('audit:read') ? [['Audit log', 'Complete activity trail', '/api/audit?']] : []),
      ];
      body = html`<div class="card-body muted">PDF reports carry your company letterhead, logo and colours. Change them under <a href="#/branding">Company branding</a>${can('settings:manage') ? '' : ' (administrators)'}.</div>
        ${table([
          { label: 'Dataset', render: (e) => html`<strong>${e[0]}</strong>` },
          { label: 'Contents', render: (e) => e[1] },
          { label: '', cls: 'num', render: (e) => exportButtons(e[2], { compact: true }) },
        ], exp)}`;
    }
    if (!ctx.render(html`<div class="page-head"><div><h1>Reports</h1><p>Valuation, profitability and raw data exports. Valuation uses moving weighted-average cost.</p></div></div>
      <div class="card">${tabs}${body}</div>`)) return;
    bindFilters(ctx);
  }, 'Reports');

  // =====================================================================
  // Returns: sales center -> warehouse
  // =====================================================================
  const RETURN_REASONS = {
    UNSOLD: 'Unsold stock', OVERSTOCK: 'Overstock', DAMAGED: 'Damaged', EXPIRED: 'Expired',
    RECALL: 'Product recall', CUSTOMER_RETURN: 'Customer return', OTHER: 'Other',
  };

  route(/^\/returns$/, async (ctx) => {
    await lookups();
    const f = { q: ctx.q('q'), status: ctx.q('status'), from_location_id: ctx.q('from_location_id'), offset: ctx.q('offset', '0') };
    const d = await GET(`/api/returns?${qs(f)}`);
    const tab = (s, label) => {
      const q = qs({ ...f, status: s, offset: '' });
      const n = s ? d.counts[s] || 0 : null;
      return html`<a href="#/returns${q ? `?${q}` : ''}" class="${f.status === s ? 'active' : ''}">${label}${n ? html` <span class="count">${n}</span>` : ''}</a>`;
    };
    const centers = whOptions(true, 'SALES_CENTER');
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Returns to warehouse</h1><p>Send unsold, overstocked or damaged goods from a sales center back to a warehouse. Stock leaves the sales center on dispatch and is added to the warehouse when received and inspected.</p></div>
        <div class="actions">${exportButtons(`/api/returns?${qs({ ...f, offset: '' })}`)}
          ${can('stock:write') ? html`<button class="btn primary" data-new>${icon('plus')}New return</button>` : ''}</div></div>
      ${!centers.length ? html`<div class="card"><div class="card-body">No sales centers yet. Add one under <a href="#/warehouses?kind=SALES_CENTER">Warehouses &amp; sales centers</a> (set the type to “Sales center”).</div></div>` : ''}
      <div class="card">
        <nav class="tabs">${tab('', 'All')}${tab('DRAFT', 'Draft')}${tab('DISPATCHED', 'In transit')}${tab('RECEIVED', 'Received')}${tab('CANCELLED', 'Cancelled')}</nav>
        <div class="toolbar"><input class="search" type="search" data-filter="q" value="${f.q}" placeholder="Search return number or sales center">
          <select data-filter="from_location_id" aria-label="Sales center"><option value="">All sales centers</option>
            ${centers.map((w) => html`<option value="${w.value}"${String(w.value) === f.from_location_id ? raw(' selected') : ''}>${w.label}</option>`)}</select></div>
        ${table([
          { label: 'Return', render: (r) => html`<strong class="mono">${r.number}</strong>` },
          { label: 'From sales center', render: (r) => html`${r.from_name}<div class="sub mono">${r.from_code}</div>` },
          { label: 'To warehouse', render: (r) => html`${r.to_name}<div class="sub mono">${r.to_code}</div>` },
          { label: 'Reason', render: (r) => RETURN_REASONS[r.reason] || r.reason },
          { label: 'Status', render: (r) => statusBadge(r.status) },
          { label: 'Units', cls: 'num', render: (r) => fmt.num(r.total_qty) },
          { label: 'Value', cls: 'num', render: (r) => fmt.money(r.total_value) },
          { label: 'Created', render: (r) => fmt.date(r.created_at) },
        ], d.items, { empty: 'No returns found', href: (r) => `#/returns/${r.id}` })}
        ${pager(d)}
      </div>`)) return;
    bindFilters(ctx);
    const nb = $('[data-new]', ctx.view);
    if (nb) nb.addEventListener('click', () => returnDialog(null, f.from_location_id ? Number(f.from_location_id) : null));
  }, 'Returns');

  async function returnDialog(existing, presetFrom = null) {
    await lookups();
    const centers = whOptions(false, 'SALES_CENTER');
    const warehouses = whOptions(false, 'WAREHOUSE');
    if (!centers.length || !warehouses.length) { toast('You need at least one active sales center and one active warehouse', 'error'); return; }
    const H = [
      { name: 'from_location_id', label: 'From sales center', type: 'select', options: centers, required: true },
      { name: 'to_location_id', label: 'To warehouse', type: 'select', options: warehouses, required: true },
      { name: 'reason', label: 'Reason', type: 'select', required: true, placeholder: false, options: Object.entries(RETURN_REASONS).map(([value, label]) => ({ value, label })) },
      { name: 'notes', label: 'Notes', type: 'textarea', full: true },
    ];
    const hv = existing || { from_location_id: presetFrom || centers[0].value, to_location_id: warehouses[0].value, reason: 'UNSOLD' };
    let lines = existing ? existing.lines.map((l) => ({ product_id: l.product_id, qty: l.qty, note: l.note || '' })) : [{ product_id: '', qty: 1, note: '' }];
    let avail = new Map();
    const { form } = openModal({
      title: existing ? `Edit ${existing.number}` : 'New return to warehouse', wide: true,
      submitLabel: existing ? 'Save changes' : 'Create draft',
      body: html`<div class="form-grid">${H.map((f) => field(f, hv[f.name]))}</div>
        <h3 style="margin:20px 0 8px">Products to return</h3>
        <p class="muted" data-avail-note>Only products with available stock at the selected sales center are listed.</p>
        <div class="table-wrap"><table class="lines-table"><thead><tr><th>Product</th><th class="num">Available</th><th class="num">Qty to return</th><th>Line note</th><th></th></tr></thead><tbody data-lines></tbody></table></div>
        <button type="button" class="btn sm" data-add-line style="margin-top:8px">${icon('plus')}Add product</button>`,
      onSubmit: async (f) => {
        const payload = { ...readForm(f, H), lines: lines.filter((l) => l.product_id).map((l) => ({ product_id: Number(l.product_id), qty: Number(l.qty), note: l.note || null })) };
        const saved = existing ? await PUT(`/api/returns/${existing.id}`, payload) : await POST('/api/returns', payload);
        toast(`${saved.number} ${existing ? 'updated' : 'created'}`, 'success');
        const target = `#/returns/${saved.id}`;
        if (location.hash === target) navigate(); else location.hash = target;
      },
    });
    const tbody = $('[data-lines]', form);
    const render = () => {
      const opts = [...avail.values()];
      tbody.innerHTML = lines.map((l) => {
        const a = avail.get(Number(l.product_id));
        return html`<tr>
          <td><select data-k="product_id" aria-label="Product"><option value="">Select product…</option>
            ${opts.map((p) => html`<option value="${p.product_id}"${String(p.product_id) === String(l.product_id) ? raw(' selected') : ''}>${p.sku} — ${p.name}</option>`)}</select></td>
          <td class="num">${a ? html`${fmt.num(a.available)} <span class="sub">${a.unit}</span>` : '—'}</td>
          <td class="w-qty"><input data-k="qty" type="number" min="1" step="1" value="${l.qty}" aria-label="Quantity"${a ? raw(` max="${a.available}"`) : ''}></td>
          <td><input data-k="note" value="${l.note || ''}" aria-label="Line note" placeholder="Optional"></td>
          <td><button type="button" class="icon-btn" data-remove aria-label="Remove line">×</button></td></tr>`.s;
      }).join('');
    };
    const loadAvail = async () => {
      const id = form.elements.from_location_id.value;
      if (!id) { avail = new Map(); render(); return; }
      const d = await GET(`/api/returns/available?location_id=${id}`);
      avail = new Map(d.items.map((p) => [p.product_id, p]));
      // A draft being edited keeps its own products selectable even if fully allocated elsewhere.
      if (existing) for (const l of existing.lines) if (!avail.has(l.product_id)) avail.set(l.product_id, { product_id: l.product_id, sku: l.sku, name: l.product_name, unit: l.unit, available: l.available_at_source });
      $('[data-avail-note]', form).textContent = d.items.length
        ? `${d.items.length} product${d.items.length === 1 ? '' : 's'} in stock at this sales center.`
        : 'This sales center has no available stock to return.';
      render();
    };
    form.elements.from_location_id.addEventListener('change', () => { lines = [{ product_id: '', qty: 1, note: '' }]; loadAvail(); });
    tbody.addEventListener('input', (e) => {
      const i = $$('tr', tbody).indexOf(e.target.closest('tr'));
      const k = e.target.dataset.k;
      if (!k || i < 0) return;
      lines[i][k] = e.target.value;
      if (k === 'product_id') render();
    });
    tbody.addEventListener('change', (e) => { if (e.target.dataset.k === 'product_id') render(); });
    tbody.addEventListener('click', (e) => {
      if (!e.target.closest('[data-remove]')) return;
      lines.splice($$('tr', tbody).indexOf(e.target.closest('tr')), 1);
      if (!lines.length) lines = [{ product_id: '', qty: 1, note: '' }];
      render();
    });
    $('[data-add-line]', form).addEventListener('click', () => { lines.push({ product_id: '', qty: 1, note: '' }); render(); });
    loadAvail();
  }

  route(/^\/returns\/(\d+)$/, async (ctx) => {
    const r = await GET(`/api/returns/${ctx.params[0]}`);
    const history = await historyCard('stock_return', r.id);
    const s = r.status;
    const short = s === 'DRAFT' ? r.lines.filter((l) => l.available_at_source < l.qty) : [];
    const pending = r.pending_approval;
    const approver = can('approvals:decide');
    const STEPS = [['DRAFT', 'Draft'], ['APPROVAL', 'Manager approval'], ['DISPATCHED', 'Dispatched (in transit)'], ['RECEIVED', 'Received at warehouse']];
    const stepIdx = s === 'DRAFT' && pending ? 1 : STEPS.findIndex(([k]) => k === s);
    if (!ctx.render(html`
      <div class="page-head"><div><div class="crumbs"><a href="#/returns">Returns</a> / ${r.number}</div>
        <h1>${r.number} ${statusBadge(s)}</h1><p>${r.from_name} (${r.from_code}) → ${r.to_name} (${r.to_code}) · ${RETURN_REASONS[r.reason]}</p></div>
        <div class="actions">
          <a class="btn" href="/api/returns/${r.id}/pdf" download>${icon('pdf')}Return note PDF</a>
          ${!pending && s === 'DRAFT' && can('stock:write') ? html`<button class="btn" data-edit>Edit</button><button class="btn danger" data-delete>Delete</button>` : ''}
          ${!pending && ['DRAFT', 'DISPATCHED'].includes(s) && can('stock:write') ? html`<button class="btn danger" data-cancel>${s === 'DISPATCHED' && !approver ? 'Request cancellation' : 'Cancel return'}</button>` : ''}
          ${!pending && s === 'DRAFT' && can('stock:write') ? html`<button class="btn primary" data-dispatch>${approver ? `Dispatch from ${r.from_code}` : 'Submit for approval'}</button>` : ''}
          ${!pending && s === 'DISPATCHED' && can('stock:write') ? html`<button class="btn success" data-receive>Receive at ${r.to_code}</button>` : ''}
        </div></div>
      ${pendingBanner(pending)}
      ${!pending && !approver && s === 'DRAFT' && can('stock:write') ? html`<p class="muted small">Returns are dispatched once your manager approves them. Stock stays in ${r.from_code} until then.</p>` : ''}
      ${s !== 'CANCELLED' ? html`<ol class="steps">${STEPS.map(([, label], i) => html`<li class="${i < stepIdx ? 'done' : i === stepIdx ? 'current' : ''}">${label}</li>`)}</ol>` : ''}
      ${short.length ? html`<div class="card"><div class="card-body"><span class="badge red">Not enough stock</span> ${short.map((l) => `${l.sku} (returning ${l.qty}, ${l.available_at_source} available)`).join(' · ')}. Reduce the quantities before dispatching.</div></div>` : ''}
      <div class="grid kpis">
        ${kpi('Units', fmt.num(r.total_qty), `${r.lines.length} product${r.lines.length === 1 ? '' : 's'}`)}
        ${kpi('Value at cost', fmt.money(r.total_value), 'Moving-average cost')}
        ${s === 'RECEIVED' ? kpi('Good / damaged', `${fmt.num(r.total_good)} / ${fmt.num(r.total_damaged)}`, 'Damaged units were written off') : ''}
        ${s === 'RECEIVED' ? kpi('Missing', fmt.num(r.total_missing), r.total_missing ? 'Lost in transit' : 'Everything arrived', { alert: r.total_missing > 0 }) : ''}
      </div>
      <div class="card"><div class="card-head"><h2>Products</h2></div>
        ${table([
          { label: 'SKU', render: (l) => html`<a class="mono" href="#/products/${l.product_id}">${l.sku}</a>` },
          { label: 'Product', render: (l) => html`${l.product_name}${l.note ? html`<div class="sub">${l.note}</div>` : ''}` },
          { label: 'Returned', cls: 'num', render: (l) => html`${fmt.num(l.qty)} <span class="sub">${l.unit}</span>` },
          ...(s === 'DRAFT' ? [{ label: `Available at ${r.from_code}`, cls: 'num', render: (l) => html`<span class="${l.available_at_source < l.qty ? 'qty-neg' : ''}">${fmt.num(l.available_at_source)}</span>` }] : []),
          ...(s === 'RECEIVED' ? [
            { label: 'Good', cls: 'num', render: (l) => fmt.num(l.qty_good) },
            { label: 'Damaged', cls: 'num', render: (l) => html`<span class="${l.qty_damaged ? 'qty-neg' : ''}">${fmt.num(l.qty_damaged)}</span>` },
          ] : []),
          { label: 'Value', cls: 'num', render: (l) => fmt.money(l.value) },
        ], r.lines)}</div>
      <div class="grid halves">
        <div class="card"><div class="card-head"><h2>Details</h2></div><div class="card-body"><dl class="info-grid">
          <div><dt>From sales center</dt><dd>${r.from_code} — ${r.from_name}</dd></div>
          <div><dt>To warehouse</dt><dd>${r.to_code} — ${r.to_name}</dd></div>
          <div><dt>Created by</dt><dd>${r.created_by_name || '—'}<div class="sub">${fmt.dt(r.created_at)}</div></dd></div>
          <div><dt>Dispatched</dt><dd>${r.dispatched_by_name || '—'}<div class="sub">${fmt.dt(r.dispatched_at)}</div></dd></div>
          <div><dt>Received</dt><dd>${r.received_by_name || '—'}<div class="sub">${fmt.dt(r.received_at)}</div></dd></div>
          <div><dt>Ledger</dt><dd><a href="#/movements?ref=${encodeURIComponent(r.number)}">View stock movements →</a></dd></div>
        </dl>${r.notes ? html`<p><strong>Notes:</strong> ${r.notes}</p>` : ''}</div></div>
        ${history}
      </div>`)) return;

    const on = (sel, fn) => { const el = $(sel, ctx.view); if (el) el.addEventListener('click', fn); };
    on('[data-edit]', () => returnDialog(r));
    const act = async (url, body, appliedMsg) => {
      try { approvalToast(await POST(url, body), appliedMsg); refreshLowCount(); navigate(); }
      catch (err) { toast(err.message, 'error'); }
    };
    on('[data-dispatch]', async () => {
      const reason = await reasonDialog({
        title: approver ? 'Dispatch return' : 'Submit return for approval',
        message: approver
          ? `Remove ${fmt.num(r.total_qty)} unit(s) from ${r.from_code} and send them to ${r.to_code}?`
          : `Your manager must approve returning ${fmt.num(r.total_qty)} unit(s) from ${r.from_code} to ${r.to_code}. Stock moves once approved.`,
        label: approver ? 'Dispatch' : 'Send for approval', optional: true, placeholder: 'Optional note for the approver',
      });
      if (reason === null) return;
      act(`/api/returns/${r.id}/dispatch`, { reason: reason || undefined }, `${r.number} dispatched — stock is in transit to ${r.to_code}`);
    });
    on('[data-cancel]', async () => {
      if (s === 'DRAFT') {
        orderAction(`/api/returns/${r.id}/cancel`, `${r.number} cancelled`, ['Cancel return', `Cancel draft ${r.number}?`], { label: 'Cancel return', danger: true });
        return;
      }
      const reason = await reasonDialog({
        title: approver ? 'Cancel return' : 'Request cancellation', danger: true,
        message: `Cancel ${r.number}? The ${fmt.num(r.total_qty)} unit(s) in transit will be put back into ${r.from_code}.${approver ? '' : ' Your manager must approve this.'}`,
        label: approver ? 'Cancel return' : 'Send for approval',
      });
      if (reason === null) return;
      act(`/api/returns/${r.id}/cancel`, { reason }, `${r.number} cancelled`);
    });
    on('[data-delete]', async () => {
      if (!await confirmDialog('Delete draft', `Permanently delete draft ${r.number}?`, { label: 'Delete', danger: true })) return;
      try { await DEL(`/api/returns/${r.id}`); toast(`${r.number} deleted`, 'success'); location.hash = '#/returns'; }
      catch (err) { toast(err.message, 'error'); }
    });
    on('[data-receive]', () => receiveReturnDialog(r));
  }, 'Return');

  function receiveReturnDialog(r) {
    const { form } = openModal({
      title: `Receive ${r.number} at ${r.to_code}`, wide: true, submitLabel: 'Post receipt',
      body: html`<p class="muted">Inspect the goods. <strong>Good</strong> units are added to ${r.to_name}. <strong>Damaged</strong> units are booked in and immediately written off. Anything not counted is recorded as missing (lost in transit).</p>
        <div class="table-wrap"><table class="lines-table"><thead><tr><th>Product</th><th class="num">Dispatched</th><th class="num">Good</th><th class="num">Damaged</th><th class="num">Missing</th></tr></thead><tbody>
        ${r.lines.map((l) => html`<tr data-line="${l.id}" data-qty="${l.qty}"><td><strong>${l.product_name}</strong><div class="sub mono">${l.sku}</div></td>
          <td class="num">${fmt.num(l.qty)}</td>
          <td class="w-qty"><input type="number" min="0" max="${l.qty}" step="1" value="${l.qty}" data-k="qty_good" aria-label="Good quantity for ${l.sku}"></td>
          <td class="w-qty"><input type="number" min="0" max="${l.qty}" step="1" value="0" data-k="qty_damaged" aria-label="Damaged quantity for ${l.sku}"></td>
          <td class="num" data-missing>0</td></tr>`)}
        </tbody></table></div>`,
      onSubmit: async (f) => {
        const lines = $$('tr[data-line]', f).map((tr) => ({
          id: Number(tr.dataset.line),
          qty_good: Number($('[data-k="qty_good"]', tr).value || 0),
          qty_damaged: Number($('[data-k="qty_damaged"]', tr).value || 0),
        }));
        const res = await POST(`/api/returns/${r.id}/receive`, { lines });
        toast(`${r.number} received: ${res.total_good} good, ${res.total_damaged} damaged${res.total_missing ? `, ${res.total_missing} missing` : ''}`, 'success');
        refreshLowCount();
        navigate();
      },
    });
    form.addEventListener('input', (e) => {
      const tr = e.target.closest('tr[data-line]');
      if (!tr) return;
      const miss = Number(tr.dataset.qty) - Number($('[data-k="qty_good"]', tr).value || 0) - Number($('[data-k="qty_damaged"]', tr).value || 0);
      const cell = $('[data-missing]', tr);
      cell.textContent = miss < 0 ? `${miss} (too many)` : String(miss);
      cell.className = `num${miss !== 0 ? ' qty-neg' : ''}`;
    });
  }

  // =====================================================================
  // Company branding (administrators)
  // =====================================================================
  route(/^\/branding$/, async (ctx) => {
    if (!can('settings:manage')) { ctx.render(html`<div class="card"><div class="empty">Only administrators can change company branding.</div></div>`); return; }
    const { settings: st, limits } = await GET('/api/settings/branding');
    const zones = (Intl.supportedValuesOf ? Intl.supportedValuesOf('timeZone') : ['UTC']);
    if (!zones.includes('UTC')) zones.unshift('UTC');
    const currencies = (Intl.supportedValuesOf ? Intl.supportedValuesOf('currency') : [st.currency]);
    const F = {
      identity: [
        { name: 'company_name', label: 'Company name', required: true, hint: 'Shown on the sign-in page, the sidebar and every report.' },
        { name: 'legal_name', label: 'Registered / legal name', hint: 'Optional. Printed under the name on documents.' },
        { name: 'tagline', label: 'Tagline', full: true, placeholder: 'e.g. Wholesale & retail distribution' },
      ],
      contact: [
        { name: 'address', label: 'Address', type: 'textarea', full: true },
        { name: 'phone', label: 'Phone' }, { name: 'email', label: 'Email', type: 'email' },
        { name: 'website', label: 'Website', placeholder: 'www.example.com' }, { name: 'tax_id', label: 'Tax / VAT / BIN number' },
      ],
      home: [
        { name: 'welcome_title', label: 'Headline', full: true },
        { name: 'welcome_text', label: 'Introduction', type: 'textarea', full: true },
        { name: 'welcome_points', label: 'Highlights (one per line)', type: 'textarea', full: true },
      ],
      docs: [
        { name: 'currency', label: 'Currency', type: 'select', required: true, placeholder: false, options: currencies.map((c) => ({ value: c, label: c })) },
        { name: 'timezone', label: 'Time zone for reports', type: 'select', required: true, placeholder: false, options: zones.map((z) => ({ value: z, label: z.replace(/_/g, ' ') })) },
        { name: 'report_footer', label: 'Report footer', full: true, placeholder: `${st.company_name} · Confidential` },
        { name: 'document_terms', label: 'Terms & conditions on purchase orders and invoices', type: 'textarea', full: true },
      ],
    };
    const all = Object.values(F).flat();
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Company branding</h1><p>Your company name, logo and colours on the sign-in page, throughout the app and on every PDF report and document.</p></div>
        <div class="actions"><a class="btn" href="/api/settings/sample.pdf" download data-sample>${icon('pdf')}Sample PDF</a></div></div>
      <form class="branding-layout" data-branding novalidate autocomplete="off">
        <div class="branding-main">
          <section class="card"><div class="card-head"><h2>Identity</h2></div><div class="card-body"><div class="form-grid">${F.identity.map((f) => field(f, st[f.name]))}</div></div></section>
          <section class="card"><div class="card-head"><h2>Logo &amp; colour</h2></div><div class="card-body">
            <div class="logo-row">
              <div class="logo-preview" data-logo-preview>${st.logo ? html`<img src="${st.logo.url}" alt="Current logo">` : html`<span class="muted">No logo</span>`}</div>
              <div>
                <label class="btn">${icon('upload')}Upload logo<input type="file" accept="image/png,image/jpeg" data-logo-file hidden></label>
                <button type="button" class="btn danger" data-logo-remove${st.logo ? '' : raw(' hidden')}>Remove</button>
                <p class="muted small">PNG or JPEG, up to ${Math.round(limits.logo_max_bytes / 1024)} KB. A wide logo with a transparent background works best (for example 600 × 200 px).</p>
              </div>
            </div>
            <div class="form-grid" style="margin-top:16px">
              <div class="field"><label for="f_brand_color">Brand colour</label>
                <div class="color-row"><input type="color" id="f_brand_color_pick" value="${st.brand_color}" aria-label="Pick brand colour"><input id="f_brand_color" name="brand_color" value="${st.brand_color}" maxlength="7" class="mono"></div>
                <small>Used for buttons, links, charts and report headers. Very light colours are darkened automatically so text stays readable.</small><div class="field-error"></div></div>
            </div>
          </div></section>
          <section class="card"><div class="card-head"><h2>Contact details</h2><span class="muted">Printed on the letterhead of reports and documents</span></div><div class="card-body"><div class="form-grid">${F.contact.map((f) => field(f, st[f.name]))}</div></div></section>
          <section class="card"><div class="card-head"><h2>Sign-in page</h2><span class="muted">Leave blank to use the default text</span></div><div class="card-body"><div class="form-grid">${F.home.map((f) => field(f, st[f.name]))}</div></div></section>
          <section class="card"><div class="card-head"><h2>Reports &amp; documents</h2></div><div class="card-body"><div class="form-grid">${F.docs.map((f) => field(f, st[f.name]))}</div></div></section>
          <div class="form-error" hidden></div>
          <div class="sticky-actions"><button type="submit" class="btn primary">Save branding</button></div>
        </div>
        <aside class="branding-preview">
          <div class="preview-label">Sign-in page</div>
          <div class="mini-hero" data-prev-hero><div class="mini-brand"><span data-prev-logo></span><strong data-prev-name></strong></div><div class="mini-title" data-prev-title></div><div class="mini-text" data-prev-text></div></div>
          <div class="preview-label">Report letterhead</div>
          <div class="mini-doc"><div class="mini-bar" data-prev-bar></div>
            <div class="mini-head"><div><span data-prev-logo2></span><strong data-prev-name2></strong><div class="mini-tag" data-prev-tag></div></div><div class="mini-contact" data-prev-contact></div></div>
            <div class="mini-table"><div class="mini-th" data-prev-th></div><div class="mini-tr"></div><div class="mini-tr alt"></div><div class="mini-tr"></div></div>
            <div class="mini-foot" data-prev-foot></div></div>
          <p class="muted small">Previews update as you type. Download the sample PDF after saving to see the real output.</p>
        </aside>
      </form>`)) return;

    const form = $('[data-branding]', ctx.view);
    const pick = $('#f_brand_color_pick', form);
    let logoUrl = st.logo ? st.logo.url : null;
    const preview = () => {
      const v = (n) => (form.elements[n] ? form.elements[n].value.trim() : '');
      const color = isHex(v('brand_color')) ? v('brand_color') : st.brand_color;
      let safe = color;
      for (let i = 0; i < 20 && contrastOf(safe, '#ffffff') < 4.5; i++) safe = mixHex(safe, '#000000', 0.08);
      const name = v('company_name') || 'Company name';
      const logo = logoUrl ? `<img src="${esc(logoUrl)}" alt="">` : '';
      $('[data-prev-hero]', form).style.background = `linear-gradient(145deg, ${mixHex(color, '#0b1020', 0.72)}, ${lum(color) > 0.3 ? mixHex(color, '#000000', 0.35) : color})`;
      $('[data-prev-logo]', form).innerHTML = logo;
      $('[data-prev-logo2]', form).innerHTML = logo;
      $('[data-prev-name]', form).textContent = name;
      $('[data-prev-name2]', form).textContent = name;
      $('[data-prev-title]', form).textContent = v('welcome_title') || 'Inventory control for every warehouse, order and SKU.';
      $('[data-prev-text]', form).textContent = v('welcome_text') || 'Real-time stock across locations, purchasing and fulfilment workflows.';
      $('[data-prev-tag]', form).textContent = v('tagline');
      $('[data-prev-tag]', form).style.color = safe;
      $('[data-prev-contact]', form).innerHTML = [...v('address').split('\n'), v('phone') && `Tel: ${v('phone')}`, v('email'), v('website'), v('tax_id') && `Tax ID: ${v('tax_id')}`]
        .filter(Boolean).slice(0, 6).map((x) => `<div>${esc(x)}</div>`).join('');
      $('[data-prev-bar]', form).style.background = safe;
      $('[data-prev-th]', form).style.background = safe;
      $('[data-prev-foot]', form).textContent = v('report_footer') || `${name} · Confidential`;
    };
    pick.addEventListener('input', () => { form.elements.brand_color.value = pick.value; preview(); });
    form.elements.brand_color.addEventListener('input', () => { if (isHex(form.elements.brand_color.value)) pick.value = form.elements.brand_color.value; });
    form.addEventListener('input', preview);
    preview();

    const refreshBranding = async (settings) => {
      const cfg = await GET('/api/auth/config');
      S.settings = { ...S.settings, ...cfg };
      moneyFmt = null;
      applyBranding(S.settings);
      renderShell();
      return settings;
    };

    $('[data-logo-file]', form).addEventListener('change', async (e) => {
      const file = e.target.files[0];
      e.target.value = '';
      if (!file) return;
      if (!/^image\/(png|jpeg)$/.test(file.type)) { toast('Please choose a PNG or JPEG image', 'error'); return; }
      if (file.size > limits.logo_max_bytes) { toast(`Logo must be ${Math.round(limits.logo_max_bytes / 1024)} KB or smaller`, 'error'); return; }
      const data = await new Promise((resolve, reject) => { const fr = new FileReader(); fr.onload = () => resolve(fr.result); fr.onerror = reject; fr.readAsDataURL(file); });
      try {
        const res = await POST('/api/settings/logo', { data });
        toast('Logo uploaded', 'success');
        await refreshBranding();
        location.hash = '#/branding';
        navigate();
        return res;
      } catch (err) { toast(err.message, 'error'); }
    });
    $('[data-logo-remove]', form).addEventListener('click', async () => {
      if (!await confirmDialog('Remove logo', 'Remove the company logo? Reports and the sign-in page will show the company name only.', { label: 'Remove', danger: true })) return;
      try { await DEL('/api/settings/logo'); toast('Logo removed', 'success'); logoUrl = null; await refreshBranding(); navigate(); }
      catch (err) { toast(err.message, 'error'); }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = $('button[type=submit]', form);
      btn.disabled = true;
      clearFormErrors(form);
      const body = {};
      for (const f of [...all, { name: 'brand_color' }]) body[f.name] = form.elements[f.name].value;
      try {
        await PUT('/api/settings/branding', body);
        await refreshBranding();
        toast('Branding saved', 'success');
        navigate();
      } catch (err) {
        if (err.status !== 401) { showFormError(form, err); toast(err.message, 'error'); }
      } finally { btn.disabled = false; }
    });
  }, 'Company branding');

  // =====================================================================
  // Import data from CSV
  // =====================================================================
  const IMPORT_HELP = {
    products: 'Creates new products and updates existing ones matched by SKU. Categories are created automatically; suppliers must already exist. Blank cells leave existing values unchanged.',
    suppliers: 'Creates suppliers and updates existing ones matched by name.',
    customers: 'Creates customers and updates existing ones matched by name.',
    stock: 'Sets or adds stock quantities per product and location (warehouse or sales center code). Every change is posted to the movement ledger with an import reference.',
  };

  route(/^\/import$/, async (ctx) => {
    const types = await GET('/api/import/types');
    const allowed = types.filter((t) => t.allowed);
    if (!allowed.length) { ctx.render(html`<div class="card"><div class="empty">You do not have permission to import data.</div></div>`); return; }
    let type = ctx.q('type', allowed[0].key);
    if (!allowed.some((t) => t.key === type)) type = allowed[0].key;
    const T = types.find((t) => t.key === type);
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Import data</h1><p>Load large amounts of data from a CSV file (Excel: <em>File → Save As → CSV UTF-8</em>). Files up to 25 MB / 100,000 rows. Every import is checked first and is all-or-nothing.</p></div></div>
      <div class="card">
        <nav class="tabs">${types.map((t) => (t.allowed
          ? html`<a href="#/import?type=${t.key}" class="${t.key === type ? 'active' : ''}">${t.label}</a>`
          : html`<span class="tab-disabled" title="Your role cannot import ${t.label.toLowerCase()}">${t.label}</span>`))}</nav>
        <div class="card-body">
          <p>${IMPORT_HELP[type]}</p>
          <p class="muted">Columns: ${T.columns.map((c) => html`<code class="${T.required.includes(c) ? 'req-col' : ''}">${c}</code> `)} <span class="small">(bold = required; common alternatives such as “Product Name” or “Quantity” are recognised; column order does not matter)</span></p>
          <a class="btn sm" href="/api/import/${type}/template" download>${icon('download')}Download template</a>
        </div>
        <form class="card-body import-form" data-import novalidate>
          <label class="dropzone" data-drop>
            <input type="file" accept=".csv,text/csv,text/plain" data-file hidden>
            ${icon('upload')}<strong data-file-name>Choose a CSV file</strong><span class="muted">or drag and drop it here</span>
          </label>
          <div class="import-options">
            ${type === 'stock' ? html`<label>Mode <select name="stock_mode"><option value="set">Set quantity (stock count / opening balance)</option><option value="add">Add quantity (goods received)</option></select></label>`
              : html`<label class="check"><input type="checkbox" name="update_existing" checked> Update records that already exist</label>`}
          </div>
          <div class="actions">
            <button type="button" class="btn" data-validate disabled>Check file</button>
            <button type="button" class="btn primary" data-commit disabled>Import</button>
          </div>
        </form>
        <div data-result></div>
      </div>`)) return;

    const form = $('[data-import]', ctx.view);
    const input = $('[data-file]', form);
    const drop = $('[data-drop]', form);
    const out = $('[data-result]', ctx.view);
    const vBtn = $('[data-validate]', form);
    const cBtn = $('[data-commit]', form);
    let text = null;
    let fileName = '';

    const readFile = async (file) => {
      if (!file) return;
      if (file.size > 25 * 1024 * 1024) { toast('File is larger than 25 MB. Split it into smaller files.', 'error'); return; }
      const buf = await file.arrayBuffer();
      try { text = new TextDecoder('utf-8', { fatal: true }).decode(buf); }
      catch { text = new TextDecoder('windows-1252').decode(buf); toast('File is not UTF-8; it was read as Windows (ANSI) text', ''); }
      fileName = file.name;
      $('[data-file-name]', form).textContent = `${file.name} · ${(file.size / 1024).toFixed(file.size > 1048576 ? 0 : 1)} KB`;
      vBtn.disabled = false;
      cBtn.disabled = true;
      out.innerHTML = '';
    };
    input.addEventListener('change', () => readFile(input.files[0]));
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => readFile(e.dataTransfer.files[0]));
    form.addEventListener('change', (e) => { if (e.target.name) { cBtn.disabled = true; out.innerHTML = ''; } });

    const send = async (dryRun) => {
      const params = { dry_run: dryRun ? '1' : '' };
      if (form.elements.stock_mode) params.stock_mode = form.elements.stock_mode.value;
      if (form.elements.update_existing) params.update_existing = form.elements.update_existing.checked ? '1' : '0';
      const res = await fetch(`/api/import/${type}?${qs(params)}`, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'text/csv; charset=utf-8', 'X-Requested-With': 'fetch', Accept: 'application/json' },
        body: text,
      });
      let data = null;
      try { data = await res.json(); } catch { /* none */ }
      if (res.status === 401) { S.user = null; renderLogin('Your session has expired. Please sign in again.'); throw new ApiError('Authentication required', 401); }
      return { ok: res.ok, status: res.status, data };
    };

    const showReport = (rep, { dryRun, error }) => {
      const kind = type === 'stock' ? 'stock line' : T.label.toLowerCase().replace(/s$/, '');
      const tiles = html`<div class="grid kpis">
        ${kpi('Rows in file', fmt.num(rep.total_rows))}
        ${kpi(dryRun ? 'Will be created' : 'Created', fmt.num(rep.created))}
        ${kpi(dryRun ? 'Will be updated' : 'Updated', fmt.num(rep.updated))}
        ${kpi('Unchanged / skipped', `${fmt.num(rep.unchanged)} / ${fmt.num(rep.skipped)}`)}
        ${kpi('Errors', fmt.num(rep.error_count), rep.error_count ? 'Fix these and upload again' : 'None', { alert: rep.error_count > 0 })}</div>`;
      const cols = html`<p class="muted small">Recognised columns: ${rep.columns.recognised.map((c) => html`<code>${c}</code> `)}
        ${rep.columns.ignored.length ? html`· Ignored: ${rep.columns.ignored.map((c) => html`<code class="ignored">${c}</code> `)}` : ''} · Separator: <code>${rep.delimiter}</code></p>`;
      const errs = rep.errors.length ? html`<h3 style="margin:16px 0 8px">Problems found${rep.error_count > rep.errors.length ? ` (first ${rep.errors.length} of ${fmt.num(rep.error_count)})` : ''}</h3>
        ${table([
          { label: 'Row', cls: 'num', render: (e) => e.row },
          { label: 'Column', render: (e) => (e.field ? html`<code>${e.field}</code>` : '—') },
          { label: 'Problem', render: (e) => e.message },
        ], rep.errors)}` : '';
      const banner = error
        ? html`<div class="notice error">${error}</div>`
        : dryRun
          ? (rep.error_count ? html`<div class="notice error">The file has ${fmt.num(rep.error_count)} problem(s). Nothing has been imported.</div>`
            : html`<div class="notice success">Check passed: ${fmt.num(rep.created + rep.updated)} ${kind}(s) ready to import. Nothing has been saved yet. Press <strong>Import</strong> to save.</div>`)
          : html`<div class="notice success">Import complete from ${fileName}. ${rep.reference ? html`Ledger reference <a href="#/movements?ref=${encodeURIComponent(rep.reference)}">${rep.reference}</a>.` : ''}</div>`;
      out.innerHTML = html`<div class="card-body">${banner}${tiles}${cols}${errs}</div>`.s;
    };

    vBtn.addEventListener('click', async () => {
      vBtn.disabled = true; cBtn.disabled = true;
      out.innerHTML = '<div class="card-body muted">Checking file…</div>';
      try {
        const r = await send(true);
        if (!r.ok) { out.innerHTML = html`<div class="card-body"><div class="notice error">${(r.data && r.data.error) || `Check failed (${r.status})`}</div></div>`.s; return; }
        showReport(r.data, { dryRun: true });
        cBtn.disabled = r.data.error_count > 0;
        cBtn.textContent = r.data.error_count ? 'Import' : `Import ${fmt.num(r.data.created + r.data.updated)} row(s)`;
      } catch (err) { if (err.status !== 401) toast(err.message, 'error'); }
      finally { vBtn.disabled = false; }
    });
    cBtn.addEventListener('click', async () => {
      cBtn.disabled = true; vBtn.disabled = true;
      out.innerHTML = '<div class="card-body muted">Importing…</div>';
      try {
        const r = await send(false);
        if (r.ok) {
          showReport(r.data, { dryRun: false });
          toast('Import complete', 'success');
          await lookups(true);
          refreshLowCount();
          cBtn.textContent = 'Import';
        } else if (r.data && r.data.details && r.data.details.errors) {
          showReport(r.data.details, { dryRun: false, error: r.data.error });
        } else {
          out.innerHTML = html`<div class="card-body"><div class="notice error">${(r.data && r.data.error) || `Import failed (${r.status})`}</div></div>`.s;
        }
      } catch (err) { if (err.status !== 401) toast(err.message, 'error'); }
      finally { vBtn.disabled = false; }
    });
  }, 'Import data');

  // =====================================================================
  // Approvals (manager sign-off for sales agents' changes)
  // =====================================================================
  const APPROVAL_COLORS = { PENDING: 'amber', APPROVED: 'green', REJECTED: 'red', WITHDRAWN: '' };
  const approvalBadge = (st) => html`<span class="badge ${APPROVAL_COLORS[st] || ''}">${st}</span>`;
  const docLink = (a) => {
    const path = a.entity === 'sales_order' ? 'sales-orders' : 'returns';
    return html`<a href="#/${path}/${a.entity_id}" class="mono">${a.document_number || `#${a.entity_id}`}</a>`;
  };

  route(/^\/approvals$/, async (ctx) => {
    const approver = can('approvals:decide');
    const f = { status: ctx.q('status', 'PENDING'), mine: ctx.q('mine'), offset: ctx.q('offset', '0') };
    const d = await GET(`/api/approvals?${qs({ ...f, status: f.status === 'ALL' ? '' : f.status })}`);
    const tab = (st, label, extra = {}) => {
      const active = f.status === st && (extra.mine || '') === (f.mine || '');
      return html`<a href="#/approvals?${qs({ status: st, ...extra })}" class="${active ? 'active' : ''}">${label}</a>`;
    };
    const waiting = d.items.filter((a) => a.can_decide).length;
    if (!ctx.render(html`
      <div class="page-head"><div><h1>Approvals</h1><p>${approver
        ? 'Change requests from sales agents who report to you (or to no specific manager). Approving applies the change immediately; nothing changes until then.'
        : 'Your requests to change confirmed orders and invoices, record customer returns, and dispatch or cancel returns. Your manager approves or rejects them.'}</p></div></div>
      ${approver && f.status === 'PENDING' && waiting ? html`<div class="notice pending">${waiting} request${waiting === 1 ? '' : 's'} waiting for your decision.</div>` : ''}
      <div class="card">
        <nav class="tabs">${tab('PENDING', 'Pending')}${approver ? tab('PENDING', 'My requests', { mine: '1' }) : ''}${tab('APPROVED', 'Approved')}${tab('REJECTED', 'Rejected')}${tab('WITHDRAWN', 'Withdrawn')}${tab('ALL', 'All')}</nav>
        ${table([
          { label: 'Request', render: (a) => html`<strong class="mono">${a.number}</strong>` },
          { label: 'Type', render: (a) => a.type_label },
          { label: 'Document', render: docLink },
          { label: 'Change', render: (a) => html`<div class="clamp">${a.summary || '—'}</div><div class="sub">Reason: ${a.reason}</div>` },
          { label: 'Requested by', render: (a) => html`${a.requested_by_name}<div class="sub">${fmt.dt(a.created_at)}</div>` },
          { label: 'Approver', render: (a) => (a.status === 'PENDING' ? (a.approver_name || html`<span class="muted">Any manager</span>`) : html`${a.decided_by_name || '—'}<div class="sub">${fmt.dt(a.decided_at)}</div>`) },
          { label: 'Status', render: (a) => html`${approvalBadge(a.status)}${a.can_decide ? html` <span class="badge purple">Your decision</span>` : ''}` },
        ], d.items, { empty: f.status === 'PENDING' ? 'Nothing is waiting for approval' : 'No requests', href: (a) => `#/approvals/${a.id}` })}
        ${pager(d)}
      </div>`)) return;
    bindFilters(ctx);
    refreshApprovalCount();
  }, 'Approvals');

  route(/^\/approvals\/(\d+)$/, async (ctx) => {
    const a = await GET(`/api/approvals/${ctx.params[0]}`);
    const p = a.payload || {};
    const docPath = a.entity === 'sales_order' ? 'sales-orders' : 'returns';
    const preview = p.preview && p.preview.length ? table([
      { label: 'SKU', render: (x) => html`<span class="mono">${x.sku}</span>` },
      { label: 'Product', key: 'name' },
      { label: 'Qty before', cls: 'num', render: (x) => fmt.num(x.qty_before) },
      { label: 'Qty after', cls: 'num', render: (x) => html`<strong class="${x.qty_after !== x.qty_before ? 'qty-neg' : ''}">${fmt.num(x.qty_after)}</strong>` },
      ...(p.status === 'SHIPPED' ? [{ label: 'Returned', cls: 'num', render: (x) => (x.return_qty ? fmt.num(x.return_qty) : '—') }] : []),
      { label: 'Price before', cls: 'num', render: (x) => (x.price_before === null ? '—' : fmt.money(x.price_before)) },
      { label: 'Price after', cls: 'num', render: (x) => (x.price_after === null ? '—' : html`<strong class="${x.price_after !== x.price_before ? 'qty-neg' : ''}">${fmt.money(x.price_after)}</strong>`) },
    ], p.preview) : '';
    if (!ctx.render(html`
      <div class="page-head"><div><div class="crumbs"><a href="#/approvals">Approvals</a> / ${a.number}</div>
        <h1>${a.number} ${approvalBadge(a.status)}</h1><p>${a.type_label} · <a href="#/${docPath}/${a.entity_id}">${p.number || 'Open document'}</a></p></div>
        <div class="actions">
          ${a.can_withdraw ? html`<button class="btn" data-withdraw>Withdraw request</button>` : ''}
          ${a.can_decide ? html`<button class="btn danger" data-reject>Reject</button><button class="btn success" data-approve>Approve &amp; apply</button>` : ''}
        </div></div>
      ${a.status === 'PENDING' && !a.can_decide && !a.can_withdraw ? html`<div class="notice pending">Waiting for ${a.approver_name || 'a manager'} to decide.</div>` : ''}
      <div class="grid halves">
        <div class="card"><div class="card-head"><h2>Request</h2></div><div class="card-body"><dl class="info-grid">
          <div><dt>Requested by</dt><dd>${a.requested_by_name}<div class="sub">${fmt.dt(a.created_at)}</div></dd></div>
          <div><dt>Approver</dt><dd>${a.approver_name || 'Any manager or administrator'}</dd></div>
          <div><dt>Decided by</dt><dd>${a.decided_by_name || '—'}${a.decided_at ? html`<div class="sub">${fmt.dt(a.decided_at)}</div>` : ''}</dd></div>
          <div><dt>Document</dt><dd><a href="#/${docPath}/${a.entity_id}">${p.number || a.entity_id}</a></dd></div>
        </dl>
        <p><strong>Reason:</strong> ${a.reason}</p>
        ${a.decision_note ? html`<p><strong>Decision note:</strong> ${a.decision_note}</p>` : ''}</div></div>
        <div class="card"><div class="card-head"><h2>What will change</h2></div><div class="card-body">
          <p>${a.summary}</p>
          ${p.status === 'SHIPPED' && p.restock_code ? html`<p class="muted">Returned goods: ${p.condition === 'DAMAGED' ? 'written off as damaged' : 'back into stock'} at <strong>${p.restock_code}</strong>.</p>` : ''}
          ${p.total_before !== undefined ? html`<p class="muted">Order total before the change: ${fmt.money(p.total_before)}</p>` : ''}
          ${p.units ? html`<p class="muted">${fmt.num(p.units)} unit(s)${p.value ? `, ${fmt.money(p.value)} at cost` : ''}.</p>` : ''}
        </div></div>
      </div>
      ${preview ? html`<div class="card"><div class="card-head"><h2>Line changes</h2></div>${preview}</div>` : ''}`)) return;

    const on = (sel, fn) => { const el = $(sel, ctx.view); if (el) el.addEventListener('click', fn); };
    const decide = async (action, note, msg) => {
      try {
        await POST(`/api/approvals/${a.id}/${action}`, { note });
        toast(msg, 'success');
        refreshLowCount();
        navigate();
      } catch (err) { toast(err.message, 'error'); }
    };
    on('[data-approve]', async () => {
      const note = await reasonDialog({ title: `Approve ${a.number}`, message: `${a.summary}. The change is applied immediately.`, label: 'Approve & apply', optional: true, placeholder: 'Optional note' });
      if (note !== null) decide('approve', note, `${a.number} approved and applied`);
    });
    on('[data-reject]', async () => {
      const note = await reasonDialog({ title: `Reject ${a.number}`, message: `Tell ${a.requested_by_name} why the request is rejected.`, label: 'Reject', danger: true });
      if (note !== null) decide('reject', note, `${a.number} rejected`);
    });
    on('[data-withdraw]', async () => {
      if (await confirmDialog('Withdraw request', `Withdraw ${a.number}? The document stays unchanged.`, { label: 'Withdraw' })) decide('withdraw', null, `${a.number} withdrawn`);
    });
  }, 'Approval');

  // =====================================================================
  // Boot
  // =====================================================================
  window.addEventListener('hashchange', navigate);
  (async () => {
    try {
      const me = await GET('/api/auth/me');
      await startSession(me);
    } catch (err) {
      if (err.status !== 401) {
        $('#root').innerHTML = html`<div class="boot">Unable to reach the server: ${err.message}</div>`.s;
      }
    }
  })();
})();
