'use strict';
// Branding, PDF reports/documents, sales-center returns and CSV import.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const zlib = require('node:zlib');
const { createApp } = require('../src/app');
const { parseCsv } = require('../src/csv');

let app; let server; let base;
const config = {
  dbPath: ':memory:', sessionTtlHours: 1, secureCookies: false, trustProxy: false, demoData: true,
  adminEmail: 'admin@inventory.local', adminPassword: 'Admin@123456', companyName: 'Test Co', currency: 'USD', logRequests: false,
};

function client() {
  let cookie = '';
  const call = async (method, url, body, { type } = {}) => {
    const headers = { cookie, 'x-requested-with': 'fetch' };
    let payload;
    if (type) { headers['content-type'] = type; payload = body; } else if (body !== undefined) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
    const res = await fetch(base + url, { method, headers, body: payload });
    const sc = res.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    const buf = Buffer.from(await res.arrayBuffer());
    let data = buf;
    if (/json/.test(res.headers.get('content-type') || '')) data = JSON.parse(buf.toString('utf8'));
    return { status: res.status, data, headers: res.headers };
  };
  return {
    get: (u) => call('GET', u), post: (u, b, o) => call('POST', u, b, o), put: (u, b) => call('PUT', u, b), del: (u) => call('DELETE', u),
    csv: (u, text) => call('POST', u, text, { type: 'text/csv' }),
    login: (email, password) => call('POST', '/api/auth/login', { email, password }),
  };
}

/** Check PDF structure (xref offsets) and return the decompressed page text. */
function inspectPdf(buf) {
  const s = buf.toString('latin1');
  assert.ok(s.startsWith('%PDF-1.4'), 'PDF header');
  assert.ok(s.trimEnd().endsWith('%%EOF'), 'PDF trailer');
  const startxref = Number(/startxref\n(\d+)/.exec(s)[1]);
  assert.ok(s.slice(startxref).startsWith('xref'), 'startxref points at xref table');
  const entries = s.slice(startxref).split('\n').slice(3).filter((l) => / 00000 n $/.test(l));
  entries.forEach((l, i) => assert.ok(s.slice(Number(l.slice(0, 10))).startsWith(`${i + 1} 0 obj`), `xref entry ${i + 1}`));
  let text = '';
  const re = /\/Filter \/FlateDecode \/Length (\d+) >>\nstream\n/g;
  let m;
  while ((m = re.exec(s))) {
    const start = m.index + m[0].length;
    try { text += zlib.inflateSync(buf.subarray(start, start + Number(m[1]))).toString('latin1'); } catch { /* image data */ }
  }
  return text;
}

// 2x2 RGBA PNG built by hand (one transparent pixel), for logo upload tests.
function tinyPng() {
  const crcTable = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b) => { let c = 0xffffffff; for (const x of b) c = crcTable[(c ^ x) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type, 'latin1'), data]);
    const c = Buffer.alloc(4); c.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, c]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(2, 0); ihdr.writeUInt32BE(2, 4); ihdr[8] = 8; ihdr[9] = 6;
  const raw = Buffer.from([0, 255, 0, 0, 255, 0, 255, 0, 255, 2, 0, 0, 255, 255, 0, 0, 0, 0]); // row filters 0 and 2 (Up)
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

let admin; let clerk; let viewer; let manager;
/** Approve a 202 "pending approval" response as the manager. */
const approve = async (res) => {
  assert.equal(res.status, 202, JSON.stringify(res.data));
  const r = await manager.post(`/api/approvals/${res.data.pending_approval.id}/approve`, {});
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return r;
};
before(async () => {
  app = createApp(config);
  server = http.createServer(app.handle);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
  admin = client(); clerk = client(); viewer = client(); manager = client();
  assert.equal((await admin.login('admin@inventory.local', 'Admin@123456')).status, 200);
  assert.equal((await manager.login('manager@inventory.local', 'Password123!')).status, 200);
  assert.equal((await clerk.login('clerk@inventory.local', 'Password123!')).status, 200);
  assert.equal((await viewer.login('viewer@inventory.local', 'Password123!')).status, 200);
});
after(() => { server.close(); app.close(); });

const loc = async (code) => (await admin.get('/api/warehouses?limit=100')).data.items.find((w) => w.code === code);
const productBySku = async (sku) => (await admin.get(`/api/products?q=${sku}&active=`)).data.items.find((p) => p.sku === sku);
const stockAt = async (productId, warehouseId) => {
  const p = (await admin.get(`/api/products/${productId}`)).data;
  const row = p.stock.find((s) => s.warehouse_id === warehouseId);
  return row ? row.on_hand : 0;
};

// ---------------------------------------------------------------------------
test('branding: only admins can change it; validation; public view', async () => {
  assert.equal((await clerk.put('/api/settings/branding', { company_name: 'X' })).status, 403);
  assert.equal((await viewer.get('/api/settings/branding')).status, 403);

  const bad = await admin.put('/api/settings/branding', { brand_color: 'blue', currency: 'XYZ', timezone: 'Mars/Base', email: 'nope' });
  assert.equal(bad.status, 422);
  assert.ok(bad.data.details.brand_color && bad.data.details.currency && bad.data.details.timezone && bad.data.details.email);

  const ok = await admin.put('/api/settings/branding', {
    company_name: 'Acme Trading', tagline: 'Distribution done right', brand_color: '#FFD000', currency: 'eur',
    timezone: 'Asia/Dhaka', address: '1 Main St\nDhaka', welcome_title: 'Welcome to Acme', welcome_points: 'One\nTwo',
  });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.settings.brand_color, '#ffd000');
  assert.equal(ok.data.settings.currency, 'EUR');
  assert.notEqual(ok.data.settings.primary, '#ffd000', 'a light brand colour is darkened for readable buttons');

  const pub = await client().get('/api/auth/config');
  assert.equal(pub.data.companyName, 'Acme Trading');
  assert.equal(pub.data.welcome.title, 'Welcome to Acme');
  assert.deepEqual(pub.data.welcome.points, ['One', 'Two']);
  assert.equal(pub.data.product.author, 'Jobaer Alam');
  assert.equal(pub.data.address, undefined, 'contact details are not part of the public view');

  // Clearing a field restores its default.
  const reset = await admin.put('/api/settings/branding', { welcome_title: '' });
  assert.match(reset.data.settings.welcome_title, /Inventory control/);
  const audit = await admin.get('/api/audit?entity=settings');
  assert.ok(audit.data.items.some((a) => a.action === 'settings.branding_update'));
});

test('branding: logo upload accepts PNG/JPEG only and is served publicly', async () => {
  const png = tinyPng();
  const up = await admin.post('/api/settings/logo', { data: `data:image/png;base64,${png.toString('base64')}` });
  assert.equal(up.status, 200, JSON.stringify(up.data));
  assert.ok(up.data.settings.logo.url.startsWith('/api/branding/logo?v='));

  const logo = await client().get(up.data.settings.logo.url);
  assert.equal(logo.status, 200);
  assert.equal(logo.headers.get('content-type'), 'image/png');
  assert.match(logo.headers.get('cache-control'), /immutable/);
  assert.ok(Buffer.compare(logo.data, png) === 0);

  const svg = await admin.post('/api/settings/logo', { data: 'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=' });
  assert.equal(svg.status, 422);
  const fake = await admin.post('/api/settings/logo', { data: `data:image/png;base64,${Buffer.from('not really a png at all!!').toString('base64')}` });
  assert.equal(fake.status, 422);

  // The PDF embeds the logo with a soft mask for transparency.
  const pdf = await admin.get('/api/settings/sample.pdf');
  assert.equal(pdf.status, 200);
  const s = pdf.data.toString('latin1');
  assert.match(s, /\/Subtype \/Image \/Width 2 \/Height 2/);
  assert.match(s, /\/SMask \d+ 0 R/);
  inspectPdf(pdf.data);
});

test('PDF exports: every CSV export can be rendered as a branded PDF', async () => {
  const urls = [
    '/api/products?format=pdf', '/api/stock?format=pdf', '/api/movements?format=pdf', '/api/reorder-suggestions?format=pdf',
    '/api/purchase-orders?format=pdf', '/api/sales-orders?format=pdf', '/api/returns?format=pdf', '/api/audit?format=pdf',
    '/api/reports/valuation?group=category&format=pdf', '/api/reports/sales?format=pdf',
  ];
  for (const u of urls) {
    const r = await admin.get(u);
    assert.equal(r.status, 200, u);
    assert.equal(r.headers.get('content-type'), 'application/pdf', u);
    assert.match(r.headers.get('content-disposition'), /^attachment; filename=".+\.pdf"$/, u);
    const text = inspectPdf(r.data);
    assert.ok(text.includes('(Acme Trading)'), `${u} has the company letterhead`);
    assert.ok(text.includes('Created by Jobaer Alam'), `${u} has the product credit`);
    assert.match(text, /\(Page 1 of \d+\)/, u);
  }
  // Permissions still apply to PDF exports.
  assert.equal((await viewer.get('/api/audit?format=pdf')).status, 403);
  // Inline viewing for "open in new tab".
  assert.match((await admin.get('/api/stock?format=pdf&inline=1')).headers.get('content-disposition'), /^inline/);
});

test('PDF documents: PO, sales documents and their status rules', async () => {
  const po = await admin.get('/api/purchase-orders/1/pdf');
  assert.equal(po.status, 200);
  const poText = inspectPdf(po.data);
  assert.ok(poText.includes('(PURCHASE ORDER)') && poText.includes('(PO-000001)'));

  const so = (await admin.get('/api/sales-orders?status=SHIPPED')).data.items[0];
  const inv = await admin.get(`/api/sales-orders/${so.id}/pdf?doc=invoice`);
  assert.equal(inv.status, 200);
  assert.ok(inspectPdf(inv.data).includes(`(${so.number.replace('SO-', 'INV-')})`));
  assert.equal((await admin.get(`/api/sales-orders/${so.id}/pdf?doc=packing`)).status, 200);

  const draft = (await admin.get('/api/sales-orders?status=DRAFT')).data.items[0];
  assert.equal((await admin.get(`/api/sales-orders/${draft.id}/pdf?doc=invoice`)).status, 409);
  const conf = inspectPdf((await admin.get(`/api/sales-orders/${draft.id}/pdf`)).data);
  assert.ok(conf.includes('(DRAFT)'), 'draft documents carry a watermark');
  assert.equal((await admin.get('/api/purchase-orders/99999/pdf')).status, 404);
});

test('locations: warehouses and sales centers can be filtered by type', async () => {
  const centers = (await admin.get('/api/warehouses?kind=SALES_CENTER')).data.items;
  assert.ok(centers.length >= 2);
  assert.ok(centers.every((w) => w.kind === 'SALES_CENTER'));
  const created = await admin.post('/api/warehouses', { code: 'SC9', name: 'Mall Sales Center', kind: 'SALES_CENTER', manager_name: 'Kim' });
  assert.equal(created.status, 201);
  assert.equal(created.data.kind, 'SALES_CENTER');
  assert.equal((await admin.post('/api/warehouses', { code: 'BAD', name: 'Bad', kind: 'SHOP' })).status, 422);
  const look = (await admin.get('/api/lookups')).data.warehouses;
  assert.ok(look.every((w) => w.kind));
});

test('returns: dispatch from sales center, receive with damage, ledger and rules', async () => {
  const sc = await loc('SC2');
  const cwh = await loc('CWH');
  const edc = await loc('EDC');
  const p = await productBySku('EL-1001');
  const before = { sc: await stockAt(p.id, sc.id), cwh: await stockAt(p.id, cwh.id) };
  assert.ok(before.sc >= 5);

  // Direction rules: only sales center -> warehouse.
  assert.equal((await clerk.post('/api/returns', { from_location_id: cwh.id, to_location_id: edc.id, lines: [{ product_id: p.id, qty: 1 }] })).status, 422);
  assert.equal((await clerk.post('/api/returns', { from_location_id: sc.id, to_location_id: sc.id, lines: [{ product_id: p.id, qty: 1 }] })).status, 422);
  assert.equal((await viewer.post('/api/returns', { from_location_id: sc.id, to_location_id: cwh.id, lines: [{ product_id: p.id, qty: 1 }] })).status, 403);

  const created = await clerk.post('/api/returns', { from_location_id: sc.id, to_location_id: cwh.id, reason: 'UNSOLD', lines: [{ product_id: p.id, qty: 5 }] });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  const ret = created.data;
  assert.match(ret.number, /^RET-\d{6}$/);
  assert.equal(ret.status, 'DRAFT');

  // Too much requested -> dispatch blocked with shortages.
  const big = await clerk.post('/api/returns', { from_location_id: sc.id, to_location_id: cwh.id, lines: [{ product_id: p.id, qty: before.sc + 1000 }] });
  const blocked = await clerk.post(`/api/returns/${big.data.id}/dispatch`);
  assert.equal(blocked.status, 409);
  assert.equal(blocked.data.details.shortages[0].sku, 'EL-1001');
  assert.equal((await clerk.del(`/api/returns/${big.data.id}`)).status, 200);

  const asked = await clerk.post(`/api/returns/${ret.id}/dispatch`);
  assert.equal(await stockAt(p.id, sc.id), before.sc, 'nothing moves until the manager approves');
  await approve(asked);
  const sent = await clerk.get(`/api/returns/${ret.id}`);
  assert.equal(sent.data.status, 'DISPATCHED');
  assert.equal(await stockAt(p.id, sc.id), before.sc - 5);
  assert.equal(await stockAt(p.id, cwh.id), before.cwh, 'in transit: not yet in the warehouse');
  assert.equal((await clerk.put(`/api/returns/${ret.id}`, { from_location_id: sc.id, to_location_id: cwh.id, lines: [{ product_id: p.id, qty: 1 }] })).status, 409);

  const over = await clerk.post(`/api/returns/${ret.id}/receive`, { lines: [{ id: ret.lines[0].id, qty_good: 5, qty_damaged: 1 }] });
  assert.equal(over.status, 422);

  const got = await clerk.post(`/api/returns/${ret.id}/receive`, { lines: [{ id: ret.lines[0].id, qty_good: 3, qty_damaged: 1 }] });
  assert.equal(got.status, 200, JSON.stringify(got.data));
  assert.equal(got.data.status, 'RECEIVED');
  assert.deepEqual([got.data.total_good, got.data.total_damaged, got.data.total_missing], [3, 1, 1]);
  assert.equal(await stockAt(p.id, cwh.id), before.cwh + 3, 'good units added, damaged written off');

  const ledger = (await admin.get(`/api/movements?ref=${ret.number}`)).data.items;
  assert.deepEqual(ledger.map((m) => `${m.type}:${m.qty}`).sort(), ['ADJUSTMENT:-1', 'TRANSFER_IN:4', 'TRANSFER_OUT:-5'].sort());
  assert.equal((await clerk.post(`/api/returns/${ret.id}/cancel`)).status, 409, 'received returns are final');

  const pdf = await admin.get(`/api/returns/${ret.id}/pdf`);
  assert.equal(pdf.status, 200);
  assert.ok(inspectPdf(pdf.data).includes('(STOCK RETURN NOTE)'));
});

test('returns: cancelling a dispatched return reinstates sales center stock', async () => {
  const sc = await loc('SC2');
  const cwh = await loc('CWH');
  const p = await productBySku('EL-1005');
  const start = await stockAt(p.id, sc.id);
  const ret = (await clerk.post('/api/returns', { from_location_id: sc.id, to_location_id: cwh.id, lines: [{ product_id: p.id, qty: 2 }] })).data;
  await approve(await clerk.post(`/api/returns/${ret.id}/dispatch`));
  assert.equal(await stockAt(p.id, sc.id), start - 2);
  assert.equal((await clerk.post(`/api/returns/${ret.id}/cancel`)).status, 422, 'a reason is required');
  await approve(await clerk.post(`/api/returns/${ret.id}/cancel`, { reason: 'Wrong items picked' }));
  const cancelled = await clerk.get(`/api/returns/${ret.id}`);
  assert.equal(cancelled.data.status, 'CANCELLED');
  assert.equal(await stockAt(p.id, sc.id), start);
  const list = await admin.get('/api/returns');
  assert.ok(list.data.counts.CANCELLED >= 1);
});

test('csv parser: quotes, embedded newlines, semicolons, BOM', () => {
  const { rows, delimiter } = parseCsv('﻿sku;name;note\r\nA-1;"Widget; large";"line1\nline2"\r\n\r\nB-2;"Say ""hi""";\n');
  assert.equal(delimiter, ';');
  assert.deepEqual(rows, [['sku', 'name', 'note'], ['A-1', 'Widget; large', 'line1\nline2'], ['B-2', 'Say "hi"', '']]);
  assert.throws(() => parseCsv('a,b\n"open,1\n'), /quoted field/);
});

test('import: templates, permissions, dry run, all-or-nothing commit', async () => {
  const tpl = await admin.get('/api/import/products/template');
  assert.equal(tpl.status, 200);
  assert.match(tpl.data.toString('utf8'), /^﻿sku,name,description,category,supplier/);

  const csv = [
    'Product Code,Product Name,Category,Supplier,Unit Cost,Selling Price,Reorder Level,Status',
    'IMP-001,Imported widget,New Imported Category,Northwind Components,"1,250.50",1999,5,yes',
    'IMP-002,Second widget,,,"2.00",3.5,,no',
    'EL-1001,,,,,,,',
  ].join('\r\n');
  assert.equal((await clerk.csv('/api/import/products', csv)).status, 403, 'clerks cannot import master data');
  assert.equal((await admin.post('/api/import/products', { not: 'csv' })).status, 415);

  const dry = await admin.csv('/api/import/products?dry_run=1', csv);
  assert.equal(dry.status, 200, JSON.stringify(dry.data));
  assert.equal(dry.data.created, 2);
  assert.equal(dry.data.unchanged, 1, 'blank cells leave existing values alone');
  assert.equal(dry.data.committed, false);
  assert.equal(await productBySku('IMP-001'), undefined, 'dry run saved nothing');

  const bad = csv + '\r\nIMP-003,Bad price,,Unknown Supplier Ltd,abc,1,1,maybe\r\nIMP-001,Duplicate,,,1,1,1,yes';
  const failed = await admin.csv('/api/import/products', bad);
  assert.equal(failed.status, 422);
  const errs = failed.data.details.errors;
  assert.ok(errs.some((e) => e.row === 5 && e.field === 'supplier'));
  assert.ok(errs.some((e) => e.row === 6 && /duplicates row 2/.test(e.message)));
  assert.equal(await productBySku('IMP-002'), undefined, 'nothing saved when any row fails');

  const done = await admin.csv('/api/import/products', csv);
  assert.equal(done.status, 200);
  assert.equal(done.data.committed, true);
  const p1 = await productBySku('IMP-001');
  assert.equal(p1.cost, 1250.5);
  assert.equal(p1.category_name, 'New Imported Category');
  assert.equal(p1.supplier_name, 'Northwind Components');
  assert.equal((await productBySku('IMP-002')).active, 0);

  const skip = await admin.csv('/api/import/products?update_existing=0', 'sku,name\nIMP-001,Renamed');
  assert.equal(skip.data.skipped, 1);
  const upd = await admin.csv('/api/import/products', 'sku,name\nIMP-001,Renamed');
  assert.equal(upd.data.updated, 1);
  assert.equal((await productBySku('IMP-001')).name, 'Renamed');
  assert.ok((await admin.get('/api/audit?q=import.commit')).data.items.length >= 2);
});

test('import: suppliers, customers and stock balances', async () => {
  const sup = await admin.csv('/api/import/suppliers', 'Supplier Name,Email,Lead Time\nImport Supplier A,a@x.example,5\nImport Supplier B,,');
  assert.equal(sup.data.created, 2, JSON.stringify(sup.data));
  const cus = await admin.csv('/api/import/customers', 'name,email\nImport Customer,c@x.example\nImport Customer 2,not-an-email');
  assert.equal(cus.status, 422);
  assert.equal(cus.data.details.errors[0].field, 'email');

  const cwh = await loc('CWH');
  const p = await productBySku('IMP-001');
  assert.equal((await viewer.csv('/api/import/stock', 'sku,location,qty\nIMP-001,CWH,10')).status, 403);
  const set = await clerk.csv('/api/import/stock?stock_mode=set', 'sku,warehouse,quantity,unit cost,bin\nIMP-001,cwh,40,12,A-01\nIMP-002,SC2,3,,');
  assert.equal(set.status, 200, JSON.stringify(set.data));
  assert.equal(await stockAt(p.id, cwh.id), 40);
  const add = await clerk.csv('/api/import/stock?stock_mode=add', 'sku,location,qty,unit_cost\nIMP-001,CWH,10,22');
  assert.equal(add.data.updated, 1);
  assert.equal(await stockAt(p.id, cwh.id), 50);
  const moves = (await admin.get(`/api/movements?ref=${add.data.reference}`)).data.items;
  assert.equal(moves[0].type, 'RECEIPT');
  const unknown = await clerk.csv('/api/import/stock', 'sku,location,qty\nNOPE,CWH,1\nIMP-001,ZZZ,1\nIMP-001,CWH,-4');
  assert.equal(unknown.status, 422);
  assert.deepEqual(unknown.data.details.errors.map((e) => e.field), ['sku', 'location', 'qty']);
  const missingCol = await clerk.csv('/api/import/stock', 'sku,qty\nIMP-001,1');
  assert.equal(missingCol.status, 422);
  assert.match(missingCol.data.error, /location/);
});

test('import: large files are handled in one transaction', async () => {
  const lines = ['sku,name,cost,price'];
  for (let i = 0; i < 20000; i++) lines.push(`BULK-${String(i).padStart(5, '0')},Bulk item ${i},1.5,3`);
  const t = Date.now();
  const r = await admin.csv('/api/import/products', lines.join('\n'));
  assert.equal(r.status, 200, JSON.stringify(r.data).slice(0, 300));
  assert.equal(r.data.created, 20000);
  assert.ok(Date.now() - t < 20000, 'imports 20k rows in reasonable time');
  assert.equal((await admin.get('/api/products?q=BULK-&limit=1')).data.total, 20000);
});

// ---------------------------------------------------------------------------
// Manager approval for sales agents
// ---------------------------------------------------------------------------
async function shippedOrder(qty = 4) {
  const cwh = await loc('CWH');
  const p = await productBySku('OF-2001');
  const cust = (await admin.get('/api/customers')).data.items[0];
  const so = (await clerk.post('/api/sales-orders', { customer_id: cust.id, warehouse_id: cwh.id, lines: [{ product_id: p.id, qty, unit_price: 10 }] })).data;
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/confirm`)).status, 200);
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/ship`)).status, 200);
  return { so: (await clerk.get(`/api/sales-orders/${so.id}`)).data, p, cwh };
}

test('approvals: agent changes to an invoice wait for their manager', async () => {
  const { so, p, cwh } = await shippedOrder(4);
  const stock0 = await stockAt(p.id, cwh.id);
  const line = so.lines[0];

  // Reason is mandatory; nothing-changed is rejected; cannot return more than was sold.
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/amend`, { lines: [{ line_id: line.id, return_qty: 1 }] })).status, 422);
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/amend`, { reason: 'x', lines: [{ line_id: line.id }] })).status, 422);
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/amend`, { reason: 'x', lines: [{ line_id: line.id, return_qty: 5 }] })).status, 422);

  const res = await clerk.post(`/api/sales-orders/${so.id}/amend`, {
    reason: 'Customer returned one ream; agreed discount', lines: [{ line_id: line.id, return_qty: 1, unit_price: 9 }],
  });
  assert.equal(res.status, 202, JSON.stringify(res.data));
  const req = res.data.pending_approval;
  assert.match(req.number, /^APR-\d{6}$/);
  assert.equal(req.approver_name, 'Morgan Manager', 'routed to the clerk own manager');
  assert.match(req.summary, /return 1 × OF-2001/);

  // Nothing changed yet; the document shows the pending request; a second request is refused.
  let cur = (await clerk.get(`/api/sales-orders/${so.id}`)).data;
  assert.equal(cur.total, 40);
  assert.equal(cur.pending_approval.number, req.number);
  assert.equal(await stockAt(p.id, cwh.id), stock0);
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/amend`, { reason: 'again', lines: [{ line_id: line.id, return_qty: 1 }] })).status, 409);

  // Who can decide: not the requester, not a viewer; the assigned manager can.
  assert.equal((await clerk.post(`/api/approvals/${req.id}/approve`, {})).status, 403);
  assert.equal((await viewer.post(`/api/approvals/${req.id}/approve`, {})).status, 403);
  assert.ok((await manager.get('/api/approvals/summary')).data.to_decide >= 1);
  assert.equal((await clerk.get('/api/approvals/summary')).data.my_pending, 1);

  const ok = await manager.post(`/api/approvals/${req.id}/approve`, { note: 'OK' });
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  assert.equal(ok.data.status, 'APPROVED');
  cur = (await clerk.get(`/api/sales-orders/${so.id}`)).data;
  assert.equal(cur.lines[0].qty_returned, 1);
  assert.equal(cur.lines[0].unit_price, 9);
  assert.equal(cur.total, 27, '3 net units at the corrected price');
  assert.equal(cur.pending_approval, null);
  assert.equal(await stockAt(p.id, cwh.id), stock0 + 1, 'returned unit is back in stock');
  assert.equal((await manager.post(`/api/approvals/${req.id}/approve`, {})).status, 409, 'cannot decide twice');

  const invoice = await admin.get(`/api/sales-orders/${so.id}/pdf?doc=invoice`);
  assert.ok(inspectPdf(invoice.data).includes('(Credited for returns)'));
  const audit = (await admin.get(`/api/audit?entity=sales_order&entity_id=${so.id}`)).data.items.map((a) => a.action);
  assert.ok(audit.includes('so.amend') && audit.includes('approval.approved'));
});

test('approvals: rejection needs a reason; withdraw; managers act directly', async () => {
  const { so } = await shippedOrder(2);
  const line = so.lines[0];
  const r1 = (await clerk.post(`/api/sales-orders/${so.id}/amend`, { reason: 'Price match', lines: [{ line_id: line.id, unit_price: 1 }] })).data.pending_approval;
  assert.equal((await manager.post(`/api/approvals/${r1.id}/reject`, {})).status, 422);
  const rej = await manager.post(`/api/approvals/${r1.id}/reject`, { note: 'Too low' });
  assert.equal(rej.data.status, 'REJECTED');
  assert.equal((await clerk.get(`/api/sales-orders/${so.id}`)).data.lines[0].unit_price, 10);

  const r2 = (await clerk.post(`/api/sales-orders/${so.id}/amend`, { reason: 'Typo', lines: [{ line_id: line.id, unit_price: 9.5 }] })).data.pending_approval;
  assert.equal((await manager.post(`/api/approvals/${r2.id}/withdraw`, {})).status, 403, 'only the requester withdraws');
  assert.equal((await clerk.post(`/api/approvals/${r2.id}/withdraw`, {})).data.status, 'WITHDRAWN');

  // Managers change invoices immediately (still with a reason, still audited).
  const direct = await manager.post(`/api/sales-orders/${so.id}/amend`, { reason: 'Goodwill', lines: [{ line_id: line.id, unit_price: 9.75 }] });
  assert.equal(direct.status, 200, JSON.stringify(direct.data));
  assert.equal(direct.data.lines[0].unit_price, 9.75);
});

test('approvals: confirmed-order changes re-reserve stock; shipping is blocked while pending', async () => {
  const cwh = await loc('CWH');
  const p = await productBySku('OF-2002');
  const cust = (await admin.get('/api/customers')).data.items[0];
  const so = (await clerk.post('/api/sales-orders', { customer_id: cust.id, warehouse_id: cwh.id, lines: [{ product_id: p.id, qty: 2 }] })).data;
  await clerk.post(`/api/sales-orders/${so.id}/confirm`);
  assert.equal((await clerk.put(`/api/sales-orders/${so.id}`, { customer_id: cust.id, warehouse_id: cwh.id, lines: [{ product_id: p.id, qty: 3 }] })).status, 409);
  const res = await clerk.post(`/api/sales-orders/${so.id}/amend`, { reason: 'Customer wants one more', lines: [{ product_id: p.id, qty: 3 }] });
  assert.equal(res.status, 202, JSON.stringify(res.data));
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/ship`)).status, 409, 'cannot ship while a change is pending');
  await approve(res);
  const after = (await clerk.get(`/api/sales-orders/${so.id}`)).data;
  assert.equal(after.lines[0].qty, 3);
  const st = (await admin.get(`/api/products/${p.id}`)).data.stock.find((x) => x.warehouse_id === cwh.id);
  assert.ok(st.reserved >= 3);
  assert.equal((await clerk.post(`/api/sales-orders/${so.id}/ship`)).status, 200);
});

test('approvals: assigned manager routing and user manager validation', async () => {
  const users = (await admin.get('/api/users?limit=100')).data.items;
  const clerkUser = users.find((u) => u.email === 'clerk@inventory.local');
  const viewerUser = users.find((u) => u.email === 'viewer@inventory.local');
  assert.equal(clerkUser.manager_name, 'Morgan Manager');
  assert.equal((await admin.put(`/api/users/${clerkUser.id}`, { manager_id: viewerUser.id })).status, 422, 'a viewer cannot approve');
  assert.equal((await admin.put(`/api/users/${clerkUser.id}`, { manager_id: clerkUser.id })).status, 422);

  // A second manager cannot decide requests routed to the clerk's own manager; an admin can.
  const m2 = await admin.post('/api/users', { email: 'm2@inventory.local', name: 'Other Manager', role: 'manager', password: 'OtherPass123' });
  assert.equal(m2.status, 201);
  const other = client();
  await other.login('m2@inventory.local', 'OtherPass123');
  const { so } = await shippedOrder(1);
  const req = (await clerk.post(`/api/sales-orders/${so.id}/amend`, { reason: 'r', lines: [{ line_id: so.lines[0].id, unit_price: 8 }] })).data.pending_approval;
  assert.equal((await other.post(`/api/approvals/${req.id}/approve`, {})).status, 403);
  assert.equal((await other.get(`/api/approvals/${req.id}`)).status, 404, 'not visible to unrelated managers');
  assert.equal((await admin.post(`/api/approvals/${req.id}/approve`, {})).status, 200);
});
