'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createApp } = require('../src/app');

let app; let server; let base;

const config = {
  dbPath: ':memory:', sessionTtlHours: 1, secureCookies: false, trustProxy: false, demoData: true,
  adminEmail: 'admin@inventory.local', adminPassword: 'Admin@123456', companyName: 'Test Co', currency: 'USD', logRequests: false,
};

function client() {
  let cookie = '';
  const call = async (method, url, body, { csrf = true } = {}) => {
    const headers = { cookie };
    if (csrf) headers['x-requested-with'] = 'fetch';
    if (body !== undefined) headers['content-type'] = 'application/json';
    const res = await fetch(base + url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    const text = await res.text();
    let data = text;
    try { data = JSON.parse(text); } catch { /* csv */ }
    return { status: res.status, data, headers: res.headers };
  };
  return {
    get: (u) => call('GET', u), post: (u, b, o) => call('POST', u, b, o), put: (u, b) => call('PUT', u, b), del: (u) => call('DELETE', u),
    login: (email, password) => call('POST', '/api/auth/login', { email, password }),
  };
}

let admin; let clerk; let viewer;
let productId; let whA; let whB; let supplierId; let customerId;

before(async () => {
  app = createApp(config);
  server = http.createServer(app.handle);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
  admin = client(); clerk = client(); viewer = client();
  assert.equal((await admin.login('admin@inventory.local', 'Admin@123456')).status, 200);
  assert.equal((await clerk.login('clerk@inventory.local', 'Password123!')).status, 200);
  assert.equal((await viewer.login('viewer@inventory.local', 'Password123!')).status, 200);

  whA = (await admin.post('/api/warehouses', { code: 'TA', name: 'Test A' })).data.id;
  whB = (await admin.post('/api/warehouses', { code: 'TB', name: 'Test B' })).data.id;
  supplierId = (await admin.post('/api/suppliers', { name: 'Test Supplier' })).data.id;
  customerId = (await admin.post('/api/customers', { name: 'Test Customer' })).data.id;
  const p = await admin.post('/api/products', { sku: 'T-001', name: 'Test Widget', cost: 10, price: 25, reorder_point: 5, supplier_id: supplierId });
  assert.equal(p.status, 201);
  productId = p.data.id;
});

after(() => { server.close(); app.close(); });

const stockOf = async (wh) => {
  const p = (await admin.get(`/api/products/${productId}`)).data;
  return p.stock.find((s) => s.warehouse_id === wh) || { on_hand: 0, reserved: 0, available: 0 };
};

// ---- Security -------------------------------------------------------------
test('rejects unauthenticated access', async () => {
  const r = await client().get('/api/products');
  assert.equal(r.status, 401);
});

test('rejects wrong password without revealing which field was wrong', async () => {
  const r = await client().login('admin@inventory.local', 'nope-nope-nope');
  assert.equal(r.status, 401);
  assert.equal(r.data.error, 'Invalid email or password');
});

test('locks out after repeated failed logins', async () => {
  const c = client();
  for (let i = 0; i < 5; i++) await c.login('manager@inventory.local', 'wrong-password-1');
  const r = await c.login('manager@inventory.local', 'Password123!');
  assert.equal(r.status, 429);
});

test('requires CSRF header on mutating requests', async () => {
  const r = await admin.post('/api/categories', { name: 'NoCsrf' }, { csrf: false });
  assert.equal(r.status, 403);
});

test('enforces role permissions', async () => {
  assert.equal((await viewer.post('/api/products', { sku: 'V-1', name: 'x' })).status, 403);
  assert.equal((await clerk.post('/api/products', { sku: 'C-1', name: 'x' })).status, 403);
  assert.equal((await clerk.get('/api/users')).status, 403);
  assert.equal((await viewer.get('/api/products')).status, 200);
});

test('sends security headers and HttpOnly session cookie', async () => {
  const r = await client().login('admin@inventory.local', 'Admin@123456');
  assert.match(r.headers.get('set-cookie'), /HttpOnly/);
  assert.match(r.headers.get('set-cookie'), /SameSite=Strict/);
  assert.ok(r.headers.get('content-security-policy'));
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
});

test('validates input and reports field errors', async () => {
  const r = await admin.post('/api/products', { sku: 'bad sku!', name: '', price: -1 });
  assert.equal(r.status, 422);
  assert.ok(r.data.details.sku && r.data.details.name && r.data.details.price);
});

test('rejects duplicate SKU with 409', async () => {
  const r = await admin.post('/api/products', { sku: 't-001', name: 'Dup' });
  assert.equal(r.status, 409);
});

// ---- Stock engine ---------------------------------------------------------
test('receipts update stock and weighted-average cost', async () => {
  await clerk.post('/api/stock/movements', { type: 'RECEIPT', product_id: productId, warehouse_id: whA, qty: 10, unit_cost: 10 });
  await clerk.post('/api/stock/movements', { type: 'RECEIPT', product_id: productId, warehouse_id: whA, qty: 10, unit_cost: 20 });
  const p = (await admin.get(`/api/products/${productId}`)).data;
  assert.equal(p.avg_cost, 15);
  assert.equal((await stockOf(whA)).on_hand, 20);
});

test('prevents negative stock', async () => {
  const r = await clerk.post('/api/stock/movements', { type: 'ISSUE', product_id: productId, warehouse_id: whA, qty: 999 });
  assert.equal(r.status, 409);
  assert.equal((await stockOf(whA)).on_hand, 20);
});

test('adjustments require a reason', async () => {
  const r = await clerk.post('/api/stock/movements', { type: 'ADJUSTMENT', product_id: productId, warehouse_id: whA, qty: -1 });
  assert.equal(r.status, 422);
});

test('transfers move stock atomically between warehouses', async () => {
  const r = await clerk.post('/api/stock/transfer', { product_id: productId, from_warehouse_id: whA, to_warehouse_id: whB, qty: 5 });
  assert.equal(r.status, 201);
  assert.equal((await stockOf(whA)).on_hand, 15);
  assert.equal((await stockOf(whB)).on_hand, 5);
  const bad = await clerk.post('/api/stock/transfer', { product_id: productId, from_warehouse_id: whB, to_warehouse_id: whA, qty: 50 });
  assert.equal(bad.status, 409);
  assert.equal((await stockOf(whB)).on_hand, 5, 'failed transfer must not change stock');
});

test('cycle count posts only the variance', async () => {
  const r = await clerk.post('/api/stock/count', { product_id: productId, warehouse_id: whB, counted: 3 });
  assert.equal(r.data.qty, -2);
  assert.equal((await stockOf(whB)).on_hand, 3);
});

test('movement ledger is immutable at the database level', () => {
  assert.throws(() => app.db.run('UPDATE movements SET qty = 1'), /immutable/);
  assert.throws(() => app.db.run('DELETE FROM movements'), /immutable/);
});

// ---- Purchasing -----------------------------------------------------------
test('purchase order: clerk drafts, manager approves, clerk receives partially then fully', async () => {
  const created = await clerk.post('/api/purchase-orders', { supplier_id: supplierId, warehouse_id: whA, lines: [{ product_id: productId, qty: 10, unit_cost: 15 }] });
  assert.equal(created.status, 201);
  const po = created.data;
  assert.equal(po.status, 'DRAFT');
  assert.match(po.number, /^PO-\d{6}$/);

  assert.equal((await clerk.post(`/api/purchase-orders/${po.id}/submit`)).status, 403, 'clerk cannot approve');
  assert.equal((await clerk.post(`/api/purchase-orders/${po.id}/receive`, { lines: [{ line_id: po.lines[0].id, qty: 1 }] })).status, 409, 'cannot receive a draft');
  assert.equal((await admin.post(`/api/purchase-orders/${po.id}/submit`)).data.status, 'ORDERED');

  const before = (await stockOf(whA)).on_hand;
  const partial = await clerk.post(`/api/purchase-orders/${po.id}/receive`, { lines: [{ line_id: po.lines[0].id, qty: 4 }] });
  assert.equal(partial.data.status, 'PARTIAL');
  assert.equal((await clerk.post(`/api/purchase-orders/${po.id}/receive`, { lines: [{ line_id: po.lines[0].id, qty: 7 }] })).status, 409, 'cannot over-receive');
  const full = await clerk.post(`/api/purchase-orders/${po.id}/receive`, { lines: [{ line_id: po.lines[0].id, qty: 6 }] });
  assert.equal(full.data.status, 'RECEIVED');
  assert.equal((await stockOf(whA)).on_hand, before + 10);
  assert.equal((await admin.put(`/api/purchase-orders/${po.id}`, { supplier_id: supplierId, warehouse_id: whA, lines: [{ product_id: productId, qty: 1 }] })).status, 409, 'received PO is locked');
});

// ---- Sales ----------------------------------------------------------------
test('sales order: confirm reserves, reserved stock cannot be issued, ship deducts', async () => {
  const onHand = (await stockOf(whA)).on_hand;
  const so = (await clerk.post('/api/sales-orders', { customer_id: customerId, warehouse_id: whA, lines: [{ product_id: productId, qty: onHand - 2 }] })).data;
  assert.equal(so.lines[0].unit_price, 25, 'defaults to product price');

  const conf = await clerk.post(`/api/sales-orders/${so.id}/confirm`);
  assert.equal(conf.data.status, 'CONFIRMED');
  const s = await stockOf(whA);
  assert.equal(s.reserved, onHand - 2);
  assert.equal(s.available, 2);

  const issue = await clerk.post('/api/stock/movements', { type: 'ISSUE', product_id: productId, warehouse_id: whA, qty: 3 });
  assert.equal(issue.status, 409, 'reserved stock is protected');

  const shipped = await clerk.post(`/api/sales-orders/${so.id}/ship`);
  assert.equal(shipped.data.status, 'SHIPPED');
  assert.ok(shipped.data.cogs > 0);
  const after = await stockOf(whA);
  assert.equal(after.on_hand, 2);
  assert.equal(after.reserved, 0);
});

test('sales order cannot be confirmed without enough stock', async () => {
  const so = (await clerk.post('/api/sales-orders', { customer_id: customerId, warehouse_id: whA, lines: [{ product_id: productId, qty: 1000 }] })).data;
  const r = await clerk.post(`/api/sales-orders/${so.id}/confirm`);
  assert.equal(r.status, 409);
  assert.equal(r.data.details.shortages[0].requested, 1000);
});

test('cancelling a confirmed order releases its reservation', async () => {
  const so = (await clerk.post('/api/sales-orders', { customer_id: customerId, warehouse_id: whA, lines: [{ product_id: productId, qty: 2 }] })).data;
  await clerk.post(`/api/sales-orders/${so.id}/confirm`);
  assert.equal((await stockOf(whA)).reserved, 2);
  // A sales agent's cancellation of a confirmed order waits for a manager.
  const req = await clerk.post(`/api/sales-orders/${so.id}/cancel`, { reason: 'Customer withdrew' });
  assert.equal(req.status, 202);
  assert.equal((await stockOf(whA)).reserved, 2, 'nothing changes until approved');
  assert.equal((await admin.post(`/api/approvals/${req.data.pending_approval.id}/approve`, {})).status, 200);
  assert.equal((await stockOf(whA)).reserved, 0);
});

// ---- Admin & reporting ----------------------------------------------------
test('cannot remove the last administrator or demote yourself', async () => {
  const r = await admin.put('/api/users/1', { role: 'viewer' });
  assert.equal(r.status, 409);
});

test('deactivating a user ends their sessions', async () => {
  const u = (await admin.post('/api/users', { email: 'temp@inventory.local', name: 'Temp', role: 'clerk', password: 'TempPass1234' })).data;
  const temp = client();
  await temp.login('temp@inventory.local', 'TempPass1234');
  assert.equal((await temp.get('/api/auth/me')).status, 200);
  await admin.put(`/api/users/${u.id}`, { active: false });
  assert.equal((await temp.get('/api/auth/me')).status, 401);
});

test('password policy is enforced', async () => {
  const r = await admin.post('/api/users', { email: 'weak@inventory.local', name: 'Weak', role: 'viewer', password: 'short' });
  assert.equal(r.status, 422);
});

test('products with history are deactivated rather than deleted', async () => {
  const r = await admin.del(`/api/products/${productId}`);
  assert.equal(r.data.deactivated, true);
  await admin.put(`/api/products/${productId}`, { active: true });
});

test('CSV export neutralises formula injection', async () => {
  await admin.post('/api/products', { sku: 'CSV-1', name: '=HYPERLINK("http://evil")' });
  const r = await admin.get('/api/products?format=csv&q=CSV-1');
  assert.match(r.headers.get('content-type'), /text\/csv/);
  assert.match(r.data, /"'=HYPERLINK/);
});

test('every mutation is written to the audit log', async () => {
  const r = await admin.get('/api/audit?entity=purchase_order');
  const actions = r.data.items.map((a) => a.action);
  for (const a of ['po.create', 'po.approve', 'po.receive']) assert.ok(actions.includes(a), `missing ${a}`);
});

test('dashboard and reports respond', async () => {
  for (const u of ['/api/dashboard', '/api/reports/valuation?group=product', '/api/reports/sales', '/api/reorder-suggestions', '/api/stock', '/api/movements']) {
    assert.equal((await viewer.get(u)).status, 200, u);
  }
});
