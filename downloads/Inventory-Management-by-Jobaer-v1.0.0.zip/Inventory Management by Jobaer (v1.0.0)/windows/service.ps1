<#
  Enterprise Inventory - start / stop / restart / status
  Used by Start.bat, Stop.bat, Restart.bat and Status.bat in the installation folder.
#>
param(
  [ValidateSet('start', 'stop', 'restart', 'status')][string]$Action = 'status',
  [string]$Dir = '',
  [switch]$Quiet
)
. (Join-Path $PSScriptRoot 'common.ps1')
if ($Dir) { $InstallDir = [IO.Path]::GetFullPath($Dir) }

$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
$port = Get-Port

function Stop-App {
  if ($task -and $task.State -eq 'Running') { Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue }
  $procs = @(Get-ServerProcesses)
  foreach ($p in $procs) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
  for ($i = 0; $i -lt 20 -and @(Get-ServerProcesses).Count; $i++) { Start-Sleep -Milliseconds 250 }
  if (-not $Quiet) { Write-Host 'Enterprise Inventory is stopped.' -ForegroundColor Yellow }
}

function Start-App {
  if (Get-Health) { Write-Host "Already running: http://localhost:$port" -ForegroundColor Green; return }
  if ($task) {
    Start-ScheduledTask -TaskName $TaskName
    for ($i = 0; $i -lt 30; $i++) { Start-Sleep -Seconds 1; $h = Get-Health; if ($h) { break } }
    if ($h) { Write-Host "Running: http://localhost:$port (version $($h.version))" -ForegroundColor Green }
    else { Write-Host "Started, but it is not answering yet. See $InstallDir\logs\server.log" -ForegroundColor Yellow }
  } else {
    # No service installed: run in this window (close the window or press Ctrl+C to stop).
    $node = Get-NodeExe
    Write-Host 'Starting in this window. Keep it open; press Ctrl+C to stop.' -ForegroundColor Cyan
    Push-Location $InstallDir
    try { & $node (Join-Path $InstallDir 'server.js') } finally { Pop-Location }
  }
}

switch ($Action) {
  'status' {
    $h = Get-Health
    Write-Host ''
    Write-Host 'Enterprise Inventory - status' -ForegroundColor White
    Write-Host "  Folder:   $InstallDir"
    if ($h) { Write-Host "  Server:   RUNNING  (version $($h.version))  http://localhost:$port" -ForegroundColor Green }
    else { Write-Host "  Server:   NOT RESPONDING on port $port" -ForegroundColor Red }
    if ($task) {
      $info = Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue
      Write-Host "  Service:  installed (task '$TaskName', state $($task.State)), last start $($info.LastRunTime)"
    } else { Write-Host '  Service:  not installed (start manually with Start.bat)' }
    $b = Get-ChildItem (Join-Path $InstallDir 'backups') -Filter 'inventory-*.db' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
    if ($b) { Write-Host "  Backup:   latest $($b.Name) ($([math]::Round($b.Length / 1MB, 2)) MB)" } else { Write-Host '  Backup:   none yet (run Backup.bat)' -ForegroundColor Yellow }
    $log = Join-Path $InstallDir 'logs\server.log'
    if (Test-Path $log) {
      Write-Host '  Last log lines:'
      Get-Content $log -Tail 8 | ForEach-Object { Write-Host "    $_" -ForegroundColor DarkGray }
    }
    Write-Host ''
  }
  'stop' { if ($task) { Request-Admin $PSCommandPath @('-Action', 'stop') }; Stop-App }
  'start' { if ($task) { Request-Admin $PSCommandPath @('-Action', 'start') }; Start-App }
  'restart' { if ($task) { Request-Admin $PSCommandPath @('-Action', 'restart') }; $Quiet = $true; Stop-App; Start-App }
}
