<#
  Enterprise Inventory - uninstall
  Removes the service, nightly backup task, firewall rule and shortcuts.
  The database, backups and settings are KEPT unless you add -RemoveData.
#>
param([switch]$RemoveData, [switch]$Yes)
. (Join-Path $PSScriptRoot 'common.ps1')
Request-Admin $PSCommandPath $(if ($RemoveData) { @('-RemoveData') } else { @() })

Write-Host ''
Write-Host 'Enterprise Inventory - uninstall' -ForegroundColor White
Write-Host "Folder: $InstallDir"
if (-not $Yes) {
  $a = Read-Host 'Remove Enterprise Inventory from this computer? (y/n)'
  if ($a -notmatch '^[yY]') { exit 0 }
  if (-not $RemoveData) {
    $d = Read-Host 'Also DELETE the database, backups and settings? This cannot be undone. Type DELETE to confirm, or press Enter to keep them'
    $RemoveData = ($d -ceq 'DELETE')
  }
}

# Final safety backup, even when keeping data.
try {
  $node = Get-NodeExe
  if (Test-Path (Join-Path $InstallDir 'data\inventory.db')) {
    $safe = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Enterprise Inventory backups'
    & $node (Join-Path $InstallDir 'scripts\backup.js') $safe
    Write-Host "A final backup was saved in $safe" -ForegroundColor Green
  }
} catch { Write-Host "Final backup skipped: $($_.Exception.Message)" -ForegroundColor Yellow }

& (Join-Path $PSScriptRoot 'service.ps1') -Action stop -Quiet
foreach ($t in @($TaskName, $BackupTaskName)) { Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue }
Get-NetFirewallRule -DisplayName 'Enterprise Inventory*' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
foreach ($p in @([Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('Desktop'))) {
  Remove-Item (Join-Path $p 'Enterprise Inventory.url') -Force -ErrorAction SilentlyContinue
}
foreach ($p in @([Environment]::GetFolderPath('CommonPrograms'), [Environment]::GetFolderPath('Programs'))) {
  Remove-Item (Join-Path $p 'Enterprise Inventory') -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host 'Service, scheduled backup, firewall rule and shortcuts removed.' -ForegroundColor Green

Set-Location $env:TEMP
$keep = @('data', 'backups', 'config.env', 'logs')
Get-ChildItem $InstallDir -Force | Where-Object { $RemoveData -or ($keep -notcontains $_.Name) } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
if ($RemoveData) {
  Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host 'Program, database, backups and settings deleted.' -ForegroundColor Yellow
} else {
  Write-Host "Program files removed. Your data and settings are still in $InstallDir (data, backups, config.env)." -ForegroundColor Green
  Write-Host 'Installing again into the same folder will use them.'
}
Pause-IfInteractive
