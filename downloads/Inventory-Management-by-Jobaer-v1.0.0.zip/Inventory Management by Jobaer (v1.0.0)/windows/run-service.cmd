@echo off
rem Enterprise Inventory - service runner (started by the "Enterprise Inventory" scheduled task).
rem Usage: run-service.cmd "C:\Program Files\nodejs\node.exe"
setlocal
cd /d "%~dp0.."
if not exist logs mkdir logs
rem Keep the log below about 10 MB: the previous log is kept as server.old.log
for %%A in ("logs\server.log") do if %%~zA GTR 10485760 move /y "logs\server.log" "logs\server.old.log" >nul
echo [%date% %time%] Starting Enterprise Inventory >> "logs\server.log"
"%~1" "%cd%\server.js" >> "logs\server.log" 2>&1
echo [%date% %time%] Stopped with exit code %errorlevel% >> "logs\server.log"
exit /b %errorlevel%
