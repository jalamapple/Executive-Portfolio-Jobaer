@echo off
rem Restore a backup: Restore.bat backups\inventory-YYYYMMDD-HHMMSS.db
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: Restore.bat backups\inventory-YYYYMMDD-HHMMSS.db
  echo.
  dir /b /o-n backups\inventory-*.db 2^>nul
  if not "%EI_NO_PAUSE%"=="1" pause
  exit /b 1
)
set EI_NO_PAUSE=1
call "%~dp0Stop.bat"
node "%~dp0scripts\restore.js" "%~1"
call "%~dp0Start.bat"
pause
