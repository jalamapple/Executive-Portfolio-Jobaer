@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\service.ps1" -Action stop
if not "%EI_NO_PAUSE%"=="1" pause
