@echo off
rem Regain administrator access. Usage: Reset-Admin.bat [email] [--password NewPassw0rd]
cd /d "%~dp0"
node "%~dp0scripts\reset-admin.js" %*
if not "%EI_NO_PAUSE%"=="1" pause
