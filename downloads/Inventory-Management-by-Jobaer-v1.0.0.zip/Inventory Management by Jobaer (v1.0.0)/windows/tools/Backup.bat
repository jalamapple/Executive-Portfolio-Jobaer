@echo off
rem Back up the database now (safe while running). Optional: Backup.bat D:\MyBackups
cd /d "%~dp0"
node "%~dp0scripts\backup.js" %*
if not "%EI_NO_PAUSE%"=="1" pause
