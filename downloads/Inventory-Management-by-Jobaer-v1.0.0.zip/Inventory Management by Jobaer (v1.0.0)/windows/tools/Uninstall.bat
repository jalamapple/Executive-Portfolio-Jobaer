@echo off
rem Removes Enterprise Inventory. Your data is kept unless you choose to delete it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\uninstall.ps1" %* & exit /b
