@echo off
title Enterprise Inventory
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\service.ps1" -Action start
if not "%EI_NO_PAUSE%"=="1" pause
