@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\service.ps1" -Action status
if not "%EI_NO_PAUSE%"=="1" pause
