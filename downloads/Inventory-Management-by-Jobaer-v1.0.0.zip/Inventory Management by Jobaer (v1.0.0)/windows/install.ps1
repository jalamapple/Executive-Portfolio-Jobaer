<#
  Enterprise Inventory - Windows installer / upgrader
  Created by Jobaer Alam

  Run "Install.bat" from the package folder (it calls this script as administrator).

  Examples (PowerShell):
    .\install.ps1                                  # guided install
    .\install.ps1 -InstallDir D:\Apps\Inventory     # different folder
    .\install.ps1 -Unattended -CompanyName "Acme" -AdminEmail admin@acme.com -AdminPassword "S3cure-Passw0rd"
    .\install.ps1 -NoService                        # no background service (start manually with Start.bat)

  Running it again on an existing installation upgrades the program files and keeps
  config.env, the database, backups and logs (a backup is taken first).
#>
[CmdletBinding()]
param(
  [string]$InstallDir = 'C:\EnterpriseInventory',
  [int]$Port = 0,
  [string]$CompanyName = '',
  [string]$AdminEmail = '',
  [string]$AdminPassword = '',
  [string]$Currency = '',
  [switch]$Demo,
  [switch]$NoService,
  [switch]$NoFirewall,
  [switch]$NoShortcuts,
  [switch]$Unattended
)

$ErrorActionPreference = 'Stop'
$TaskName = 'Enterprise Inventory'
$BackupTaskName = 'Enterprise Inventory Backup'
$MinNode = [version]'22.13.0'
$PackageDir = Split-Path -Parent $PSScriptRoot

function Write-Step($text) { Write-Host ''; Write-Host "==> $text" -ForegroundColor Cyan }
function Write-Ok($text) { Write-Host "    $text" -ForegroundColor Green }
function Write-Note($text) { Write-Host "    $text" -ForegroundColor Yellow }
function Fail($text) { Write-Host ''; Write-Host "ERROR: $text" -ForegroundColor Red; if (-not $Unattended) { Read-Host 'Press Enter to close' | Out-Null }; exit 1 }
function Ask($prompt, $default) {
  if ($Unattended) { return $default }
  $v = Read-Host "$prompt [$default]"
  if ([string]::IsNullOrWhiteSpace($v)) { return $default } else { return $v.Trim() }
}
function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Write-Utf8($path, $text) { [IO.File]::WriteAllText($path, $text, (New-Object Text.UTF8Encoding $false)) }

Write-Host ''
Write-Host '  ==============================================' -ForegroundColor White
Write-Host '    Enterprise Inventory - Setup' -ForegroundColor White
Write-Host '    Created by Jobaer Alam' -ForegroundColor Gray
Write-Host '  ==============================================' -ForegroundColor White

if (-not (Test-Path (Join-Path $PackageDir 'server.js'))) { Fail "server.js not found next to the installer ($PackageDir). Extract the whole zip file first." }

# ---- Administrator rights (service, firewall, C:\ folder) -------------------
$needsAdmin = (-not $NoService) -or (-not $NoFirewall)
if ($needsAdmin -and -not (Test-Admin)) {
  Write-Note 'Administrator rights are needed to install the background service and firewall rule.'
  Write-Note 'Windows will ask for permission...'
  $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
  foreach ($k in $PSBoundParameters.Keys) {
    $v = $PSBoundParameters[$k]
    if ($v -is [switch]) { if ($v) { $argList += "-$k" } } else { $argList += "-$k"; $argList += "`"$v`"" }
  }
  try { Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs | Out-Null } catch { Fail 'Administrator permission was refused. Re-run Install.bat and choose Yes, or use -NoService -NoFirewall.' }
  exit 0
}

# ---- Node.js ---------------------------------------------------------------
Write-Step 'Checking Node.js'
function Get-NodeExe {
  $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  foreach ($p in @("$env:ProgramFiles\nodejs\node.exe", "${env:ProgramFiles(x86)}\nodejs\node.exe")) { if (Test-Path $p) { return $p } }
  return $null
}
$node = Get-NodeExe
if (-not $node) {
  Write-Note 'Node.js is not installed.'
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  $answer = 'n'
  if ($winget) { $answer = Ask 'Install Node.js LTS now with winget? (y/n)' 'y' }
  if ($winget -and $answer -match '^[yY]') {
    & winget install --id OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
    $node = Get-NodeExe
  }
  if (-not $node) { Start-Process 'https://nodejs.org/en/download'; Fail 'Install Node.js LTS (22.13 or newer) from https://nodejs.org, then run Install.bat again.' }
}
$nodeVersion = [version]((& $node -v).TrimStart('v'))
if ($nodeVersion -lt $MinNode) { Fail "Node.js $nodeVersion is too old. Install Node.js LTS ($MinNode or newer) from https://nodejs.org and run Install.bat again." }
Write-Ok "Node.js $nodeVersion ($node)"

# ---- Install or upgrade ----------------------------------------------------
$InstallDir = [IO.Path]::GetFullPath($InstallDir)
$configFile = Join-Path $InstallDir 'config.env'
$upgrade = Test-Path $configFile
$version = (Get-Content (Join-Path $PackageDir 'package.json') -Raw | ConvertFrom-Json).version

if ($upgrade) {
  Write-Step "Upgrading the existing installation in $InstallDir to version $version"
  if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  }
  & (Join-Path $PSScriptRoot 'service.ps1') -Action stop -Dir $InstallDir -Quiet
  Push-Location $InstallDir
  try { & $node (Join-Path $InstallDir 'scripts\backup.js'); if ($LASTEXITCODE -ne 0) { Fail 'Pre-upgrade backup failed; nothing was changed.' } } finally { Pop-Location }
  Write-Ok 'Database backed up before upgrading'
} else {
  Write-Step "New installation in $InstallDir"
  if ($Port -eq 0) { $Port = [int](Ask 'Web port' '3000') }
  $CompanyName = if ($CompanyName) { $CompanyName } else { Ask 'Company name' 'My Company' }
  $AdminEmail = if ($AdminEmail) { $AdminEmail } else { Ask 'Administrator email (used to sign in)' 'admin@company.local' }
  $Currency = if ($Currency) { $Currency.ToUpper() } else { (Ask 'Currency code (USD, EUR, BDT, GBP...)' 'USD').ToUpper() }
  if (-not $AdminPassword) {
    if ($Unattended) { Fail 'Unattended install needs -AdminPassword.' }
    while ($true) {
      $p1 = Read-Host 'Administrator password (10+ characters, letters and numbers)' -AsSecureString
      $p2 = Read-Host 'Repeat the password' -AsSecureString
      $plain1 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($p1))
      $plain2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($p2))
      if ($plain1 -ne $plain2) { Write-Note 'The passwords do not match. Try again.'; continue }
      if ($plain1.Length -lt 10 -or $plain1 -notmatch '[A-Za-z]' -or $plain1 -notmatch '\d') { Write-Note 'Use at least 10 characters with letters and numbers.'; continue }
      $AdminPassword = $plain1; break
    }
  }
  if ($AdminPassword.Length -lt 10 -or $AdminPassword -notmatch '[A-Za-z]' -or $AdminPassword -notmatch '\d') { Fail 'The administrator password needs at least 10 characters with letters and numbers.' }
  if ($AdminEmail -notmatch '^[^\s@]+@[^\s@]+\.[^\s@]+$') { Fail "'$AdminEmail' is not a valid email address." }
  if ($Currency -notmatch '^[A-Z]{3}$') { Fail "'$Currency' is not a 3-letter currency code." }
  if (-not $Demo -and -not $Unattended) { $Demo = ((Ask 'Load demo data for evaluation? (y/n)' 'n') -match '^[yY]') }
}

# ---- Copy program files ----------------------------------------------------
Write-Step 'Copying program files'
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$items = @('server.js', 'package.json', 'src', 'public', 'scripts', 'windows', 'docs', 'README.md', 'INSTALL.md', 'CHANGELOG.md', 'LICENSE.txt', 'config.env.example')
foreach ($item in $items) {
  $src = Join-Path $PackageDir $item
  if (-not (Test-Path $src)) { continue }
  $dst = Join-Path $InstallDir $item
  if (Test-Path $src -PathType Container) {
    if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
    Copy-Item $src $dst -Recurse -Force
  } else { Copy-Item $src $dst -Force }
}
foreach ($bat in Get-ChildItem (Join-Path $PackageDir 'windows\tools') -Filter *.bat) { Copy-Item $bat.FullName (Join-Path $InstallDir $bat.Name) -Force }
Get-ChildItem $InstallDir -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
foreach ($d in @('data', 'backups', 'logs')) { New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir $d) | Out-Null }
Write-Ok "Program files installed (version $version)"

# ---- Settings --------------------------------------------------------------
if (-not $upgrade) {
  Write-Step 'Writing settings (config.env)'
  $cfg = Get-Content (Join-Path $InstallDir 'config.env.example') -Raw
  $set = @{ PORT = "$Port"; COMPANY_NAME = $CompanyName; ADMIN_EMAIL = $AdminEmail; CURRENCY = $Currency; DEMO_DATA = $(if ($Demo) { 'true' } else { 'false' }) }
  foreach ($k in $set.Keys) { $cfg = [regex]::Replace($cfg, "(?m)^$k=.*$", ("$k=" + $set[$k]).Replace('$', '$$')) }
  # The password is never written to disk: it is handed to the first start through the environment only.
  $cfg = [regex]::Replace($cfg, '(?m)^ADMIN_PASSWORD=.*$', '# ADMIN_PASSWORD is not stored here. Use Reset-Admin.bat if the administrator password is lost.')
  Write-Utf8 $configFile $cfg

  Write-Step 'Creating the database'
  Push-Location $InstallDir
  $env:ADMIN_PASSWORD = $AdminPassword
  try {
    & $node -e "require('./src/app').createApp(require('./src/config')).close()"
    if ($LASTEXITCODE -ne 0) { Fail 'The database could not be created. See the messages above.' }
  } finally { Remove-Item Env:ADMIN_PASSWORD -ErrorAction SilentlyContinue; Pop-Location }
  Write-Ok "Database created: $InstallDir\data\inventory.db"
}
$cfgText = Get-Content $configFile -Raw
$Port = [int]([regex]::Match($cfgText, '(?m)^PORT=(\d+)').Groups[1].Value)
if (-not $Port) { $Port = 3000 }

# ---- Background service (scheduled task) -----------------------------------
$runner = Join-Path $InstallDir 'windows\run-service.cmd'
if (-not $NoService) {
  Write-Step 'Installing the background service'
  $action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/d /c `"`"$runner`" `"$node`"`"" -WorkingDirectory $InstallDir
  $trigger = New-ScheduledTaskTrigger -AtStartup
  $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
    -Description 'Enterprise Inventory web server (created by Jobaer Alam). Starts with Windows.' -Force | Out-Null

  $bAction = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/d /c `"`"$node`" `"$InstallDir\scripts\backup.js`" >> `"$InstallDir\logs\backup.log`" 2>&1`"" -WorkingDirectory $InstallDir
  $bTrigger = New-ScheduledTaskTrigger -Daily -At 1am
  Register-ScheduledTask -TaskName $BackupTaskName -Action $bAction -Trigger $bTrigger -Principal $principal `
    -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries) -Description 'Nightly Enterprise Inventory database backup.' -Force | Out-Null

  Start-ScheduledTask -TaskName $TaskName
  Write-Ok "Service '$TaskName' installed: starts with Windows and restarts automatically"
  Write-Ok "Nightly backup at 01:00 into $InstallDir\backups"
}

# ---- Firewall --------------------------------------------------------------
if (-not $NoFirewall -and (Test-Admin)) {
  Write-Step 'Allowing access from other computers (Windows Firewall)'
  Get-NetFirewallRule -DisplayName 'Enterprise Inventory*' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
  New-NetFirewallRule -DisplayName "Enterprise Inventory (TCP $Port)" -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Domain,Private | Out-Null
  Write-Ok "Inbound TCP port $Port allowed on private and domain networks"
}

# ---- Shortcuts -------------------------------------------------------------
if (-not $NoShortcuts) {
  $url = "[InternetShortcut]`r`nURL=http://localhost:$Port/`r`n"
  $targets = @()
  if (Test-Admin) {
    $targets += [Environment]::GetFolderPath('CommonDesktopDirectory')
    $targets += Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'Enterprise Inventory'
  } else {
    $targets += [Environment]::GetFolderPath('Desktop')
    $targets += Join-Path ([Environment]::GetFolderPath('Programs')) 'Enterprise Inventory'
  }
  foreach ($t in $targets) {
    New-Item -ItemType Directory -Force -Path $t | Out-Null
    Write-Utf8 (Join-Path $t 'Enterprise Inventory.url') $url
  }
  $menu = $targets[1]
  $shell = New-Object -ComObject WScript.Shell
  foreach ($tool in @(@('Backup now', 'Backup.bat'), @('Restart service', 'Restart.bat'), @('Service status', 'Status.bat'), @('Installation folder', ''))) {
    $lnk = $shell.CreateShortcut((Join-Path $menu "$($tool[0]).lnk"))
    $lnk.TargetPath = if ($tool[1]) { Join-Path $InstallDir $tool[1] } else { $InstallDir }
    $lnk.WorkingDirectory = $InstallDir
    $lnk.Save()
  }
  Write-Ok 'Desktop and Start menu shortcuts created'
}

# ---- Verify ----------------------------------------------------------------
$healthy = $false
if (-not $NoService) {
  Write-Step 'Starting'
  for ($i = 0; $i -lt 30 -and -not $healthy; $i++) {
    Start-Sleep -Seconds 1
    try { $h = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 2; $healthy = ($h.status -eq 'ok') } catch { }
  }
  if ($healthy) { Write-Ok "Running: version $($h.version)" } else { Write-Note "The service did not answer yet. Check $InstallDir\logs\server.log" }
}

Write-Host ''
Write-Host '  ==============================================' -ForegroundColor Green
Write-Host ("    Enterprise Inventory {0} is {1}" -f $version, $(if ($upgrade) { 'upgraded' } else { 'installed' })) -ForegroundColor Green
Write-Host '  ==============================================' -ForegroundColor Green
Write-Host "    Open:         http://localhost:$Port"
foreach ($ip in (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notmatch '^(127\.|169\.254\.)' } | Select-Object -ExpandProperty IPAddress)) {
  Write-Host "    Network:      http://${ip}:$Port"
}
if (-not $upgrade) { Write-Host "    Sign in as:   $AdminEmail (the password you chose)" }
Write-Host "    Folder:       $InstallDir"
Write-Host "    Settings:     $configFile"
Write-Host "    Tools:        Start.bat, Stop.bat, Restart.bat, Status.bat, Backup.bat, Restore.bat, Reset-Admin.bat, Uninstall.bat"
if ($NoService) { Write-Note 'No service installed: run Start.bat in the installation folder to start the application.' }
Write-Host ''
if (-not $Unattended) {
  if ($healthy) { Start-Process "http://localhost:$Port/" }
  Read-Host 'Press Enter to close' | Out-Null
}
