# Shared helpers for the Enterprise Inventory Windows tools (dot-sourced).
$ErrorActionPreference = 'Stop'
$TaskName = 'Enterprise Inventory'
$BackupTaskName = 'Enterprise Inventory Backup'
$InstallDir = Split-Path -Parent $PSScriptRoot

function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Re-launch the calling script as administrator (Windows shows a permission prompt).
function Request-Admin($scriptPath, $extraArgs) {
  if (Test-Admin) { return }
  $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$scriptPath`"") + $extraArgs
  try { Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs | Out-Null }
  catch { Write-Host 'Administrator permission was refused.' -ForegroundColor Red }
  exit 0
}

function Get-NodeExe {
  $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  foreach ($p in @("$env:ProgramFiles\nodejs\node.exe", "${env:ProgramFiles(x86)}\nodejs\node.exe")) { if (Test-Path $p) { return $p } }
  throw 'Node.js was not found. Install Node.js LTS from https://nodejs.org'
}

function Get-Port {
  $cfg = Join-Path $InstallDir 'config.env'
  if (Test-Path $cfg) {
    $m = [regex]::Match((Get-Content $cfg -Raw), '(?m)^PORT=(\d+)')
    if ($m.Success) { return [int]$m.Groups[1].Value }
  }
  return 3000
}

function Get-Health {
  try { return Invoke-RestMethod -Uri ("http://127.0.0.1:{0}/api/health" -f (Get-Port)) -TimeoutSec 3 } catch { return $null }
}

# The application's node.exe: matched by its full server.js path, or as the process listening on PORT.
function Get-ServerProcesses {
  $needle = (Join-Path $InstallDir 'server.js').ToLower()
  $listeners = @(Get-NetTCPConnection -LocalPort (Get-Port) -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess)
  Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" -ErrorAction SilentlyContinue |
    Where-Object { ($_.CommandLine -and $_.CommandLine.ToLower().Contains($needle)) -or ($listeners -contains $_.ProcessId) }
}

function Pause-IfInteractive { if (-not $env:EI_NO_PAUSE) { Read-Host 'Press Enter to close' | Out-Null } }
