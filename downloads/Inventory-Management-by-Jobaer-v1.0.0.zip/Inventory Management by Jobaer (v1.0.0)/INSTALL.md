# Enterprise Inventory: installation

*Version 1.0.0 · Created by Jobaer Alam*

The complete, illustrated guide is in **docs/Installation-Guide.pdf** (also `.html`). This page is the short version.

## Requirements
- **Operating system:** Windows 10/11 or Windows Server 2019 and later, Linux with systemd, or Docker.
- **Node.js:** 22.13 or newer (current LTS recommended). The Windows installer can install it for you.
- **Hardware:** 1 GB RAM and 500 MB of disk space.
- **Network:** one network port (default 3000).

## Windows (recommended)
1. Right-click the zip, choose **Properties**, tick **Unblock** and click OK. Then extract it.
2. Double-click **`Install.bat`** and choose **Yes** at the administrator prompt.
3. Answer the questions: port, company name, administrator email and password, and currency.
4. The browser opens `http://localhost:3000`. Sign in with the administrator account you just created.

The installer does the following:
- **Program:** installs to `C:\EnterpriseInventory`.
- **Service:** registers a background service that starts with Windows and restarts automatically.
- **Backups:** schedules a backup every night at 01:00.
- **Network:** opens the port in Windows Firewall for private and domain networks.
- **Shortcuts:** creates desktop and Start menu shortcuts.

Other computers can use `http://<server-ip>:3000`.

Tools in `C:\EnterpriseInventory`:

| Tool | Purpose |
|---|---|
| `Status.bat` | Shows whether it is running, the latest backup and recent log lines |
| `Start.bat` / `Stop.bat` / `Restart.bat` | Controls the service. Restart after editing `config.env`. |
| `Backup.bat [folder]` | Backs up now. This is safe while people are working. |
| `Restore.bat <backup file>` | Restores a backup. The current database is kept aside first. |
| `Reset-Admin.bat [email]` | Gives you access again if the administrator password is lost. It prints a new password. |
| `Uninstall.bat` | Removes the program. Your data is kept unless you type DELETE. |

**Upgrading:** run the new version's `Install.bat`. It backs up the database first and keeps your settings and data.

## Linux
```bash
unzip EnterpriseInventory-1.0.0.zip && cd EnterpriseInventory-1.0.0
sudo bash linux/install.sh
```
- **Install location:** `/opt/enterprise-inventory`.
- **Service:** a systemd service called `enterprise-inventory`, plus a nightly backup timer.
- **Logs:** `journalctl -u enterprise-inventory -f`

## Docker
```bash
# edit ADMIN_EMAIL / ADMIN_PASSWORD in docker-compose.yml first
docker compose up -d --build
```

## After installing
1. **Branding:** go to **Administration → Company branding** and set the logo, colours, address, currency and time zone.
2. **Locations:** go to **Master data → Warehouses & sales centers** and create your locations.
3. **Users:** go to **Administration → Users & roles** and create accounts. Set **Reports to** for each sales agent; that manager approves their changes.
4. **Data:** go to **Administration → Import data** and import, in order: suppliers, customers, products, then stock balances.
5. **Backups:** copy the `backups` folder to another disk or to cloud storage regularly.

## Settings
All settings are in `config.env`, and each one is explained in `config.env.example`. Restart after changing anything.

| Setting | Notes |
|---|---|
| `PORT` | The web port. |
| `HOST` | `0.0.0.0` lets the whole network connect. Use `127.0.0.1` when the app is behind a reverse proxy. |
| `SECURE_COOKIES` | Set to `true` **only** with HTTPS. With plain `http://`, sign-in will fail. |
| `TRUST_PROXY` | Set to `true` behind a reverse proxy. |
| `DB_PATH`, `BACKUP_DIR`, `BACKUP_KEEP` | Database file, backup folder, and number of backups to keep (default 30). |

For internet access, put the app behind an HTTPS reverse proxy such as Caddy, nginx or IIS. The guide has ready-made configurations.
