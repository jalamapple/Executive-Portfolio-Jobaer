# Changelog: Enterprise Inventory

## 1.0.0 (2026-11-20)
First release. Created by Jobaer Alam.

### Inventory
- **Stock:** multi-location stock across warehouses and sales centers, with on-hand, reserved and available quantities.
- **Stock movements:** receipts, issues, adjustments, cycle counts and transfers.
- **Ledger:** an immutable record of every stock movement, with moving weighted-average costing.

### Orders and returns
- **Purchasing:** purchase orders go through approval, and goods can be received in several partial deliveries.
- **Sales orders:** confirming an order reserves its stock. Orders are then shipped and invoiced.
- **Customer returns:** returned items are credited on the invoice.
- **Returns to warehouse:** sales centers can send stock back to a warehouse. Each return goes through dispatch, transit and receipt, where the goods are inspected.
- **Replenishment:** reorder suggestions, with one-click draft purchase orders.

### Approvals and security
- **Manager approval:** sales agents need their assigned manager's approval to change an invoice, record a return, or cancel an order.
- **Roles:** four roles: admin, manager, clerk / sales agent, and viewer.
- **Audit log:** a full record of who did what.
- **Account protection:** a sign-in lockout after repeated failed attempts, secure sessions, and a CSRF check.

### Reports and documents
- **Exports:** branded PDF and CSV exports of every list and report.
- **PDF documents:** purchase orders, order confirmations, packing slips, invoices and return notes.
- **Company branding:** logo, colours, contact details, sign-in page text, currency and time zone.

### Data import
- **CSV import:** products, suppliers, customers and stock balances, up to 100,000 rows per file.
- **Safe imports:** each file is checked first, and the import is all-or-nothing.

### Installation and administration
- **Windows installer:** a background service with automatic restart, nightly backups, a firewall rule and shortcuts.
- **Admin tools:** backup, restore and administrator-reset tools.
- **Other platforms:** a Linux systemd installer, Docker files, and Azure App Service support.
