@echo off
rem Enterprise Inventory - Windows setup. Double-click to install or upgrade.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\install.ps1" %*
if errorlevel 1 pause
