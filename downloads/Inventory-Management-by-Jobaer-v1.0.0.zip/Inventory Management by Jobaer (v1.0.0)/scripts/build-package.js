#!/usr/bin/env node
'use strict';
/**
 * Build the distributable package:  npm run package
 *   dist/EnterpriseInventory-<version>/        (ready-to-install folder)
 *   dist/EnterpriseInventory-<version>.zip     (what you hand out)
 *   dist/EnterpriseInventory-<version>.zip.sha256
 * The installation guide is printed to PDF with Microsoft Edge or Google Chrome when available.
 */
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

const ROOT = path.join(__dirname, '..');
const { version } = require('../package.json');
const NAME = `EnterpriseInventory-${version}`;
const DIST = path.join(ROOT, 'dist');
const OUT = path.join(DIST, NAME);

const INCLUDE = [
  'server.js', 'package.json', 'config.env.example', 'README.md', 'INSTALL.md', 'CHANGELOG.md', 'LICENSE.txt',
  'Install.bat', 'Dockerfile', 'docker-compose.yml', '.dockerignore', 'src', 'public', 'scripts', 'windows', 'linux', 'docs',
];
const EXCLUDE = new Set(['scripts/build-package.js']);

const rel = (p) => path.relative(OUT, p).split(path.sep).join('/');

function copy(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const f of fs.readdirSync(src)) copy(path.join(src, f), path.join(dst, f));
    return;
  }
  const r = path.relative(ROOT, src).split(path.sep).join('/');
  if (EXCLUDE.has(r)) return;
  let data = fs.readFileSync(src);
  // Normalise line endings: CRLF for Windows batch files, LF for Linux files.
  if (/\.(bat|cmd)$/i.test(src)) data = Buffer.from(data.toString('utf8').replace(/\r?\n/g, '\r\n'));
  else if (r.startsWith('linux/') || /\.(sh|js|json|md|yml|env\.example|service|timer)$/i.test(src) || r === 'Dockerfile') data = Buffer.from(data.toString('utf8').replace(/\r\n/g, '\n'));
  fs.writeFileSync(dst, data);
}

function findBrowser() {
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  ];
  return candidates.find((c) => fs.existsSync(c));
}

function printPdf(html, pdf) {
  const browser = findBrowser();
  if (!browser) { console.warn('  ! No Edge/Chrome found: skipping PDF (the HTML guide is included).'); return false; }
  const profile = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'ei-pdf-'));
  try {
    execFileSync(browser, ['--headless=new', '--disable-gpu', '--no-first-run', `--user-data-dir=${profile}`,
      '--no-pdf-header-footer', `--print-to-pdf=${pdf}`, `file:///${html.replace(/\\/g, '/')}`], { stdio: 'ignore', timeout: 120000 });
  } finally { fs.rmSync(profile, { recursive: true, force: true }); }
  return fs.existsSync(pdf) && fs.statSync(pdf).size > 1000;
}

// Minimal ZIP writer (deflate), storing Unix permissions so linux/install.sh stays executable.
function writeZip(dir, zipPath, prefix) {
  const files = [];
  (function walk(d) {
    for (const f of fs.readdirSync(d).sort()) {
      const p = path.join(d, f);
      if (fs.statSync(p).isDirectory()) walk(p); else files.push(p);
    }
  })(dir);
  const chunks = [];
  const central = [];
  let offset = 0;
  const now = new Date();
  const dosTime = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
  const dosDate = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
  for (const file of files) {
    const name = Buffer.from(`${prefix}/${path.relative(dir, file).split(path.sep).join('/')}`, 'utf8');
    const data = fs.readFileSync(file);
    const crc = zlib.crc32(data);
    const comp = zlib.deflateRawSync(data, { level: 9 });
    const exec = /\.sh$/.test(file);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x0800, 6); local.writeUInt16LE(8, 8);
    local.writeUInt16LE(dosTime, 10); local.writeUInt16LE(dosDate, 12); local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(comp.length, 18); local.writeUInt32LE(data.length, 22); local.writeUInt16LE(name.length, 26);
    chunks.push(local, name, comp);
    const cen = Buffer.alloc(46);
    cen.writeUInt32LE(0x02014b50, 0); cen.writeUInt16LE((3 << 8) | 20, 4); cen.writeUInt16LE(20, 6); cen.writeUInt16LE(0x0800, 8);
    cen.writeUInt16LE(8, 10); cen.writeUInt16LE(dosTime, 12); cen.writeUInt16LE(dosDate, 14); cen.writeUInt32LE(crc, 16);
    cen.writeUInt32LE(comp.length, 20); cen.writeUInt32LE(data.length, 24); cen.writeUInt16LE(name.length, 28);
    cen.writeUInt32LE((((exec ? 0o100755 : 0o100644) << 16) >>> 0), 38); cen.writeUInt32LE(offset, 42);
    central.push(cen, name);
    offset += local.length + name.length + comp.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  fs.writeFileSync(zipPath, Buffer.concat([...chunks, cd, end]));
  return files.length;
}

console.log(`Building ${NAME}`);
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
for (const item of INCLUDE) {
  const src = path.join(ROOT, item);
  if (!fs.existsSync(src)) { console.warn(`  ! missing ${item}`); continue; }
  copy(src, path.join(OUT, item));
}
// Stamp the version into the guide.
const guide = path.join(OUT, 'docs', 'Installation-Guide.html');
fs.writeFileSync(guide, fs.readFileSync(guide, 'utf8').replace(/Version \d+\.\d+\.\d+/g, `Version ${version}`).replace(/EnterpriseInventory-\d+\.\d+\.\d+/g, NAME));
const md = path.join(OUT, 'INSTALL.md');
fs.writeFileSync(md, fs.readFileSync(md, 'utf8').replace(/EnterpriseInventory-\d+\.\d+\.\d+/g, NAME));
console.log(`  ${printPdf(guide, path.join(OUT, 'docs', 'Installation-Guide.pdf')) ? 'PDF guide printed' : 'PDF guide skipped'}`);

const zip = path.join(DIST, `${NAME}.zip`);
const count = writeZip(OUT, zip, NAME);
const hash = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
fs.writeFileSync(`${zip}.sha256`, `${hash}  ${NAME}.zip\n`);
console.log(`  ${count} files -> ${rel(zip).replace(/^(\.\.\/)+/, 'dist/')} (${(fs.statSync(zip).size / 1024).toFixed(0)} KB)`);
console.log(`  SHA-256 ${hash}`);
