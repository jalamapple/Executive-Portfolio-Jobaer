#!/usr/bin/env node
'use strict';
/**
 * Regain access when the administrator password is lost or the account is locked/deactivated.
 *   node scripts/reset-admin.js                         -> resets ADMIN_EMAIL with a new random password
 *   node scripts/reset-admin.js boss@company.com        -> resets (or creates) that administrator
 *   node scripts/reset-admin.js boss@company.com --password "NewPassw0rd!"
 * The account is re-activated, given the admin role, and all its sessions are signed out.
 * Works while the server is running.
 */
const crypto = require('node:crypto');
const config = require('../src/config');
const { openDatabase } = require('../src/db');
const { hashPassword, checkPasswordPolicy } = require('../src/auth');

const args = process.argv.slice(2);
const pi = args.indexOf('--password');
let password = pi >= 0 ? args[pi + 1] : null;
const email = (args.find((a, i) => !a.startsWith('--') && i !== pi + 1) || config.adminEmail).toLowerCase();

if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { console.error(`"${email}" is not a valid email address`); process.exit(1); }
if (!password) {
  // Readable but strong: 4 groups of letters/digits, guaranteed to include both.
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  const bytes = crypto.randomBytes(16);
  password = [...bytes].map((b) => alphabet[b % alphabet.length]).join('').replace(/(.{4})(?!$)/g, '$1-') + '7a';
}
try { checkPasswordPolicy(password); } catch (err) { console.error(`Password rejected: ${Object.values(err.details || {})[0] || err.message}`); process.exit(1); }

const db = openDatabase(config.dbPath);
const user = db.get('SELECT id, role, active FROM users WHERE email = ?', email);
let id;
if (user) {
  db.run(`UPDATE users SET password_hash = ?, role = 'admin', active = 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`, hashPassword(password), user.id);
  db.run('DELETE FROM sessions WHERE user_id = ?', user.id);
  id = user.id;
} else {
  id = db.run(`INSERT INTO users (email, name, role, password_hash) VALUES (?, 'Administrator', 'admin', ?)`, email, hashPassword(password)).id;
}
db.run('INSERT INTO audit_log (user_id, user_email, action, entity, entity_id, details) VALUES (?,?,?,?,?,?)',
  null, 'console', user ? 'user.admin_reset' : 'user.admin_created', 'user', String(id), JSON.stringify({ email, via: 'reset-admin script' }));
db.close();

console.log(`${user ? 'Reset' : 'Created'} administrator account`);
console.log(`  Email:    ${email}`);
console.log(`  Password: ${password}`);
console.log('Sign in and change this password from the user menu (top right).');
console.log('Note: if sign-in is still blocked after 5 wrong attempts, wait 15 minutes or restart the application.');
