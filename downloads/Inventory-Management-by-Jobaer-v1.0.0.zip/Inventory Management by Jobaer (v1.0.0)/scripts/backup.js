#!/usr/bin/env node
'use strict';
/**
 * Online backup of the database. Safe while the server is running (SQLite VACUUM INTO).
 *   node scripts/backup.js            -> backups/inventory-YYYYMMDD-HHMMSS.db
 *   node scripts/backup.js D:\Backups -> writes there instead
 * Keeps the newest BACKUP_KEEP files (default 30) in the backup folder.
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('../src/config');

const dir = path.resolve(process.argv[2] || config.backupDir);
const keep = Math.max(1, Number(process.env.BACKUP_KEEP) || 30);

if (!fs.existsSync(config.dbPath)) {
  console.error(`No database found at ${config.dbPath}. Start the application once to create it.`);
  process.exit(1);
}
fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
const target = path.join(dir, `inventory-${stamp}.db`);

const db = new DatabaseSync(config.dbPath);
db.exec('PRAGMA busy_timeout = 10000');
db.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
db.close();

const check = new DatabaseSync(target, { readOnly: true });
const ok = check.prepare('PRAGMA integrity_check').get();
const counts = check.prepare(`SELECT (SELECT COUNT(*) FROM products) AS products, (SELECT COUNT(*) FROM movements) AS movements`).get();
check.close();
const status = Object.values(ok)[0];
if (status !== 'ok') {
  console.error(`Backup written but failed its integrity check: ${status}`);
  process.exit(1);
}

const old = fs.readdirSync(dir).filter((f) => /^inventory-\d{8}-\d{6}\.db$/.test(f)).sort().reverse().slice(keep);
for (const f of old) fs.rmSync(path.join(dir, f), { force: true });

const size = fs.statSync(target).size;
console.log(`Backup OK: ${target}`);
console.log(`  ${(size / 1024 / 1024).toFixed(2)} MB · ${counts.products} products · ${counts.movements} stock movements`);
if (old.length) console.log(`  Removed ${old.length} old backup(s); keeping the newest ${keep}.`);
