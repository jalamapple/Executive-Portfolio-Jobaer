#!/usr/bin/env node
'use strict';
/**
 * Restore the database from a backup file. STOP THE APPLICATION FIRST.
 *   node scripts/restore.js backups/inventory-20261120-101500.db
 * The current database is kept as data/pre-restore-<timestamp>.db so nothing is lost.
 */
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('../src/config');

(async () => {
  const src = process.argv[2] && path.resolve(process.argv[2]);
  if (!src || !fs.existsSync(src)) {
    console.error('Usage: node scripts/restore.js <backup file>');
    if (fs.existsSync(config.backupDir)) {
      const list = fs.readdirSync(config.backupDir).filter((f) => f.endsWith('.db')).sort().reverse().slice(0, 10);
      if (list.length) console.error(`Recent backups in ${config.backupDir}:\n  ${list.join('\n  ')}`);
    }
    process.exit(1);
  }

  // Refuse while the server is answering on its port.
  try {
    const res = await fetch(`http://127.0.0.1:${config.port}/api/health`, { signal: AbortSignal.timeout(1500) });
    if (res.ok) {
      console.error(`The application is running on port ${config.port}. Stop it first (Windows: Stop.bat, Linux: sudo systemctl stop enterprise-inventory).`);
      process.exit(1);
    }
  } catch { /* not running: good */ }

  const check = new DatabaseSync(src, { readOnly: true });
  const status = Object.values(check.prepare('PRAGMA integrity_check').get())[0];
  const hasTables = check.prepare(`SELECT COUNT(*) AS n FROM sqlite_master WHERE name IN ('products','movements','users')`).get().n === 3;
  check.close();
  if (status !== 'ok' || !hasTables) {
    console.error(`${src} is not a valid Enterprise Inventory backup (${status !== 'ok' ? status : 'tables missing'}).`);
    process.exit(1);
  }

  fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
  if (fs.existsSync(config.dbPath)) {
    const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
    const keepAs = path.join(path.dirname(config.dbPath), `pre-restore-${stamp}.db`);
    // Fold any WAL content into the main file before moving it aside.
    const cur = new DatabaseSync(config.dbPath);
    cur.exec('PRAGMA wal_checkpoint(TRUNCATE)');
    cur.close();
    fs.renameSync(config.dbPath, keepAs);
    for (const ext of ['-wal', '-shm']) fs.rmSync(config.dbPath + ext, { force: true });
    console.log(`Current database kept as ${keepAs}`);
  }
  fs.copyFileSync(src, config.dbPath);
  console.log(`Restored ${src}\n     to ${config.dbPath}\nStart the application again.`);
})();
