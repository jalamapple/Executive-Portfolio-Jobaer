#!/usr/bin/env bash
# Enterprise Inventory - Linux installer / upgrader (systemd). Created by Jobaer Alam.
#
#   sudo ./linux/install.sh                 # guided install into /opt/enterprise-inventory
#   sudo PORT=8080 ./linux/install.sh       # different port
#
# Re-running upgrades the program files and keeps config.env, data, backups and logs.
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/enterprise-inventory}"
SERVICE=enterprise-inventory
APP_USER=inventory
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say()  { printf '\n\033[36m==> %s\033[0m\n' "$*"; }
ok()   { printf '    \033[32m%s\033[0m\n' "$*"; }
fail() { printf '\n\033[31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Run as root: sudo $0"
[ -f "$PKG_DIR/server.js" ] || fail "server.js not found in $PKG_DIR. Extract the whole package first."
command -v systemctl >/dev/null || fail "systemd is required (or use the Docker files instead)."

say "Checking Node.js"
NODE="$(command -v node || true)"
[ -n "$NODE" ] || fail "Node.js is not installed. Install Node.js 22 LTS or newer: https://nodejs.org/en/download (e.g. via NodeSource or your package manager), then re-run."
"$NODE" -e 'const [a,b]=process.versions.node.split(".").map(Number); process.exit(a>22||(a===22&&b>=13)?0:1)' \
  || fail "Node.js $("$NODE" -v) is too old; version 22.13 or newer is required."
ok "Node.js $("$NODE" -v) ($NODE)"

UPGRADE=0
[ -f "$APP_DIR/config.env" ] && UPGRADE=1

if [ "$UPGRADE" -eq 1 ]; then
  say "Upgrading $APP_DIR"
  systemctl stop "$SERVICE" 2>/dev/null || true
  (cd "$APP_DIR" && sudo -u "$APP_USER" "$NODE" scripts/backup.js) || fail "Pre-upgrade backup failed; nothing was changed."
else
  say "New installation in $APP_DIR"
  ask() { local v; read -r -p "$1 [$2]: " v; echo "${v:-$2}"; }
  PORT="${PORT:-$(ask 'Web port' 3000)}"
  COMPANY="${COMPANY_NAME:-$(ask 'Company name' 'My Company')}"
  EMAIL="${ADMIN_EMAIL:-$(ask 'Administrator email' 'admin@company.local')}"
  CURRENCY="${CURRENCY:-$(ask 'Currency code' USD)}"
  if [ -z "${ADMIN_PASSWORD:-}" ]; then
    while true; do
      read -r -s -p "Administrator password (10+ chars, letters and numbers): " P1; echo
      read -r -s -p "Repeat the password: " P2; echo
      [ "$P1" = "$P2" ] || { echo "Passwords do not match."; continue; }
      [[ ${#P1} -ge 10 && "$P1" =~ [A-Za-z] && "$P1" =~ [0-9] ]] || { echo "Use 10+ characters with letters and numbers."; continue; }
      ADMIN_PASSWORD="$P1"; break
    done
  fi
fi

say "Installing program files"
id "$APP_USER" >/dev/null 2>&1 || useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin "$APP_USER"
mkdir -p "$APP_DIR"
for item in server.js package.json src public scripts linux docs README.md INSTALL.md CHANGELOG.md LICENSE.txt config.env.example; do
  [ -e "$PKG_DIR/$item" ] || continue
  rm -rf "${APP_DIR:?}/$item"
  cp -R "$PKG_DIR/$item" "$APP_DIR/$item"
done
mkdir -p "$APP_DIR/data" "$APP_DIR/backups" "$APP_DIR/logs"

if [ "$UPGRADE" -eq 0 ]; then
  say "Writing settings"
  sed -e "s|^PORT=.*|PORT=$PORT|" -e "s|^COMPANY_NAME=.*|COMPANY_NAME=$COMPANY|" -e "s|^ADMIN_EMAIL=.*|ADMIN_EMAIL=$EMAIL|" \
      -e "s|^CURRENCY=.*|CURRENCY=${CURRENCY^^}|" "$APP_DIR/config.env.example" > "$APP_DIR/config.env"
  chown root:"$APP_USER" "$APP_DIR/config.env"; chmod 640 "$APP_DIR/config.env"
  chown -R "$APP_USER":"$APP_USER" "$APP_DIR/data" "$APP_DIR/backups" "$APP_DIR/logs"
  say "Creating the database"
  (cd "$APP_DIR" && sudo -u "$APP_USER" env ADMIN_PASSWORD="$ADMIN_PASSWORD" "$NODE" -e "require('./src/app').createApp(require('./src/config')).close()")
  sed -i 's|^ADMIN_PASSWORD=.*|# ADMIN_PASSWORD was used to create the first administrator and has been removed.|' "$APP_DIR/config.env"
  ok "Database created in $APP_DIR/data"
fi
chown -R root:root "$APP_DIR"/{server.js,package.json,src,public,scripts}
chown -R "$APP_USER":"$APP_USER" "$APP_DIR/data" "$APP_DIR/backups" "$APP_DIR/logs"

say "Installing the systemd service"
sed -e "s|@APP_DIR@|$APP_DIR|g" -e "s|@NODE@|$NODE|g" -e "s|@USER@|$APP_USER|g" "$PKG_DIR/linux/enterprise-inventory.service" > /etc/systemd/system/$SERVICE.service
sed -e "s|@APP_DIR@|$APP_DIR|g" -e "s|@NODE@|$NODE|g" -e "s|@USER@|$APP_USER|g" "$PKG_DIR/linux/enterprise-inventory-backup.service" > /etc/systemd/system/$SERVICE-backup.service
cp "$PKG_DIR/linux/enterprise-inventory-backup.timer" /etc/systemd/system/$SERVICE-backup.timer
systemctl daemon-reload
systemctl enable --now "$SERVICE" "$SERVICE-backup.timer"

PORT_NOW="$(grep -E '^PORT=' "$APP_DIR/config.env" | cut -d= -f2)"
for _ in $(seq 1 20); do
  if curl -fs "http://127.0.0.1:${PORT_NOW:-3000}/api/health" >/dev/null 2>&1; then break; fi
  sleep 1
done
say "Done"
ok "Open:      http://$(hostname -I 2>/dev/null | awk '{print $1}'):${PORT_NOW:-3000}"
ok "Status:    systemctl status $SERVICE     Logs: journalctl -u $SERVICE -f"
ok "Backup:    sudo -u $APP_USER node $APP_DIR/scripts/backup.js   (automatic every night)"
ok "Settings:  $APP_DIR/config.env  (then: sudo systemctl restart $SERVICE)"
command -v ufw >/dev/null && ok "Firewall:  sudo ufw allow ${PORT_NOW:-3000}/tcp"
