'use strict';
/**
 * RFC 4180 CSV parser: quoted fields, escaped quotes, embedded newlines, CRLF/LF, UTF-8 BOM.
 * The delimiter (comma, semicolon or tab) is detected from the header line, so files saved by
 * Excel in regions that use a semicolon also import.
 */
function detectDelimiter(text) {
  const first = text.slice(0, text.search(/\r?\n|$/));
  const counts = [',', ';', '\t'].map((d) => [d, first.split(d).length - 1]);
  counts.sort((a, b) => b[1] - a[1]);
  return counts[0][1] > 0 ? counts[0][0] : ',';
}

function parseCsv(input, { maxRows = Infinity } = {}) {
  const text = String(input).replace(/^﻿/, '');
  const delim = detectDelimiter(text);
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  let i = 0;
  const n = text.length;
  const endField = () => { row.push(field); field = ''; };
  const endRow = () => {
    endField();
    if (row.length > 1 || row[0] !== '') rows.push(row); // skip blank lines
    row = [];
    if (rows.length > maxRows) throw new Error(`The file has more than ${maxRows - 1} data rows`);
  };
  while (i < n) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
        quoted = false; i++; continue;
      }
      field += ch; i++; continue;
    }
    if (ch === '"' && field === '') { quoted = true; i++; continue; }
    if (ch === delim) { endField(); i++; continue; }
    if (ch === '\r') { i++; if (text[i] === '\n') i++; endRow(); continue; }
    if (ch === '\n') { i++; endRow(); continue; }
    field += ch; i++;
  }
  if (quoted) throw new Error('The file ends inside a quoted field (check for an unmatched ")');
  if (field !== '' || row.length) endRow();
  return { rows, delimiter: delim };
}

/** Normalise a header: "Unit Cost ($)" -> "unit_cost". */
const normaliseHeader = (h) => String(h).trim().toLowerCase().replace(/\(.*?\)/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');

module.exports = { parseCsv, normaliseHeader };
