'use strict';
const fs = require('node:fs');
const path = require('node:path');

class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

/**
 * Tabular export, rendered as CSV or as a branded PDF depending on ?format=.
 * columns: [{ key, label, type?, w?, sum?, pdf? }]
 * meta: { title, filters: [[label, value]], summary: (fmt) => [{label, value}], landscape }
 */
class TableResult {
  constructor(filename, columns, rows, meta = {}) {
    this.filename = filename;
    this.columns = columns;
    this.rows = rows;
    this.title = meta.title || filename.replace(/\.\w+$/, '').replace(/[-_]/g, ' ').replace(/^./, (c) => c.toUpperCase());
    this.filters = meta.filters || [];
    this.summary = meta.summary || null;
    this.landscape = Boolean(meta.landscape);
  }
}
const CsvResult = TableResult;

/** A binary file (PDF, image) with explicit headers. */
class FileResult {
  constructor(filename, contentType, data, { inline = false, cache = 'no-store' } = {}) {
    this.filename = filename;
    this.contentType = contentType;
    this.data = data;
    this.inline = inline;
    this.cache = cache;
  }
}

/** True when the request asks for a downloadable export. */
const exportFormat = (query) => (query.format === 'csv' || query.format === 'pdf' ? query.format : null);

class Router {
  constructor() { this.routes = []; }

  // opts.raw: read the body as text (CSV uploads) instead of JSON; opts.limit: body size limit in bytes.
  add(method, pattern, perm, handler, opts = {}) {
    const keys = [];
    const source = pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; });
    this.routes.push({ method, re: new RegExp(`^${source}/?$`), keys, perm, handler, opts });
  }
  get(p, perm, h, o) { this.add('GET', p, perm, h, o); }
  post(p, perm, h, o) { this.add('POST', p, perm, h, o); }
  put(p, perm, h, o) { this.add('PUT', p, perm, h, o); }
  delete(p, perm, h, o) { this.add('DELETE', p, perm, h, o); }

  match(method, pathname) {
    let pathMatched = false;
    for (const r of this.routes) {
      const m = r.re.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method) continue;
      const params = {};
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      return { route: r, params };
    }
    return pathMatched ? { methodNotAllowed: true } : null;
  }
}

function readJson(req, limit = 1_000_000) {
  return new Promise((resolve, reject) => {
    if (req.method === 'GET' || req.method === 'HEAD') return resolve({});
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new HttpError(413, 'Request body too large'));
        req.destroy();
      } else chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      if (!/application\/json/i.test(req.headers['content-type'] || '')) {
        return reject(new HttpError(415, 'Content-Type must be application/json'));
      }
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(new HttpError(400, 'Malformed JSON body')); }
    });
    req.on('error', reject);
  });
}

/** Read a text body (CSV upload). */
function readText(req, limit) {
  return new Promise((resolve, reject) => {
    const type = String(req.headers['content-type'] || '');
    if (!/^(text\/csv|text\/plain|application\/vnd\.ms-excel|application\/octet-stream)/i.test(type)) {
      req.resume();
      return reject(new HttpError(415, 'Upload the file as text/csv'));
    }
    let size = 0;
    let failed = false;
    const chunks = [];
    req.on('data', (chunk) => {
      if (failed) return;
      size += chunk.length;
      if (size > limit) {
        failed = true;
        reject(new HttpError(413, `File is too large (limit ${Math.round(limit / 1048576)} MB)`));
      } else chunks.push(chunk);
    });
    req.on('end', () => { if (!failed) resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', reject);
  });
}

function sendJson(res, status, body, headers = {}) {
  const data = body === undefined ? '' : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(data);
}

// Quote every cell, and neutralise spreadsheet formula injection in text cells.
function csvCell(v) {
  if (v === null || v === undefined) return '';
  let s = String(v);
  if (typeof v === 'string' && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return `"${s.replace(/"/g, '""')}"`;
}

const safeFilename = (name) => String(name).replace(/[^\w.-]/g, '_');

function sendFile(res, file) {
  res.writeHead(200, {
    'Content-Type': file.contentType,
    'Content-Length': file.data.length,
    'Content-Disposition': `${file.inline ? 'inline' : 'attachment'}; filename="${safeFilename(file.filename)}"`,
    'Cache-Control': file.cache,
  });
  res.end(file.data);
}

function sendCsv(res, result) {
  const lines = [result.columns.map((c) => csvCell(c.label)).join(',')];
  for (const row of result.rows) lines.push(result.columns.map((c) => csvCell(row[c.key])).join(','));
  const safeName = result.filename.replace(/[^\w.-]/g, '_');
  res.writeHead(200, {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="${safeName}"`,
    'Cache-Control': 'no-store',
  });
  res.end('﻿' + lines.join('\r\n'));
}

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; " +
    "connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json',
  '.webmanifest': 'application/manifest+json',
};

function serveStatic(root, pathname, req, res) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { rel = '/'; }
  let file = path.resolve(root, '.' + (rel === '/' ? '/index.html' : rel));
  if (!file.startsWith(root + path.sep)) {
    res.writeHead(403); return res.end();
  }
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
    if (path.extname(file)) { res.writeHead(404); return res.end('Not found'); }
    file = path.join(root, 'index.html'); // SPA fallback
  }
  // Always revalidate so a deploy takes effect immediately; unchanged files cost only a 304.
  const ext = path.extname(file);
  const lastModified = fs.statSync(file).mtime.toUTCString();
  const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'Last-Modified': lastModified };
  if (req.headers['if-modified-since'] === lastModified) { res.writeHead(304, headers); return res.end(); }
  res.writeHead(200, headers);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

module.exports = { HttpError, CsvResult, TableResult, FileResult, exportFormat, Router, readJson, readText, sendJson, sendCsv, sendFile, serveStatic, parseCookies, SECURITY_HEADERS };
