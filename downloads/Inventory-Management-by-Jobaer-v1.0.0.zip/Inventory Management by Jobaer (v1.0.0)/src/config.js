'use strict';
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');

/**
 * Settings come from real environment variables first, then from config.env next to server.js
 * (or the file named by CONFIG_FILE). config.env uses simple KEY=value lines; # starts a comment.
 */
function loadConfigFile() {
  const file = process.env.CONFIG_FILE || path.join(ROOT, 'config.env');
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return null; }
  for (const raw of text.replace(/^﻿/, '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    const key = line.slice(0, i).trim();
    let value = line.slice(i + 1).trim();
    if (/^(['"]).*\1$/.test(value)) value = value.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = value;
  }
  return file;
}
const configFile = loadConfigFile();

const env = process.env;
const isProd = env.NODE_ENV === 'production';
const bool = (v, d) => (v === undefined || v === '' ? d : /^(1|true|yes|on)$/i.test(v));

// On Azure App Service (Linux) only /home is persistent, so default the database there.
const defaultDb = env.WEBSITE_SITE_NAME ? '/home/data/inventory.db' : path.join(ROOT, 'data', 'inventory.db');
const resolve = (p) => (path.isAbsolute(p) ? p : path.join(ROOT, p));

module.exports = {
  root: ROOT,
  configFile,
  version: require('../package.json').version,
  host: env.HOST || '0.0.0.0',
  port: Number(env.PORT) || 3000,
  dbPath: env.DB_PATH ? resolve(env.DB_PATH) : defaultDb,
  backupDir: resolve(env.BACKUP_DIR || 'backups'),
  sessionTtlHours: Number(env.SESSION_TTL_HOURS) || 12,
  secureCookies: bool(env.SECURE_COOKIES, isProd),
  trustProxy: bool(env.TRUST_PROXY, Boolean(env.WEBSITE_SITE_NAME)),
  demoData: bool(env.DEMO_DATA, true),
  adminEmail: env.ADMIN_EMAIL || 'admin@inventory.local',
  adminPassword: env.ADMIN_PASSWORD || 'Admin@123456',
  companyName: env.COMPANY_NAME || 'Enterprise Inventory',
  currency: env.CURRENCY || 'USD',
  logRequests: bool(env.LOG_REQUESTS, true),
};
