'use strict';
const { decodeImage } = require('./pdf');

// Fixed product identity. Company branding is configurable; the product credit is not.
const PRODUCT = Object.freeze({ name: 'Enterprise Inventory', author: 'Jobaer Alam' });

const DEFAULT_WELCOME = {
  welcome_title: 'Inventory control for every warehouse, order and SKU.',
  welcome_text: 'Real-time stock across locations, purchasing and fulfilment workflows, and a complete audit trail.',
  welcome_points: [
    'Multi-warehouse stock with reservations and transfers',
    'Purchase approval and partial receiving',
    'Weighted-average costing and valuation reports',
    'Role-based access and immutable movement ledger',
  ].join('\n'),
};

// Editable fields with their validation rules.
const FIELDS = {
  company_name: { type: 'string', max: 120 },
  legal_name: { type: 'string', max: 200 },
  tagline: { type: 'string', max: 160 },
  address: { type: 'text', max: 500 },
  phone: { type: 'string', max: 60 },
  email: { type: 'email' },
  website: { type: 'string', max: 200 },
  tax_id: { type: 'string', max: 80 },
  brand_color: { type: 'string', max: 7 },
  currency: { type: 'string', max: 3 },
  timezone: { type: 'string', max: 64 },
  welcome_title: { type: 'string', max: 160 },
  welcome_text: { type: 'text', max: 500 },
  welcome_points: { type: 'text', max: 800 },
  report_footer: { type: 'string', max: 200 },
  document_terms: { type: 'text', max: 1500 },
};

const LOGO_MAX_BYTES = 512 * 1024;

// ---- Colour helpers (shared idea with the browser; kept tiny on purpose) ----
const clamp = (v) => Math.max(0, Math.min(255, Math.round(v)));
const parseHex = (hex) => {
  const v = parseInt(hex.slice(1), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
};
const toHex = (rgb) => '#' + rgb.map((v) => clamp(v).toString(16).padStart(2, '0')).join('');
const mix = (hex, other, amount) => {
  const a = parseHex(hex), b = parseHex(other);
  return toHex(a.map((v, i) => v + (b[i] - v) * amount));
};
const luminance = (hex) => {
  const [r, g, b] = parseHex(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
const contrast = (a, b) => {
  const [l1, l2] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
};
/** Darken a colour until white text on it is readable (WCAG AA, 4.5:1). */
const readableOnWhiteText = (hex) => {
  let c = hex;
  for (let i = 0; i < 20 && contrast(c, '#ffffff') < 4.5; i++) c = mix(c, '#000000', 0.08);
  return c;
};

function isValidTimezone(tz) {
  try { new Intl.DateTimeFormat('en-GB', { timeZone: tz }); return true; } catch { return false; }
}
const CURRENCIES = new Set(Intl.supportedValuesOf('currency'));
const isValidCurrency = (code) => CURRENCIES.has(code);

function createBranding(db, config) {
  let cache = null;

  const defaults = () => ({
    company_name: config.companyName,
    legal_name: '',
    tagline: '',
    address: '',
    phone: '',
    email: '',
    website: '',
    tax_id: '',
    brand_color: '#2f5bea',
    currency: config.currency,
    timezone: 'UTC',
    ...DEFAULT_WELCOME,
    report_footer: '',
    document_terms: '',
  });

  function get() {
    if (cache) return cache;
    const stored = Object.fromEntries(db.all('SELECT key, value FROM settings').map((r) => [r.key, r.value]));
    const logo = db.get(`SELECT mime, length(data) AS size, updated_at FROM assets WHERE name = 'logo'`);
    const s = defaults();
    for (const k of Object.keys(FIELDS)) if (stored[k] !== undefined && stored[k] !== null) s[k] = stored[k];
    s.logo = logo ? { mime: logo.mime, size: logo.size, updated_at: logo.updated_at, url: `/api/branding/logo?v=${encodeURIComponent(logo.updated_at)}` } : null;
    s.primary = readableOnWhiteText(s.brand_color);
    cache = s;
    return s;
  }

  /** Validate a partial update; returns the cleaned values. Throws { field: message } map on error. */
  function check(patch) {
    const errors = {};
    const out = {};
    for (const [k, v] of Object.entries(patch)) {
      if (!FIELDS[k]) continue;
      if (v === null || v === undefined) { out[k] = null; continue; }
      if (typeof v !== 'string') { errors[k] = 'must be text'; continue; }
      const val = FIELDS[k].type === 'text' ? v.replace(/\r\n/g, '\n').trim() : v.trim();
      if (FIELDS[k].max && val.length > FIELDS[k].max) { errors[k] = `must be at most ${FIELDS[k].max} characters`; continue; }
      out[k] = val;
    }
    if (out.company_name !== undefined && !out.company_name) errors.company_name = 'is required';
    if (out.brand_color && !/^#[0-9a-f]{6}$/i.test(out.brand_color)) errors.brand_color = 'must be a hex colour like #2f5bea';
    if (out.brand_color) out.brand_color = out.brand_color.toLowerCase();
    if (out.currency) {
      out.currency = out.currency.toUpperCase();
      if (!/^[A-Z]{3}$/.test(out.currency) || !isValidCurrency(out.currency)) errors.currency = 'must be an ISO 4217 code such as USD';
    }
    if (out.timezone && !isValidTimezone(out.timezone)) errors.timezone = 'is not a recognised time zone';
    if (out.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(out.email)) errors.email = 'must be a valid email address';
    if (out.website && !/^(https?:\/\/)?[\w.-]+\.[a-z]{2,}(\/\S*)?$/i.test(out.website)) errors.website = 'must be a valid web address';
    return { values: out, errors };
  }

  function update(values) {
    db.tx(() => {
      for (const [k, v] of Object.entries(values)) {
        if (v === null || (v === '' && ['company_name', 'brand_color', 'currency', 'timezone', 'welcome_title', 'welcome_text', 'welcome_points'].includes(k))) {
          db.run('DELETE FROM settings WHERE key = ?', k); // back to default
        } else {
          db.run(`INSERT INTO settings (key, value) VALUES (?, ?)
                  ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')`, k, v);
        }
      }
    });
    cache = null;
    return get();
  }

  /** Validate and store a logo. Returns an error message, or null on success. */
  function setLogo(buf) {
    if (buf.length > LOGO_MAX_BYTES) return `Logo must be ${LOGO_MAX_BYTES / 1024} KB or smaller`;
    let decoded;
    try { decoded = decodeImage(buf); } catch (err) { return err.message; }
    const mime = decoded.type === 'png' ? 'image/png' : 'image/jpeg';
    db.run(`INSERT INTO assets (name, mime, data) VALUES ('logo', ?, ?)
            ON CONFLICT(name) DO UPDATE SET mime = excluded.mime, data = excluded.data, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')`, mime, buf);
    cache = null;
    logoCache = null;
    return null;
  }

  function clearLogo() {
    db.run(`DELETE FROM assets WHERE name = 'logo'`);
    cache = null;
    logoCache = null;
  }

  let logoCache = null;
  /** Raw logo bytes plus a decoded copy for PDFs (decoded once, then cached). */
  function logo() {
    if (logoCache) return logoCache;
    const row = db.get(`SELECT mime, data, updated_at FROM assets WHERE name = 'logo'`);
    if (!row) return null;
    const data = Buffer.from(row.data);
    let decoded = null;
    try { decoded = decodeImage(data); } catch { /* stored before validation rules changed */ }
    logoCache = { mime: row.mime, data, updated_at: row.updated_at, decoded };
    return logoCache;
  }

  /** Subset that is safe to show before sign-in. */
  function publicView() {
    const s = get();
    return {
      companyName: s.company_name, tagline: s.tagline, brandColor: s.brand_color, primary: s.primary,
      logoUrl: s.logo ? s.logo.url : null, currency: s.currency,
      welcome: { title: s.welcome_title, text: s.welcome_text, points: s.welcome_points.split('\n').map((p) => p.trim()).filter(Boolean) },
      product: PRODUCT,
    };
  }

  return { get, check, update, setLogo, clearLogo, logo, publicView, FIELDS, LOGO_MAX_BYTES };
}

module.exports = { createBranding, PRODUCT, mix, readableOnWhiteText };
