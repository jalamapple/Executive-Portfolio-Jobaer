'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const NOW = "(strftime('%Y-%m-%dT%H:%M:%fZ','now'))";

// Each entry is one forward-only migration. PRAGMA user_version tracks what has run.
const MIGRATIONS = [
  `
  CREATE TABLE users (
    id            INTEGER PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name          TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('admin','manager','clerk','viewer')),
    active        INTEGER NOT NULL DEFAULT 1,
    last_login_at TEXT,
    created_at    TEXT NOT NULL DEFAULT ${NOW},
    updated_at    TEXT NOT NULL DEFAULT ${NOW}
  );

  CREATE TABLE sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL,
    ip         TEXT,
    user_agent TEXT,
    created_at TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE INDEX idx_sessions_user ON sessions(user_id);

  CREATE TABLE categories (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    description TEXT,
    created_at  TEXT NOT NULL DEFAULT ${NOW}
  );

  CREATE TABLE warehouses (
    id         INTEGER PRIMARY KEY,
    code       TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name       TEXT NOT NULL,
    address    TEXT,
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT ${NOW}
  );

  CREATE TABLE suppliers (
    id             INTEGER PRIMARY KEY,
    name           TEXT NOT NULL,
    contact_name   TEXT,
    email          TEXT,
    phone          TEXT,
    address        TEXT,
    lead_time_days INTEGER,
    active         INTEGER NOT NULL DEFAULT 1,
    created_at     TEXT NOT NULL DEFAULT ${NOW}
  );

  CREATE TABLE customers (
    id         INTEGER PRIMARY KEY,
    name       TEXT NOT NULL,
    email      TEXT,
    phone      TEXT,
    address    TEXT,
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT ${NOW}
  );

  CREATE TABLE products (
    id            INTEGER PRIMARY KEY,
    sku           TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name          TEXT NOT NULL,
    description   TEXT,
    category_id   INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    supplier_id   INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
    unit          TEXT NOT NULL DEFAULT 'ea',
    barcode       TEXT,
    cost          REAL NOT NULL DEFAULT 0,  -- standard / list cost
    avg_cost      REAL NOT NULL DEFAULT 0,  -- moving weighted-average cost
    price         REAL NOT NULL DEFAULT 0,
    reorder_point INTEGER NOT NULL DEFAULT 0,
    reorder_qty   INTEGER NOT NULL DEFAULT 0,
    active        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL DEFAULT ${NOW},
    updated_at    TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE INDEX idx_products_name ON products(name);
  CREATE INDEX idx_products_barcode ON products(barcode);
  CREATE INDEX idx_products_category ON products(category_id);

  CREATE TABLE stock (
    product_id   INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
    on_hand      INTEGER NOT NULL DEFAULT 0,
    reserved     INTEGER NOT NULL DEFAULT 0,
    bin          TEXT,
    PRIMARY KEY (product_id, warehouse_id),
    CHECK (on_hand >= 0 AND reserved >= 0 AND reserved <= on_hand)
  ) WITHOUT ROWID;
  CREATE INDEX idx_stock_warehouse ON stock(warehouse_id);

  CREATE TABLE movements (
    id            INTEGER PRIMARY KEY,
    product_id    INTEGER NOT NULL REFERENCES products(id),
    warehouse_id  INTEGER NOT NULL REFERENCES warehouses(id),
    type          TEXT NOT NULL CHECK (type IN
                    ('RECEIPT','ISSUE','ADJUSTMENT','COUNT','TRANSFER_IN','TRANSFER_OUT','PO_RECEIPT','SALE')),
    qty           INTEGER NOT NULL,
    balance_after INTEGER NOT NULL,
    unit_cost     REAL,
    ref_type      TEXT,
    ref_id        TEXT,
    note          TEXT,
    user_id       INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE INDEX idx_mov_product ON movements(product_id, created_at);
  CREATE INDEX idx_mov_warehouse ON movements(warehouse_id, created_at);
  CREATE INDEX idx_mov_created ON movements(created_at);
  CREATE INDEX idx_mov_ref ON movements(ref_type, ref_id);

  -- The movement ledger is append-only: corrections are made with new movements.
  CREATE TRIGGER movements_no_update BEFORE UPDATE ON movements
    BEGIN SELECT RAISE(ABORT, 'Stock movements are immutable'); END;
  CREATE TRIGGER movements_no_delete BEFORE DELETE ON movements
    BEGIN SELECT RAISE(ABORT, 'Stock movements are immutable'); END;

  CREATE TABLE purchase_orders (
    id            INTEGER PRIMARY KEY,
    number        TEXT UNIQUE,
    supplier_id   INTEGER NOT NULL REFERENCES suppliers(id),
    warehouse_id  INTEGER NOT NULL REFERENCES warehouses(id),
    status        TEXT NOT NULL DEFAULT 'DRAFT'
                    CHECK (status IN ('DRAFT','ORDERED','PARTIAL','RECEIVED','CANCELLED')),
    expected_date TEXT,
    notes         TEXT,
    created_by    INTEGER REFERENCES users(id),
    approved_by   INTEGER REFERENCES users(id),
    ordered_at    TEXT,
    created_at    TEXT NOT NULL DEFAULT ${NOW},
    updated_at    TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE INDEX idx_po_status ON purchase_orders(status);

  CREATE TABLE po_lines (
    id           INTEGER PRIMARY KEY,
    po_id        INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    product_id   INTEGER NOT NULL REFERENCES products(id),
    qty_ordered  INTEGER NOT NULL CHECK (qty_ordered > 0),
    qty_received INTEGER NOT NULL DEFAULT 0 CHECK (qty_received >= 0 AND qty_received <= qty_ordered),
    unit_cost    REAL NOT NULL DEFAULT 0
  );
  CREATE INDEX idx_po_lines_po ON po_lines(po_id);
  CREATE INDEX idx_po_lines_product ON po_lines(product_id);

  CREATE TABLE sales_orders (
    id           INTEGER PRIMARY KEY,
    number       TEXT UNIQUE,
    customer_id  INTEGER NOT NULL REFERENCES customers(id),
    warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
    status       TEXT NOT NULL DEFAULT 'DRAFT'
                   CHECK (status IN ('DRAFT','CONFIRMED','SHIPPED','CANCELLED')),
    notes        TEXT,
    created_by   INTEGER REFERENCES users(id),
    confirmed_at TEXT,
    shipped_at   TEXT,
    created_at   TEXT NOT NULL DEFAULT ${NOW},
    updated_at   TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE INDEX idx_so_status ON sales_orders(status);

  CREATE TABLE so_lines (
    id         INTEGER PRIMARY KEY,
    so_id      INTEGER NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    qty        INTEGER NOT NULL CHECK (qty > 0),
    unit_price REAL NOT NULL DEFAULT 0,
    unit_cost  REAL
  );
  CREATE INDEX idx_so_lines_so ON so_lines(so_id);

  CREATE TABLE audit_log (
    id         INTEGER PRIMARY KEY,
    user_id    INTEGER,
    user_email TEXT,
    action     TEXT NOT NULL,
    entity     TEXT,
    entity_id  TEXT,
    details    TEXT,
    ip         TEXT,
    created_at TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE INDEX idx_audit_created ON audit_log(created_at);
  CREATE INDEX idx_audit_entity ON audit_log(entity, entity_id);
  `,
  // v2: company branding
  `
  CREATE TABLE settings (
    key        TEXT PRIMARY KEY,
    value      TEXT,
    updated_at TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE TABLE assets (
    name       TEXT PRIMARY KEY,
    mime       TEXT NOT NULL,
    data       BLOB NOT NULL,
    updated_at TEXT NOT NULL DEFAULT ${NOW}
  );
  `,
  // v3: location types (warehouse / sales center) and stock returns from sales centers
  `
  ALTER TABLE warehouses ADD COLUMN kind TEXT NOT NULL DEFAULT 'WAREHOUSE' CHECK (kind IN ('WAREHOUSE','SALES_CENTER'));
  ALTER TABLE warehouses ADD COLUMN phone TEXT;
  ALTER TABLE warehouses ADD COLUMN manager_name TEXT;

  CREATE TABLE stock_returns (
    id               INTEGER PRIMARY KEY,
    number           TEXT UNIQUE,
    from_location_id INTEGER NOT NULL REFERENCES warehouses(id),
    to_location_id   INTEGER NOT NULL REFERENCES warehouses(id),
    status           TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','DISPATCHED','RECEIVED','CANCELLED')),
    reason           TEXT NOT NULL DEFAULT 'UNSOLD'
                       CHECK (reason IN ('UNSOLD','OVERSTOCK','DAMAGED','EXPIRED','RECALL','CUSTOMER_RETURN','OTHER')),
    notes            TEXT,
    created_by       INTEGER REFERENCES users(id),
    dispatched_by    INTEGER REFERENCES users(id),
    received_by      INTEGER REFERENCES users(id),
    dispatched_at    TEXT,
    received_at      TEXT,
    created_at       TEXT NOT NULL DEFAULT ${NOW},
    updated_at       TEXT NOT NULL DEFAULT ${NOW},
    CHECK (from_location_id <> to_location_id)
  );
  CREATE INDEX idx_returns_status ON stock_returns(status);

  CREATE TABLE stock_return_lines (
    id           INTEGER PRIMARY KEY,
    return_id    INTEGER NOT NULL REFERENCES stock_returns(id) ON DELETE CASCADE,
    product_id   INTEGER NOT NULL REFERENCES products(id),
    qty          INTEGER NOT NULL CHECK (qty > 0),
    qty_good     INTEGER CHECK (qty_good >= 0),
    qty_damaged  INTEGER CHECK (qty_damaged >= 0),
    note         TEXT,
    CHECK (COALESCE(qty_good, 0) + COALESCE(qty_damaged, 0) <= qty)
  );
  CREATE INDEX idx_return_lines_return ON stock_return_lines(return_id);
  `,
  // v4: manager approval for changes made by sales agents
  `
  ALTER TABLE users ADD COLUMN manager_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
  ALTER TABLE so_lines ADD COLUMN qty_returned INTEGER NOT NULL DEFAULT 0 CHECK (qty_returned >= 0 AND qty_returned <= qty);

  CREATE TABLE approval_requests (
    id            INTEGER PRIMARY KEY,
    number        TEXT UNIQUE,
    type          TEXT NOT NULL CHECK (type IN ('SO_AMEND','SO_CANCEL','RETURN_DISPATCH','RETURN_CANCEL')),
    entity        TEXT NOT NULL,
    entity_id     INTEGER NOT NULL,
    payload       TEXT NOT NULL,
    summary       TEXT,
    reason        TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','WITHDRAWN')),
    requested_by  INTEGER NOT NULL REFERENCES users(id),
    approver_id   INTEGER REFERENCES users(id),
    decided_by    INTEGER REFERENCES users(id),
    decided_at    TEXT,
    decision_note TEXT,
    created_at    TEXT NOT NULL DEFAULT ${NOW},
    updated_at    TEXT NOT NULL DEFAULT ${NOW}
  );
  CREATE INDEX idx_approvals_status ON approval_requests(status, created_at);
  CREATE INDEX idx_approvals_entity ON approval_requests(entity, entity_id);
  -- At most one open request per document, so approvals can never conflict.
  CREATE UNIQUE INDEX idx_approvals_one_pending ON approval_requests(entity, entity_id) WHERE status = 'PENDING';
  `,
];

function openDatabase(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const raw = new DatabaseSync(file);
  raw.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');

  const cache = new Map();
  const stmt = (sql) => {
    let s = cache.get(sql);
    if (!s) { s = raw.prepare(sql); cache.set(sql, s); }
    return s;
  };
  const norm = (params) => params.map((p) => (p === undefined ? null : typeof p === 'boolean' ? (p ? 1 : 0) : p));

  let depth = 0;
  const db = {
    raw,
    all: (sql, ...p) => stmt(sql).all(...norm(p)),
    get: (sql, ...p) => stmt(sql).get(...norm(p)),
    run: (sql, ...p) => {
      const r = stmt(sql).run(...norm(p));
      return { changes: Number(r.changes), id: Number(r.lastInsertRowid) };
    },
    exec: (sql) => raw.exec(sql),
    // Nested calls become savepoints, so services can compose safely.
    tx(fn) {
      const sp = `sp_${depth}`;
      raw.exec(depth === 0 ? 'BEGIN IMMEDIATE' : `SAVEPOINT ${sp}`);
      depth++;
      try {
        const result = fn();
        depth--;
        raw.exec(depth === 0 ? 'COMMIT' : `RELEASE ${sp}`);
        return result;
      } catch (err) {
        depth--;
        raw.exec(depth === 0 ? 'ROLLBACK' : `ROLLBACK TO ${sp}; RELEASE ${sp}`);
        throw err;
      }
    },
    close: () => raw.close(),
  };

  const version = db.get('PRAGMA user_version').user_version;
  for (let v = version; v < MIGRATIONS.length; v++) {
    db.tx(() => {
      raw.exec(MIGRATIONS[v]);
      raw.exec(`PRAGMA user_version = ${v + 1}`);
    });
  }
  return db;
}

module.exports = { openDatabase };
