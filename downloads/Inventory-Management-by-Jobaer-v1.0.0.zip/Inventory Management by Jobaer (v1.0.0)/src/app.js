'use strict';
const path = require('node:path');
const { openDatabase } = require('./db');
const { HttpError, TableResult, FileResult, Router, readJson, readText, sendJson, sendCsv, sendFile, serveStatic, SECURITY_HEADERS } = require('./http');
const { can, createSessions, createLoginLimiter } = require('./auth');
const { createInventory } = require('./inventory');
const { seed } = require('./seed');
const { createBranding } = require('./branding');
const { createApprovals } = require('./approvals');
const { renderTableReport } = require('./reports');

const PUBLIC_DIR = path.resolve(__dirname, '..', 'public');

/** Translate SQLite constraint failures into meaningful HTTP responses. */
function toHttpError(err) {
  if (err instanceof HttpError) return err;
  const msg = String((err && err.message) || '');
  const unique = /UNIQUE constraint failed: \w+\.(\w+)/.exec(msg);
  if (unique) return new HttpError(409, `A record with this ${unique[1]} already exists`, { [unique[1]]: 'must be unique' });
  if (msg.includes('FOREIGN KEY constraint failed')) return new HttpError(409, 'A referenced record does not exist or is still in use');
  if (msg.includes('CHECK constraint failed')) return new HttpError(409, 'The operation would violate a data integrity rule (e.g. negative stock)');
  if (msg.includes('immutable')) return new HttpError(409, msg);
  return null;
}

function createApp(config) {
  const db = openDatabase(config.dbPath);
  const inv = createInventory(db);
  const sessions = createSessions(db, { ttlHours: config.sessionTtlHours, secureCookies: config.secureCookies });
  const limiter = createLoginLimiter();
  const branding = createBranding(db, config);

  /** Render an export with the company letterhead. */
  const pdfFor = (c, result) => {
    const logo = branding.logo();
    const data = renderTableReport({
      branding: branding.get(), logo: logo && logo.decoded, result,
      generatedBy: c.user ? c.user.name : null,
    });
    return new FileResult(result.filename.replace(/.csv$/i, '') + '.pdf', 'application/pdf', data, { inline: c.query.inline === '1' });
  };

  const audit = (c, action, entity = null, entityId = null, details = null) => {
    db.run('INSERT INTO audit_log (user_id, user_email, action, entity, entity_id, details, ip) VALUES (?,?,?,?,?,?,?)',
      c.user ? c.user.id : null, c.user ? c.user.email : null, action, entity,
      entityId === null || entityId === undefined ? null : String(entityId),
      details ? JSON.stringify(details) : null, c.ip);
  };

  const router = new Router();
  const approvals = createApprovals(db, { audit });
  const deps = { db, inv, sessions, limiter, audit, config, branding, approvals };
  require('./routes/auth')(router, deps);
  require('./routes/master')(router, deps);
  require('./routes/stock')(router, deps);
  require('./routes/orders')(router, deps);
  require('./routes/admin')(router, deps);
  require('./routes/branding')(router, deps);
  require('./routes/returns')(router, deps);
  require('./routes/import')(router, deps);
  require('./routes/approvals')(router, deps);

  seed(db, inv, config);
  const purgeTimer = setInterval(() => sessions.purgeExpired(), 3600 * 1000);
  purgeTimer.unref();

  const clientIp = (req) => {
    if (config.trustProxy && req.headers['x-forwarded-for']) {
      return String(req.headers['x-forwarded-for']).split(',')[0].trim().replace(/:\d+$/, '');
    }
    return req.socket.remoteAddress;
  };

  async function handle(req, res) {
    const started = process.hrtime.bigint();
    for (const [k, v] of Object.entries(SECURITY_HEADERS)) res.setHeader(k, v);
    if (config.secureCookies) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');

    let url;
    try { url = new URL(req.url, 'http://localhost'); }
    catch { res.writeHead(400); return res.end(); }

    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
      return serveStatic(PUBLIC_DIR, url.pathname, req, res);
    }

    const c = { req, res, params: {}, query: Object.fromEntries(url.searchParams), ip: clientIp(req), status: 200, user: null };
    try {
      const match = router.match(req.method, url.pathname);
      if (!match) throw new HttpError(404, 'Endpoint not found');
      if (match.methodNotAllowed) throw new HttpError(405, 'Method not allowed');
      c.params = match.params;

      // CSRF defence in depth: SameSite=Strict cookies plus a header cross-site forms cannot set.
      if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'fetch') {
        throw new HttpError(403, 'Missing X-Requested-With header');
      }
      c.user = sessions.userFor(sessions.tokenFrom(req));
      const opts = match.route.opts || {};
      // Authenticate before buffering a large upload, so anonymous clients cannot make us hold 25 MB.
      if (opts.raw && match.route.perm !== 'public' && !c.user) { req.resume(); throw new HttpError(401, 'Authentication required'); }
      c.body = opts.raw ? await readText(req, opts.limit || 1_000_000) : await readJson(req);

      const perm = match.route.perm;
      if (perm !== 'public') {
        if (!c.user) throw new HttpError(401, 'Authentication required');
        if (!can(c.user.role, perm)) throw new HttpError(403, 'You do not have permission to perform this action');
      }

      const result = await match.route.handler(c);
      if (result instanceof TableResult) {
        if (c.query.format === 'pdf') sendFile(res, pdfFor(c, result));
        else sendCsv(res, result);
      } else if (result instanceof FileResult) sendFile(res, result);
      else sendJson(res, c.status, result ?? { ok: true });
    } catch (err) {
      const httpErr = toHttpError(err);
      if (httpErr) {
        c.status = httpErr.status;
        sendJson(res, httpErr.status, { error: httpErr.message, details: httpErr.details });
      } else {
        c.status = 500;
        console.error(`[error] ${req.method} ${url.pathname}`, err);
        sendJson(res, 500, { error: 'Internal server error' });
      }
    } finally {
      if (config.logRequests) {
        const ms = Number(process.hrtime.bigint() - started) / 1e6;
        console.log(`${new Date().toISOString()} ${req.method} ${url.pathname} ${c.status} ${ms.toFixed(1)}ms${c.user ? ` user=${c.user.id}` : ''}`);
      }
    }
  }

  return { handle, db, branding, close: () => { clearInterval(purgeTimer); db.close(); } };
}

module.exports = { createApp };
