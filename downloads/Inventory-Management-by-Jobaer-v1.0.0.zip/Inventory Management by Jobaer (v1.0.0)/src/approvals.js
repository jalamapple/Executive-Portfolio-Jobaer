'use strict';
/**
 * Manager approval for sensitive changes made by sales agents (clerks).
 *
 * A route that changes a confirmed/shipped sales order or a sales-center return calls
 * approvals.submit(). Users who may approve (managers, admins) have the change applied at once;
 * everyone else gets a PENDING request that their assigned manager (or any administrator) must
 * approve. On approval the registered handler applies the change inside a transaction, so if
 * the change is no longer possible (e.g. stock was sold meanwhile) nothing happens and the
 * request stays pending with a clear error.
 */
const { HttpError } = require('./http');
const { can } = require('./auth');

const NOW = "strftime('%Y-%m-%dT%H:%M:%fZ','now')";
class DryRun extends Error {}

const TYPE_LABEL = {
  SO_AMEND: 'Change invoice / sales order',
  SO_CANCEL: 'Cancel confirmed sales order',
  RETURN_DISPATCH: 'Dispatch return to warehouse',
  RETURN_CANCEL: 'Cancel dispatched return',
};

function createApprovals(db, { audit }) {
  const handlers = new Map(); // type -> { entity, apply(c, payload, entityId, ref) }

  function register(type, entity, apply) { handlers.set(type, { entity, apply }); }

  const userById = (id) => db.get('SELECT id, name, email, role, active, manager_id FROM users WHERE id = ?', id);

  /** The approver for a requester: their assigned manager if valid, otherwise "any manager or admin" (null). */
  function approverFor(user) {
    const u = userById(user.id);
    if (!u || !u.manager_id) return null;
    const m = userById(u.manager_id);
    return m && m.active && can(m.role, 'approvals:decide') ? m.id : null;
  }

  /** Can this user decide this request? Never their own; admins always; managers when assigned or unassigned. */
  function canDecide(user, req) {
    if (!user || req.requested_by === user.id) return false;
    if (user.role === 'admin') return true;
    if (!can(user.role, 'approvals:decide')) return false;
    return req.approver_id === null || req.approver_id === user.id;
  }

  function pendingFor(entity, entityId) {
    return db.get(`SELECT * FROM approval_requests WHERE entity = ? AND entity_id = ? AND status = 'PENDING'`, entity, entityId) || null;
  }

  /** Block other actions while a document has an open request. */
  function assertNoPending(entity, entityId) {
    const p = pendingFor(entity, entityId);
    if (p) throw new HttpError(409, `${p.number} is awaiting manager approval for this document. Wait for a decision or withdraw the request first.`, { approval: p.number });
  }

  /**
   * Apply the change now (approvers) or create a pending request (agents).
   * Returns { applied: true, result } or { applied: false, request }.
   */
  function submit(c, { type, entityId, payload, reason, summary }) {
    const h = handlers.get(type);
    if (!h) throw new Error(`No approval handler for ${type}`);
    const why = String(reason || '').trim();
    if (!why) throw new HttpError(422, 'Please give a reason for this change', { reason: 'is required' });
    if (why.length > 500) throw new HttpError(422, 'Reason is too long', { reason: 'must be at most 500 characters' });

    if (can(c.user.role, 'approvals:decide')) {
      assertNoPending(h.entity, entityId); // decide the open request first so it cannot go stale
      const result = db.tx(() => h.apply(c, payload, entityId, null));
      audit(c, `approval.direct_${type.toLowerCase()}`, h.entity, entityId, { reason: why, summary });
      return { applied: true, result };
    }

    assertNoPending(h.entity, entityId);
    // Dry-run the change now so obviously invalid requests are rejected immediately.
    try {
      db.tx(() => { h.apply(c, payload, entityId, null); throw new DryRun(); });
    } catch (err) { if (!(err instanceof DryRun)) throw err; }

    const id = db.tx(() => {
      const rid = db.run(`INSERT INTO approval_requests (type, entity, entity_id, payload, summary, reason, requested_by, approver_id)
                          VALUES (?,?,?,?,?,?,?,?)`,
        type, h.entity, entityId, JSON.stringify(payload), summary || null, why, c.user.id, approverFor(c.user)).id;
      db.run('UPDATE approval_requests SET number = ? WHERE id = ?', `APR-${String(rid).padStart(6, '0')}`, rid);
      return rid;
    });
    const req = load(id);
    audit(c, 'approval.request', 'approval', id, { number: req.number, type, entity: h.entity, entity_id: entityId, reason: why });
    return { applied: false, request: req };
  }

  function load(id) {
    const r = db.get(`
      SELECT a.*, ru.name AS requested_by_name, ru.email AS requested_by_email,
             au.name AS approver_name, du.name AS decided_by_name
      FROM approval_requests a JOIN users ru ON ru.id = a.requested_by
      LEFT JOIN users au ON au.id = a.approver_id LEFT JOIN users du ON du.id = a.decided_by
      WHERE a.id = ?`, id);
    if (!r) throw new HttpError(404, 'Approval request not found');
    r.payload = JSON.parse(r.payload);
    r.type_label = TYPE_LABEL[r.type];
    return r;
  }

  function decide(c, id, decision, note) {
    const req = load(id);
    if (req.status !== 'PENDING') throw new HttpError(409, `${req.number} has already been ${req.status.toLowerCase()}`);
    if (decision === 'WITHDRAWN') {
      if (req.requested_by !== c.user.id) throw new HttpError(403, 'Only the person who made the request can withdraw it');
    } else if (!canDecide(c.user, req)) {
      throw new HttpError(403, req.requested_by === c.user.id
        ? 'You cannot approve or reject your own request'
        : `Only ${req.approver_name || 'a manager'} or an administrator can decide this request`);
    }
    if (decision === 'REJECTED' && !String(note || '').trim()) throw new HttpError(422, 'Please explain why the request is rejected', { note: 'is required' });

    db.tx(() => {
      if (decision === 'APPROVED') {
        const h = handlers.get(req.type);
        // Apply as the approver, but keep the requester in the ledger notes.
        h.apply(c, req.payload, req.entity_id, req.number);
      }
      const changed = db.run(`UPDATE approval_requests SET status = ?, decided_by = ?, decided_at = ${NOW}, decision_note = ?, updated_at = ${NOW}
                              WHERE id = ? AND status = 'PENDING'`, decision, c.user.id, String(note || '').trim() || null, id).changes;
      if (!changed) throw new HttpError(409, `${req.number} was decided by someone else just now`);
    });
    audit(c, `approval.${decision.toLowerCase()}`, 'approval', id, { number: req.number, type: req.type, entity: req.entity, entity_id: req.entity_id, note: note || null });
    audit(c, `approval.${decision.toLowerCase()}`, req.entity, req.entity_id, { number: req.number, type: req.type });
    return load(id);
  }

  return { register, submit, load, decide, canDecide, pendingFor, assertNoPending, TYPE_LABEL };
}

module.exports = { createApprovals, TYPE_LABEL };
