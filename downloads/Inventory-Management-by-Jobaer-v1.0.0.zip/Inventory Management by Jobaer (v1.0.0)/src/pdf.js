'use strict';
/**
 * Minimal, dependency-free PDF 1.4 writer.
 * Coordinates are in points with a TOP-LEFT origin (converted internally).
 * Uses the standard Helvetica fonts with WinAnsi encoding, so no fonts are embedded.
 * Supports text, rectangles, lines and PNG/JPEG images (PNG alpha becomes a soft mask).
 */
const zlib = require('node:zlib');

const PAGE_SIZES = { A4: [595.28, 841.89], Letter: [612, 792] };

// Glyph widths (1/1000 em) for ASCII 32..126, from the Adobe Helvetica AFM files.
const W_REGULAR = [
  278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556,
  556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
  667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556,
  556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
];
const W_BOLD = [
  278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556,
  556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778,
  667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611,
  611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584,
];

// Unicode -> WinAnsi byte for the 0x80..0x9F block.
const WIN_ANSI_EXTRA = {
  0x20ac: 0x80, 0x201a: 0x82, 0x0192: 0x83, 0x201e: 0x84, 0x2026: 0x85, 0x2020: 0x86, 0x2021: 0x87, 0x02c6: 0x88,
  0x2030: 0x89, 0x0160: 0x8a, 0x2039: 0x8b, 0x0152: 0x8c, 0x017d: 0x8e, 0x2018: 0x91, 0x2019: 0x92, 0x201c: 0x93,
  0x201d: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97, 0x02dc: 0x98, 0x2122: 0x99, 0x0161: 0x9a, 0x203a: 0x9b,
  0x0153: 0x9c, 0x017e: 0x9e, 0x0178: 0x9f,
};

/** Map a JS string to WinAnsi byte codes; unsupported characters become '?'. */
function toWinAnsi(str) {
  const out = [];
  for (const ch of String(str ?? '')) {
    const cp = ch.codePointAt(0);
    if (cp === 9) out.push(32);
    else if ((cp >= 32 && cp <= 126) || (cp >= 160 && cp <= 255)) out.push(cp);
    else if (WIN_ANSI_EXTRA[cp]) out.push(WIN_ANSI_EXTRA[cp]);
    else if (cp === 0x202f || cp === 0x2009 || cp === 0x2007) out.push(32); // narrow/thin spaces from Intl
    else if (cp >= 32) out.push(63);
  }
  return out;
}

/** True when every character can be drawn with the standard fonts. */
const isEncodable = (str) => {
  for (const ch of String(str ?? '')) {
    const cp = ch.codePointAt(0);
    if (!((cp >= 32 && cp <= 126) || (cp >= 160 && cp <= 255) || WIN_ANSI_EXTRA[cp] || cp === 0x202f || cp === 0x2009 || cp === 0x2007 || cp === 9)) return false;
  }
  return true;
};

function widthOf(str, size, bold) {
  const table = bold ? W_BOLD : W_REGULAR;
  let w = 0;
  for (const b of toWinAnsi(str)) w += b >= 32 && b <= 126 ? table[b - 32] : 556;
  return (w * size) / 1000;
}

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
  const n = m ? parseInt(m[1], 16) : 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => +(v / 255).toFixed(4));
}

const pdfString = (bytes) => {
  let s = '(';
  for (const b of bytes) {
    if (b === 0x28 || b === 0x29 || b === 0x5c) s += '\\' + String.fromCharCode(b);
    else if (b < 32 || b > 126) s += '\\' + b.toString(8).padStart(3, '0');
    else s += String.fromCharCode(b);
  }
  return s + ')';
};

// Info-dictionary strings: UTF-16BE with BOM, hex encoded, so any language works.
const pdfTextString = (str) => {
  const buf = Buffer.from('﻿' + String(str ?? ''), 'utf16le').swap16();
  return `<${buf.toString('hex')}>`;
};

const n = (v) => (Math.round(v * 100) / 100).toString();

// ---------------------------------------------------------------------------
// Images
// ---------------------------------------------------------------------------

/** Parse a PNG or JPEG into the pieces a PDF image XObject needs. Throws on unsupported input. */
function decodeImage(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 24) throw new Error('Image is empty or truncated');
  if (buf.readUInt32BE(0) === 0x89504e47) return decodePng(buf);
  if (buf[0] === 0xff && buf[1] === 0xd8) return decodeJpeg(buf);
  throw new Error('Only PNG and JPEG images are supported');
}

function decodeJpeg(buf) {
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const marker = buf[i + 1];
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
    const len = buf.readUInt16BE(i + 2);
    // SOF0..SOF15 except DHT(C4), JPG(C8), DAC(CC)
    if (marker >= 0xc0 && marker <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marker)) {
      const height = buf.readUInt16BE(i + 5);
      const width = buf.readUInt16BE(i + 7);
      const comps = buf[i + 9];
      const colorSpace = comps === 1 ? '/DeviceGray' : comps === 4 ? '/DeviceCMYK' : '/DeviceRGB';
      if (!width || !height) break;
      return {
        width, height, type: 'jpeg',
        color: { data: buf, dict: `/ColorSpace ${colorSpace} /BitsPerComponent 8 /Filter /DCTDecode${comps === 4 ? ' /Decode [1 0 1 0 1 0 1 0]' : ''}` },
      };
    }
    i += 2 + len;
  }
  throw new Error('Could not read JPEG dimensions');
}

function decodePng(buf) {
  let pos = 8;
  let ihdr = null;
  let palette = null;
  let trns = null;
  const idat = [];
  while (pos + 8 <= buf.length) {
    const len = buf.readUInt32BE(pos);
    const type = buf.toString('latin1', pos + 4, pos + 8);
    const data = buf.subarray(pos + 8, pos + 8 + len);
    if (type === 'IHDR') {
      ihdr = { width: data.readUInt32BE(0), height: data.readUInt32BE(4), depth: data[8], colorType: data[9], interlace: data[12] };
    } else if (type === 'PLTE') palette = data;
    else if (type === 'tRNS') trns = data;
    else if (type === 'IDAT') idat.push(data);
    else if (type === 'IEND') break;
    pos += 12 + len;
  }
  if (!ihdr || !idat.length) throw new Error('PNG file is incomplete');
  const { width, height, depth, colorType, interlace } = ihdr;
  if (depth !== 8) throw new Error('PNG must use 8 bits per channel');
  if (interlace) throw new Error('Interlaced PNGs are not supported; please re-save without interlacing');
  if (width > 4000 || height > 4000) throw new Error('Image must be at most 4000×4000 pixels');
  const channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[colorType];
  if (!channels) throw new Error('Unsupported PNG colour type');
  if (colorType === 3 && !palette) throw new Error('Palette PNG is missing its palette');

  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * channels;
  if (raw.length < (stride + 1) * height) throw new Error('PNG image data is truncated');
  const px = Buffer.alloc(stride * height);
  // Undo the per-scanline PNG filters.
  for (let y = 0; y < height; y++) {
    const filter = raw[y * (stride + 1)];
    const src = y * (stride + 1) + 1;
    const dst = y * stride;
    for (let x = 0; x < stride; x++) {
      const a = x >= channels ? px[dst + x - channels] : 0;
      const b = y > 0 ? px[dst - stride + x] : 0;
      const c = x >= channels && y > 0 ? px[dst - stride + x - channels] : 0;
      let v = raw[src + x];
      if (filter === 1) v += a;
      else if (filter === 2) v += b;
      else if (filter === 3) v += (a + b) >> 1;
      else if (filter === 4) {
        const p = a + b - c;
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
      } else if (filter !== 0) throw new Error('PNG uses an invalid filter');
      px[dst + x] = v & 255;
    }
  }

  const count = width * height;
  const gray = colorType === 0 || colorType === 4;
  const color = Buffer.alloc(count * (gray ? 1 : 3));
  let alpha = null;
  if (colorType === 4 || colorType === 6 || (colorType === 3 && trns)) alpha = Buffer.alloc(count);
  for (let i = 0; i < count; i++) {
    if (colorType === 0) color[i] = px[i];
    else if (colorType === 4) { color[i] = px[i * 2]; alpha[i] = px[i * 2 + 1]; }
    else if (colorType === 2) px.copy(color, i * 3, i * 3, i * 3 + 3);
    else if (colorType === 6) { px.copy(color, i * 3, i * 4, i * 4 + 3); alpha[i] = px[i * 4 + 3]; }
    else {
      const idx = px[i];
      palette.copy(color, i * 3, idx * 3, idx * 3 + 3);
      if (alpha) alpha[i] = idx < trns.length ? trns[idx] : 255;
    }
  }
  if (alpha && alpha.every((v) => v === 255)) alpha = null;
  return {
    width, height, type: 'png',
    color: { data: zlib.deflateSync(color), dict: `/ColorSpace ${gray ? '/DeviceGray' : '/DeviceRGB'} /BitsPerComponent 8 /Filter /FlateDecode` },
    alpha: alpha ? { data: zlib.deflateSync(alpha), dict: '/ColorSpace /DeviceGray /BitsPerComponent 8 /Filter /FlateDecode' } : null,
  };
}

// ---------------------------------------------------------------------------
// Document
// ---------------------------------------------------------------------------

class PdfDocument {
  constructor({ size = 'A4', landscape = false, info = {} } = {}) {
    const [w, h] = PAGE_SIZES[size] || PAGE_SIZES.A4;
    this.width = landscape ? h : w;
    this.height = landscape ? w : h;
    this.info = info;
    this.pages = [];
    this.images = [];
    this.page = null;
  }

  addPage() {
    this.page = { ops: [], images: new Set() };
    this.pages.push(this.page);
    return this.page;
  }

  /** Select a page (by index) for further drawing, e.g. to add footers after layout. */
  usePage(i) { this.page = this.pages[i]; }

  measure(str, size, bold = false) { return widthOf(str, size, bold); }

  /** Shorten text with an ellipsis so it fits in maxWidth. */
  fit(str, maxWidth, size, bold = false) {
    const s = String(str ?? '');
    if (widthOf(s, size, bold) <= maxWidth) return s;
    const chars = [...s];
    let lo = 0, hi = chars.length;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (widthOf(chars.slice(0, mid).join('') + '…', size, bold) <= maxWidth) lo = mid; else hi = mid - 1;
    }
    return lo ? chars.slice(0, lo).join('').trimEnd() + '…' : '';
  }

  /** Word-wrap text into lines no wider than maxWidth. Honours explicit newlines. */
  wrap(str, maxWidth, size, bold = false) {
    const lines = [];
    for (const para of String(str ?? '').split(/\r?\n/)) {
      let line = '';
      for (const word of para.split(/\s+/).filter(Boolean)) {
        const next = line ? `${line} ${word}` : word;
        if (widthOf(next, size, bold) <= maxWidth || !line) line = next;
        else { lines.push(line); line = word; }
        while (widthOf(line, size, bold) > maxWidth && line.length > 1) { // single very long word
          const cut = this.fit(line, maxWidth, size, bold).replace(/…$/, '');
          if (!cut) break;
          lines.push(cut); line = line.slice(cut.length);
        }
      }
      lines.push(line);
    }
    return lines;
  }

  /** Draw text whose TOP edge is at y. Options: size, bold, color, align (left|right|center), width. */
  text(x, y, str, { size = 10, bold = false, color = '#000000', align = 'left', width = 0 } = {}) {
    const s = String(str ?? '');
    if (!s) return;
    let tx = x;
    if (align !== 'left' && width) {
      const w = widthOf(s, size, bold);
      tx = align === 'right' ? x + width - w : x + (width - w) / 2;
    }
    const baseline = this.height - (y + size * 0.8);
    const [r, g, b] = hexToRgb(color);
    this.page.ops.push(`BT ${n(r)} ${n(g)} ${n(b)} rg /${bold ? 'F2' : 'F1'} ${n(size)} Tf ${n(tx)} ${n(baseline)} Td ${pdfString(toWinAnsi(s))} Tj ET`);
  }

  rect(x, y, w, h, { fill = null, stroke = null, lineWidth = 0.5 } = {}) {
    const ops = ['q'];
    if (fill) { const [r, g, b] = hexToRgb(fill); ops.push(`${r} ${g} ${b} rg`); }
    if (stroke) { const [r, g, b] = hexToRgb(stroke); ops.push(`${r} ${g} ${b} RG ${n(lineWidth)} w`); }
    ops.push(`${n(x)} ${n(this.height - y - h)} ${n(w)} ${n(h)} re ${fill && stroke ? 'B' : fill ? 'f' : 'S'} Q`);
    this.page.ops.push(ops.join(' '));
  }

  line(x1, y1, x2, y2, { color = '#000000', width = 0.5 } = {}) {
    const [r, g, b] = hexToRgb(color);
    this.page.ops.push(`q ${r} ${g} ${b} RG ${n(width)} w ${n(x1)} ${n(this.height - y1)} m ${n(x2)} ${n(this.height - y2)} l S Q`);
  }

  /** Large diagonal text centred on the page (draw it first so content sits on top). */
  watermark(str, { size = 96, color = '#eef0f4' } = {}) {
    const s = String(str ?? '');
    const w = widthOf(s, size, true);
    const a = Math.atan2(this.height, this.width);
    const cos = Math.cos(a), sin = Math.sin(a);
    const cx = this.width / 2, cy = this.height / 2;
    const x = cx - (w / 2) * cos + (size * 0.35) * sin;
    const y = cy - (w / 2) * sin - (size * 0.35) * cos;
    const [r, g, b] = hexToRgb(color);
    this.page.ops.push(`BT ${r} ${g} ${b} rg /F2 ${n(size)} Tf ${n(cos)} ${n(sin)} ${n(-sin)} ${n(cos)} ${n(x)} ${n(y)} Tm ${pdfString(toWinAnsi(s))} Tj ET`);
  }

  /** Register a decoded image once; returns a handle usable on any page. */
  registerImage(decoded) {
    const handle = { ...decoded, name: `Im${this.images.length + 1}` };
    this.images.push(handle);
    return handle;
  }

  image(handle, x, y, w, h) {
    this.page.images.add(handle);
    this.page.ops.push(`q ${n(w)} 0 0 ${n(h)} ${n(x)} ${n(this.height - y - h)} cm /${handle.name} Do Q`);
  }

  toBuffer() {
    const objects = []; // index = object number - 1, value = Buffer
    const reserve = () => { objects.push(null); return objects.length; };
    const set = (num, body) => { objects[num - 1] = Buffer.isBuffer(body) ? body : Buffer.from(body, 'latin1'); };
    const stream = (dict, data) => Buffer.concat([
      Buffer.from(`<< ${dict} /Length ${data.length} >>\nstream\n`, 'latin1'), data, Buffer.from('\nendstream', 'latin1'),
    ]);

    const catalog = reserve();
    const pagesObj = reserve();
    const fontRegular = reserve();
    const fontBold = reserve();
    set(fontRegular, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    set(fontBold, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');

    const imageObj = new Map();
    for (const img of this.images) {
      let smask = '';
      if (img.alpha) {
        const m = reserve();
        set(m, stream(`/Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} ${img.alpha.dict}`, img.alpha.data));
        smask = ` /SMask ${m} 0 R`;
      }
      const o = reserve();
      set(o, stream(`/Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} ${img.color.dict}${smask}`, img.color.data));
      imageObj.set(img, o);
    }

    const kids = [];
    for (const page of this.pages) {
      const content = reserve();
      set(content, stream('/Filter /FlateDecode', zlib.deflateSync(Buffer.from(page.ops.join('\n'), 'latin1'))));
      const xobj = [...page.images].map((img) => `/${img.name} ${imageObj.get(img)} 0 R`).join(' ');
      const p = reserve();
      set(p, `<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${n(this.width)} ${n(this.height)}] ` +
        `/Resources << /Font << /F1 ${fontRegular} 0 R /F2 ${fontBold} 0 R >>${xobj ? ` /XObject << ${xobj} >>` : ''} >> /Contents ${content} 0 R >>`);
      kids.push(`${p} 0 R`);
    }
    set(pagesObj, `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${kids.length} >>`);
    set(catalog, `<< /Type /Catalog /Pages ${pagesObj} 0 R >>`);

    const d = new Date();
    const pad = (v) => String(v).padStart(2, '0');
    const date = `D:${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
    const info = reserve();
    const entries = Object.entries(this.info).filter(([, v]) => v).map(([k, v]) => `/${k} ${pdfTextString(v)}`);
    set(info, `<< ${entries.join(' ')} /CreationDate (${date}) >>`);

    const parts = [Buffer.from('%PDF-1.4\n%\xe2\xe3\xcf\xd3\n', 'latin1')];
    let offset = parts[0].length;
    const offsets = [];
    objects.forEach((body, i) => {
      offsets.push(offset);
      const chunk = Buffer.concat([Buffer.from(`${i + 1} 0 obj\n`, 'latin1'), body, Buffer.from('\nendobj\n', 'latin1')]);
      parts.push(chunk);
      offset += chunk.length;
    });
    const xref = [`xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`, ...offsets.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`)].join('');
    parts.push(Buffer.from(`${xref}trailer\n<< /Size ${objects.length + 1} /Root ${catalog} 0 R /Info ${info} 0 R >>\nstartxref\n${offset}\n%%EOF\n`, 'latin1'));
    return Buffer.concat(parts);
  }
}

module.exports = { PdfDocument, decodeImage, isEncodable, widthOf };
