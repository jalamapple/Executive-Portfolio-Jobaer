'use strict';
const crypto = require('node:crypto');
const { HttpError, parseCookies } = require('./http');

const ROLES = ['admin', 'manager', 'clerk', 'viewer'];

// Permission -> roles allowed. 'read' is granted to every signed-in user.
const PERMISSIONS = {
  read: ['admin', 'manager', 'clerk', 'viewer'],
  'master:write': ['admin', 'manager'],
  'stock:write': ['admin', 'manager', 'clerk'],
  'orders:write': ['admin', 'manager', 'clerk'],
  'orders:approve': ['admin', 'manager'],
  'audit:read': ['admin', 'manager'],
  'users:manage': ['admin'],
  'settings:manage': ['admin'],
  // Managers and admins approve sales agents' changes to invoices and returns (and act without approval).
  'approvals:decide': ['admin', 'manager'],
};

const can = (role, perm) => Boolean(PERMISSIONS[perm] && PERMISSIONS[perm].includes(role));
const permissionsFor = (role) => Object.keys(PERMISSIONS).filter((p) => can(role, p));

const SCRYPT = { N: 16384, r: 8, p: 1 };

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64, SCRYPT);
  return `scrypt$${salt.toString('base64')}$${hash.toString('base64')}`;
}

function verifyPassword(password, stored) {
  const [alg, salt, hash] = String(stored).split('$');
  if (alg !== 'scrypt' || !salt || !hash) return false;
  const expected = Buffer.from(hash, 'base64');
  const actual = crypto.scryptSync(password, Buffer.from(salt, 'base64'), expected.length, SCRYPT);
  return crypto.timingSafeEqual(actual, expected);
}

// Used when the email does not exist, so response timing does not reveal valid accounts.
const DUMMY_HASH = hashPassword(crypto.randomBytes(12).toString('hex'));

function checkPasswordPolicy(password) {
  if (typeof password !== 'string' || password.length < 10 || password.length > 128) {
    throw new HttpError(422, 'Password does not meet policy', { password: 'must be 10–128 characters' });
  }
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    throw new HttpError(422, 'Password does not meet policy', { password: 'must contain letters and numbers' });
  }
}

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

function createSessions(db, { ttlHours, secureCookies }) {
  const ttlMs = ttlHours * 3600 * 1000;
  return {
    create(userId, c) {
      const token = crypto.randomBytes(32).toString('base64url');
      db.run(
        'INSERT INTO sessions (token_hash, user_id, expires_at, ip, user_agent) VALUES (?,?,?,?,?)',
        sha256(token), userId, Date.now() + ttlMs, c.ip, String(c.req.headers['user-agent'] || '').slice(0, 300),
      );
      return token;
    },
    cookie(token) {
      const parts = [`sid=${token}`, 'HttpOnly', 'Path=/', 'SameSite=Strict', `Max-Age=${Math.floor(ttlMs / 1000)}`];
      if (secureCookies) parts.push('Secure');
      return parts.join('; ');
    },
    clearCookie() {
      return `sid=; HttpOnly; Path=/; SameSite=Strict; Max-Age=0${secureCookies ? '; Secure' : ''}`;
    },
    tokenFrom(req) {
      return parseCookies(req.headers.cookie).sid || null;
    },
    userFor(token) {
      if (!token) return null;
      return db.get(
        `SELECT u.id, u.email, u.name, u.role FROM sessions s JOIN users u ON u.id = s.user_id
         WHERE s.token_hash = ? AND s.expires_at > ? AND u.active = 1`,
        sha256(token), Date.now(),
      ) || null;
    },
    destroy(token) {
      if (token) db.run('DELETE FROM sessions WHERE token_hash = ?', sha256(token));
    },
    destroyForUser(userId, exceptToken = null) {
      if (exceptToken) db.run('DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?', userId, sha256(exceptToken));
      else db.run('DELETE FROM sessions WHERE user_id = ?', userId);
    },
    purgeExpired() {
      db.run('DELETE FROM sessions WHERE expires_at <= ?', Date.now());
    },
  };
}

/** In-memory brute-force protection: lock a (ip, email) pair after repeated failures. */
function createLoginLimiter({ maxAttempts = 5, lockMinutes = 15 } = {}) {
  const attempts = new Map();
  return {
    check(key) {
      const a = attempts.get(key);
      if (a && a.lockedUntil > Date.now()) {
        const mins = Math.ceil((a.lockedUntil - Date.now()) / 60000);
        throw new HttpError(429, `Too many failed attempts. Try again in ${mins} minute(s).`);
      }
    },
    fail(key) {
      const a = attempts.get(key) || { count: 0, lockedUntil: 0 };
      a.count++;
      if (a.count >= maxAttempts) { a.lockedUntil = Date.now() + lockMinutes * 60000; a.count = 0; }
      attempts.set(key, a);
      if (attempts.size > 10000) attempts.delete(attempts.keys().next().value);
    },
    reset(key) { attempts.delete(key); },
  };
}

module.exports = {
  ROLES, PERMISSIONS, can, permissionsFor, hashPassword, verifyPassword, DUMMY_HASH,
  checkPasswordPolicy, createSessions, createLoginLimiter,
};
