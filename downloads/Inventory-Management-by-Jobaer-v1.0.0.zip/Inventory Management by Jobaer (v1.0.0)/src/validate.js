'use strict';
const { HttpError } = require('./http');

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Validate and coerce a request body against a spec.
 * spec: { field: { type, required, default, min, max, values, pattern, trim } }
 * types: string | text | email | int | number | bool | id | enum | date
 * partial: true for updates (absent fields are left untouched).
 */
function validate(input, spec, { partial = false } = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new HttpError(400, 'Request body must be a JSON object');
  }
  const out = {};
  const errors = {};

  for (const [key, rule] of Object.entries(spec)) {
    let v = input[key];
    if (typeof v === 'string' && rule.trim !== false) v = v.trim();

    if (v === undefined || v === null || v === '') {
      if (v === undefined && partial) continue;
      if (rule.required) { errors[key] = 'is required'; continue; }
      out[key] = rule.default !== undefined ? rule.default : null;
      continue;
    }

    switch (rule.type) {
      case 'string':
      case 'text': {
        const s = String(v);
        const max = rule.max ?? (rule.type === 'text' ? 5000 : 255);
        if (s.length > max) errors[key] = `must be at most ${max} characters`;
        else if (rule.min && s.length < rule.min) errors[key] = `must be at least ${rule.min} characters`;
        else if (rule.pattern && !rule.pattern.test(s)) errors[key] = rule.patternMessage || 'has an invalid format';
        else out[key] = s;
        break;
      }
      case 'email': {
        const s = String(v).toLowerCase();
        if (s.length > 254 || !EMAIL.test(s)) errors[key] = 'must be a valid email address';
        else out[key] = s;
        break;
      }
      case 'int':
      case 'id': {
        const n = Number(v);
        const min = rule.type === 'id' ? 1 : rule.min;
        if (!Number.isInteger(n)) errors[key] = 'must be a whole number';
        else if (min !== undefined && n < min) errors[key] = `must be at least ${min}`;
        else if (rule.max !== undefined && n > rule.max) errors[key] = `must be at most ${rule.max}`;
        else out[key] = n;
        break;
      }
      case 'number': {
        const n = Number(v);
        if (!Number.isFinite(n)) errors[key] = 'must be a number';
        else if (rule.min !== undefined && n < rule.min) errors[key] = `must be at least ${rule.min}`;
        else if (rule.max !== undefined && n > rule.max) errors[key] = `must be at most ${rule.max}`;
        else out[key] = Math.round(n * 10000) / 10000;
        break;
      }
      case 'bool':
        if ([true, 1, '1', 'true'].includes(v)) out[key] = 1;
        else if ([false, 0, '0', 'false'].includes(v)) out[key] = 0;
        else errors[key] = 'must be true or false';
        break;
      case 'enum':
        if (!rule.values.includes(v)) errors[key] = `must be one of: ${rule.values.join(', ')}`;
        else out[key] = v;
        break;
      case 'date':
        if (!DATE.test(String(v)) || Number.isNaN(Date.parse(v))) errors[key] = 'must be a date (YYYY-MM-DD)';
        else out[key] = String(v);
        break;
      default:
        throw new Error(`Unknown validation type ${rule.type}`);
    }
  }

  if (Object.keys(errors).length) throw new HttpError(422, 'Validation failed', errors);
  return out;
}

/** Validate an array of order lines, prefixing error keys with the line index. */
function validateLines(lines, spec, { max = 500 } = {}) {
  if (!Array.isArray(lines) || lines.length === 0) {
    throw new HttpError(422, 'At least one line item is required', { lines: 'is required' });
  }
  if (lines.length > max) throw new HttpError(422, `An order can have at most ${max} lines`);
  const errors = {};
  const out = lines.map((line, i) => {
    try { return validate(line, spec); }
    catch (err) {
      if (!(err instanceof HttpError) || !err.details) throw err;
      for (const [k, msg] of Object.entries(err.details)) errors[`lines[${i}].${k}`] = msg;
      return null;
    }
  });
  if (Object.keys(errors).length) throw new HttpError(422, 'One or more line items are invalid', errors);
  return out;
}

const likeParam = (q) => `%${String(q).replace(/[\\%_]/g, (m) => '\\' + m)}%`;

function paging(query, { max = 200, def = 50 } = {}) {
  const limit = Math.min(Math.max(parseInt(query.limit, 10) || def, 1), max);
  const offset = Math.max(parseInt(query.offset, 10) || 0, 0);
  return { limit, offset };
}

function idParam(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) throw new HttpError(404, 'Not found');
  return n;
}

module.exports = { validate, validateLines, likeParam, paging, idParam };
