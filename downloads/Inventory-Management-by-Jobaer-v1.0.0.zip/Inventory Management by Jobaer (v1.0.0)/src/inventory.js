'use strict';
const { HttpError } = require('./http');

const round = (n, dp = 4) => Math.round(n * 10 ** dp) / 10 ** dp;

/**
 * The stock engine. Every change to on-hand quantity goes through move(), which
 * writes an immutable ledger entry and keeps the moving weighted-average cost current.
 */
function createInventory(db) {
  function product(id) {
    const p = db.get('SELECT id, sku, name, active, avg_cost, price, cost FROM products WHERE id = ?', id);
    if (!p) throw new HttpError(404, `Product #${id} not found`);
    return p;
  }

  function warehouse(id, { requireActive = true } = {}) {
    const w = db.get('SELECT id, code, name, kind, active FROM warehouses WHERE id = ?', id);
    if (!w) throw new HttpError(404, `Location #${id} not found`);
    if (requireActive && !w.active) throw new HttpError(409, `Location ${w.code} is inactive`);
    return w;
  }

  function stockRow(productId, warehouseId) {
    db.run('INSERT OR IGNORE INTO stock (product_id, warehouse_id) VALUES (?, ?)', productId, warehouseId);
    return db.get('SELECT on_hand, reserved FROM stock WHERE product_id = ? AND warehouse_id = ?', productId, warehouseId);
  }

  function move({ productId, warehouseId, qty, type, unitCost = null, refType = null, refId = null, note = null, userId = null, createdAt = null }) {
    if (!Number.isInteger(qty) || qty === 0) throw new HttpError(422, 'Quantity must be a non-zero whole number');
    return db.tx(() => {
      const p = product(productId);
      const w = warehouse(warehouseId);
      const s = stockRow(productId, warehouseId);
      const balance = s.on_hand + qty;

      // Reserved stock belongs to confirmed sales orders and cannot be consumed by other movements.
      if (balance < s.reserved) {
        throw new HttpError(409,
          `Insufficient available stock for ${p.sku} in ${w.code}: available ${s.on_hand - s.reserved}, requested ${-qty}`,
          { available: s.on_hand - s.reserved, requested: -qty });
      }

      if (qty > 0 && unitCost !== null && unitCost !== undefined) {
        const total = db.get('SELECT COALESCE(SUM(on_hand), 0) AS n FROM stock WHERE product_id = ?', productId).n;
        const avg = total > 0 ? (total * p.avg_cost + qty * unitCost) / (total + qty) : unitCost;
        db.run(`UPDATE products SET avg_cost = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`, round(avg), productId);
      }

      db.run('UPDATE stock SET on_hand = ? WHERE product_id = ? AND warehouse_id = ?', balance, productId, warehouseId);
      const r = db.run(
        `INSERT INTO movements (product_id, warehouse_id, type, qty, balance_after, unit_cost, ref_type, ref_id, note, user_id, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?, COALESCE(?, strftime('%Y-%m-%dT%H:%M:%fZ','now')))`,
        productId, warehouseId, type, qty, balance, unitCost ?? p.avg_cost, refType, refId, note, userId, createdAt,
      );
      return { movement_id: r.id, product_id: productId, warehouse_id: warehouseId, qty, balance_after: balance };
    });
  }

  /** Cycle count: post the difference between counted and system quantity. */
  function count({ productId, warehouseId, counted, note, userId }) {
    return db.tx(() => {
      product(productId);
      warehouse(warehouseId);
      const s = stockRow(productId, warehouseId);
      const delta = counted - s.on_hand;
      if (delta === 0) return { movement_id: null, qty: 0, balance_after: s.on_hand, message: 'Count matches system quantity' };
      return move({ productId, warehouseId, qty: delta, type: 'COUNT', note, userId });
    });
  }

  function transfer({ productId, fromId, toId, qty, note, userId }) {
    if (fromId === toId) throw new HttpError(422, 'Source and destination warehouses must differ');
    if (!Number.isInteger(qty) || qty <= 0) throw new HttpError(422, 'Transfer quantity must be a positive whole number');
    return db.tx(() => {
      const ref = `TR-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
      const out = move({ productId, warehouseId: fromId, qty: -qty, type: 'TRANSFER_OUT', refType: 'TRANSFER', refId: ref, note, userId });
      const inn = move({ productId, warehouseId: toId, qty, type: 'TRANSFER_IN', refType: 'TRANSFER', refId: ref, note, userId });
      return { reference: ref, out, in: inn };
    });
  }

  function reserve(productId, warehouseId, qty) {
    const s = stockRow(productId, warehouseId);
    if (s.on_hand - s.reserved < qty) return false;
    db.run('UPDATE stock SET reserved = reserved + ? WHERE product_id = ? AND warehouse_id = ?', qty, productId, warehouseId);
    return true;
  }

  function release(productId, warehouseId, qty) {
    db.run('UPDATE stock SET reserved = MAX(reserved - ?, 0) WHERE product_id = ? AND warehouse_id = ?', qty, productId, warehouseId);
  }

  return { move, count, transfer, reserve, release, stockRow, product, warehouse };
}

module.exports = { createInventory };
