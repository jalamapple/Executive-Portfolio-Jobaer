'use strict';
/**
 * Branded PDF layouts: tabular reports and business documents (purchase orders, sales documents).
 * Every page carries the company letterhead (first page) or a compact running header, plus a footer.
 */
const { PdfDocument, isEncodable } = require('./pdf');
const { PRODUCT, mix } = require('./branding');

const INK = '#1a2233';
const MUTED = '#5f6b80';
const RULE = '#d9dee8';
const ZEBRA = '#f6f8fb';
const M = 40; // page margin

/** Formatters bound to the company's currency and time zone. */
function createFormat(b) {
  let money;
  for (const display of ['symbol', 'code']) {
    const f = new Intl.NumberFormat('en-US', { style: 'currency', currency: b.currency, currencyDisplay: display });
    if (isEncodable(f.format(1234.5)) || display === 'code') { money = f; break; }
  }
  const int = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
  const num = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const date = new Intl.DateTimeFormat('en-GB', { timeZone: b.timezone, day: '2-digit', month: 'short', year: 'numeric' });
  const plainDate = new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', day: '2-digit', month: 'short', year: 'numeric' });
  const dateTime = new Intl.DateTimeFormat('en-GB', { timeZone: b.timezone, day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false });
  const asDate = (v) => (v instanceof Date ? v : new Date(v));
  const fmt = {
    money: (v) => (v === null || v === undefined || v === '' ? '' : money.format(Number(v))),
    int: (v) => (v === null || v === undefined || v === '' ? '' : int.format(Number(v))),
    number: (v) => (v === null || v === undefined || v === '' ? '' : num.format(Number(v))),
    pct: (v) => (v === null || v === undefined || !Number.isFinite(Number(v)) ? '' : `${num.format(Number(v))}%`),
    date: (v) => {
      if (!v) return '';
      if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return plainDate.format(new Date(`${v}T00:00:00Z`)); // calendar date, no shift
      const d = asDate(v);
      return Number.isNaN(d.getTime()) ? String(v) : date.format(d);
    },
    datetime: (v) => {
      if (!v) return '';
      const d = asDate(v);
      return Number.isNaN(d.getTime()) ? String(v) : dateTime.format(d);
    },
    bool: (v) => (v === null || v === undefined ? '' : v ? 'Yes' : 'No'),
    text: (v) => (v === null || v === undefined ? '' : String(v)),
  };
  fmt.zoneLabel = b.timezone === 'UTC' ? 'UTC' : b.timezone.replace(/_/g, ' ');
  return fmt;
}

const RIGHT_TYPES = new Set(['money', 'int', 'number', 'pct']);
const DEFAULT_WEIGHT = { text: 2, money: 1.15, int: 0.85, number: 1, pct: 0.8, date: 1.05, datetime: 1.4, bool: 0.6 };

class BrandedPdf {
  /**
   * @param {object} opts
   * @param {object} opts.branding  merged branding settings
   * @param {object|null} opts.logo decoded logo image (from branding.logo().decoded)
   * @param {string} opts.title     document title (running header + metadata)
   */
  constructor({ branding, logo, title, landscape = false, subject = '' }) {
    this.b = branding;
    this.fmt = createFormat(branding);
    this.title = title;
    this.brand = branding.primary;
    this.tint = mix(branding.primary, '#ffffff', 0.9);
    this.doc = new PdfDocument({
      landscape,
      info: { Title: title, Author: branding.company_name, Subject: subject, Creator: PRODUCT.name, Producer: `${PRODUCT.name} (created by ${PRODUCT.author})` },
    });
    this.logo = logo ? this.doc.registerImage(logo) : null;
    this.cw = this.doc.width - 2 * M;
    this.bottom = this.doc.height - 54;
    this.y = 0;
    this.onPageBreak = null;
    this.watermark = null;
  }

  // ---- Page furniture ----------------------------------------------------
  firstPage() {
    const d = this.doc;
    const b = this.b;
    d.addPage();
    if (this.watermark) d.watermark(this.watermark);
    d.rect(0, 0, d.width, 6, { fill: this.brand });

    let left = M;
    let leftBottom = 30;
    if (this.logo) {
      const maxH = 46, maxW = 150;
      const scale = Math.min(maxH / this.logo.height, maxW / this.logo.width);
      const w = this.logo.width * scale, h = this.logo.height * scale;
      d.image(this.logo, M, 28, w, h);
      left = M + w + 12;
      leftBottom = 28 + h;
    }
    const nameW = this.cw - (left - M) - 210;
    let y = 30;
    d.text(left, y, d.fit(b.company_name, nameW, 16, true), { size: 16, bold: true, color: INK });
    y += 20;
    if (b.legal_name && b.legal_name !== b.company_name) { d.text(left, y, d.fit(b.legal_name, nameW, 8.5), { size: 8.5, color: MUTED }); y += 11; }
    if (b.tagline) { d.text(left, y, d.fit(b.tagline, nameW, 9), { size: 9, color: this.brand }); y += 12; }
    leftBottom = Math.max(leftBottom, y);

    // Contact block, right aligned.
    const contact = [
      ...String(b.address || '').split('\n').map((s) => s.trim()).filter(Boolean),
      b.phone && `Tel: ${b.phone}`, b.email, b.website, b.tax_id && `Tax ID: ${b.tax_id}`,
    ].filter(Boolean).slice(0, 8);
    let ry = 31;
    for (const line of contact) {
      d.text(d.width - M - 200, ry, d.fit(line, 200, 8.5), { size: 8.5, color: MUTED, align: 'right', width: 200 });
      ry += 11.5;
    }
    const top = Math.max(leftBottom, ry, 74) + 12;
    d.line(M, top, d.width - M, top, { color: RULE, width: 0.75 });
    this.y = top + 18;
  }

  nextPage() {
    const d = this.doc;
    d.addPage();
    if (this.watermark) d.watermark(this.watermark);
    d.rect(0, 0, d.width, 4, { fill: this.brand });
    d.text(M, 18, d.fit(this.b.company_name, this.cw / 2, 9, true), { size: 9, bold: true, color: INK });
    d.text(M + this.cw / 2, 18, d.fit(this.title, this.cw / 2, 9), { size: 9, color: MUTED, align: 'right', width: this.cw / 2 });
    d.line(M, 34, d.width - M, 34, { color: RULE, width: 0.75 });
    this.y = 48;
    if (this.onPageBreak) this.onPageBreak();
  }

  /** Make sure `h` points fit on the current page, breaking if necessary. Returns true if a new page started. */
  ensure(h) {
    if (this.y + h <= this.bottom) return false;
    this.nextPage();
    return true;
  }

  footers() {
    const d = this.doc;
    const total = d.pages.length;
    const left = this.b.report_footer || `${this.b.company_name} · Confidential`;
    for (let i = 0; i < total; i++) {
      d.usePage(i);
      const fy = d.height - 38;
      d.line(M, fy, d.width - M, fy, { color: RULE, width: 0.5 });
      d.text(M, fy + 7, d.fit(left, this.cw - 90, 8), { size: 8, color: MUTED });
      d.text(M, fy + 19, `Generated by ${PRODUCT.name} · Created by ${PRODUCT.author}`, { size: 6.5, color: '#9aa4b5' });
      d.text(d.width - M - 90, fy + 7, `Page ${i + 1} of ${total}`, { size: 8, color: MUTED, align: 'right', width: 90 });
    }
  }

  // ---- Blocks ------------------------------------------------------------
  heading(title, lines = []) {
    const d = this.doc;
    d.text(M, this.y, d.fit(title, this.cw, 18, true), { size: 18, bold: true, color: INK });
    this.y += 25;
    for (const l of lines) {
      for (const w of d.wrap(l, this.cw, 9)) { d.text(M, this.y, w, { size: 9, color: MUTED }); this.y += 12; }
    }
    this.y += 8;
  }

  tiles(items) {
    if (!items || !items.length) return;
    const d = this.doc;
    const gap = 8;
    const w = (this.cw - gap * (items.length - 1)) / items.length;
    this.ensure(52);
    items.forEach((t, i) => {
      const x = M + i * (w + gap);
      d.rect(x, this.y, w, 46, { fill: this.tint });
      d.rect(x, this.y, 3, 46, { fill: this.brand });
      d.text(x + 11, this.y + 9, d.fit(String(t.label).toUpperCase(), w - 16, 7, true), { size: 7, bold: true, color: MUTED });
      d.text(x + 11, this.y + 22, d.fit(t.value, w - 16, 13, true), { size: 13, bold: true, color: INK });
    });
    this.y += 46 + 16;
  }

  paragraph(title, text) {
    if (!text) return;
    const d = this.doc;
    const lines = d.wrap(text, this.cw, 8.5);
    this.ensure(30);
    d.text(M, this.y, title.toUpperCase(), { size: 7.5, bold: true, color: MUTED });
    this.y += 13;
    for (const l of lines) {
      this.ensure(12);
      d.text(M, this.y, l, { size: 8.5, color: INK });
      this.y += 11.5;
    }
    this.y += 10;
  }

  /**
   * columns: [{ key, label, type, w, sum, render }]; rows: objects.
   * options.totals: object of precomputed totals, or true to sum columns flagged `sum`.
   */
  table(columns, rows, { totals = null, totalsLabel = 'Total', emptyText = 'No records match this report.' } = {}) {
    const d = this.doc;
    const cols = columns.filter((c) => c.pdf !== false);
    const weights = cols.map((c) => c.w || DEFAULT_WEIGHT[c.type || 'text'] || 1);
    const sumW = weights.reduce((a, b) => a + b, 0);
    const widths = weights.map((w) => (w / sumW) * this.cw);
    const xs = widths.reduce((acc, w, i) => { acc.push(i ? acc[i - 1] + widths[i - 1] : M); return acc; }, []);
    const pad = 5;
    const cell = (col, row) => (col.render ? col.render(row) : this.fmt[col.type || 'text'](row[col.key]));

    const header = () => {
      d.rect(M, this.y, this.cw, 20, { fill: this.brand });
      cols.forEach((col, i) => {
        const right = RIGHT_TYPES.has(col.type);
        d.text(xs[i] + pad, this.y + 6.5, d.fit(col.label, widths[i] - pad * 2, 7.5, true),
          { size: 7.5, bold: true, color: '#ffffff', align: right ? 'right' : 'left', width: widths[i] - pad * 2 });
      });
      this.y += 20;
    };

    this.ensure(60);
    header();
    const prev = this.onPageBreak;
    this.onPageBreak = header;

    if (!rows.length) {
      d.text(M + pad, this.y + 8, emptyText, { size: 9, color: MUTED });
      this.y += 28;
    }
    rows.forEach((row, r) => {
      this.ensure(16);
      if (r % 2 === 1) d.rect(M, this.y, this.cw, 16, { fill: ZEBRA });
      cols.forEach((col, i) => {
        const right = RIGHT_TYPES.has(col.type);
        d.text(xs[i] + pad, this.y + 4.5, d.fit(cell(col, row), widths[i] - pad * 2, 8),
          { size: 8, color: INK, align: right ? 'right' : 'left', width: widths[i] - pad * 2 });
      });
      this.y += 16;
    });

    let t = totals;
    if (t === true) {
      t = {};
      for (const col of cols) if (col.sum) t[col.key] = rows.reduce((s, row) => s + (Number(row[col.key]) || 0), 0);
    }
    if (t && rows.length) {
      this.ensure(20);
      d.rect(M, this.y, this.cw, 19, { fill: this.tint });
      d.line(M, this.y, M + this.cw, this.y, { color: this.brand, width: 1 });
      d.text(xs[0] + pad, this.y + 5.5, totalsLabel, { size: 8, bold: true, color: INK });
      cols.forEach((col, i) => {
        if (i === 0 || t[col.key] === undefined) return;
        d.text(xs[i] + pad, this.y + 5.5, d.fit(this.fmt[col.type || 'text'](t[col.key]), widths[i] - pad * 2, 8, true),
          { size: 8, bold: true, color: INK, align: RIGHT_TYPES.has(col.type) ? 'right' : 'left', width: widths[i] - pad * 2 });
      });
      this.y += 19;
    }
    this.onPageBreak = prev;
    this.y += 12;
  }

  note(text) {
    if (!text) return;
    this.ensure(14);
    this.doc.text(M, this.y, text, { size: 8, color: MUTED });
    this.y += 14;
  }

  toBuffer() {
    this.footers();
    return this.doc.toBuffer();
  }
}

// ---------------------------------------------------------------------------

/** A generic table report (all CSV exports can also be rendered this way). */
function renderTableReport({ branding, logo, result, generatedBy, maxRows = 5000 }) {
  const rows = result.rows.slice(0, maxRows);
  const pdf = new BrandedPdf({ branding, logo, title: result.title, landscape: Boolean(result.landscape), subject: 'Report' });
  pdf.firstPage();
  const meta = [`Generated ${pdf.fmt.datetime(new Date())} (${pdf.fmt.zoneLabel})${generatedBy ? ` by ${generatedBy}` : ''}`];
  const filters = (result.filters || []).filter(([, v]) => v !== undefined && v !== null && v !== '');
  if (filters.length) meta.push(filters.map(([k, v]) => `${k}: ${v}`).join('   ·   '));
  meta.push(`${pdf.fmt.int(result.rows.length)} record${result.rows.length === 1 ? '' : 's'}`);
  pdf.heading(result.title, meta);
  if (result.summary) pdf.tiles(typeof result.summary === 'function' ? result.summary(pdf.fmt) : result.summary);
  pdf.table(result.columns, rows, { totals: result.columns.some((c) => c.sum) ? true : null });
  if (result.rows.length > rows.length) {
    pdf.note(`Showing the first ${pdf.fmt.int(rows.length)} of ${pdf.fmt.int(result.rows.length)} records. Download the CSV export for the complete data set.`);
  }
  return pdf.toBuffer();
}

/**
 * A business document such as a purchase order, invoice or packing slip.
 * spec: { title, number, status, watermark, meta: [[label, value]], parties: [{ title, lines }],
 *         columns, rows, totals: [[label, value, strong]], notes, terms, signatures: [label] }
 */
function renderDocument({ branding, logo, spec }) {
  const pdf = new BrandedPdf({ branding, logo, title: `${spec.title} ${spec.number}`, subject: spec.title });
  const d = pdf.doc;
  pdf.watermark = spec.watermark || null;
  pdf.firstPage();

  // Title block (left) and key facts (right).
  const top = pdf.y;
  d.text(M, top, spec.title.toUpperCase(), { size: 20, bold: true, color: pdf.brand });
  d.text(M, top + 26, spec.number, { size: 12, bold: true, color: INK });
  if (spec.status) {
    const label = spec.status;
    const w = d.measure(label, 7.5, true) + 12;
    d.rect(M, top + 44, w, 14, { fill: pdf.tint });
    d.text(M + 6, top + 47.5, label, { size: 7.5, bold: true, color: pdf.brand });
  }
  let my = top + 2;
  const mx = d.width - M - 230;
  for (const [k, v] of spec.meta || []) {
    if (!v) continue;
    d.text(mx, my, k, { size: 8.5, color: MUTED });
    d.text(mx + 95, my, d.fit(v, 135, 8.5, true), { size: 8.5, bold: true, color: INK, align: 'right', width: 135 });
    my += 13;
  }
  pdf.y = Math.max(top + 66, my + 6);

  // Party boxes.
  const parties = (spec.parties || []).filter(Boolean);
  if (parties.length) {
    const gap = 12;
    const w = (pdf.cw - gap * (parties.length - 1)) / parties.length;
    const wrapped = parties.map((p) => p.lines.filter(Boolean).flatMap((l) => d.wrap(l, w - 20, 9)).slice(0, 8));
    const h = 30 + Math.max(...wrapped.map((l) => l.length)) * 12;
    parties.forEach((p, i) => {
      const x = M + i * (w + gap);
      d.rect(x, pdf.y, w, h, { stroke: RULE, lineWidth: 0.75 });
      d.rect(x, pdf.y, w, 18, { fill: pdf.tint });
      d.text(x + 10, pdf.y + 5.5, p.title.toUpperCase(), { size: 7.5, bold: true, color: pdf.brand });
      wrapped[i].forEach((line, j) => d.text(x + 10, pdf.y + 25 + j * 12, line, { size: 9, color: INK, bold: j === 0 }));
    });
    pdf.y += h + 18;
  }

  pdf.table(spec.columns, spec.rows, { emptyText: 'This document has no lines.' });

  // Totals, right aligned.
  if (spec.totals && spec.totals.length) {
    const w = 230;
    const x = d.width - M - w;
    pdf.ensure(spec.totals.length * 18 + 6);
    for (const [label, value, strong] of spec.totals) {
      if (strong) d.rect(x, pdf.y - 3, w, 19, { fill: pdf.tint });
      d.text(x + 8, pdf.y + 1.5, label, { size: strong ? 9.5 : 8.5, bold: Boolean(strong), color: strong ? INK : MUTED });
      d.text(x + 8, pdf.y + 1.5, value, { size: strong ? 9.5 : 8.5, bold: true, color: INK, align: 'right', width: w - 16 });
      pdf.y += strong ? 21 : 15;
    }
    pdf.y += 10;
  }

  pdf.paragraph('Notes', spec.notes);
  pdf.paragraph('Terms & conditions', spec.terms);

  if (spec.signatures && spec.signatures.length) {
    pdf.ensure(60);
    pdf.y += 26;
    const gap = 30;
    const w = (pdf.cw - gap * (spec.signatures.length - 1)) / spec.signatures.length;
    spec.signatures.forEach((label, i) => {
      const x = M + i * (w + gap);
      d.line(x, pdf.y, x + w, pdf.y, { color: INK, width: 0.6 });
      d.text(x, pdf.y + 5, label, { size: 8, color: MUTED });
    });
    pdf.y += 24;
  }
  return pdf.toBuffer();
}

module.exports = { renderTableReport, renderDocument, createFormat };
