'use strict';
const { HttpError, CsvResult, FileResult, exportFormat } = require('../http');
const { validate, validateLines, paging, idParam, likeParam } = require('../validate');
const { renderDocument, createFormat } = require('../reports');

const NOW = "strftime('%Y-%m-%dT%H:%M:%fZ','now')";
const pad = (n) => String(n).padStart(6, '0');

function assertUniqueProducts(lines) {
  const seen = new Set();
  lines.forEach((l, i) => {
    if (seen.has(l.product_id)) {
      throw new HttpError(422, 'Each product may appear only once per order', { [`lines[${i}].product_id`]: 'is duplicated' });
    }
    seen.add(l.product_id);
  });
}

function assertActiveParty(db, table, id, label) {
  const row = db.get(`SELECT id, name, active FROM ${table} WHERE id = ?`, id);
  if (!row) throw new HttpError(422, `${label} not found`, { [`${table === 'suppliers' ? 'supplier' : 'customer'}_id`]: 'does not exist' });
  if (!row.active) throw new HttpError(409, `${label} "${row.name}" is inactive`);
  return row;
}

module.exports = function registerOrders(r, { db, inv, audit, branding, approvals }) {
  const addressLines = (...parts) => parts.flatMap((p) => String(p || '').split('\n')).map((x) => x.trim()).filter(Boolean);
  const pdfDoc = (c, filename, build) => {
    const b = branding.get();
    const logo = branding.logo();
    const spec = build(createFormat(b), b);
    const data = renderDocument({ branding: b, logo: logo && logo.decoded, spec });
    audit(c, 'document.generate', spec.entity, spec.entityId, { document: spec.title, number: spec.number });
    return new FileResult(filename, 'application/pdf', data, { inline: c.query.inline === '1' });
  };
  // =========================================================================
  // Purchase orders: DRAFT -> ORDERED (approved) -> PARTIAL -> RECEIVED
  // =========================================================================
  const PO_HEADER = {
    supplier_id: { type: 'id', required: true },
    warehouse_id: { type: 'id', required: true },
    expected_date: { type: 'date' },
    notes: { type: 'text', max: 2000 },
  };
  const PO_LINE = {
    product_id: { type: 'id', required: true },
    qty: { type: 'int', required: true, min: 1, max: 1e9 },
    unit_cost: { type: 'number', min: 0, max: 1e9 },
  };

  const loadPo = (id) => {
    const po = db.get(
      `SELECT po.*, s.name AS supplier_name, s.email AS supplier_email, w.code AS warehouse_code, w.name AS warehouse_name,
              cu.name AS created_by_name, au.name AS approved_by_name
       FROM purchase_orders po JOIN suppliers s ON s.id = po.supplier_id JOIN warehouses w ON w.id = po.warehouse_id
       LEFT JOIN users cu ON cu.id = po.created_by LEFT JOIN users au ON au.id = po.approved_by WHERE po.id = ?`, id);
    if (!po) throw new HttpError(404, 'Purchase order not found');
    po.lines = db.all(
      `SELECT l.*, p.sku, p.name AS product_name, p.unit, ROUND(l.qty_ordered * l.unit_cost, 2) AS line_total
       FROM po_lines l JOIN products p ON p.id = l.product_id WHERE l.po_id = ? ORDER BY l.id`, id);
    po.total = Math.round(po.lines.reduce((s, l) => s + l.qty_ordered * l.unit_cost, 0) * 100) / 100;
    return po;
  };

  const writePoLines = (poId, lines) => {
    db.run('DELETE FROM po_lines WHERE po_id = ?', poId);
    for (const l of lines) {
      const p = inv.product(l.product_id);
      db.run('INSERT INTO po_lines (po_id, product_id, qty_ordered, unit_cost) VALUES (?,?,?,?)',
        poId, l.product_id, l.qty, l.unit_cost ?? p.cost);
    }
  };

  r.get('/api/purchase-orders', 'read', (c) => {
    const where = [];
    const params = [];
    if (c.query.status) { where.push('po.status = ?'); params.push(c.query.status); }
    if (c.query.supplier_id) { where.push('po.supplier_id = ?'); params.push(Number(c.query.supplier_id)); }
    if (c.query.q) { where.push(`(po.number LIKE ? ESCAPE '\\' OR s.name LIKE ? ESCAPE '\\')`); params.push(likeParam(c.query.q), likeParam(c.query.q)); }
    const sql = `
      SELECT po.id, po.number, po.status, po.expected_date, po.created_at, po.ordered_at,
             s.name AS supplier_name, w.code AS warehouse_code,
             (SELECT COUNT(*) FROM po_lines l WHERE l.po_id = po.id) AS line_count,
             (SELECT ROUND(COALESCE(SUM(l.qty_ordered * l.unit_cost), 0), 2) FROM po_lines l WHERE l.po_id = po.id) AS total,
             (SELECT COALESCE(SUM(l.qty_received), 0) FROM po_lines l WHERE l.po_id = po.id) AS qty_received,
             (SELECT COALESCE(SUM(l.qty_ordered), 0) FROM po_lines l WHERE l.po_id = po.id) AS qty_ordered
      FROM purchase_orders po JOIN suppliers s ON s.id = po.supplier_id JOIN warehouses w ON w.id = po.warehouse_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}`;
    if (exportFormat(c.query)) {
      const rows = db.all(`${sql} ORDER BY po.id DESC LIMIT 100000`, ...params);
      return new CsvResult('purchase-orders.csv', [
        { key: 'number', label: 'PO', w: 1.1 }, { key: 'status', label: 'Status', w: 1 }, { key: 'supplier_name', label: 'Supplier', w: 2.2 },
        { key: 'warehouse_code', label: 'Warehouse', w: 0.9 }, { key: 'expected_date', label: 'Expected', type: 'date' },
        { key: 'qty_ordered', label: 'Qty ordered', type: 'int', sum: true }, { key: 'qty_received', label: 'Qty received', type: 'int', sum: true },
        { key: 'total', label: 'Total', type: 'money', sum: true }, { key: 'created_at', label: 'Created', type: 'date' },
      ], rows, {
        title: 'Purchase orders', landscape: true,
        filters: [['Status', c.query.status], ['Search', c.query.q]],
        summary: (f) => [
          { label: 'Orders', value: f.int(rows.length) },
          { label: 'Open', value: f.int(rows.filter((x) => ['ORDERED', 'PARTIAL'].includes(x.status)).length) },
          { label: 'Total value', value: f.money(rows.filter((x) => x.status !== 'CANCELLED').reduce((s, x) => s + x.total, 0)) },
        ],
      });
    }
    const { limit, offset } = paging(c.query);
    const total = db.get(`SELECT COUNT(*) AS n FROM (${sql})`, ...params).n;
    return { items: db.all(`${sql} ORDER BY po.id DESC LIMIT ? OFFSET ?`, ...params, limit, offset), total, limit, offset };
  });

  r.get('/api/purchase-orders/:id', 'read', (c) => loadPo(idParam(c.params.id)));

  r.get('/api/purchase-orders/:id/pdf', 'read', (c) => {
    const po = loadPo(idParam(c.params.id));
    const sup = db.get('SELECT * FROM suppliers WHERE id = ?', po.supplier_id);
    const wh = db.get('SELECT * FROM warehouses WHERE id = ?', po.warehouse_id);
    return pdfDoc(c, `${po.number}.pdf`, (f, b) => ({
      entity: 'purchase_order', entityId: po.id,
      title: 'Purchase order', number: po.number, status: po.status,
      watermark: po.status === 'DRAFT' ? 'DRAFT' : po.status === 'CANCELLED' ? 'CANCELLED' : null,
      meta: [
        ['Order date', f.date(po.ordered_at || po.created_at)], ['Expected delivery', f.date(po.expected_date)],
        ['Raised by', po.created_by_name], ['Approved by', po.approved_by_name], ['Currency', b.currency],
      ],
      parties: [
        { title: 'Supplier', lines: [sup.name, sup.contact_name && `Attn: ${sup.contact_name}`, ...addressLines(sup.address), sup.phone, sup.email] },
        { title: 'Deliver to', lines: [b.company_name, `${wh.name} (${wh.code})`, ...addressLines(wh.address || b.address)] },
      ],
      columns: [
        { key: 'sku', label: 'SKU', w: 1.2 }, { key: 'product_name', label: 'Description', w: 3 },
        { key: 'unit', label: 'Unit', w: 0.6 }, { key: 'qty_ordered', label: 'Qty', type: 'int', w: 0.7 },
        { key: 'qty_received', label: 'Received', type: 'int', w: 0.8 },
        { key: 'unit_cost', label: 'Unit cost', type: 'money', w: 1.1 }, { key: 'line_total', label: 'Amount', type: 'money', w: 1.2 },
      ],
      rows: po.lines,
      totals: [['Total units', f.int(po.lines.reduce((t, l) => t + l.qty_ordered, 0))], ['Order total', f.money(po.total), true]],
      notes: po.notes, terms: b.document_terms,
      signatures: ['Authorised signature', 'Date'],
    }));
  });

  r.post('/api/purchase-orders', 'orders:write', (c) => {
    const h = validate(c.body, PO_HEADER);
    const lines = validateLines(c.body.lines, PO_LINE);
    assertUniqueProducts(lines);
    const id = db.tx(() => {
      assertActiveParty(db, 'suppliers', h.supplier_id, 'Supplier');
      inv.warehouse(h.warehouse_id);
      const poId = db.run(
        'INSERT INTO purchase_orders (supplier_id, warehouse_id, expected_date, notes, created_by) VALUES (?,?,?,?,?)',
        h.supplier_id, h.warehouse_id, h.expected_date, h.notes, c.user.id).id;
      db.run('UPDATE purchase_orders SET number = ? WHERE id = ?', `PO-${pad(poId)}`, poId);
      writePoLines(poId, lines);
      return poId;
    });
    const po = loadPo(id);
    audit(c, 'po.create', 'purchase_order', id, { number: po.number, total: po.total, lines: lines.length });
    c.status = 201;
    return po;
  });

  r.put('/api/purchase-orders/:id', 'orders:write', (c) => {
    const id = idParam(c.params.id);
    const h = validate(c.body, PO_HEADER);
    const lines = validateLines(c.body.lines, PO_LINE);
    assertUniqueProducts(lines);
    db.tx(() => {
      const po = loadPo(id);
      if (po.status !== 'DRAFT') throw new HttpError(409, `Only draft orders can be edited (status is ${po.status})`);
      assertActiveParty(db, 'suppliers', h.supplier_id, 'Supplier');
      inv.warehouse(h.warehouse_id);
      db.run(`UPDATE purchase_orders SET supplier_id = ?, warehouse_id = ?, expected_date = ?, notes = ?, updated_at = ${NOW} WHERE id = ?`,
        h.supplier_id, h.warehouse_id, h.expected_date, h.notes, id);
      writePoLines(id, lines);
    });
    const po = loadPo(id);
    audit(c, 'po.update', 'purchase_order', id, { number: po.number, total: po.total });
    return po;
  });

  r.post('/api/purchase-orders/:id/submit', 'orders:approve', (c) => {
    const id = idParam(c.params.id);
    const po = loadPo(id);
    if (po.status !== 'DRAFT') throw new HttpError(409, `Only draft orders can be approved (status is ${po.status})`);
    db.run(`UPDATE purchase_orders SET status = 'ORDERED', approved_by = ?, ordered_at = ${NOW}, updated_at = ${NOW} WHERE id = ?`, c.user.id, id);
    audit(c, 'po.approve', 'purchase_order', id, { number: po.number, total: po.total });
    return loadPo(id);
  });

  r.post('/api/purchase-orders/:id/receive', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    const lines = validateLines(c.body.lines, {
      line_id: { type: 'id', required: true },
      qty: { type: 'int', required: true, min: 0, max: 1e9 },
    }).filter((l) => l.qty > 0);
    if (!lines.length) throw new HttpError(422, 'Enter a quantity to receive on at least one line');
    const note = typeof c.body.note === 'string' ? c.body.note.slice(0, 500) : null;

    const received = db.tx(() => {
      const po = loadPo(id);
      if (!['ORDERED', 'PARTIAL'].includes(po.status)) throw new HttpError(409, `Cannot receive against a ${po.status} order`);
      const out = [];
      for (const l of lines) {
        const line = po.lines.find((x) => x.id === l.line_id);
        if (!line) throw new HttpError(422, `Line #${l.line_id} does not belong to ${po.number}`);
        const outstanding = line.qty_ordered - line.qty_received;
        if (l.qty > outstanding) throw new HttpError(409, `${line.sku}: cannot receive ${l.qty}, only ${outstanding} outstanding`);
        db.run('UPDATE po_lines SET qty_received = qty_received + ? WHERE id = ?', l.qty, line.id);
        inv.move({
          productId: line.product_id, warehouseId: po.warehouse_id, qty: l.qty, type: 'PO_RECEIPT',
          unitCost: line.unit_cost, refType: 'PO', refId: po.number, note, userId: c.user.id,
        });
        out.push({ sku: line.sku, qty: l.qty });
      }
      const remaining = db.get('SELECT SUM(qty_ordered - qty_received) AS n FROM po_lines WHERE po_id = ?', id).n;
      db.run(`UPDATE purchase_orders SET status = ?, updated_at = ${NOW} WHERE id = ?`, remaining === 0 ? 'RECEIVED' : 'PARTIAL', id);
      return out;
    });
    const po = loadPo(id);
    audit(c, 'po.receive', 'purchase_order', id, { number: po.number, received, status: po.status });
    return po;
  });

  r.post('/api/purchase-orders/:id/cancel', 'orders:approve', (c) => {
    const id = idParam(c.params.id);
    const po = loadPo(id);
    if (!['DRAFT', 'ORDERED'].includes(po.status)) {
      throw new HttpError(409, po.status === 'PARTIAL'
        ? 'Partially received orders cannot be cancelled'
        : `Cannot cancel a ${po.status} order`);
    }
    db.run(`UPDATE purchase_orders SET status = 'CANCELLED', updated_at = ${NOW} WHERE id = ?`, id);
    audit(c, 'po.cancel', 'purchase_order', id, { number: po.number });
    return loadPo(id);
  });

  r.delete('/api/purchase-orders/:id', 'orders:write', (c) => {
    const id = idParam(c.params.id);
    const po = loadPo(id);
    if (po.status !== 'DRAFT') throw new HttpError(409, 'Only draft orders can be deleted; cancel it instead');
    db.run('DELETE FROM purchase_orders WHERE id = ?', id);
    audit(c, 'po.delete', 'purchase_order', id, { number: po.number });
    return { deleted: true };
  });

  // =========================================================================
  // Sales orders: DRAFT -> CONFIRMED (stock reserved) -> SHIPPED (stock issued)
  // =========================================================================
  const SO_HEADER = {
    customer_id: { type: 'id', required: true },
    warehouse_id: { type: 'id', required: true },
    notes: { type: 'text', max: 2000 },
  };
  const SO_LINE = {
    product_id: { type: 'id', required: true },
    qty: { type: 'int', required: true, min: 1, max: 1e9 },
    unit_price: { type: 'number', min: 0, max: 1e9 },
  };

  const loadSo = (id) => {
    const so = db.get(
      `SELECT so.*, cu.name AS customer_name, cu.email AS customer_email, cu.address AS customer_address,
              w.code AS warehouse_code, w.name AS warehouse_name, u.name AS created_by_name
       FROM sales_orders so JOIN customers cu ON cu.id = so.customer_id JOIN warehouses w ON w.id = so.warehouse_id
       LEFT JOIN users u ON u.id = so.created_by WHERE so.id = ?`, id);
    if (!so) throw new HttpError(404, 'Sales order not found');
    so.lines = db.all(
      `SELECT l.*, p.sku, p.name AS product_name, p.unit, ROUND((l.qty - l.qty_returned) * l.unit_price, 2) AS line_total,
              l.qty - l.qty_returned AS qty_net, COALESCE(s.on_hand - s.reserved, 0) AS available
       FROM so_lines l JOIN products p ON p.id = l.product_id
       LEFT JOIN stock s ON s.product_id = l.product_id AND s.warehouse_id = ?
       WHERE l.so_id = ? ORDER BY l.id`, so.warehouse_id, id);
    so.total = Math.round(so.lines.reduce((s, l) => s + l.qty_net * l.unit_price, 0) * 100) / 100;
    so.returned_qty = so.lines.reduce((s, l) => s + l.qty_returned, 0);
    so.returned_value = Math.round(so.lines.reduce((s, l) => s + l.qty_returned * l.unit_price, 0) * 100) / 100;
    if (so.status === 'SHIPPED') {
      const cogs = so.lines.reduce((s, l) => s + l.qty_net * (l.unit_cost || 0), 0);
      so.cogs = Math.round(cogs * 100) / 100;
      so.margin = Math.round((so.total - cogs) * 100) / 100;
    }
    so.pending_approval = approvals.pendingFor('sales_order', so.id);
    return so;
  };

  const writeSoLines = (soId, lines) => {
    db.run('DELETE FROM so_lines WHERE so_id = ?', soId);
    for (const l of lines) {
      const p = inv.product(l.product_id);
      if (!p.active) throw new HttpError(409, `Product ${p.sku} is inactive`);
      db.run('INSERT INTO so_lines (so_id, product_id, qty, unit_price) VALUES (?,?,?,?)',
        soId, l.product_id, l.qty, l.unit_price ?? p.price);
    }
  };

  r.get('/api/sales-orders', 'read', (c) => {
    const where = [];
    const params = [];
    if (c.query.status) { where.push('so.status = ?'); params.push(c.query.status); }
    if (c.query.customer_id) { where.push('so.customer_id = ?'); params.push(Number(c.query.customer_id)); }
    if (c.query.q) { where.push(`(so.number LIKE ? ESCAPE '\\' OR cu.name LIKE ? ESCAPE '\\')`); params.push(likeParam(c.query.q), likeParam(c.query.q)); }
    const sql = `
      SELECT so.id, so.number, so.status, so.created_at, so.confirmed_at, so.shipped_at,
             cu.name AS customer_name, w.code AS warehouse_code,
             (SELECT COUNT(*) FROM so_lines l WHERE l.so_id = so.id) AS line_count,
             (SELECT ROUND(COALESCE(SUM((l.qty - l.qty_returned) * l.unit_price), 0), 2) FROM so_lines l WHERE l.so_id = so.id) AS total
      FROM sales_orders so JOIN customers cu ON cu.id = so.customer_id JOIN warehouses w ON w.id = so.warehouse_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}`;
    if (exportFormat(c.query)) {
      const rows = db.all(`${sql} ORDER BY so.id DESC LIMIT 100000`, ...params);
      return new CsvResult('sales-orders.csv', [
        { key: 'number', label: 'SO', w: 1.1 }, { key: 'status', label: 'Status', w: 1 }, { key: 'customer_name', label: 'Customer', w: 2.4 },
        { key: 'warehouse_code', label: 'Location', w: 0.9 }, { key: 'line_count', label: 'Lines', type: 'int' },
        { key: 'total', label: 'Total', type: 'money', sum: true },
        { key: 'created_at', label: 'Created', type: 'date' }, { key: 'shipped_at', label: 'Shipped', type: 'date' },
      ], rows, {
        title: 'Sales orders', landscape: true,
        filters: [['Status', c.query.status], ['Search', c.query.q]],
        summary: (f) => [
          { label: 'Orders', value: f.int(rows.length) },
          { label: 'To ship', value: f.int(rows.filter((x) => x.status === 'CONFIRMED').length) },
          { label: 'Shipped value', value: f.money(rows.filter((x) => x.status === 'SHIPPED').reduce((s, x) => s + x.total, 0)) },
        ],
      });
    }
    const { limit, offset } = paging(c.query);
    const total = db.get(`SELECT COUNT(*) AS n FROM (${sql})`, ...params).n;
    return { items: db.all(`${sql} ORDER BY so.id DESC LIMIT ? OFFSET ?`, ...params, limit, offset), total, limit, offset };
  });

  r.get('/api/sales-orders/:id', 'read', (c) => loadSo(idParam(c.params.id)));

  // doc = confirmation | invoice | packing
  r.get('/api/sales-orders/:id/pdf', 'read', (c) => {
    const so = loadSo(idParam(c.params.id));
    const kind = ['confirmation', 'invoice', 'packing'].includes(c.query.doc) ? c.query.doc : 'confirmation';
    if (kind === 'invoice' && so.status !== 'SHIPPED') throw new HttpError(409, 'An invoice can only be issued after the order has shipped');
    if (kind === 'packing' && !['CONFIRMED', 'SHIPPED'].includes(so.status)) throw new HttpError(409, 'A packing slip needs a confirmed or shipped order');
    const cust = db.get('SELECT * FROM customers WHERE id = ?', so.customer_id);
    const wh = db.get('SELECT * FROM warehouses WHERE id = ?', so.warehouse_id);
    const title = { confirmation: 'Order confirmation', invoice: 'Invoice', packing: 'Packing slip' }[kind];
    const number = kind === 'invoice' ? so.number.replace(/^SO-/, 'INV-') : so.number;
    const priced = kind !== 'packing';
    return pdfDoc(c, `${number}${kind === 'packing' ? '-packing-slip' : kind === 'confirmation' ? '-confirmation' : ''}.pdf`, (f, b) => ({
      entity: 'sales_order', entityId: so.id,
      title, number, status: so.status,
      watermark: so.status === 'DRAFT' ? 'DRAFT' : so.status === 'CANCELLED' ? 'CANCELLED' : null,
      meta: [
        [kind === 'invoice' ? 'Invoice date' : 'Order date', f.date(kind === 'invoice' ? so.shipped_at : so.confirmed_at || so.created_at)],
        ['Sales order', kind === 'invoice' ? so.number : null],
        ['Shipped', kind !== 'invoice' ? f.date(so.shipped_at) : null],
        ['Ship from', `${wh.name} (${wh.code})`], ['Prepared by', so.created_by_name], ['Currency', priced ? b.currency : null],
      ],
      parties: [
        { title: kind === 'invoice' ? 'Bill to' : 'Customer', lines: [cust.name, ...addressLines(cust.address), cust.phone, cust.email] },
        { title: 'Ship to', lines: [cust.name, ...addressLines(cust.address)] },
      ],
      columns: [
        { key: 'sku', label: 'SKU', w: 1.2 }, { key: 'product_name', label: 'Description', w: 3.2 },
        { key: 'unit', label: 'Unit', w: 0.6 }, { key: 'qty', label: 'Qty', type: 'int', w: 0.7 },
        ...(so.returned_qty && kind !== 'packing' ? [{ key: 'qty_returned', label: 'Returned', type: 'int', w: 0.8 }] : []),
        ...(priced
          ? [{ key: 'unit_price', label: 'Unit price', type: 'money', w: 1.1 }, { key: 'line_total', label: 'Amount', type: 'money', w: 1.2 }]
          : [{ key: 'check', label: 'Packed', w: 0.8, render: () => '[   ]' }]),
      ],
      rows: so.lines,
      totals: priced
        ? [
          ['Total units', f.int(so.lines.reduce((t, l) => t + l.qty_net, 0))],
          ...(so.returned_qty ? [['Credited for returns', `- ${f.money(so.returned_value)}`]] : []),
          [kind === 'invoice' ? 'Amount due' : 'Order total', f.money(so.total), true],
        ]
        : [['Total units', f.int(so.lines.reduce((t, l) => t + l.qty, 0)), true]],
      notes: so.notes, terms: priced ? b.document_terms : null,
      signatures: kind === 'packing' ? ['Packed by', 'Received by (customer)'] : kind === 'invoice' ? null : ['Authorised signature'],
    }));
  });

  r.post('/api/sales-orders', 'orders:write', (c) => {
    const h = validate(c.body, SO_HEADER);
    const lines = validateLines(c.body.lines, SO_LINE);
    assertUniqueProducts(lines);
    const id = db.tx(() => {
      assertActiveParty(db, 'customers', h.customer_id, 'Customer');
      inv.warehouse(h.warehouse_id);
      const soId = db.run('INSERT INTO sales_orders (customer_id, warehouse_id, notes, created_by) VALUES (?,?,?,?)',
        h.customer_id, h.warehouse_id, h.notes, c.user.id).id;
      db.run('UPDATE sales_orders SET number = ? WHERE id = ?', `SO-${pad(soId)}`, soId);
      writeSoLines(soId, lines);
      return soId;
    });
    const so = loadSo(id);
    audit(c, 'so.create', 'sales_order', id, { number: so.number, total: so.total, lines: lines.length });
    c.status = 201;
    return so;
  });

  r.put('/api/sales-orders/:id', 'orders:write', (c) => {
    const id = idParam(c.params.id);
    const h = validate(c.body, SO_HEADER);
    const lines = validateLines(c.body.lines, SO_LINE);
    assertUniqueProducts(lines);
    db.tx(() => {
      const so = loadSo(id);
      if (so.status !== 'DRAFT') throw new HttpError(409, `Only draft orders can be edited (status is ${so.status}). Use "Request change" for confirmed or invoiced orders.`);
      assertActiveParty(db, 'customers', h.customer_id, 'Customer');
      inv.warehouse(h.warehouse_id);
      db.run(`UPDATE sales_orders SET customer_id = ?, warehouse_id = ?, notes = ?, updated_at = ${NOW} WHERE id = ?`,
        h.customer_id, h.warehouse_id, h.notes, id);
      writeSoLines(id, lines);
    });
    const so = loadSo(id);
    audit(c, 'so.update', 'sales_order', id, { number: so.number, total: so.total });
    return so;
  });

  r.post('/api/sales-orders/:id/confirm', 'orders:write', (c) => {
    const id = idParam(c.params.id);
    db.tx(() => {
      const so = loadSo(id);
      if (so.status !== 'DRAFT') throw new HttpError(409, `Only draft orders can be confirmed (status is ${so.status})`);
      inv.warehouse(so.warehouse_id);
      const shortages = [];
      for (const l of so.lines) {
        const s = inv.stockRow(l.product_id, so.warehouse_id);
        const available = s.on_hand - s.reserved;
        if (available < l.qty) shortages.push({ sku: l.sku, requested: l.qty, available });
      }
      if (shortages.length) {
        const list = shortages.map((s) => `${s.sku} (need ${s.requested}, have ${s.available})`).join('; ');
        throw new HttpError(409, `Insufficient stock in ${so.warehouse_code}: ${list}`, { shortages });
      }
      for (const l of so.lines) inv.reserve(l.product_id, so.warehouse_id, l.qty);
      db.run(`UPDATE sales_orders SET status = 'CONFIRMED', confirmed_at = ${NOW}, updated_at = ${NOW} WHERE id = ?`, id);
    });
    const so = loadSo(id);
    audit(c, 'so.confirm', 'sales_order', id, { number: so.number, total: so.total });
    return so;
  });

  r.post('/api/sales-orders/:id/ship', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    db.tx(() => {
      const so = loadSo(id);
      if (so.status !== 'CONFIRMED') throw new HttpError(409, `Only confirmed orders can be shipped (status is ${so.status})`);
      approvals.assertNoPending('sales_order', id);
      for (const l of so.lines) {
        inv.release(l.product_id, so.warehouse_id, l.qty);
        const p = inv.product(l.product_id);
        db.run('UPDATE so_lines SET unit_cost = ? WHERE id = ?', p.avg_cost, l.id);
        inv.move({
          productId: l.product_id, warehouseId: so.warehouse_id, qty: -l.qty, type: 'SALE',
          unitCost: p.avg_cost, refType: 'SO', refId: so.number, userId: c.user.id,
        });
      }
      db.run(`UPDATE sales_orders SET status = 'SHIPPED', shipped_at = ${NOW}, updated_at = ${NOW} WHERE id = ?`, id);
    });
    const so = loadSo(id);
    audit(c, 'so.ship', 'sales_order', id, { number: so.number, total: so.total, cogs: so.cogs });
    return so;
  });

  const cancelSo = (c, id, ref) => {
    const so = loadSo(id);
    if (!['DRAFT', 'CONFIRMED'].includes(so.status)) throw new HttpError(409, `Cannot cancel a ${so.status} order`);
    if (so.status === 'CONFIRMED') for (const l of so.lines) inv.release(l.product_id, so.warehouse_id, l.qty);
    db.run(`UPDATE sales_orders SET status = 'CANCELLED', updated_at = ${NOW} WHERE id = ?`, id);
    audit(c, 'so.cancel', 'sales_order', id, { number: so.number, approval: ref || undefined });
    return loadSo(id);
  };
  approvals.register('SO_CANCEL', 'sales_order', (c, payload, id, ref) => {
    const so = loadSo(id);
    if (so.status !== 'CONFIRMED') throw new HttpError(409, `${so.number} is now ${so.status}; the cancellation no longer applies`);
    return cancelSo(c, id, ref);
  });

  r.post('/api/sales-orders/:id/cancel', 'orders:write', (c) => {
    const id = idParam(c.params.id);
    const so = loadSo(id);
    if (so.status === 'CONFIRMED') {
      // Cancelling a confirmed order needs a manager (agents get a pending request).
      const out = approvals.submit(c, {
        type: 'SO_CANCEL', entityId: id, payload: { number: so.number, total: so.total },
        reason: c.body.reason, summary: `Cancel ${so.number} (${so.customer_name}, ${so.lines.length} line(s))`,
      });
      if (!out.applied) { c.status = 202; return { pending_approval: out.request }; }
      return out.result;
    }
    approvals.assertNoPending('sales_order', id);
    return db.tx(() => cancelSo(c, id, null));
  });

  // ---- Change a confirmed order or a shipped invoice (manager approval for agents) ----
  //  CONFIRMED: { lines: [{ product_id, qty, unit_price }], notes }  (full replacement, stock re-reserved)
  //  SHIPPED:   { lines: [{ line_id, unit_price, return_qty }], restock_location_id, condition, notes }
  //             (price corrections and customer returns; returned goods go back into stock or are written off)
  const applyAmend = (c, p, id, ref) => {
    const so = loadSo(id);
    if (so.status !== p.status) throw new HttpError(409, `${so.number} changed from ${p.status} to ${so.status} since the request; please submit a new request`);
    const tag = ref ? ` (${ref})` : '';
    if (so.status === 'CONFIRMED') {
      for (const l of so.lines) inv.release(l.product_id, so.warehouse_id, l.qty);
      writeSoLines(id, p.lines);
      const shortages = [];
      for (const l of p.lines) {
        if (!inv.reserve(l.product_id, so.warehouse_id, l.qty)) {
          const st = inv.stockRow(l.product_id, so.warehouse_id);
          shortages.push({ sku: inv.product(l.product_id).sku, requested: l.qty, available: st.on_hand - st.reserved });
        }
      }
      if (shortages.length) {
        throw new HttpError(409, `Insufficient stock in ${so.warehouse_code}: ${shortages.map((x) => `${x.sku} (need ${x.requested}, have ${x.available})`).join('; ')}`, { shortages });
      }
    } else if (so.status === 'SHIPPED') {
      const loc = p.restock_location_id || so.warehouse_id;
      for (const x of p.lines) {
        const l = so.lines.find((y) => y.id === x.line_id);
        if (!l) throw new HttpError(422, `Line ${x.line_id} is not on ${so.number}`);
        const ret = x.return_qty || 0;
        if (l.qty_returned + ret > l.qty) throw new HttpError(409, `${l.sku}: only ${l.qty - l.qty_returned} unit(s) can still be returned`);
        if (x.unit_price !== undefined && x.unit_price !== null) db.run('UPDATE so_lines SET unit_price = ? WHERE id = ?', x.unit_price, l.id);
        if (ret > 0) {
          db.run('UPDATE so_lines SET qty_returned = qty_returned + ? WHERE id = ?', ret, l.id);
          inv.move({ productId: l.product_id, warehouseId: loc, qty: ret, type: 'RECEIPT', unitCost: l.unit_cost ?? null,
            refType: 'SO', refId: so.number, note: `Customer return on ${so.number}${tag}`, userId: c.user.id });
          if (p.condition === 'DAMAGED') {
            inv.move({ productId: l.product_id, warehouseId: loc, qty: -ret, type: 'ADJUSTMENT',
              refType: 'SO', refId: so.number, note: `Damaged customer return on ${so.number}: written off${tag}`, userId: c.user.id });
          }
        }
      }
    } else {
      throw new HttpError(409, `${so.number} is ${so.status}; only confirmed or shipped orders can be changed this way`);
    }
    if (p.notes !== undefined) db.run('UPDATE sales_orders SET notes = ? WHERE id = ?', p.notes, id);
    db.run(`UPDATE sales_orders SET updated_at = ${NOW} WHERE id = ?`, id);
    const after = loadSo(id);
    audit(c, 'so.amend', 'sales_order', id, { number: so.number, approval: ref || undefined, total_before: so.total, total_after: after.total, summary: p.summary });
    return after;
  };
  approvals.register('SO_AMEND', 'sales_order', applyAmend);

  r.post('/api/sales-orders/:id/amend', 'orders:write', (c) => {
    const id = idParam(c.params.id);
    const so = loadSo(id);
    const money = (v) => Number(v).toFixed(2);
    let payload;
    const changes = [];
    const preview = [];
    if (so.status === 'CONFIRMED') {
      const lines = validateLines(c.body.lines, SO_LINE);
      assertUniqueProducts(lines);
      const before = new Map(so.lines.map((l) => [l.product_id, l]));
      for (const l of lines) {
        const p = inv.product(l.product_id);
        const b = before.get(l.product_id);
        const price = l.unit_price ?? (b ? b.unit_price : p.price);
        l.unit_price = price;
        preview.push({ sku: p.sku, name: p.name, qty_before: b ? b.qty : 0, qty_after: l.qty, price_before: b ? b.unit_price : null, price_after: price });
        if (!b) changes.push(`add ${l.qty} × ${p.sku}`);
        else if (b.qty !== l.qty || b.unit_price !== price) changes.push(`${p.sku} ${b.qty} @ ${money(b.unit_price)} → ${l.qty} @ ${money(price)}`);
      }
      for (const b of so.lines) {
        if (!lines.some((l) => l.product_id === b.product_id)) {
          changes.push(`remove ${b.sku}`);
          preview.push({ sku: b.sku, name: b.product_name, qty_before: b.qty, qty_after: 0, price_before: b.unit_price, price_after: null });
        }
      }
      payload = { status: 'CONFIRMED', lines };
    } else if (so.status === 'SHIPPED') {
      const h = validate(c.body, {
        restock_location_id: { type: 'id' },
        condition: { type: 'enum', values: ['GOOD', 'DAMAGED'], default: 'GOOD' },
      });
      const lines = validateLines(c.body.lines, {
        line_id: { type: 'id', required: true },
        unit_price: { type: 'number', min: 0, max: 1e9 },
        return_qty: { type: 'int', min: 0, max: 1e9, default: 0 },
      });
      const out = [];
      for (const x of lines) {
        const l = so.lines.find((y) => y.id === x.line_id);
        if (!l) throw new HttpError(422, `Line ${x.line_id} is not on ${so.number}`);
        const priceChanged = x.unit_price !== null && x.unit_price !== undefined && x.unit_price !== l.unit_price;
        if (x.return_qty > l.qty - l.qty_returned) throw new HttpError(422, `${l.sku}: at most ${l.qty - l.qty_returned} unit(s) can be returned`);
        if (!priceChanged && !x.return_qty) continue;
        out.push({ line_id: l.id, unit_price: priceChanged ? x.unit_price : null, return_qty: x.return_qty });
        preview.push({ sku: l.sku, name: l.product_name, qty_before: l.qty - l.qty_returned, qty_after: l.qty - l.qty_returned - x.return_qty,
          price_before: l.unit_price, price_after: priceChanged ? x.unit_price : l.unit_price, return_qty: x.return_qty });
        if (x.return_qty) changes.push(`return ${x.return_qty} × ${l.sku}${h.condition === 'DAMAGED' ? ' (damaged)' : ''}`);
        if (priceChanged) changes.push(`${l.sku} price ${money(l.unit_price)} → ${money(x.unit_price)}`);
      }
      const loc = h.restock_location_id || so.warehouse_id;
      if (h.restock_location_id) inv.warehouse(h.restock_location_id);
      payload = { status: 'SHIPPED', lines: out, restock_location_id: loc, condition: h.condition };
      if (out.some((x) => x.return_qty)) {
        const w = db.get('SELECT code FROM warehouses WHERE id = ?', loc);
        payload.restock_code = w && w.code;
      }
    } else {
      throw new HttpError(409, so.status === 'DRAFT' ? 'Draft orders can be edited directly' : `${so.status} orders cannot be changed`);
    }
    if (c.body.notes !== undefined && (c.body.notes || null) !== (so.notes || null)) {
      payload.notes = c.body.notes ? String(c.body.notes).slice(0, 2000) : null;
      changes.push('notes updated');
    }
    if (!changes.length) throw new HttpError(422, 'Nothing has changed');
    payload.summary = changes.join('; ');
    payload.preview = preview;
    payload.number = so.number;
    payload.total_before = so.total;
    const out = approvals.submit(c, {
      type: 'SO_AMEND', entityId: id, payload, reason: c.body.reason,
      summary: `${so.number}: ${payload.summary}`.slice(0, 500),
    });
    if (!out.applied) { c.status = 202; return { pending_approval: out.request }; }
    return out.result;
  });

  r.delete('/api/sales-orders/:id', 'orders:write', (c) => {
    const id = idParam(c.params.id);
    const so = loadSo(id);
    if (so.status !== 'DRAFT') throw new HttpError(409, 'Only draft orders can be deleted; cancel it instead');
    db.run('DELETE FROM sales_orders WHERE id = ?', id);
    audit(c, 'so.delete', 'sales_order', id, { number: so.number });
    return { deleted: true };
  });
};
