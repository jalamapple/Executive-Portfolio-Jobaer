'use strict';
const { HttpError } = require('../http');
const { validate } = require('../validate');
const { verifyPassword, DUMMY_HASH, permissionsFor, checkPasswordPolicy, hashPassword } = require('../auth');

const publicUser = (u) => ({ id: u.id, email: u.email, name: u.name, role: u.role, permissions: permissionsFor(u.role) });

module.exports = function registerAuth(r, { db, sessions, limiter, audit, config, branding }) {
  const settings = () => branding.publicView();

  r.post('/api/auth/login', 'public', (c) => {
    const { email, password } = validate(c.body, {
      email: { type: 'email', required: true },
      password: { type: 'string', required: true, max: 200, trim: false },
    });
    const key = `${c.ip}|${email}`;
    limiter.check(key);

    const u = db.get('SELECT * FROM users WHERE email = ?', email);
    const passwordOk = verifyPassword(password, u ? u.password_hash : DUMMY_HASH);
    if (!u || !u.active || !passwordOk) {
      limiter.fail(key);
      audit(c, 'auth.login_failed', 'user', u ? u.id : null, { email });
      throw new HttpError(401, 'Invalid email or password');
    }
    limiter.reset(key);

    const token = sessions.create(u.id, c);
    c.res.setHeader('Set-Cookie', sessions.cookie(token));
    db.run(`UPDATE users SET last_login_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`, u.id);
    c.user = u;
    audit(c, 'auth.login', 'user', u.id);
    return { user: publicUser(u), settings: settings() };
  });

  r.post('/api/auth/logout', 'public', (c) => {
    sessions.destroy(sessions.tokenFrom(c.req));
    c.res.setHeader('Set-Cookie', sessions.clearCookie());
    if (c.user) audit(c, 'auth.logout', 'user', c.user.id);
    return { ok: true };
  });

  r.get('/api/auth/me', 'read', (c) => ({ user: publicUser(c.user), settings: settings() }));

  // Public branding for the sign-in page (name, colours, logo, welcome copy). Demo hints only while the demo accounts still exist.
  r.get('/api/auth/config', 'public', () => ({
    ...branding.publicView(),
    demo: Boolean(config.demoData && db.get(`SELECT 1 AS x FROM users WHERE email = 'viewer@inventory.local' AND active = 1`)),
  }));

  r.post('/api/auth/password', 'read', (c) => {
    const body = validate(c.body, {
      current_password: { type: 'string', required: true, max: 200, trim: false },
      new_password: { type: 'string', required: true, max: 200, trim: false },
    });
    const u = db.get('SELECT * FROM users WHERE id = ?', c.user.id);
    if (!verifyPassword(body.current_password, u.password_hash)) {
      throw new HttpError(422, 'Current password is incorrect', { current_password: 'is incorrect' });
    }
    checkPasswordPolicy(body.new_password);
    db.run(`UPDATE users SET password_hash = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`,
      hashPassword(body.new_password), u.id);
    sessions.destroyForUser(u.id, sessions.tokenFrom(c.req)); // sign out other devices
    audit(c, 'auth.password_changed', 'user', u.id);
    return { ok: true };
  });

  r.get('/api/health', 'public', () => {
    db.get('SELECT 1 AS ok');
    return { status: 'ok', version: config.version || null, time: new Date().toISOString() };
  });
};

module.exports.publicUser = publicUser;
