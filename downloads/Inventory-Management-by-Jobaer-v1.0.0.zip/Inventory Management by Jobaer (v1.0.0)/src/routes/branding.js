'use strict';
const { HttpError, FileResult } = require('../http');
const { renderDocument, createFormat } = require('../reports');

module.exports = function registerBranding(r, { branding, audit }) {
  // Logo for the sign-in page, sidebar and favicon-sized uses. Versioned URLs are cached for a year.
  r.get('/api/branding/logo', 'public', (c) => {
    const logo = branding.logo();
    if (!logo) throw new HttpError(404, 'No logo has been uploaded');
    const versioned = c.query.v && c.query.v === logo.updated_at;
    return new FileResult(`logo.${logo.mime === 'image/png' ? 'png' : 'jpg'}`, logo.mime, logo.data,
      { inline: true, cache: versioned ? 'public, max-age=31536000, immutable' : 'no-cache' });
  });

  r.get('/api/settings/branding', 'settings:manage', () => ({
    settings: branding.get(),
    limits: { logo_max_bytes: branding.LOGO_MAX_BYTES, fields: Object.fromEntries(Object.entries(branding.FIELDS).map(([k, v]) => [k, v.max || null])) },
  }));

  r.put('/api/settings/branding', 'settings:manage', (c) => {
    if (!c.body || typeof c.body !== 'object' || Array.isArray(c.body)) throw new HttpError(422, 'Expected an object of settings');
    const { values, errors } = branding.check(c.body);
    if (Object.keys(errors).length) throw new HttpError(422, 'Please correct the highlighted fields', errors);
    if (!Object.keys(values).length) throw new HttpError(422, 'No settings to update');
    const before = branding.get();
    const changed = Object.fromEntries(Object.entries(values).filter(([k, v]) => (v ?? '') !== (before[k] ?? '')));
    const settings = branding.update(values);
    if (Object.keys(changed).length) audit(c, 'settings.branding_update', 'settings', 'branding', { changed: Object.keys(changed) });
    return { settings };
  });

  r.post('/api/settings/logo', 'settings:manage', (c) => {
    const m = /^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/=\s]+)$/.exec(String((c.body && c.body.data) || ''));
    if (!m) throw new HttpError(422, 'Upload a PNG or JPEG image', { logo: 'must be a PNG or JPEG image' });
    const buf = Buffer.from(m[2], 'base64');
    const error = branding.setLogo(buf);
    if (error) throw new HttpError(422, error, { logo: error });
    audit(c, 'settings.logo_upload', 'settings', 'logo', { bytes: buf.length });
    return { settings: branding.get() };
  });

  r.delete('/api/settings/logo', 'settings:manage', (c) => {
    branding.clearLogo();
    audit(c, 'settings.logo_remove', 'settings', 'logo');
    return { settings: branding.get() };
  });

  // A sample document so administrators can check the letterhead before using it for real.
  r.get('/api/settings/sample.pdf', 'settings:manage', (c) => {
    const b = branding.get();
    const fmt = createFormat(b);
    const logo = branding.logo();
    const lines = [
      { sku: 'SAMPLE-001', name: 'Sample product A', qty: 12, unit: 'ea', price: 24.5 },
      { sku: 'SAMPLE-002', name: 'Sample product B with a longer description', qty: 3, unit: 'box', price: 189 },
      { sku: 'SAMPLE-003', name: 'Sample product C', qty: 40, unit: 'ea', price: 2.75 },
    ].map((l) => ({ ...l, total: l.qty * l.price }));
    const total = lines.reduce((s, l) => s + l.total, 0);
    const data = renderDocument({
      branding: b, logo: logo && logo.decoded,
      spec: {
        title: 'Sample document', number: 'SAMPLE-000001', status: 'PREVIEW', watermark: 'SAMPLE',
        meta: [['Date', fmt.date(new Date())], ['Prepared by', c.user.name], ['Currency', b.currency]],
        parties: [
          { title: 'Bill to', lines: ['Example Customer Ltd', '1 Sample Street', 'Sample City'] },
          { title: 'Ship from', lines: [b.company_name, ...String(b.address || '').split('\n')] },
        ],
        columns: [
          { key: 'sku', label: 'SKU', w: 1.2 }, { key: 'name', label: 'Description', w: 3 },
          { key: 'qty', label: 'Qty', type: 'int', w: 0.7 }, { key: 'unit', label: 'Unit', w: 0.6 },
          { key: 'price', label: 'Unit price', type: 'money', w: 1.1 }, { key: 'total', label: 'Amount', type: 'money', w: 1.2 },
        ],
        rows: lines,
        totals: [['Total', fmt.money(total), true]],
        notes: 'This is a preview of how your company branding appears on generated documents.',
        terms: b.document_terms,
      },
    });
    return new FileResult('branding-sample.pdf', 'application/pdf', data, { inline: c.query.inline === '1' });
  });
};

