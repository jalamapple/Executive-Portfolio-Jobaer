'use strict';
/**
 * Stock returns from a sales center back to a warehouse.
 *   DRAFT -> DISPATCHED (stock leaves the sales center, now in transit)
 *         -> RECEIVED   (warehouse inspects: good stock is added, damaged stock is written off,
 *                        anything missing is recorded as lost in transit)
 *   DRAFT / DISPATCHED -> CANCELLED (a dispatched return is put back into the sales center)
 */
const { HttpError, CsvResult, FileResult, exportFormat } = require('../http');
const { validate, validateLines, paging, idParam, likeParam } = require('../validate');
const { renderDocument, createFormat } = require('../reports');

const NOW = "strftime('%Y-%m-%dT%H:%M:%fZ','now')";
const REASONS = ['UNSOLD', 'OVERSTOCK', 'DAMAGED', 'EXPIRED', 'RECALL', 'CUSTOMER_RETURN', 'OTHER'];
const REASON_LABEL = {
  UNSOLD: 'Unsold stock', OVERSTOCK: 'Overstock', DAMAGED: 'Damaged', EXPIRED: 'Expired',
  RECALL: 'Product recall', CUSTOMER_RETURN: 'Customer return', OTHER: 'Other',
};

const HEADER = {
  from_location_id: { type: 'id', required: true },
  to_location_id: { type: 'id', required: true },
  reason: { type: 'enum', values: REASONS, default: 'UNSOLD' },
  notes: { type: 'text', max: 2000 },
};
const LINE = {
  product_id: { type: 'id', required: true },
  qty: { type: 'int', required: true, min: 1, max: 1e9 },
  note: { type: 'string', max: 300 },
};

module.exports = function registerReturns(r, { db, inv, audit, branding, approvals }) {
  const load = (id) => {
    const ret = db.get(
      `SELECT rt.*, f.code AS from_code, f.name AS from_name, f.address AS from_address,
              t.code AS to_code, t.name AS to_name, t.address AS to_address,
              cu.name AS created_by_name, du.name AS dispatched_by_name, ru.name AS received_by_name
       FROM stock_returns rt JOIN warehouses f ON f.id = rt.from_location_id JOIN warehouses t ON t.id = rt.to_location_id
       LEFT JOIN users cu ON cu.id = rt.created_by LEFT JOIN users du ON du.id = rt.dispatched_by
       LEFT JOIN users ru ON ru.id = rt.received_by WHERE rt.id = ?`, id);
    if (!ret) throw new HttpError(404, 'Return not found');
    ret.lines = db.all(
      `SELECT l.*, p.sku, p.name AS product_name, p.unit, p.avg_cost,
              ROUND(l.qty * p.avg_cost, 2) AS value,
              COALESCE(s.on_hand - s.reserved, 0) AS available_at_source
       FROM stock_return_lines l JOIN products p ON p.id = l.product_id
       LEFT JOIN stock s ON s.product_id = l.product_id AND s.warehouse_id = ?
       WHERE l.return_id = ? ORDER BY l.id`, ret.from_location_id, id);
    ret.total_qty = ret.lines.reduce((s, l) => s + l.qty, 0);
    ret.total_value = Math.round(ret.lines.reduce((s, l) => s + l.value, 0) * 100) / 100;
    if (ret.status === 'RECEIVED') {
      ret.total_good = ret.lines.reduce((s, l) => s + (l.qty_good || 0), 0);
      ret.total_damaged = ret.lines.reduce((s, l) => s + (l.qty_damaged || 0), 0);
      ret.total_missing = ret.total_qty - ret.total_good - ret.total_damaged;
    }
    ret.pending_approval = approvals.pendingFor('stock_return', ret.id);
    return ret;
  };

  const checkLocations = (fromId, toId) => {
    if (fromId === toId) throw new HttpError(422, 'Choose different locations', { to_location_id: 'must differ from the sales center' });
    const from = inv.warehouse(fromId);
    const to = inv.warehouse(toId);
    if (from.kind !== 'SALES_CENTER') throw new HttpError(422, `${from.code} is not a sales center`, { from_location_id: 'must be a sales center' });
    if (to.kind !== 'WAREHOUSE') throw new HttpError(422, `${to.code} is not a warehouse`, { to_location_id: 'must be a warehouse' });
  };

  const parseLines = (raw) => {
    const lines = validateLines(raw, LINE);
    const seen = new Set();
    lines.forEach((l, i) => {
      if (seen.has(l.product_id)) throw new HttpError(422, 'Each product may appear only once per return', { [`lines[${i}].product_id`]: 'is duplicated' });
      seen.add(l.product_id);
      inv.product(l.product_id);
    });
    return lines;
  };

  const writeLines = (id, lines) => {
    db.run('DELETE FROM stock_return_lines WHERE return_id = ?', id);
    for (const l of lines) db.run('INSERT INTO stock_return_lines (return_id, product_id, qty, note) VALUES (?,?,?,?)', id, l.product_id, l.qty, l.note);
  };

  const requireStatus = (ret, ...allowed) => {
    if (!allowed.includes(ret.status)) throw new HttpError(409, `Return ${ret.number} is ${ret.status.toLowerCase()}; this action needs status ${allowed.join(' or ')}`);
  };

  // ---- List ----------------------------------------------------------------
  r.get('/api/returns', 'read', (c) => {
    const where = [];
    const params = [];
    if (c.query.status) { where.push('rt.status = ?'); params.push(c.query.status); }
    if (c.query.from_location_id) { where.push('rt.from_location_id = ?'); params.push(Number(c.query.from_location_id)); }
    if (c.query.to_location_id) { where.push('rt.to_location_id = ?'); params.push(Number(c.query.to_location_id)); }
    if (c.query.q) { where.push(`(rt.number LIKE ? ESCAPE '\\' OR f.name LIKE ? ESCAPE '\\')`); params.push(likeParam(c.query.q), likeParam(c.query.q)); }
    const sql = `
      SELECT rt.id, rt.number, rt.status, rt.reason, rt.created_at, rt.dispatched_at, rt.received_at,
             f.code AS from_code, f.name AS from_name, t.code AS to_code, t.name AS to_name,
             (SELECT COUNT(*) FROM stock_return_lines l WHERE l.return_id = rt.id) AS line_count,
             (SELECT COALESCE(SUM(l.qty), 0) FROM stock_return_lines l WHERE l.return_id = rt.id) AS total_qty,
             (SELECT ROUND(COALESCE(SUM(l.qty * p.avg_cost), 0), 2) FROM stock_return_lines l JOIN products p ON p.id = l.product_id WHERE l.return_id = rt.id) AS total_value
      FROM stock_returns rt JOIN warehouses f ON f.id = rt.from_location_id JOIN warehouses t ON t.id = rt.to_location_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}`;
    if (exportFormat(c.query)) {
      const rows = db.all(`${sql} ORDER BY rt.id DESC LIMIT 100000`, ...params).map((x) => ({ ...x, reason_label: REASON_LABEL[x.reason] }));
      return new CsvResult('stock-returns.csv', [
        { key: 'number', label: 'Return', w: 1.1 }, { key: 'status', label: 'Status', w: 1 },
        { key: 'from_name', label: 'From sales center', w: 2 }, { key: 'to_name', label: 'To warehouse', w: 2 },
        { key: 'reason_label', label: 'Reason', w: 1.3 }, { key: 'line_count', label: 'Lines', type: 'int' },
        { key: 'total_qty', label: 'Units', type: 'int', sum: true }, { key: 'total_value', label: 'Value at cost', type: 'money', sum: true },
        { key: 'dispatched_at', label: 'Dispatched', type: 'date' }, { key: 'received_at', label: 'Received', type: 'date' },
      ], rows, {
        title: 'Stock returns', landscape: true,
        filters: [['Status', c.query.status], ['Search', c.query.q]],
        summary: (f) => [
          { label: 'Returns', value: f.int(rows.length) },
          { label: 'In transit', value: f.int(rows.filter((x) => x.status === 'DISPATCHED').length) },
          { label: 'Units returned', value: f.int(rows.filter((x) => x.status !== 'CANCELLED').reduce((s, x) => s + x.total_qty, 0)) },
        ],
      });
    }
    const { limit, offset } = paging(c.query);
    const total = db.get(`SELECT COUNT(*) AS n FROM (${sql})`, ...params).n;
    const counts = Object.fromEntries(db.all('SELECT status, COUNT(*) AS n FROM stock_returns GROUP BY status').map((x) => [x.status, x.n]));
    return { items: db.all(`${sql} ORDER BY rt.id DESC LIMIT ? OFFSET ?`, ...params, limit, offset), total, limit, offset, counts, reasons: REASON_LABEL };
  });

  // Products with available stock at a location (for the return form). Registered before /:id.
  r.get('/api/returns/available', 'read', (c) => {
    const id = idParam(c.query.location_id);
    return {
      items: db.all(`SELECT p.id AS product_id, p.sku, p.name, p.unit, s.on_hand - s.reserved AS available
                     FROM stock s JOIN products p ON p.id = s.product_id
                     WHERE s.warehouse_id = ? AND s.on_hand - s.reserved > 0 ORDER BY p.name`, id),
    };
  });

  r.get('/api/returns/:id', 'read', (c) => ({ ...load(idParam(c.params.id)), reasons: REASON_LABEL }));

  // ---- Create / edit ---------------------------------------------------------
  r.post('/api/returns', 'stock:write', (c) => {
    const h = validate(c.body, HEADER);
    const lines = parseLines(c.body.lines);
    const id = db.tx(() => {
      checkLocations(h.from_location_id, h.to_location_id);
      const rid = db.run('INSERT INTO stock_returns (from_location_id, to_location_id, reason, notes, created_by) VALUES (?,?,?,?,?)',
        h.from_location_id, h.to_location_id, h.reason, h.notes, c.user.id).id;
      db.run('UPDATE stock_returns SET number = ? WHERE id = ?', `RET-${String(rid).padStart(6, '0')}`, rid);
      writeLines(rid, lines);
      return rid;
    });
    const ret = load(id);
    audit(c, 'return.create', 'stock_return', id, { number: ret.number, lines: lines.length });
    c.status = 201;
    return ret;
  });

  r.put('/api/returns/:id', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    const h = validate(c.body, HEADER);
    const lines = parseLines(c.body.lines);
    db.tx(() => {
      requireStatus(load(id), 'DRAFT');
      approvals.assertNoPending('stock_return', id);
      checkLocations(h.from_location_id, h.to_location_id);
      db.run(`UPDATE stock_returns SET from_location_id = ?, to_location_id = ?, reason = ?, notes = ?, updated_at = ${NOW} WHERE id = ?`,
        h.from_location_id, h.to_location_id, h.reason, h.notes, id);
      writeLines(id, lines);
    });
    audit(c, 'return.update', 'stock_return', id, { lines: lines.length });
    return load(id);
  });

  r.delete('/api/returns/:id', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    const ret = load(id);
    requireStatus(ret, 'DRAFT');
    approvals.assertNoPending('stock_return', id);
    db.run('DELETE FROM stock_returns WHERE id = ?', id);
    audit(c, 'return.delete', 'stock_return', id, { number: ret.number });
    return { deleted: true };
  });

  // ---- Workflow ------------------------------------------------------------
  const dispatch = (c, id, ref) => {
    {
      const ret = load(id);
      requireStatus(ret, 'DRAFT');
      if (!ret.lines.length) throw new HttpError(422, 'Add at least one product before dispatching');
      checkLocations(ret.from_location_id, ret.to_location_id);
      const shortages = ret.lines.filter((l) => l.available_at_source < l.qty)
        .map((l) => ({ sku: l.sku, requested: l.qty, available: l.available_at_source }));
      if (shortages.length) {
        throw new HttpError(409, `Not enough available stock at ${ret.from_code} for ${shortages.length} product(s)`, { shortages });
      }
      for (const l of ret.lines) {
        inv.move({ productId: l.product_id, warehouseId: ret.from_location_id, qty: -l.qty, type: 'TRANSFER_OUT',
          refType: 'RETURN', refId: ret.number, note: `Return to ${ret.to_code} (${REASON_LABEL[ret.reason]})`, userId: c.user.id });
      }
      db.run(`UPDATE stock_returns SET status = 'DISPATCHED', dispatched_by = ?, dispatched_at = ${NOW}, updated_at = ${NOW} WHERE id = ?`, c.user.id, id);
      audit(c, 'return.dispatch', 'stock_return', id, { number: ret.number, units: ret.total_qty, approval: ref || undefined });
    }
    return load(id);
  };
  approvals.register('RETURN_DISPATCH', 'stock_return', (c, payload, id, ref) => dispatch(c, id, ref));

  // Sales agents submit the return for their manager's approval; approval dispatches it.
  r.post('/api/returns/:id/dispatch', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    const ret = load(id);
    requireStatus(ret, 'DRAFT');
    const out = approvals.submit(c, {
      type: 'RETURN_DISPATCH', entityId: id, payload: { number: ret.number, units: ret.total_qty, value: ret.total_value },
      reason: c.body.reason || `${REASON_LABEL[ret.reason]}${ret.notes ? `: ${ret.notes}` : ''}`,
      summary: `${ret.number}: return ${ret.total_qty} unit(s) from ${ret.from_code} to ${ret.to_code}`,
    });
    if (!out.applied) { c.status = 202; return { pending_approval: out.request }; }
    return out.result;
  });

  /** body.lines: [{ id, qty_good, qty_damaged }]; omitted lines are received in full as good stock. */
  r.post('/api/returns/:id/receive', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    const input = Array.isArray(c.body.lines) ? c.body.lines : [];
    db.tx(() => {
      const ret = load(id);
      requireStatus(ret, 'DISPATCHED');
      approvals.assertNoPending('stock_return', id);
      inv.warehouse(ret.to_location_id);
      const byId = new Map(input.map((x, i) => [Number(x && x.id), { ...x, i }]));
      for (const l of ret.lines) {
        const x = byId.get(l.id);
        const good = x ? Number(x.qty_good ?? 0) : l.qty;
        const damaged = x ? Number(x.qty_damaged ?? 0) : 0;
        if (!Number.isInteger(good) || !Number.isInteger(damaged) || good < 0 || damaged < 0) {
          throw new HttpError(422, `Quantities for ${l.sku} must be whole numbers of zero or more`, { [`lines[${x ? x.i : 0}].qty_good`]: 'is invalid' });
        }
        if (good + damaged > l.qty) {
          throw new HttpError(422, `${l.sku}: received ${good + damaged} but only ${l.qty} were dispatched`, { [`lines[${x.i}].qty_good`]: `at most ${l.qty} in total` });
        }
        const note = `Return ${ret.number} from ${ret.from_code}`;
        if (good + damaged > 0) {
          inv.move({ productId: l.product_id, warehouseId: ret.to_location_id, qty: good + damaged, type: 'TRANSFER_IN',
            refType: 'RETURN', refId: ret.number, note, userId: c.user.id });
        }
        if (damaged > 0) {
          inv.move({ productId: l.product_id, warehouseId: ret.to_location_id, qty: -damaged, type: 'ADJUSTMENT',
            refType: 'RETURN', refId: ret.number, note: `Damaged on return ${ret.number}: written off`, userId: c.user.id });
        }
        db.run('UPDATE stock_return_lines SET qty_good = ?, qty_damaged = ? WHERE id = ?', good, damaged, l.id);
      }
      db.run(`UPDATE stock_returns SET status = 'RECEIVED', received_by = ?, received_at = ${NOW}, updated_at = ${NOW} WHERE id = ?`, c.user.id, id);
    });
    const ret = load(id);
    audit(c, 'return.receive', 'stock_return', id, { number: ret.number, good: ret.total_good, damaged: ret.total_damaged, missing: ret.total_missing });
    return ret;
  });

  const cancel = (c, id, ref) => {
    {
      const ret = load(id);
      requireStatus(ret, 'DRAFT', 'DISPATCHED');
      if (ret.status === 'DISPATCHED') { // put the stock back where it came from
        for (const l of ret.lines) {
          inv.move({ productId: l.product_id, warehouseId: ret.from_location_id, qty: l.qty, type: 'TRANSFER_IN',
            refType: 'RETURN', refId: ret.number, note: `Return ${ret.number} cancelled: stock reinstated`, userId: c.user.id });
        }
      }
      db.run(`UPDATE stock_returns SET status = 'CANCELLED', updated_at = ${NOW} WHERE id = ?`, id);
      audit(c, 'return.cancel', 'stock_return', id, { number: ret.number, was: ret.status, approval: ref || undefined });
    }
    return load(id);
  };
  approvals.register('RETURN_CANCEL', 'stock_return', (c, payload, id, ref) => {
    const ret = load(id);
    if (ret.status !== 'DISPATCHED') throw new HttpError(409, `${ret.number} is now ${ret.status}; the cancellation no longer applies`);
    return cancel(c, id, ref);
  });

  r.post('/api/returns/:id/cancel', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    const ret = load(id);
    if (ret.status === 'DISPATCHED') {
      // Stock is in transit: putting it back into the sales center needs a manager.
      const out = approvals.submit(c, {
        type: 'RETURN_CANCEL', entityId: id, payload: { number: ret.number, units: ret.total_qty },
        reason: c.body.reason, summary: `${ret.number}: cancel and put ${ret.total_qty} unit(s) back into ${ret.from_code}`,
      });
      if (!out.applied) { c.status = 202; return { pending_approval: out.request }; }
      return out.result;
    }
    approvals.assertNoPending('stock_return', id);
    return db.tx(() => cancel(c, id, null));
  });

  // ---- Return note (PDF) ---------------------------------------------------
  r.get('/api/returns/:id/pdf', 'read', (c) => {
    const ret = load(idParam(c.params.id));
    const b = branding.get();
    const f = createFormat(b);
    const logo = branding.logo();
    const received = ret.status === 'RECEIVED';
    const lines = (...parts) => parts.flatMap((p) => String(p || '').split('\n')).map((x) => x.trim()).filter(Boolean);
    const data = renderDocument({
      branding: b, logo: logo && logo.decoded,
      spec: {
        title: 'Stock return note', number: ret.number, status: ret.status,
        watermark: ret.status === 'DRAFT' ? 'DRAFT' : ret.status === 'CANCELLED' ? 'CANCELLED' : null,
        meta: [
          ['Created', f.date(ret.created_at)], ['Reason', REASON_LABEL[ret.reason]],
          ['Dispatched', ret.dispatched_at ? `${f.date(ret.dispatched_at)} · ${ret.dispatched_by_name || ''}` : null],
          ['Received', ret.received_at ? `${f.date(ret.received_at)} · ${ret.received_by_name || ''}` : null],
          ['Prepared by', ret.created_by_name],
        ],
        parties: [
          { title: 'From sales center', lines: [`${ret.from_name} (${ret.from_code})`, ...lines(ret.from_address)] },
          { title: 'To warehouse', lines: [`${ret.to_name} (${ret.to_code})`, ...lines(ret.to_address)] },
        ],
        columns: [
          { key: 'sku', label: 'SKU', w: 1.2 }, { key: 'product_name', label: 'Description', w: 3 },
          { key: 'unit', label: 'Unit', w: 0.6 }, { key: 'qty', label: 'Returned', type: 'int', w: 0.8 },
          ...(received
            ? [{ key: 'qty_good', label: 'Good', type: 'int', w: 0.7 }, { key: 'qty_damaged', label: 'Damaged', type: 'int', w: 0.8 }]
            : [{ key: 'chk', label: 'Checked', w: 0.8, render: () => '[   ]' }]),
          { key: 'value', label: 'Value at cost', type: 'money', w: 1.2 },
        ],
        rows: ret.lines,
        totals: [
          ['Units returned', f.int(ret.total_qty)],
          ...(received ? [['Good / damaged / missing', `${f.int(ret.total_good)} / ${f.int(ret.total_damaged)} / ${f.int(ret.total_missing)}`]] : []),
          ['Value at cost', f.money(ret.total_value), true],
        ],
        notes: ret.notes,
        signatures: ['Dispatched by (sales center)', 'Received by (warehouse)'],
      },
    });
    return new FileResult(`${ret.number}.pdf`, 'application/pdf', data, { inline: c.query.inline === '1' });
  });
};

module.exports.REASON_LABEL = REASON_LABEL;
