'use strict';
const { HttpError } = require('../http');
const { idParam, paging } = require('../validate');
const { can } = require('../auth');

module.exports = function registerApprovals(r, { db, approvals }) {
  // Requests visible to a user: their own, plus those they may decide.
  const scope = (user) => {
    if (user.role === 'admin') return { sql: '1 = 1', params: [] };
    if (can(user.role, 'approvals:decide')) return { sql: '(a.requested_by = ? OR a.approver_id IS NULL OR a.approver_id = ?)', params: [user.id, user.id] };
    return { sql: 'a.requested_by = ?', params: [user.id] };
  };

  r.get('/api/approvals', 'read', (c) => {
    const s = scope(c.user);
    const where = [s.sql];
    const params = [...s.params];
    if (c.query.status) { where.push('a.status = ?'); params.push(c.query.status); }
    if (c.query.mine === '1') { where.push('a.requested_by = ?'); params.push(c.user.id); }
    if (c.query.entity) { where.push('a.entity = ?'); params.push(c.query.entity); }
    if (c.query.entity_id) { where.push('a.entity_id = ?'); params.push(Number(c.query.entity_id)); }
    const { limit, offset } = paging(c.query);
    const w = `WHERE ${where.join(' AND ')}`;
    const total = db.get(`SELECT COUNT(*) AS n FROM approval_requests a ${w}`, ...params).n;
    const items = db.all(`
      SELECT a.id, a.number, a.type, a.entity, a.entity_id, a.summary, a.reason, a.status, a.created_at, a.decided_at,
             a.requested_by, a.approver_id, a.decision_note,
             ru.name AS requested_by_name, au.name AS approver_name, du.name AS decided_by_name,
             COALESCE(so.number, rt.number) AS document_number
      FROM approval_requests a JOIN users ru ON ru.id = a.requested_by
      LEFT JOIN users au ON au.id = a.approver_id LEFT JOIN users du ON du.id = a.decided_by
      LEFT JOIN sales_orders so ON a.entity = 'sales_order' AND so.id = a.entity_id
      LEFT JOIN stock_returns rt ON a.entity = 'stock_return' AND rt.id = a.entity_id
      ${w} ORDER BY a.status = 'PENDING' DESC, a.id DESC LIMIT ? OFFSET ?`, ...params, limit, offset)
      .map((x) => ({ ...x, type_label: approvals.TYPE_LABEL[x.type], can_decide: x.status === 'PENDING' && approvals.canDecide(c.user, x) }));
    return { items, total, limit, offset };
  });

  // Badge counts for the sidebar.
  r.get('/api/approvals/summary', 'read', (c) => {
    const pending = db.all(`SELECT id, requested_by, approver_id FROM approval_requests WHERE status = 'PENDING'`);
    return {
      to_decide: pending.filter((x) => approvals.canDecide(c.user, x)).length,
      my_pending: pending.filter((x) => x.requested_by === c.user.id).length,
    };
  });

  r.get('/api/approvals/:id', 'read', (c) => {
    const req = approvals.load(idParam(c.params.id));
    const s = scope(c.user);
    const visible = db.get(`SELECT 1 AS x FROM approval_requests a WHERE a.id = ? AND ${s.sql}`, req.id, ...s.params);
    if (!visible) throw new HttpError(404, 'Approval request not found');
    return { ...req, can_decide: req.status === 'PENDING' && approvals.canDecide(c.user, req), can_withdraw: req.status === 'PENDING' && req.requested_by === c.user.id };
  });

  r.post('/api/approvals/:id/approve', 'approvals:decide', (c) => approvals.decide(c, idParam(c.params.id), 'APPROVED', c.body.note));
  r.post('/api/approvals/:id/reject', 'approvals:decide', (c) => approvals.decide(c, idParam(c.params.id), 'REJECTED', c.body.note));
  r.post('/api/approvals/:id/withdraw', 'read', (c) => approvals.decide(c, idParam(c.params.id), 'WITHDRAWN', c.body.note));
};
