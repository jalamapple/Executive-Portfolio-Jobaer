'use strict';
const { HttpError, CsvResult, exportFormat } = require('../http');
const { validate, likeParam, paging, idParam } = require('../validate');

const NOW = "strftime('%Y-%m-%dT%H:%M:%fZ','now')";

function insert(db, table, data) {
  const cols = Object.keys(data);
  return db.run(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`,
    ...cols.map((k) => data[k])).id;
}

function update(db, table, id, data, { touch = false } = {}) {
  const cols = Object.keys(data);
  const sets = cols.map((k) => `${k} = ?`);
  if (touch) sets.push(`updated_at = ${NOW}`);
  db.run(`UPDATE ${table} SET ${sets.join(', ')} WHERE id = ?`, ...cols.map((k) => data[k]), id);
}

function findOr404(db, table, id, label) {
  const row = db.get(`SELECT * FROM ${table} WHERE id = ?`, id);
  if (!row) throw new HttpError(404, `${label} not found`);
  return row;
}

/** Generic list/get/create/update/delete for simple master-data tables. */
function crud(r, { db, audit }, cfg) {
  const { path, table, entity, label, spec, search = [], order = 'name', hasActive = false, inUse = [], filters = [] } = cfg;

  r.get(`/api/${path}`, 'read', (c) => {
    const { limit, offset } = paging(c.query, { max: 1000 });
    const where = [];
    const params = [];
    if (c.query.q && search.length) {
      where.push(`(${search.map((col) => `${col} LIKE ? ESCAPE '\\'`).join(' OR ')})`);
      search.forEach(() => params.push(likeParam(c.query.q)));
    }
    if (hasActive && c.query.active !== undefined && c.query.active !== '') {
      where.push('active = ?');
      params.push(c.query.active === '1' || c.query.active === 'true' ? 1 : 0);
    }
    for (const col of filters) {
      if (c.query[col]) { where.push(`${col} = ?`); params.push(String(c.query[col])); }
    }
    const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const total = db.get(`SELECT COUNT(*) AS n FROM ${table} ${w}`, ...params).n;
    const items = db.all(`SELECT * FROM ${table} ${w} ORDER BY ${order} LIMIT ? OFFSET ?`, ...params, limit, offset);
    return { items, total, limit, offset };
  });

  r.get(`/api/${path}/:id`, 'read', (c) => findOr404(db, table, idParam(c.params.id), label));

  r.post(`/api/${path}`, 'master:write', (c) => {
    const data = validate(c.body, spec);
    const id = insert(db, table, data);
    audit(c, `${entity}.create`, entity, id, data);
    c.status = 201;
    return findOr404(db, table, id, label);
  });

  r.put(`/api/${path}/:id`, 'master:write', (c) => {
    const id = idParam(c.params.id);
    const before = findOr404(db, table, id, label);
    const data = validate(c.body, spec, { partial: true });
    if (!Object.keys(data).length) throw new HttpError(422, 'No fields to update');
    update(db, table, id, data);
    audit(c, `${entity}.update`, entity, id, diff(before, data));
    return findOr404(db, table, id, label);
  });

  r.delete(`/api/${path}/:id`, 'master:write', (c) => {
    const id = idParam(c.params.id);
    const row = findOr404(db, table, id, label);
    const used = inUse.some(([t, col]) => db.get(`SELECT 1 AS x FROM ${t} WHERE ${col} = ? LIMIT 1`, id));
    if (used) {
      if (!hasActive) throw new HttpError(409, `${label} is in use and cannot be deleted`);
      db.run(`UPDATE ${table} SET active = 0 WHERE id = ?`, id);
      audit(c, `${entity}.deactivate`, entity, id, { reason: 'in use' });
      return { deactivated: true, message: `${label} is referenced by other records, so it was deactivated instead of deleted` };
    }
    db.run(`DELETE FROM ${table} WHERE id = ?`, id);
    audit(c, `${entity}.delete`, entity, id, row);
    return { deleted: true };
  });
}

function diff(before, changes) {
  const out = {};
  for (const [k, v] of Object.entries(changes)) if (before[k] !== v) out[k] = { from: before[k], to: v };
  return out;
}

const PRODUCT_SPEC = {
  sku: { type: 'string', required: true, max: 64, pattern: /^[A-Za-z0-9._\-/]+$/, patternMessage: 'may only contain letters, digits and . _ - /' },
  name: { type: 'string', required: true, max: 200 },
  description: { type: 'text' },
  category_id: { type: 'id' },
  supplier_id: { type: 'id' },
  unit: { type: 'string', max: 16, default: 'ea' },
  barcode: { type: 'string', max: 64 },
  cost: { type: 'number', min: 0, max: 1e9, default: 0 },
  price: { type: 'number', min: 0, max: 1e9, default: 0 },
  reorder_point: { type: 'int', min: 0, max: 1e9, default: 0 },
  reorder_qty: { type: 'int', min: 0, max: 1e9, default: 0 },
  active: { type: 'bool', default: 1 },
};

const PRODUCT_COLUMNS = [
  { key: 'sku', label: 'SKU', w: 1.3 }, { key: 'name', label: 'Name', w: 2.6 }, { key: 'category_name', label: 'Category', w: 1.4 },
  { key: 'supplier_name', label: 'Preferred supplier', w: 1.6 }, { key: 'unit', label: 'Unit', w: 0.6 }, { key: 'barcode', label: 'Barcode', pdf: false },
  { key: 'on_hand', label: 'On hand', type: 'int', sum: true }, { key: 'reserved', label: 'Reserved', type: 'int', sum: true },
  { key: 'available', label: 'Available', type: 'int', sum: true },
  { key: 'reorder_point', label: 'Reorder pt', type: 'int' }, { key: 'avg_cost', label: 'Avg cost', type: 'money' },
  { key: 'price', label: 'Price', type: 'money' },
  { key: 'stock_value', label: 'Stock value', type: 'money', sum: true }, { key: 'active', label: 'Active', type: 'bool' },
];

module.exports = function registerMaster(r, deps) {
  const { db, audit } = deps;

  crud(r, deps, {
    path: 'categories', table: 'categories', entity: 'category', label: 'Category',
    spec: { name: { type: 'string', required: true, max: 100 }, description: { type: 'text', max: 1000 } },
    search: ['name'],
  });

  crud(r, deps, {
    path: 'warehouses', table: 'warehouses', entity: 'warehouse', label: 'Location', order: 'kind DESC, code',
    spec: {
      code: { type: 'string', required: true, max: 20, pattern: /^[A-Za-z0-9_-]+$/, patternMessage: 'may only contain letters, digits, _ and -' },
      name: { type: 'string', required: true, max: 150 },
      kind: { type: 'enum', values: ['WAREHOUSE', 'SALES_CENTER'], default: 'WAREHOUSE' },
      address: { type: 'text', max: 500 },
      phone: { type: 'string', max: 50 },
      manager_name: { type: 'string', max: 150 },
      active: { type: 'bool', default: 1 },
    },
    search: ['code', 'name'], hasActive: true, filters: ['kind'],
    inUse: [['movements', 'warehouse_id'], ['purchase_orders', 'warehouse_id'], ['sales_orders', 'warehouse_id'],
      ['stock_returns', 'from_location_id'], ['stock_returns', 'to_location_id']],
  });

  crud(r, deps, {
    path: 'suppliers', table: 'suppliers', entity: 'supplier', label: 'Supplier',
    spec: {
      name: { type: 'string', required: true, max: 200 },
      contact_name: { type: 'string', max: 150 },
      email: { type: 'email' },
      phone: { type: 'string', max: 50 },
      address: { type: 'text', max: 500 },
      lead_time_days: { type: 'int', min: 0, max: 365 },
      active: { type: 'bool', default: 1 },
    },
    search: ['name', 'contact_name', 'email'], hasActive: true,
    inUse: [['purchase_orders', 'supplier_id']],
  });

  crud(r, deps, {
    path: 'customers', table: 'customers', entity: 'customer', label: 'Customer',
    spec: {
      name: { type: 'string', required: true, max: 200 },
      email: { type: 'email' },
      phone: { type: 'string', max: 50 },
      address: { type: 'text', max: 500 },
      active: { type: 'bool', default: 1 },
    },
    search: ['name', 'email'], hasActive: true,
    inUse: [['sales_orders', 'customer_id']],
  });

  // ---- Products ----------------------------------------------------------
  const productQuery = (c) => {
    const where = [];
    const params = [];
    if (c.query.q) {
      where.push(`(p.sku LIKE ? ESCAPE '\\' OR p.name LIKE ? ESCAPE '\\' OR p.barcode = ?)`);
      params.push(likeParam(c.query.q), likeParam(c.query.q), c.query.q);
    }
    if (c.query.category_id) { where.push('p.category_id = ?'); params.push(Number(c.query.category_id)); }
    if (c.query.supplier_id) { where.push('p.supplier_id = ?'); params.push(Number(c.query.supplier_id)); }
    if (c.query.active === '1' || c.query.active === '0') { where.push('p.active = ?'); params.push(Number(c.query.active)); }
    const having = c.query.low_stock === '1' ? 'HAVING p.reorder_point > 0 AND available <= p.reorder_point' : '';
    const sql = `
      SELECT p.*, c.name AS category_name, sp.name AS supplier_name,
             COALESCE(SUM(s.on_hand), 0) AS on_hand,
             COALESCE(SUM(s.reserved), 0) AS reserved,
             COALESCE(SUM(s.on_hand - s.reserved), 0) AS available,
             ROUND(COALESCE(SUM(s.on_hand), 0) * p.avg_cost, 2) AS stock_value
      FROM products p
      LEFT JOIN categories c ON c.id = p.category_id
      LEFT JOIN suppliers sp ON sp.id = p.supplier_id
      LEFT JOIN stock s ON s.product_id = p.id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      GROUP BY p.id ${having}`;
    return { sql, params };
  };

  const SORTS = { name: 'name', sku: 'sku', on_hand: 'on_hand DESC', value: 'stock_value DESC', updated: 'updated_at DESC' };

  r.get('/api/products', 'read', (c) => {
    const { sql, params } = productQuery(c);
    const order = SORTS[c.query.sort] || 'name';
    if (exportFormat(c.query)) {
      const nameOf = (table, id) => (id ? (db.get(`SELECT name FROM ${table} WHERE id = ?`, Number(id)) || {}).name : null);
      return new CsvResult('products.csv', PRODUCT_COLUMNS, db.all(`${sql} ORDER BY ${order} LIMIT 100000`, ...params), {
        title: c.query.low_stock === '1' ? 'Low stock products' : 'Product catalogue',
        landscape: true,
        filters: [
          ['Search', c.query.q], ['Category', nameOf('categories', c.query.category_id)], ['Supplier', nameOf('suppliers', c.query.supplier_id)],
          ['Status', c.query.active === '1' ? 'Active' : c.query.active === '0' ? 'Inactive' : 'All'],
        ],
      });
    }
    const { limit, offset } = paging(c.query);
    const total = db.get(`SELECT COUNT(*) AS n FROM (${sql})`, ...params).n;
    const items = db.all(`${sql} ORDER BY ${order} LIMIT ? OFFSET ?`, ...params, limit, offset);
    return { items, total, limit, offset };
  });

  r.get('/api/products/:id', 'read', (c) => {
    const id = idParam(c.params.id);
    const product = db.get(
      `SELECT p.*, c.name AS category_name, sp.name AS supplier_name FROM products p
       LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN suppliers sp ON sp.id = p.supplier_id WHERE p.id = ?`, id);
    if (!product) throw new HttpError(404, 'Product not found');
    product.stock = db.all(
      `SELECT s.warehouse_id, w.code AS warehouse_code, w.name AS warehouse_name, s.on_hand, s.reserved,
              s.on_hand - s.reserved AS available, s.bin, ROUND(s.on_hand * ?, 2) AS value
       FROM stock s JOIN warehouses w ON w.id = s.warehouse_id WHERE s.product_id = ? ORDER BY w.code`,
      product.avg_cost, id);
    product.movements = db.all(
      `SELECT m.*, w.code AS warehouse_code, u.name AS user_name FROM movements m
       JOIN warehouses w ON w.id = m.warehouse_id LEFT JOIN users u ON u.id = m.user_id
       WHERE m.product_id = ? ORDER BY m.id DESC LIMIT 25`, id);
    product.open_po_qty = db.get(
      `SELECT COALESCE(SUM(l.qty_ordered - l.qty_received), 0) AS n FROM po_lines l
       JOIN purchase_orders po ON po.id = l.po_id WHERE l.product_id = ? AND po.status IN ('ORDERED','PARTIAL')`, id).n;
    return product;
  });

  r.post('/api/products', 'master:write', (c) => {
    const data = validate(c.body, PRODUCT_SPEC);
    data.avg_cost = data.cost;
    const id = insert(db, 'products', data);
    audit(c, 'product.create', 'product', id, data);
    c.status = 201;
    return db.get('SELECT * FROM products WHERE id = ?', id);
  });

  r.put('/api/products/:id', 'master:write', (c) => {
    const id = idParam(c.params.id);
    const before = findOr404(db, 'products', id, 'Product');
    const data = validate(c.body, PRODUCT_SPEC, { partial: true });
    if (!Object.keys(data).length) throw new HttpError(422, 'No fields to update');
    update(db, 'products', id, data, { touch: true });
    audit(c, 'product.update', 'product', id, diff(before, data));
    return db.get('SELECT * FROM products WHERE id = ?', id);
  });

  r.post('/api/products/:id/bin', 'stock:write', (c) => {
    const id = idParam(c.params.id);
    const body = validate(c.body, { warehouse_id: { type: 'id', required: true }, bin: { type: 'string', max: 40 } });
    db.run('INSERT OR IGNORE INTO stock (product_id, warehouse_id) VALUES (?, ?)', id, body.warehouse_id);
    db.run('UPDATE stock SET bin = ? WHERE product_id = ? AND warehouse_id = ?', body.bin, id, body.warehouse_id);
    audit(c, 'product.bin', 'product', id, body);
    return { ok: true };
  });

  r.delete('/api/products/:id', 'master:write', (c) => {
    const id = idParam(c.params.id);
    const p = findOr404(db, 'products', id, 'Product');
    const used = db.get('SELECT 1 AS x FROM movements WHERE product_id = ? LIMIT 1', id)
      || db.get('SELECT 1 AS x FROM po_lines WHERE product_id = ? LIMIT 1', id)
      || db.get('SELECT 1 AS x FROM so_lines WHERE product_id = ? LIMIT 1', id);
    if (used) {
      db.run(`UPDATE products SET active = 0, updated_at = ${NOW} WHERE id = ?`, id);
      audit(c, 'product.deactivate', 'product', id, { sku: p.sku });
      return { deactivated: true, message: 'Product has transaction history, so it was deactivated instead of deleted' };
    }
    db.run('DELETE FROM products WHERE id = ?', id);
    audit(c, 'product.delete', 'product', id, p);
    return { deleted: true };
  });
};

module.exports.insert = insert;
module.exports.PRODUCT_SPEC = PRODUCT_SPEC;
