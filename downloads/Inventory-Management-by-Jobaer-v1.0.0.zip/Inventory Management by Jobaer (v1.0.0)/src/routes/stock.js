'use strict';
const { HttpError, CsvResult, exportFormat } = require('../http');
const { validate, likeParam, paging } = require('../validate');

const MOVEMENT_TYPES = ['RECEIPT', 'ISSUE', 'ADJUSTMENT', 'COUNT', 'TRANSFER_IN', 'TRANSFER_OUT', 'PO_RECEIPT', 'SALE'];

const MOVEMENT_COLUMNS = [
  { key: 'id', label: 'ID', pdf: false }, { key: 'created_at', label: 'Timestamp (UTC)', type: 'datetime' }, { key: 'type', label: 'Type', w: 1.1 },
  { key: 'sku', label: 'SKU', w: 1.2 }, { key: 'product_name', label: 'Product', w: 2.2 }, { key: 'warehouse_code', label: 'Location', w: 0.7 },
  { key: 'qty', label: 'Qty', type: 'int' }, { key: 'balance_after', label: 'Balance', type: 'int' }, { key: 'unit_cost', label: 'Unit cost', type: 'money' },
  { key: 'ref_type', label: 'Ref type', pdf: false }, { key: 'ref_id', label: 'Reference', w: 1.3 }, { key: 'note', label: 'Note', w: 1.8 },
  { key: 'user_name', label: 'User', w: 1.1 },
];

const STOCK_COLUMNS = [
  { key: 'sku', label: 'SKU', w: 1.3 }, { key: 'name', label: 'Product', w: 2.8 }, { key: 'warehouse_code', label: 'Location', w: 0.9 },
  { key: 'bin', label: 'Bin', w: 0.8 }, { key: 'on_hand', label: 'On hand', type: 'int', sum: true }, { key: 'reserved', label: 'Reserved', type: 'int', sum: true },
  { key: 'available', label: 'Available', type: 'int', sum: true }, { key: 'unit', label: 'Unit', w: 0.6 }, { key: 'avg_cost', label: 'Avg cost', type: 'money' },
  { key: 'value', label: 'Value', type: 'money', sum: true },
];

const REORDER_COLUMNS = [
  { key: 'supplier_name', label: 'Supplier', w: 1.8 }, { key: 'sku', label: 'SKU', w: 1.2 }, { key: 'name', label: 'Product', w: 2.6 },
  { key: 'unit', label: 'Unit', w: 0.6 }, { key: 'available', label: 'Available', type: 'int' }, { key: 'on_order', label: 'On order', type: 'int' },
  { key: 'reorder_point', label: 'Reorder pt', type: 'int' }, { key: 'suggested_qty', label: 'Suggested', type: 'int', sum: true },
  { key: 'cost', label: 'Unit cost', type: 'money' }, { key: 'est_cost', label: 'Est. cost', type: 'money', sum: true },
];

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

module.exports = function registerStock(r, { db, inv, audit }) {
  // ---- Stock levels ------------------------------------------------------
  r.get('/api/stock', 'read', (c) => {
    const where = ['p.active = 1'];
    const params = [];
    if (c.query.warehouse_id) { where.push('s.warehouse_id = ?'); params.push(Number(c.query.warehouse_id)); }
    if (c.query.q) {
      where.push(`(p.sku LIKE ? ESCAPE '\\' OR p.name LIKE ? ESCAPE '\\' OR p.barcode = ?)`);
      params.push(likeParam(c.query.q), likeParam(c.query.q), c.query.q);
    }
    if (c.query.nonzero === '1') where.push('s.on_hand <> 0');
    const sql = `
      SELECT s.product_id, p.sku, p.name, p.unit, p.avg_cost, p.reorder_point, s.warehouse_id,
             w.code AS warehouse_code, w.name AS warehouse_name, s.bin, s.on_hand, s.reserved,
             s.on_hand - s.reserved AS available, ROUND(s.on_hand * p.avg_cost, 2) AS value
      FROM stock s JOIN products p ON p.id = s.product_id JOIN warehouses w ON w.id = s.warehouse_id
      WHERE ${where.join(' AND ')}`;
    if (exportFormat(c.query)) {
      const rows = db.all(`${sql} ORDER BY p.name, w.code LIMIT 100000`, ...params);
      const wh = c.query.warehouse_id ? db.get('SELECT code, name FROM warehouses WHERE id = ?', Number(c.query.warehouse_id)) : null;
      const units = rows.reduce((s, x) => s + x.on_hand, 0);
      const value = rows.reduce((s, x) => s + x.value, 0);
      return new CsvResult('stock-levels.csv', STOCK_COLUMNS, rows, {
        title: 'Stock levels', landscape: true,
        filters: [['Location', wh ? `${wh.code} - ${wh.name}` : 'All locations'], ['Search', c.query.q], ['Rows', c.query.nonzero === '1' ? 'Non-zero only' : null]],
        summary: (f) => [
          { label: 'Stock lines', value: f.int(rows.length) }, { label: 'Units on hand', value: f.int(units) },
          { label: 'Reserved', value: f.int(rows.reduce((s, x) => s + x.reserved, 0)) }, { label: 'Stock value', value: f.money(value) },
        ],
      });
    }
    const { limit, offset } = paging(c.query);
    const total = db.get(`SELECT COUNT(*) AS n FROM (${sql})`, ...params).n;
    const totals = db.get(`SELECT COALESCE(SUM(on_hand),0) AS units, COALESCE(SUM(value),0) AS value FROM (${sql})`, ...params);
    const items = db.all(`${sql} ORDER BY p.name, w.code LIMIT ? OFFSET ?`, ...params, limit, offset);
    return { items, total, limit, offset, totals };
  });

  // ---- Manual movements --------------------------------------------------
  r.post('/api/stock/movements', 'stock:write', (c) => {
    const b = validate(c.body, {
      type: { type: 'enum', values: ['RECEIPT', 'ISSUE', 'ADJUSTMENT'], required: true },
      product_id: { type: 'id', required: true },
      warehouse_id: { type: 'id', required: true },
      qty: { type: 'int', required: true, min: -1e9, max: 1e9 },
      unit_cost: { type: 'number', min: 0, max: 1e9 },
      note: { type: 'string', max: 500 },
    });
    if (b.type !== 'ADJUSTMENT' && b.qty <= 0) throw new HttpError(422, 'Quantity must be positive', { qty: 'must be greater than 0' });
    if (b.type === 'ADJUSTMENT' && !b.note) throw new HttpError(422, 'A reason is required for adjustments', { note: 'reason is required' });
    const qty = b.type === 'ISSUE' ? -b.qty : b.qty;
    const result = inv.move({
      productId: b.product_id, warehouseId: b.warehouse_id, qty, type: b.type,
      unitCost: b.type === 'RECEIPT' ? b.unit_cost : null, note: b.note, userId: c.user.id,
    });
    audit(c, `stock.${b.type.toLowerCase()}`, 'product', b.product_id, { ...b, balance_after: result.balance_after });
    c.status = 201;
    return result;
  });

  r.post('/api/stock/count', 'stock:write', (c) => {
    const b = validate(c.body, {
      product_id: { type: 'id', required: true },
      warehouse_id: { type: 'id', required: true },
      counted: { type: 'int', required: true, min: 0, max: 1e9 },
      note: { type: 'string', max: 500 },
    });
    const result = inv.count({ productId: b.product_id, warehouseId: b.warehouse_id, counted: b.counted, note: b.note || 'Cycle count', userId: c.user.id });
    audit(c, 'stock.count', 'product', b.product_id, { ...b, variance: result.qty });
    return result;
  });

  r.post('/api/stock/transfer', 'stock:write', (c) => {
    const b = validate(c.body, {
      product_id: { type: 'id', required: true },
      from_warehouse_id: { type: 'id', required: true },
      to_warehouse_id: { type: 'id', required: true },
      qty: { type: 'int', required: true, min: 1, max: 1e9 },
      note: { type: 'string', max: 500 },
    });
    const result = inv.transfer({ productId: b.product_id, fromId: b.from_warehouse_id, toId: b.to_warehouse_id, qty: b.qty, note: b.note, userId: c.user.id });
    audit(c, 'stock.transfer', 'product', b.product_id, { ...b, reference: result.reference });
    c.status = 201;
    return result;
  });

  // ---- Movement ledger ---------------------------------------------------
  r.get('/api/movements', 'read', (c) => {
    const where = [];
    const params = [];
    const q = c.query;
    if (q.product_id) { where.push('m.product_id = ?'); params.push(Number(q.product_id)); }
    if (q.warehouse_id) { where.push('m.warehouse_id = ?'); params.push(Number(q.warehouse_id)); }
    if (q.type && MOVEMENT_TYPES.includes(q.type)) { where.push('m.type = ?'); params.push(q.type); }
    if (q.ref) { where.push('m.ref_id = ?'); params.push(q.ref); }
    if (q.q) { where.push(`(p.sku LIKE ? ESCAPE '\\' OR p.name LIKE ? ESCAPE '\\')`); params.push(likeParam(q.q), likeParam(q.q)); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(q.from || '')) { where.push('m.created_at >= ?'); params.push(q.from); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(q.to || '')) { where.push(`m.created_at < date(?, '+1 day')`); params.push(q.to); }
    const sql = `
      SELECT m.*, p.sku, p.name AS product_name, w.code AS warehouse_code, u.name AS user_name
      FROM movements m JOIN products p ON p.id = m.product_id JOIN warehouses w ON w.id = m.warehouse_id
      LEFT JOIN users u ON u.id = m.user_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}`;
    if (exportFormat(q)) {
      const wh = q.warehouse_id ? db.get('SELECT code FROM warehouses WHERE id = ?', Number(q.warehouse_id)) : null;
      const prod = q.product_id ? db.get('SELECT sku FROM products WHERE id = ?', Number(q.product_id)) : null;
      return new CsvResult('stock-movements.csv', MOVEMENT_COLUMNS, db.all(`${sql} ORDER BY m.id DESC LIMIT 100000`, ...params), {
        title: 'Stock movement ledger', landscape: true,
        filters: [
          ['From', DATE_RE.test(q.from || '') ? q.from : null], ['To', DATE_RE.test(q.to || '') ? q.to : null],
          ['Type', MOVEMENT_TYPES.includes(q.type) ? q.type : null], ['Location', wh && wh.code], ['Product', prod && prod.sku],
          ['Reference', q.ref], ['Search', q.q],
        ],
      });
    }
    const { limit, offset } = paging(q);
    const total = db.get(`SELECT COUNT(*) AS n FROM (${sql})`, ...params).n;
    const items = db.all(`${sql} ORDER BY m.id DESC LIMIT ? OFFSET ?`, ...params, limit, offset);
    return { items, total, limit, offset };
  });

  // ---- Replenishment -----------------------------------------------------
  r.get('/api/reorder-suggestions', 'read', (c) => {
    const rows = db.all(`
      SELECT p.id AS product_id, p.sku, p.name, p.unit, p.reorder_point, p.reorder_qty, p.cost, p.avg_cost,
             p.supplier_id, sp.name AS supplier_name,
             COALESCE(SUM(s.on_hand), 0) AS on_hand,
             COALESCE(SUM(s.on_hand - s.reserved), 0) AS available,
             COALESCE((SELECT SUM(l.qty_ordered - l.qty_received) FROM po_lines l
                       JOIN purchase_orders po ON po.id = l.po_id
                       WHERE l.product_id = p.id AND po.status IN ('DRAFT','ORDERED','PARTIAL')), 0) AS on_order
      FROM products p
      LEFT JOIN stock s ON s.product_id = p.id
      LEFT JOIN suppliers sp ON sp.id = p.supplier_id
      WHERE p.active = 1 AND p.reorder_point > 0
      GROUP BY p.id
      HAVING available + on_order <= p.reorder_point
      ORDER BY sp.name IS NULL, sp.name, p.name`);
    const items = rows.map((row) => {
      const suggested = Math.max(row.reorder_qty, row.reorder_point - (row.available + row.on_order), 1);
      return { ...row, suggested_qty: suggested, est_cost: Math.round(suggested * row.cost * 100) / 100 };
    });
    if (exportFormat(c.query)) {
      return new CsvResult('replenishment.csv', REORDER_COLUMNS, items.map((i) => ({ ...i, supplier_name: i.supplier_name || 'No preferred supplier' })), {
        title: 'Replenishment report', landscape: true,
        summary: (f) => [
          { label: 'Products to reorder', value: f.int(items.length) },
          { label: 'Suppliers', value: f.int(new Set(items.map((i) => i.supplier_id)).size) },
          { label: 'Units suggested', value: f.int(items.reduce((s, i) => s + i.suggested_qty, 0)) },
          { label: 'Estimated cost', value: f.money(items.reduce((s, i) => s + i.est_cost, 0)) },
        ],
      });
    }
    return { items };
  });
};
