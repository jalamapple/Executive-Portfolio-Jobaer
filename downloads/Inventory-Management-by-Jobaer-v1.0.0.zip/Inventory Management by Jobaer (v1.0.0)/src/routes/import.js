'use strict';
/**
 * Bulk CSV import for products, suppliers, customers and stock balances.
 *
 * POST /api/import/:entity   (body: the CSV file, Content-Type text/csv)
 *   ?dry_run=1           validate everything and report what would happen, then roll back
 *   ?update_existing=0   skip rows whose key already exists instead of updating them
 *   ?stock_mode=set|add  stock only: set the counted quantity, or add received quantity
 *
 * Imports are all-or-nothing: if any row fails, nothing is saved and every problem is reported
 * with its row number, so a corrected file can simply be uploaded again.
 */
const { HttpError, FileResult } = require('../http');
const { validate } = require('../validate');
const { can } = require('../auth');
const { parseCsv, normaliseHeader } = require('../csv');
const { PRODUCT_SPEC } = require('./master');

const MAX_ROWS = 100000;
const MAX_REPORTED_ERRORS = 500;
const NOW = "strftime('%Y-%m-%dT%H:%M:%fZ','now')";

const BOOL_WORDS = { yes: '1', y: '1', true: '1', active: '1', '1': '1', no: '0', n: '0', false: '0', inactive: '0', '0': '0' };
const normBool = (v) => (v === undefined || v === '' ? v : BOOL_WORDS[String(v).trim().toLowerCase()] ?? v);
const normNumber = (v) => (typeof v === 'string' ? v.replace(/[\s,]/g, '').replace(/^[^\d.-]+/, '') : v); // "1,234.50", "$12"

class Rollback extends Error {}

const ENTITIES = {
  products: {
    label: 'Products', perm: 'master:write', key: 'sku',
    columns: ['sku', 'name', 'description', 'category', 'supplier', 'unit', 'barcode', 'cost', 'price', 'reorder_point', 'reorder_qty', 'active'],
    required: ['sku', 'name'],
    aliases: {
      product_code: 'sku', item_code: 'sku', code: 'sku', product_name: 'name', item_name: 'name', title: 'name',
      category_name: 'category', supplier_name: 'supplier', preferred_supplier: 'supplier', vendor: 'supplier',
      uom: 'unit', unit_of_measure: 'unit', ean: 'barcode', upc: 'barcode', gtin: 'barcode',
      unit_cost: 'cost', cost_price: 'cost', purchase_price: 'cost', selling_price: 'price', sale_price: 'price', unit_price: 'price',
      reorder_level: 'reorder_point', min_stock: 'reorder_point', minimum_stock: 'reorder_point', reorder_quantity: 'reorder_qty', status: 'active',
    },
    example: [
      ['SKU-1001', 'Example product', 'Optional description', 'Electronics', 'Northwind Components', 'ea', '5012345678900', '10.50', '19.99', '20', '50', 'yes'],
    ],
  },
  suppliers: {
    label: 'Suppliers', perm: 'master:write', key: 'name',
    columns: ['name', 'contact_name', 'email', 'phone', 'address', 'lead_time_days', 'active'],
    required: ['name'],
    aliases: { supplier: 'supplier_name', supplier_name: 'name', vendor: 'name', company: 'name', contact: 'contact_name', telephone: 'phone', mobile: 'phone', lead_time: 'lead_time_days', status: 'active' },
    example: [['Example Supplies Ltd', 'Jane Doe', 'orders@example.com', '+1 555 0100', '1 Example Road, City', '7', 'yes']],
  },
  customers: {
    label: 'Customers', perm: 'master:write', key: 'name',
    columns: ['name', 'email', 'phone', 'address', 'active'],
    required: ['name'],
    aliases: { customer: 'name', customer_name: 'name', company: 'name', telephone: 'phone', mobile: 'phone', status: 'active' },
    example: [['Example Customer Ltd', 'buyer@example.com', '+1 555 0199', '9 Customer Street, City', 'yes']],
  },
  stock: {
    label: 'Stock balances', perm: 'stock:write', key: null,
    columns: ['sku', 'location', 'qty', 'unit_cost', 'bin'],
    required: ['sku', 'location', 'qty'],
    aliases: {
      product_code: 'sku', item_code: 'sku', warehouse: 'location', warehouse_code: 'location', location_code: 'location',
      sales_center: 'location', store: 'location', quantity: 'qty', on_hand: 'qty', count: 'qty', cost: 'unit_cost', bin_location: 'bin',
    },
    example: [['SKU-1001', 'CWH', '120', '10.50', 'A-01-03']],
  },
};

const SUPPLIER_SPEC = {
  name: { type: 'string', required: true, max: 200 }, contact_name: { type: 'string', max: 150 },
  email: { type: 'email' }, phone: { type: 'string', max: 50 }, address: { type: 'text', max: 500 },
  lead_time_days: { type: 'int', min: 0, max: 365 }, active: { type: 'bool', default: 1 },
};
const CUSTOMER_SPEC = {
  name: { type: 'string', required: true, max: 200 }, email: { type: 'email' }, phone: { type: 'string', max: 50 },
  address: { type: 'text', max: 500 }, active: { type: 'bool', default: 1 },
};

module.exports = function registerImport(r, { db, inv, audit }) {
  const entityOr404 = (name) => {
    const e = ENTITIES[name];
    if (!e) throw new HttpError(404, `Unknown import type "${name}". Use one of: ${Object.keys(ENTITIES).join(', ')}`);
    return e;
  };

  r.get('/api/import/types', 'read', (c) => Object.entries(ENTITIES)
    .map(([k, e]) => ({ key: k, label: e.label, columns: e.columns, required: e.required, allowed: can(c.user.role, e.perm) })));

  r.get('/api/import/:entity/template', 'read', (c) => {
    const e = entityOr404(c.params.entity);
    const cell = (v) => (/[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
    const csv = [e.columns, ...e.example].map((row) => row.map(cell).join(',')).join('\r\n') + '\r\n';
    return new FileResult(`${c.params.entity}-import-template.csv`, 'text/csv; charset=utf-8', Buffer.from('﻿' + csv, 'utf8'));
  });

  r.post('/api/import/:entity', 'read', (c) => {
    const name = c.params.entity;
    const e = entityOr404(name);
    if (!can(c.user.role, e.perm)) throw new HttpError(403, 'You do not have permission to import this data');
    const dryRun = c.query.dry_run === '1';
    const updateExisting = c.query.update_existing !== '0';
    const stockMode = c.query.stock_mode === 'add' ? 'add' : 'set';

    let parsed;
    try { parsed = parseCsv(c.body, { maxRows: MAX_ROWS + 1 }); } catch (err) { throw new HttpError(422, `Could not read the CSV file: ${err.message}`); }
    if (parsed.rows.length < 2) throw new HttpError(422, 'The file needs a header row and at least one data row');

    // Map headers to fields.
    const header = parsed.rows[0].map(normaliseHeader);
    const fields = header.map((h) => (e.columns.includes(h) ? h : e.aliases[h] && e.columns.includes(e.aliases[h]) ? e.aliases[h] : null));
    const recognised = [...new Set(fields.filter(Boolean))];
    const ignored = parsed.rows[0].filter((_, i) => !fields[i]).map((h) => String(h).trim()).filter(Boolean);
    const missing = e.required.filter((f) => !recognised.includes(f));
    if (missing.length) {
      throw new HttpError(422, `Missing required column(s): ${missing.join(', ')}`, { columns: { required: e.required, found: parsed.rows[0], missing } });
    }

    const data = parsed.rows.slice(1).map((cells, i) => {
      const obj = {};
      fields.forEach((f, j) => { if (f && obj[f] === undefined) obj[f] = (cells[j] ?? '').trim(); });
      return { line: i + 2, obj };
    });

    const report = {
      entity: name, dry_run: dryRun, total_rows: data.length, created: 0, updated: 0, skipped: 0, unchanged: 0,
      error_count: 0, errors: [], columns: { recognised, ignored }, delimiter: parsed.delimiter === '\t' ? 'tab' : parsed.delimiter,
      committed: false,
    };
    const fail = (line, field, message) => {
      report.error_count++;
      if (report.errors.length < MAX_REPORTED_ERRORS) report.errors.push({ row: line, field, message });
    };
    const checked = (line, fn) => {
      try { return fn(); } catch (err) {
        if (err instanceof HttpError) {
          if (err.details && typeof err.details === 'object' && Object.keys(err.details).length && !Array.isArray(err.details)) {
            for (const [f, m] of Object.entries(err.details)) fail(line, f, typeof m === 'string' ? m : err.message);
          } else fail(line, null, err.message);
          return undefined;
        }
        throw err;
      }
    };

    const importer = { products: importProducts, suppliers: importParties('suppliers', SUPPLIER_SPEC), customers: importParties('customers', CUSTOMER_SPEC), stock: importStock }[name];
    const ref = `IMP-${new Date().toISOString().replace(/\D/g, '').slice(0, 14)}`;

    try {
      db.tx(() => {
        importer({ data, report, checked, fail, updateExisting, stockMode, ref, userId: c.user.id });
        if (dryRun || report.error_count) throw new Rollback();
      });
      report.committed = true;
    } catch (err) {
      if (!(err instanceof Rollback)) throw err;
    }

    if (report.committed) {
      audit(c, 'import.commit', 'import', name, {
        rows: report.total_rows, created: report.created, updated: report.updated, skipped: report.skipped, unchanged: report.unchanged,
        ...(name === 'stock' ? { mode: stockMode, reference: ref } : {}),
      });
      if (name === 'stock') report.reference = ref;
    }
    if (!dryRun && report.error_count) {
      throw new HttpError(422, `Import cancelled: ${report.error_count} row error(s). Nothing was saved.`, report);
    }
    return report;
  }, { raw: true, limit: 25 * 1024 * 1024 });

  // ---- Importers -----------------------------------------------------------
  const seenGuard = (key, report) => {
    const seen = new Map();
    return (line, value, fail) => {
      const k = String(value).toLowerCase();
      if (seen.has(k)) { fail(line, key, `duplicates row ${seen.get(k)} in this file`); return false; }
      seen.set(k, line);
      return true;
    };
  };

  function importProducts({ data, report, checked, fail, updateExisting }) {
    const once = seenGuard('sku', report);
    const categoryId = new Map(db.all('SELECT id, name FROM categories').map((x) => [x.name.toLowerCase(), x.id]));
    const supplierId = new Map(db.all('SELECT id, name FROM suppliers ORDER BY id DESC').map((x) => [x.name.toLowerCase(), x.id]));
    const editable = Object.keys(PRODUCT_SPEC).filter((k) => !['category_id', 'supplier_id'].includes(k));

    for (const { line, obj } of data) {
      if (!obj.sku) { fail(line, 'sku', 'is required'); continue; }
      if (!once(line, obj.sku, fail)) continue;
      const existing = db.get('SELECT * FROM products WHERE sku = ? COLLATE NOCASE', obj.sku);
      if (existing && !updateExisting) { report.skipped++; continue; }

      const input = {};
      for (const k of editable) if (obj[k] !== undefined) input[k] = obj[k];
      if (input.active !== undefined) input.active = normBool(input.active);
      for (const k of ['cost', 'price', 'reorder_point', 'reorder_qty']) if (input[k]) input[k] = normNumber(input[k]);

      let ok = true;
      if (obj.category) {
        let id = categoryId.get(obj.category.toLowerCase());
        if (!id && obj.category.length <= 100) {
          id = db.run('INSERT INTO categories (name) VALUES (?)', obj.category).id;
          categoryId.set(obj.category.toLowerCase(), id);
        }
        if (id) input.category_id = id; else { fail(line, 'category', 'must be at most 100 characters'); ok = false; }
      }
      if (obj.supplier) {
        const id = supplierId.get(obj.supplier.toLowerCase());
        if (id) input.supplier_id = id; else { fail(line, 'supplier', `"${obj.supplier}" does not exist (import suppliers first)`); ok = false; }
      }
      // Validate even when a lookup failed, so every problem in the row is reported at once.
      if (existing) {
        // Blank cells leave existing values untouched.
        const patch = Object.fromEntries(Object.entries(input).filter(([, v]) => v !== ''));
        const clean = checked(line, () => validate(patch, PRODUCT_SPEC, { partial: true }));
        if (!clean || !ok) continue;
        const changed = Object.keys(clean).filter((k) => clean[k] !== existing[k]);
        if (!changed.length) { report.unchanged++; continue; }
        db.run(`UPDATE products SET ${changed.map((k) => `${k} = ?`).join(', ')}, updated_at = ${NOW} WHERE id = ?`, ...changed.map((k) => clean[k]), existing.id);
        report.updated++;
      } else {
        const clean = checked(line, () => validate(input, PRODUCT_SPEC));
        if (!clean || !ok) continue;
        clean.avg_cost = clean.cost;
        const cols = Object.keys(clean);
        const done = checked(line, () => db.run(`INSERT INTO products (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`, ...cols.map((k) => clean[k])));
        if (done) report.created++;
      }
    }
  }

  function importParties(table, spec) {
    return ({ data, report, checked, fail, updateExisting }) => {
      const once = seenGuard('name', report);
      const existingByName = new Map(db.all(`SELECT * FROM ${table} ORDER BY id DESC`).map((x) => [x.name.toLowerCase(), x]));
      for (const { line, obj } of data) {
        if (!obj.name) { fail(line, 'name', 'is required'); continue; }
        if (!once(line, obj.name, fail)) continue;
        const input = { ...obj };
        if (input.active !== undefined) input.active = normBool(input.active);
        if (input.lead_time_days) input.lead_time_days = normNumber(input.lead_time_days);
        const existing = existingByName.get(obj.name.toLowerCase());
        if (existing && !updateExisting) { report.skipped++; continue; }
        if (existing) {
          const patch = Object.fromEntries(Object.entries(input).filter(([, v]) => v !== '' && v !== undefined));
          const clean = checked(line, () => validate(patch, spec, { partial: true }));
          if (!clean) continue;
          const changed = Object.keys(clean).filter((k) => clean[k] !== existing[k]);
          if (!changed.length) { report.unchanged++; continue; }
          db.run(`UPDATE ${table} SET ${changed.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, ...changed.map((k) => clean[k]), existing.id);
          report.updated++;
        } else {
          const clean = checked(line, () => validate(input, spec));
          if (!clean) continue;
          const cols = Object.keys(clean);
          db.run(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`, ...cols.map((k) => clean[k]));
          report.created++;
        }
      }
    };
  }

  function importStock({ data, report, checked, fail, stockMode, ref, userId }) {
    const seen = new Map();
    const products = new Map(db.all('SELECT id, sku FROM products').map((x) => [x.sku.toLowerCase(), x.id]));
    const locations = new Map(db.all('SELECT id, code, active FROM warehouses').map((x) => [x.code.toLowerCase(), x]));
    for (const { line, obj } of data) {
      const pid = obj.sku && products.get(obj.sku.toLowerCase());
      const loc = obj.location && locations.get(obj.location.toLowerCase());
      if (!obj.sku) { fail(line, 'sku', 'is required'); continue; }
      if (!pid) { fail(line, 'sku', `"${obj.sku}" does not exist`); continue; }
      if (!obj.location) { fail(line, 'location', 'is required'); continue; }
      if (!loc) { fail(line, 'location', `"${obj.location}" is not a known location code`); continue; }
      if (!loc.active) { fail(line, 'location', `${loc.code} is inactive`); continue; }
      const key = `${pid}|${loc.id}`;
      if (stockMode === 'set' && seen.has(key)) { fail(line, 'sku', `same product and location as row ${seen.get(key)}`); continue; }
      seen.set(key, line);

      const clean = checked(line, () => validate({ qty: normNumber(obj.qty), unit_cost: normNumber(obj.unit_cost), bin: obj.bin }, {
        qty: { type: 'int', required: true, min: stockMode === 'set' ? 0 : 1, max: 1e9 },
        unit_cost: { type: 'number', min: 0, max: 1e9 },
        bin: { type: 'string', max: 30 },
      }));
      if (!clean) continue;

      const result = checked(line, () => {
        const s = inv.stockRow(pid, loc.id);
        if (clean.bin) db.run('UPDATE stock SET bin = ? WHERE product_id = ? AND warehouse_id = ?', clean.bin, pid, loc.id);
        const delta = stockMode === 'set' ? clean.qty - s.on_hand : clean.qty;
        if (delta === 0) return 'unchanged';
        inv.move({
          productId: pid, warehouseId: loc.id, qty: delta, type: stockMode === 'set' ? 'COUNT' : 'RECEIPT',
          unitCost: delta > 0 ? clean.unit_cost : null, refType: 'IMPORT', refId: ref,
          note: stockMode === 'set' ? 'Stock balance import' : 'Stock receipt import', userId,
        });
        return s.on_hand === 0 && stockMode === 'set' ? 'created' : 'updated';
      });
      if (result) report[result]++;
    }
  }
};
