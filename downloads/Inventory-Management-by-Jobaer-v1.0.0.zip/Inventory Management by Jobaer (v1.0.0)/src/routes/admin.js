'use strict';
const { HttpError, CsvResult, exportFormat } = require('../http');
const { validate, paging, idParam, likeParam } = require('../validate');
const { ROLES, hashPassword, checkPasswordPolicy } = require('../auth');

const NOW = "strftime('%Y-%m-%dT%H:%M:%fZ','now')";
const USER_COLS = `id, email, name, role, active, manager_id, last_login_at, created_at, updated_at,
  (SELECT m.name FROM users m WHERE m.id = users.manager_id) AS manager_name`;

module.exports = function registerAdmin(r, { db, sessions, audit }) {
  /** A user's approving manager must be an active manager or administrator, and not the user themselves. */
  const checkManager = (managerId, userId = null) => {
    if (managerId === null || managerId === undefined) return;
    if (userId && managerId === userId) throw new HttpError(422, 'A user cannot be their own manager', { manager_id: 'cannot be the same user' });
    const m = db.get('SELECT role, active FROM users WHERE id = ?', managerId);
    if (!m) throw new HttpError(422, 'Manager not found', { manager_id: 'does not exist' });
    if (!m.active || !['admin', 'manager'].includes(m.role)) throw new HttpError(422, 'The approving manager must be an active manager or administrator', { manager_id: 'must be an active manager or administrator' });
  };
  // ---- Users ---------------------------------------------------------------
  r.get('/api/users', 'users:manage', (c) => {
    const { limit, offset } = paging(c.query, { max: 500 });
    const where = c.query.q ? `WHERE name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\'` : '';
    const params = c.query.q ? [likeParam(c.query.q), likeParam(c.query.q)] : [];
    const total = db.get(`SELECT COUNT(*) AS n FROM users ${where}`, ...params).n;
    const items = db.all(`SELECT ${USER_COLS} FROM users ${where} ORDER BY name LIMIT ? OFFSET ?`, ...params, limit, offset);
    return { items, total, limit, offset };
  });

  r.post('/api/users', 'users:manage', (c) => {
    const b = validate(c.body, {
      email: { type: 'email', required: true },
      name: { type: 'string', required: true, max: 150 },
      role: { type: 'enum', values: ROLES, required: true },
      password: { type: 'string', required: true, max: 200, trim: false },
      active: { type: 'bool', default: 1 },
      manager_id: { type: 'id' },
    });
    checkPasswordPolicy(b.password);
    checkManager(b.manager_id);
    const id = db.run('INSERT INTO users (email, name, role, password_hash, active, manager_id) VALUES (?,?,?,?,?,?)',
      b.email, b.name, b.role, hashPassword(b.password), b.active, b.manager_id).id;
    audit(c, 'user.create', 'user', id, { email: b.email, role: b.role, manager_id: b.manager_id });
    c.status = 201;
    return db.get(`SELECT ${USER_COLS} FROM users WHERE id = ?`, id);
  });

  r.put('/api/users/:id', 'users:manage', (c) => {
    const id = idParam(c.params.id);
    const before = db.get('SELECT * FROM users WHERE id = ?', id);
    if (!before) throw new HttpError(404, 'User not found');
    const b = validate(c.body, {
      name: { type: 'string', required: true, max: 150 },
      role: { type: 'enum', values: ROLES, required: true },
      active: { type: 'bool', required: true },
      password: { type: 'string', max: 200, trim: false },
      manager_id: { type: 'id' },
    }, { partial: true });
    if (b.manager_id !== undefined) checkManager(b.manager_id, id);

    const losesAdmin = before.role === 'admin' && before.active && ((b.role && b.role !== 'admin') || b.active === 0);
    if (losesAdmin) {
      if (id === c.user.id) throw new HttpError(409, 'You cannot remove your own administrator access');
      const others = db.get(`SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND active = 1 AND id <> ?`, id).n;
      if (others === 0) throw new HttpError(409, 'At least one active administrator is required');
    }

    const changes = {};
    if (b.name !== undefined) changes.name = b.name;
    if (b.role !== undefined) changes.role = b.role;
    if (b.active !== undefined) changes.active = b.active;
    if (b.manager_id !== undefined && b.manager_id !== before.manager_id) changes.manager_id = b.manager_id;
    if (b.password) { checkPasswordPolicy(b.password); changes.password_hash = hashPassword(b.password); }
    if (!Object.keys(changes).length) throw new HttpError(422, 'No fields to update');

    const cols = Object.keys(changes);
    db.run(`UPDATE users SET ${cols.map((k) => `${k} = ?`).join(', ')}, updated_at = ${NOW} WHERE id = ?`,
      ...cols.map((k) => changes[k]), id);
    if (changes.password_hash || changes.active === 0 || (changes.role && changes.role !== before.role)) {
      sessions.destroyForUser(id); // force re-authentication with new rights
    }
    const logged = { ...changes };
    if (logged.password_hash) { delete logged.password_hash; logged.password = 'reset'; }
    audit(c, 'user.update', 'user', id, logged);
    return db.get(`SELECT ${USER_COLS} FROM users WHERE id = ?`, id);
  });

  // ---- Audit trail -----------------------------------------------------------
  r.get('/api/audit', 'audit:read', (c) => {
    const where = [];
    const params = [];
    if (c.query.entity) { where.push('entity = ?'); params.push(c.query.entity); }
    if (c.query.entity_id) { where.push('entity_id = ?'); params.push(String(c.query.entity_id)); }
    if (c.query.user_id) { where.push('user_id = ?'); params.push(Number(c.query.user_id)); }
    if (c.query.q) { where.push(`(action LIKE ? ESCAPE '\\' OR user_email LIKE ? ESCAPE '\\')`); params.push(likeParam(c.query.q), likeParam(c.query.q)); }
    const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
    if (exportFormat(c.query)) {
      return new CsvResult('audit-log.csv', [
        { key: 'id', label: 'ID', pdf: false }, { key: 'created_at', label: 'Timestamp (UTC)', type: 'datetime' }, { key: 'user_email', label: 'User', w: 1.8 },
        { key: 'action', label: 'Action', w: 1.7 }, { key: 'entity', label: 'Entity', w: 0.9 }, { key: 'entity_id', label: 'Entity ID', w: 0.8 },
        { key: 'details', label: 'Details', w: 3.2 }, { key: 'ip', label: 'IP', w: 1 },
      ], db.all(`SELECT * FROM audit_log ${w} ORDER BY id DESC LIMIT 100000`, ...params), {
        title: 'Audit log', landscape: true,
        filters: [['Entity', c.query.entity], ['Entity ID', c.query.entity_id], ['Search', c.query.q]],
      });
    }
    const { limit, offset } = paging(c.query);
    const total = db.get(`SELECT COUNT(*) AS n FROM audit_log ${w}`, ...params).n;
    const items = db.all(`SELECT * FROM audit_log ${w} ORDER BY id DESC LIMIT ? OFFSET ?`, ...params, limit, offset);
    return { items, total, limit, offset };
  });

  // ---- Lookups (for form dropdowns) ---------------------------------------
  r.get('/api/lookups', 'read', () => ({
    categories: db.all('SELECT id, name FROM categories ORDER BY name'),
    warehouses: db.all('SELECT id, code, name, kind, active FROM warehouses ORDER BY kind DESC, code'),
    suppliers: db.all('SELECT id, name, active FROM suppliers ORDER BY name'),
    customers: db.all('SELECT id, name, active FROM customers ORDER BY name'),
    products: db.all('SELECT id, sku, name, unit, cost, avg_cost, price, active FROM products ORDER BY name'),
  }));

  // ---- Dashboard -----------------------------------------------------------
  r.get('/api/dashboard', 'read', () => {
    const kpi = db.get(`
      SELECT (SELECT COUNT(*) FROM products WHERE active = 1) AS products,
             (SELECT COUNT(*) FROM warehouses WHERE active = 1) AS warehouses,
             (SELECT COALESCE(SUM(on_hand), 0) FROM stock) AS units,
             (SELECT ROUND(COALESCE(SUM(s.on_hand * p.avg_cost), 0), 2) FROM stock s JOIN products p ON p.id = s.product_id) AS value,
             (SELECT COUNT(*) FROM purchase_orders WHERE status IN ('ORDERED','PARTIAL')) AS open_pos,
             (SELECT COUNT(*) FROM purchase_orders WHERE status = 'DRAFT') AS draft_pos,
             (SELECT COUNT(*) FROM sales_orders WHERE status = 'CONFIRMED') AS to_ship,
             (SELECT COUNT(*) FROM sales_orders WHERE status = 'DRAFT') AS draft_sos`);

    const lowStock = db.all(`
      SELECT p.id, p.sku, p.name, p.reorder_point, p.unit,
             COALESCE(SUM(s.on_hand - s.reserved), 0) AS available
      FROM products p LEFT JOIN stock s ON s.product_id = p.id
      WHERE p.active = 1 AND p.reorder_point > 0
      GROUP BY p.id HAVING available <= p.reorder_point
      ORDER BY CAST(available AS REAL) / p.reorder_point, p.name`);
    kpi.low_stock = lowStock.length;
    kpi.out_of_stock = lowStock.filter((p) => p.available <= 0).length;

    const since = new Date(Date.now() - 13 * 86400000).toISOString().slice(0, 10);
    const trendRows = db.all(`
      SELECT substr(created_at, 1, 10) AS day,
             SUM(CASE WHEN qty > 0 THEN qty ELSE 0 END) AS qty_in,
             SUM(CASE WHEN qty < 0 THEN -qty ELSE 0 END) AS qty_out
      FROM movements WHERE created_at >= ? AND type NOT IN ('TRANSFER_IN','TRANSFER_OUT')
      GROUP BY day ORDER BY day`, since);
    const byDay = new Map(trendRows.map((t) => [t.day, t]));
    const trend = [];
    for (let i = 13; i >= 0; i--) {
      const day = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      const t = byDay.get(day);
      trend.push({ day, qty_in: t ? t.qty_in : 0, qty_out: t ? t.qty_out : 0 });
    }

    return {
      kpi,
      low_stock: lowStock.slice(0, 8),
      trend,
      value_by_warehouse: db.all(`
        SELECT w.code AS label, w.name, ROUND(COALESCE(SUM(s.on_hand * p.avg_cost), 0), 2) AS value
        FROM warehouses w LEFT JOIN stock s ON s.warehouse_id = w.id LEFT JOIN products p ON p.id = s.product_id
        WHERE w.active = 1 GROUP BY w.id ORDER BY value DESC`),
      value_by_category: db.all(`
        SELECT COALESCE(c.name, 'Uncategorised') AS label, ROUND(COALESCE(SUM(s.on_hand * p.avg_cost), 0), 2) AS value
        FROM products p JOIN stock s ON s.product_id = p.id LEFT JOIN categories c ON c.id = p.category_id
        GROUP BY c.id ORDER BY value DESC LIMIT 8`),
      recent_movements: db.all(`
        SELECT m.id, m.type, m.qty, m.created_at, m.ref_id, p.sku, p.name AS product_name, w.code AS warehouse_code
        FROM movements m JOIN products p ON p.id = m.product_id JOIN warehouses w ON w.id = m.warehouse_id
        ORDER BY m.id DESC LIMIT 8`),
    };
  });

  // ---- Reports -------------------------------------------------------------
  r.get('/api/reports/valuation', 'read', (c) => {
    const group = ['warehouse', 'category', 'product'].includes(c.query.group) ? c.query.group : 'warehouse';
    const sql = {
      warehouse: `
        SELECT w.code AS key, w.name AS label, COUNT(DISTINCT CASE WHEN s.on_hand > 0 THEN s.product_id END) AS skus,
               COALESCE(SUM(s.on_hand), 0) AS units, ROUND(COALESCE(SUM(s.on_hand * p.avg_cost), 0), 2) AS value,
               ROUND(COALESCE(SUM(s.on_hand * p.price), 0), 2) AS retail_value
        FROM warehouses w LEFT JOIN stock s ON s.warehouse_id = w.id LEFT JOIN products p ON p.id = s.product_id
        GROUP BY w.id ORDER BY value DESC`,
      category: `
        SELECT COALESCE(c.name, 'Uncategorised') AS key, COALESCE(c.description, '') AS label,
               COUNT(DISTINCT CASE WHEN s.on_hand > 0 THEN p.id END) AS skus,
               COALESCE(SUM(s.on_hand), 0) AS units, ROUND(COALESCE(SUM(s.on_hand * p.avg_cost), 0), 2) AS value,
               ROUND(COALESCE(SUM(s.on_hand * p.price), 0), 2) AS retail_value
        FROM products p LEFT JOIN stock s ON s.product_id = p.id LEFT JOIN categories c ON c.id = p.category_id
        GROUP BY c.id ORDER BY value DESC`,
      product: `
        SELECT p.sku AS key, p.name AS label, 1 AS skus, COALESCE(SUM(s.on_hand), 0) AS units,
               ROUND(COALESCE(SUM(s.on_hand), 0) * p.avg_cost, 2) AS value,
               ROUND(COALESCE(SUM(s.on_hand), 0) * p.price, 2) AS retail_value
        FROM products p LEFT JOIN stock s ON s.product_id = p.id
        GROUP BY p.id HAVING units <> 0 ORDER BY value DESC`,
    }[group];
    const rows = db.all(sql);
    if (exportFormat(c.query)) {
      const cost = rows.reduce((s, x) => s + x.value, 0);
      const retail = rows.reduce((s, x) => s + x.retail_value, 0);
      return new CsvResult(`valuation-by-${group}.csv`, [
        { key: 'key', label: group === 'warehouse' ? 'Location' : group[0].toUpperCase() + group.slice(1), w: 1.4 }, { key: 'label', label: 'Description', w: 2.6 },
        { key: 'skus', label: 'SKUs in stock', type: 'int', sum: group !== 'product' }, { key: 'units', label: 'Units', type: 'int', sum: true },
        { key: 'value', label: 'Cost value', type: 'money', sum: true }, { key: 'retail_value', label: 'Retail value', type: 'money', sum: true },
      ], rows, {
        title: `Inventory valuation by ${group === 'warehouse' ? 'location' : group}`,
        filters: [['Costing method', 'Moving weighted-average cost']],
        summary: (f) => [
          { label: 'Units on hand', value: f.int(rows.reduce((s, x) => s + x.units, 0)) },
          { label: 'Cost value', value: f.money(cost) },
          { label: 'Retail value', value: f.money(retail) },
          { label: 'Potential margin', value: f.money(retail - cost) },
        ],
      });
    }
    const totals = rows.reduce((t, row) => ({ units: t.units + row.units, value: t.value + row.value, retail_value: t.retail_value + row.retail_value }),
      { units: 0, value: 0, retail_value: 0 });
    return { group, items: rows, totals };
  });

  r.get('/api/reports/sales', 'read', (c) => {
    const from = /^\d{4}-\d{2}-\d{2}$/.test(c.query.from || '') ? c.query.from : new Date(Date.now() - 29 * 86400000).toISOString().slice(0, 10);
    const to = /^\d{4}-\d{2}-\d{2}$/.test(c.query.to || '') ? c.query.to : new Date().toISOString().slice(0, 10);
    const rows = db.all(`
      SELECT p.sku, p.name, SUM(l.qty - l.qty_returned) AS units, ROUND(SUM((l.qty - l.qty_returned) * l.unit_price), 2) AS revenue,
             ROUND(SUM((l.qty - l.qty_returned) * COALESCE(l.unit_cost, 0)), 2) AS cogs
      FROM so_lines l JOIN sales_orders so ON so.id = l.so_id JOIN products p ON p.id = l.product_id
      WHERE so.status = 'SHIPPED' AND so.shipped_at >= ? AND so.shipped_at < date(?, '+1 day')
      GROUP BY p.id ORDER BY revenue DESC`, from, to)
      .map((row) => ({ ...row, margin: Math.round((row.revenue - row.cogs) * 100) / 100 }));
    if (exportFormat(c.query)) {
      const revenue = rows.reduce((s, x) => s + x.revenue, 0);
      const cogs = rows.reduce((s, x) => s + x.cogs, 0);
      return new CsvResult(`sales-${from}-to-${to}.csv`, [
        { key: 'sku', label: 'SKU', w: 1.3 }, { key: 'name', label: 'Product', w: 2.8 }, { key: 'units', label: 'Units sold', type: 'int', sum: true },
        { key: 'revenue', label: 'Revenue', type: 'money', sum: true }, { key: 'cogs', label: 'COGS', type: 'money', sum: true },
        { key: 'margin', label: 'Gross margin', type: 'money', sum: true }, { key: 'margin_pct', label: 'Margin %', type: 'pct' },
      ], rows.map((x) => ({ ...x, margin_pct: x.revenue ? Math.round((x.margin / x.revenue) * 1000) / 10 : null })), {
        title: 'Sales & margin report',
        filters: [['Period', `${from} to ${to}`], ['Basis', 'Shipped sales orders']],
        summary: (f) => [
          { label: 'Revenue', value: f.money(revenue) }, { label: 'Cost of goods sold', value: f.money(cogs) },
          { label: 'Gross margin', value: f.money(revenue - cogs) },
          { label: 'Margin %', value: revenue ? f.pct(((revenue - cogs) / revenue) * 100) : '-' },
        ],
      });
    }
    const totals = rows.reduce((t, row) => ({ units: t.units + row.units, revenue: t.revenue + row.revenue, cogs: t.cogs + row.cogs }),
      { units: 0, revenue: 0, cogs: 0 });
    totals.margin = totals.revenue - totals.cogs;
    return { from, to, items: rows, totals };
  });
};
