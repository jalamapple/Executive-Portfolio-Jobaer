'use strict';
const { hashPassword } = require('./auth');

/** Creates the first administrator and, optionally, a realistic demo dataset. Runs only on an empty database. */
function seed(db, inv, config) {
  if (db.get('SELECT COUNT(*) AS n FROM users').n > 0) return;

  db.tx(() => {
    const adminId = db.run('INSERT INTO users (email, name, role, password_hash) VALUES (?,?,?,?)',
      config.adminEmail, 'System Administrator', 'admin', hashPassword(config.adminPassword)).id;
    console.log(`[seed] Created administrator ${config.adminEmail}`);
    if (!process.env.ADMIN_PASSWORD) {
      console.warn('[seed] Using the default admin password. Set ADMIN_PASSWORD before first start in production.');
    }
    if (!config.demoData) return;

    const demoPw = hashPassword('Password123!');
    for (const [email, name, role] of [
      ['manager@inventory.local', 'Morgan Manager', 'manager'],
      ['clerk@inventory.local', 'Casey Clerk', 'clerk'],
      ['viewer@inventory.local', 'Val Viewer', 'viewer'],
    ]) db.run('INSERT INTO users (email, name, role, password_hash) VALUES (?,?,?,?)', email, name, role, demoPw);

    const cat = {};
    for (const [name, description] of [
      ['Electronics', 'Devices, peripherals and accessories'],
      ['Office Supplies', 'Paper, stationery and consumables'],
      ['Furniture', 'Desks, chairs and storage'],
      ['Packaging', 'Boxes, tape and shipping materials'],
      ['Safety Equipment', 'PPE and site safety'],
    ]) cat[name] = db.run('INSERT INTO categories (name, description) VALUES (?,?)', name, description).id;

    const wh = {};
    for (const [code, name, kind, address, manager] of [
      ['CWH', 'Central Warehouse', 'WAREHOUSE', '100 Logistics Way, Building A', 'Sam Okafor'],
      ['EDC', 'East Distribution Center', 'WAREHOUSE', '42 Harbour Road, Unit 7', null],
      ['RET', 'Downtown Sales Center', 'SALES_CENTER', '15 Market Street', 'Priya Nair'],
      ['SC2', 'Airport Sales Center', 'SALES_CENTER', 'Terminal 2, Departures Level', 'Lee Martin'],
    ]) wh[code] = db.run('INSERT INTO warehouses (code, name, kind, address, manager_name) VALUES (?,?,?,?,?)', code, name, kind, address, manager).id;

    const sup = {};
    for (const [name, contact, email, phone, lead] of [
      ['Northwind Components', 'Alex Rivera', 'orders@northwind.example', '+1 555 0100', 7],
      ['Acme Office Co.', 'Jordan Lee', 'sales@acme-office.example', '+1 555 0142', 3],
      ['Summit Furniture Ltd.', 'Sam Patel', 'trade@summit.example', '+1 555 0178', 21],
      ['PackRight Supplies', 'Riley Chen', 'hello@packright.example', '+1 555 0199', 5],
    ]) sup[name] = db.run('INSERT INTO suppliers (name, contact_name, email, phone, lead_time_days) VALUES (?,?,?,?,?)', name, contact, email, phone, lead).id;

    const cust = [];
    for (const [name, email, address] of [
      ['Contoso Retail', 'purchasing@contoso.example', '1 Commerce Plaza'],
      ['Fabrikam Industries', 'procurement@fabrikam.example', '88 Industrial Park'],
      ['Tailspin Offices', 'admin@tailspin.example', '300 Skyline Ave'],
      ['Litware Schools', 'facilities@litware.example', '12 Campus Drive'],
    ]) cust.push(db.run('INSERT INTO customers (name, email, address) VALUES (?,?,?)', name, email, address).id);

    const products = [
      ['EL-1001', 'Wireless Mouse', 'Electronics', 'Northwind Components', 'ea', 8.5, 19.99, 40, 100, '0012345000017'],
      ['EL-1002', 'Mechanical Keyboard', 'Electronics', 'Northwind Components', 'ea', 32, 79, 20, 50, '0012345000024'],
      ['EL-1003', '27" 4K Monitor', 'Electronics', 'Northwind Components', 'ea', 210, 349, 10, 20, '0012345000031'],
      ['EL-1004', 'USB-C Docking Station', 'Electronics', 'Northwind Components', 'ea', 64, 129, 15, 30, '0012345000048'],
      ['EL-1005', 'Noise-Cancelling Headset', 'Electronics', 'Northwind Components', 'ea', 45, 99, 25, 50, '0012345000055'],
      ['OF-2001', 'A4 Copy Paper (500 sheets)', 'Office Supplies', 'Acme Office Co.', 'ream', 3.2, 6.5, 200, 500, '0012345000062'],
      ['OF-2002', 'Ballpoint Pens (box of 50)', 'Office Supplies', 'Acme Office Co.', 'box', 6, 14, 30, 60, '0012345000079'],
      ['OF-2003', 'Sticky Notes 76x76mm (12 pack)', 'Office Supplies', 'Acme Office Co.', 'pack', 4.1, 9.5, 50, 100, '0012345000086'],
      ['OF-2004', 'Heavy-Duty Stapler', 'Office Supplies', 'Acme Office Co.', 'ea', 11, 24, 15, 30, '0012345000093'],
      ['FU-3001', 'Ergonomic Office Chair', 'Furniture', 'Summit Furniture Ltd.', 'ea', 140, 289, 8, 15, '0012345000109'],
      ['FU-3002', 'Sit-Stand Desk 160cm', 'Furniture', 'Summit Furniture Ltd.', 'ea', 260, 499, 5, 10, '0012345000116'],
      ['FU-3003', 'Mobile Pedestal, 3 Drawer', 'Furniture', 'Summit Furniture Ltd.', 'ea', 75, 149, 6, 12, '0012345000123'],
      ['PK-4001', 'Shipping Box 40x30x20cm', 'Packaging', 'PackRight Supplies', 'ea', 0.9, 2.2, 300, 1000, '0012345000130'],
      ['PK-4002', 'Packing Tape 48mm x 66m', 'Packaging', 'PackRight Supplies', 'roll', 1.4, 3.5, 120, 300, '0012345000147'],
      ['PK-4003', 'Bubble Wrap Roll 50m', 'Packaging', 'PackRight Supplies', 'roll', 12, 26, 20, 40, '0012345000154'],
      ['SF-5001', 'Safety Glasses, Clear', 'Safety Equipment', null, 'ea', 2.5, 7, 60, 120, '0012345000161'],
      ['SF-5002', 'Hi-Vis Vest, Size L', 'Safety Equipment', null, 'ea', 3.8, 9.5, 40, 80, '0012345000178'],
    ];
    const pid = {};
    for (const [sku, name, category, supplier, unit, cost, price, rop, roq, barcode] of products) {
      pid[sku] = db.run(
        `INSERT INTO products (sku, name, category_id, supplier_id, unit, cost, avg_cost, price, reorder_point, reorder_qty, barcode)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
        sku, name, cat[category], supplier ? sup[supplier] : null, unit, cost, cost, price, rop, roq, barcode).id;
    }

    // Opening balances and two weeks of activity, so the dashboard has a story to tell.
    const day = (d, h = 10) => new Date(Date.now() - d * 86400000 + h * 3600000 - 12 * 3600000).toISOString();
    let seedN = 7;
    const rand = () => { seedN = (seedN * 16807) % 2147483647; return seedN / 2147483647; };
    const opening = {
      'EL-1001': [180, 60, 25], 'EL-1002': [70, 15, 6], 'EL-1003': [24, 6, 0], 'EL-1004': [12, 4, 0],
      'EL-1005': [55, 20, 10], 'OF-2001': [900, 300, 80], 'OF-2002': [110, 30, 20], 'OF-2003': [40, 20, 8],
      'OF-2004': [35, 10, 5], 'FU-3001': [22, 8, 0], 'FU-3002': [9, 3, 0], 'FU-3003': [4, 2, 0],
      'PK-4001': [1600, 400, 0], 'PK-4002': [260, 120, 15], 'PK-4003': [55, 10, 0], 'SF-5001': [140, 40, 0], 'SF-5002': [30, 12, 0],
    };
    const codes = ['CWH', 'EDC', 'RET'];
    for (const [sku, qtys] of Object.entries(opening)) {
      const p = products.find((x) => x[0] === sku);
      qtys.forEach((q, i) => {
        if (q > 0) inv.move({ productId: pid[sku], warehouseId: wh[codes[i]], qty: q, type: 'RECEIPT', unitCost: p[5], note: 'Opening balance', userId: adminId, createdAt: day(14, 8) });
      });
    }
    for (let d = 13; d >= 1; d--) {
      for (const sku of Object.keys(opening)) {
        if (rand() > 0.35) continue;
        const s = db.get('SELECT on_hand - reserved AS a FROM stock WHERE product_id = ? AND warehouse_id = ?', pid[sku], wh.CWH);
        const q = Math.max(1, Math.round((s ? s.a : 0) * (0.02 + rand() * 0.05)));
        if (s && s.a > q) inv.move({ productId: pid[sku], warehouseId: wh.CWH, qty: -q, type: 'ISSUE', note: 'Internal consumption', userId: adminId, createdAt: day(d, 9 + Math.floor(rand() * 8)) });
      }
      if (d % 4 === 0) {
        const p = products[Math.floor(rand() * products.length)];
        inv.move({ productId: pid[p[0]], warehouseId: wh.CWH, qty: Math.ceil(p[8] / 2), type: 'RECEIPT', unitCost: Math.round(p[5] * (0.95 + rand() * 0.1) * 100) / 100, note: 'Spot purchase', userId: adminId, createdAt: day(d, 14) });
      }
    }
    inv.transfer({ productId: pid['EL-1001'], fromId: wh.CWH, toId: wh.RET, qty: 20, note: 'Store replenishment', userId: adminId });
    for (const [sku, qty] of [['EL-1001', 15], ['EL-1005', 12], ['OF-2002', 20], ['SF-5001', 10]]) {
      inv.transfer({ productId: pid[sku], fromId: wh.CWH, toId: wh.SC2, qty, note: 'Sales center replenishment', userId: adminId });
    }

    // Stock returns from sales centers: one received (with a damaged unit), one in transit, one draft.
    const mkReturn = (from, reason, lines, notes) => {
      const id = db.run('INSERT INTO stock_returns (from_location_id, to_location_id, reason, notes, created_by) VALUES (?,?,?,?,?)',
        wh[from], wh.CWH, reason, notes, adminId).id;
      const number = `RET-${String(id).padStart(6, '0')}`;
      db.run('UPDATE stock_returns SET number = ? WHERE id = ?', number, id);
      for (const [sku, qty] of lines) db.run('INSERT INTO stock_return_lines (return_id, product_id, qty) VALUES (?,?,?)', id, pid[sku], qty);
      return { id, number, lines, from };
    };
    const dispatch = (r) => {
      for (const [sku, qty] of r.lines) inv.move({ productId: pid[sku], warehouseId: wh[r.from], qty: -qty, type: 'TRANSFER_OUT', refType: 'RETURN', refId: r.number, note: 'Return to CWH', userId: adminId });
      db.run(`UPDATE stock_returns SET status = 'DISPATCHED', dispatched_by = ?, dispatched_at = ? WHERE id = ?`, adminId, day(2), r.id);
    };
    const r1 = mkReturn('SC2', 'OVERSTOCK', [['OF-2002', 8], ['SF-5001', 4]], 'Seasonal overstock after promotion');
    dispatch(r1);
    inv.move({ productId: pid['OF-2002'], warehouseId: wh.CWH, qty: 8, type: 'TRANSFER_IN', refType: 'RETURN', refId: r1.number, note: `Return ${r1.number} from SC2`, userId: adminId });
    inv.move({ productId: pid['SF-5001'], warehouseId: wh.CWH, qty: 4, type: 'TRANSFER_IN', refType: 'RETURN', refId: r1.number, note: `Return ${r1.number} from SC2`, userId: adminId });
    inv.move({ productId: pid['SF-5001'], warehouseId: wh.CWH, qty: -1, type: 'ADJUSTMENT', refType: 'RETURN', refId: r1.number, note: `Damaged on return ${r1.number}: written off`, userId: adminId });
    db.run('UPDATE stock_return_lines SET qty_good = qty, qty_damaged = 0 WHERE return_id = ?', r1.id);
    db.run('UPDATE stock_return_lines SET qty_good = 3, qty_damaged = 1 WHERE return_id = ? AND product_id = ?', r1.id, pid['SF-5001']);
    db.run(`UPDATE stock_returns SET status = 'RECEIVED', received_by = ?, received_at = ? WHERE id = ?`, adminId, day(1), r1.id);
    dispatch(mkReturn('RET', 'UNSOLD', [['EL-1001', 5], ['OF-2002', 4]], 'Slow sellers going back to central stock'));
    mkReturn('SC2', 'DAMAGED', [['EL-1005', 2]], 'Packaging crushed in transit to store');

    // Purchase orders in several states
    const mkPo = (supplier, status, lines, expectedInDays) => {
      const id = db.run(
        `INSERT INTO purchase_orders (supplier_id, warehouse_id, status, expected_date, created_by, approved_by, ordered_at)
         VALUES (?,?,?,date('now', ?),?,?,?)`,
        sup[supplier], wh.CWH, status, `+${expectedInDays} day`, adminId, status === 'DRAFT' ? null : adminId, status === 'DRAFT' ? null : day(2)).id;
      db.run('UPDATE purchase_orders SET number = ? WHERE id = ?', `PO-${String(id).padStart(6, '0')}`, id);
      for (const [sku, qty] of lines) {
        const p = products.find((x) => x[0] === sku);
        db.run('INSERT INTO po_lines (po_id, product_id, qty_ordered, unit_cost) VALUES (?,?,?,?)', id, pid[sku], qty, p[5]);
      }
    };
    mkPo('Northwind Components', 'ORDERED', [['EL-1003', 20], ['EL-1004', 30]], 5);
    mkPo('Summit Furniture Ltd.', 'ORDERED', [['FU-3003', 12], ['FU-3002', 6]], 14);
    mkPo('PackRight Supplies', 'DRAFT', [['PK-4003', 40]], 7);

    // Sales orders: one shipped, one confirmed (reserved), one draft
    const mkSo = (customer, lines) => {
      const id = db.run('INSERT INTO sales_orders (customer_id, warehouse_id, created_by) VALUES (?,?,?)', customer, wh.CWH, adminId).id;
      db.run('UPDATE sales_orders SET number = ? WHERE id = ?', `SO-${String(id).padStart(6, '0')}`, id);
      for (const [sku, qty] of lines) {
        const p = products.find((x) => x[0] === sku);
        db.run('INSERT INTO so_lines (so_id, product_id, qty, unit_price) VALUES (?,?,?,?)', id, pid[sku], qty, p[6]);
      }
      return id;
    };
    const shipped = mkSo(cust[0], [['EL-1001', 25], ['EL-1002', 10]]);
    for (const l of db.all('SELECT * FROM so_lines WHERE so_id = ?', shipped)) {
      const p = db.get('SELECT avg_cost FROM products WHERE id = ?', l.product_id);
      db.run('UPDATE so_lines SET unit_cost = ? WHERE id = ?', p.avg_cost, l.id);
      inv.move({ productId: l.product_id, warehouseId: wh.CWH, qty: -l.qty, type: 'SALE', unitCost: p.avg_cost, refType: 'SO', refId: `SO-${String(shipped).padStart(6, '0')}`, userId: adminId });
    }
    db.run(`UPDATE sales_orders SET status = 'SHIPPED', confirmed_at = ?, shipped_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`, day(1), shipped);

    const confirmed = mkSo(cust[1], [['FU-3001', 4], ['OF-2001', 100]]);
    for (const l of db.all('SELECT * FROM so_lines WHERE so_id = ?', confirmed)) inv.reserve(l.product_id, wh.CWH, l.qty);
    db.run(`UPDATE sales_orders SET status = 'CONFIRMED', confirmed_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?`, confirmed);

    mkSo(cust[2], [['OF-2002', 10], ['OF-2004', 5], ['EL-1005', 8]]);

    // Approval chain: the sales agent (clerk) reports to the manager.
    db.run(`UPDATE users SET manager_id = (SELECT id FROM users WHERE email = 'manager@inventory.local') WHERE email = 'clerk@inventory.local'`);
    db.run(`UPDATE users SET manager_id = ? WHERE email = 'manager@inventory.local'`, adminId);

    db.run(`INSERT INTO audit_log (user_id, user_email, action, entity, details) VALUES (?,?,?,?,?)`,
      adminId, config.adminEmail, 'system.seed', 'system', JSON.stringify({ demo: true }));
    console.log('[seed] Demo data loaded (demo users share password "Password123!")');
  });
}

module.exports = { seed };
