# Enterprise Inventory

*Created by Jobaer Alam*

Enterprise Inventory is inventory management software for multiple warehouses. It covers stock control, purchasing, sales fulfilment, costing, reporting, role-based access and a full audit trail.

It has **zero runtime dependencies**. It needs only Node.js 22.13+ (it uses the built-in `node:sqlite` engine), so there is no `npm install` step, no native build and no supply-chain surface.

## Quick start

```bash
cd Inventory
npm start            # http://localhost:3000
```

On first start the app creates the database (`data/inventory.db`) and seeds demo data.

| Account | Password | Role |
|---|---|---|
| admin@inventory.local | `Admin@123456` | Administrator |
| manager@inventory.local | `Password123!` | Manager |
| clerk@inventory.local | `Password123!` | Warehouse clerk |
| viewer@inventory.local | `Password123!` | Read-only |

Other commands:

- `npm test` runs the API and business-rule test suite (40 tests).
- `npm run dev` restarts the server when files change.

## Installation package

```bash
npm run package      # -> dist/EnterpriseInventory-<version>.zip (+ .sha256)
```

The zip contains:

- **Windows:** `Install.bat`, which sets up a background service, nightly backups, a firewall rule, shortcuts, and in-place upgrades.
- **Linux:** a systemd installer.
- **Docker:** Docker files.
- **Admin tools:** backup, restore and reset-admin.
- **Guide:** an Installation & Administration Guide in PDF and HTML.

See [INSTALL.md](INSTALL.md). Settings live in `config.env` (template: `config.env.example`).

## Features

| Area | Capabilities |
|---|---|
| **Locations** | Warehouses and sales centers (multiple of each), with manager, phone and address. Sales centers hold and sell their own stock. |
| **Products** | SKU, barcode, category, preferred supplier, unit of measure, standard cost, selling price, reorder point and quantity, active flag, bin locations per warehouse |
| **Stock** | Multi-warehouse on-hand / reserved / available stock; receipts, issues, adjustments (reason required), cycle counts (variance posted automatically) and atomic inter-warehouse transfers |
| **Ledger** | Every stock change is an append-only movement with running balance, cost, reference and user. Database triggers block edits and deletes. |
| **Costing** | Moving weighted-average cost, updated on every receipt; COGS and margin captured at shipment |
| **Purchasing** | Draft → manager approval → ordered → partial / full receiving, with over-receipt protection |
| **Sales** | Draft → confirm (reserves stock) → ship (issues stock). Shortage detection and reservation release on cancel. |
| **Returns to warehouse** | Sales center → warehouse returns: draft → dispatched (in transit) → received with inspection. Good units go back into stock, damaged units are written off, and missing units are recorded. Each return has a PDF return note. |
| **Replenishment** | Reorder suggestions that count stock already on order, grouped by supplier, with one-click draft POs |
| **Reports** | Dashboard KPIs and charts, valuation by location, category or product, sales and margin by period. Every report and list can be downloaded as **CSV** or as a **branded PDF**. |
| **Documents (PDF)** | Purchase orders, order confirmations, packing slips, invoices and return notes, all on your company letterhead |
| **Company branding** | Company name, legal name, tagline, logo (PNG/JPEG), brand colour, contact details, tax ID, sign-in page text, currency, time zone, report footer and terms. Applied to the sign-in page, the app and every PDF. |
| **CSV import** | Bulk import of products, suppliers, customers and stock balances (up to 25 MB / 100,000 rows). Common column names are recognised and Excel's semicolon or non-UTF-8 files are handled. Each import is validated first, with row-by-row error reports, and is all-or-nothing. |
| **Security** | RBAC (admin / manager / clerk / viewer), scrypt password hashing, HttpOnly + SameSite=Strict session cookies, CSRF header check, brute-force lockout, strict CSP and security headers, parameterised SQL, CSV formula-injection protection |
| **Manager approval** | Sales agents (clerk role) need their manager's approval to change a confirmed order or a shipped invoice (prices, quantities, customer returns), to cancel a confirmed order, and to dispatch or cancel a return to the warehouse. Each user can be assigned an approving manager; administrators can always approve, and nobody can approve their own request. Requests carry a mandatory reason and a before/after preview. Nothing changes until approval, and the document is locked while a request is open. |
| **Audit** | Every create, update, approval, receipt, shipment, login and failed login is logged with user, IP and details. Filterable and exportable. |

### Roles

| Permission | admin | manager | clerk | viewer |
|---|:-:|:-:|:-:|:-:|
| View everything | ✔ | ✔ | ✔ | ✔ |
| Receive / issue / count / transfer stock, ship orders | ✔ | ✔ | ✔ | |
| Create and edit draft orders | ✔ | ✔ | ✔ | |
| Change confirmed orders / invoices, customer returns, dispatch returns | ✔ | ✔ | needs approval | |
| Approve sales agents' change requests | ✔ | ✔ (own team) | | |
| Approve / cancel purchase orders | ✔ | ✔ | | |
| Manage products and master data | ✔ | ✔ | | |
| View audit log | ✔ | ✔ | | |
| Import products, suppliers and customers | ✔ | ✔ | | |
| Import stock balances, create returns | ✔ | ✔ | ✔ | |
| Manage users and company branding | ✔ | | | |

## Configuration (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3000` | HTTP port (set automatically by Azure App Service) |
| `DB_PATH` | `./data/inventory.db` (`/home/data/inventory.db` on Azure) | SQLite database file |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | `admin@inventory.local` / `Admin@123456` | First administrator, created on an empty database only |
| `DEMO_DATA` | `true` | Seed demo users, products and orders on first start |
| `COMPANY_NAME` | `Enterprise Inventory` | Branding in the UI |
| `CURRENCY` | `USD` | ISO 4217 code used for money formatting |
| `SESSION_TTL_HOURS` | `12` | Session lifetime |
| `SECURE_COOKIES` | `true` when `NODE_ENV=production` | Adds `Secure` to cookies and sends HSTS |
| `TRUST_PROXY` | `true` on Azure | Read the client IP from `X-Forwarded-For` |
| `LOG_REQUESTS` | `true` | One log line per API request |

## Production deployment (Azure App Service, Linux)

1. Create a **Node 22 LTS or newer** Linux web app.
2. In **App settings**, set:
   - `NODE_ENV=production`
   - `DEMO_DATA=false`
   - a strong `ADMIN_PASSWORD`
   - `ADMIN_EMAIL`, `COMPANY_NAME` and `CURRENCY`
3. Deploy the `Inventory` folder, for example with `az webapp up --runtime "NODE:22-lts"` or zip deploy. The startup command is `npm start`.
4. Set the **health check** path to `/api/health`.
5. The database lives in `/home/data`, which persists across restarts and deployments. Back it up regularly. App Service backups include `/home`.

Notes for production:

- **Instance count.** SQLite is a single-writer database, so run **one instance**. To scale out horizontally, move to PostgreSQL or Azure SQL. The data layer (`src/db.js`) is deliberately thin to make that move straightforward.
- **Sign-in throttling.** The login limiter is in memory, so it is per instance.
- **First sign-in.** Sign in as the administrator and change the password from the user menu.

## Project layout

```
server.js              HTTP server, graceful shutdown
src/app.js             Request pipeline: security headers, CSRF, auth, RBAC, error mapping, audit
src/db.js              SQLite connection, versioned migrations, nested transactions
src/inventory.js       Stock engine: movements, average cost, counts, transfers, reservations
src/auth.js            Password hashing, sessions, login throttling, role permissions
src/validate.js        Input validation and paging helpers
src/routes/*.js        REST API (auth, master data, stock, orders, returns, import, branding, admin & reports)
src/pdf.js             Dependency-free PDF writer (text, tables, PNG/JPEG logos)
src/reports.js         Branded report and document layouts
src/branding.js        Company branding settings and logo storage
src/csv.js             CSV parser for imports
src/seed.js            First admin and demo dataset
public/                Single-page web app (no framework, no build step)
test/api.test.js       End-to-end API tests (node:test)
```

## API overview

All endpoints are under `/api` and use JSON.

- **Errors.** Errors return `{ error, details }` with the appropriate HTTP status.
- **Mutations.** Mutating requests need the `X-Requested-With: fetch` header and a session cookie from `POST /api/auth/login`.
- **Pagination.** List endpoints accept `limit` and `offset`.
- **Exports.** List and report endpoints accept `format=csv` or `format=pdf` (add `inline=1` to view a PDF in the browser).

Main resources:

- `products`
- `categories`
- `warehouses`
- `suppliers`
- `customers`
- `stock`
- `stock/movements`
- `stock/count`
- `stock/transfer`
- `movements`
- `reorder-suggestions`
- `purchase-orders` (plus `/submit`, `/receive`, `/cancel`, `/pdf`)
- `sales-orders` (plus `/confirm`, `/ship`, `/cancel`, `/pdf?doc=confirmation|packing|invoice`)
- `returns` (plus `/dispatch`, `/receive`, `/cancel`, `/pdf`)
- `sales-orders/:id/amend` (change a confirmed order or invoice; returns `202` with `pending_approval` for sales agents)
- `approvals` (plus `/summary`, `/:id/approve`, `/:id/reject`, `/:id/withdraw`)
- `import/:entity` (CSV body; `?dry_run=1`; `/template`)
- `settings/branding`, `settings/logo`, `settings/sample.pdf`, `branding/logo`
- `users`
- `audit`
- `dashboard`
- `reports/valuation`
- `reports/sales`
- `lookups`
