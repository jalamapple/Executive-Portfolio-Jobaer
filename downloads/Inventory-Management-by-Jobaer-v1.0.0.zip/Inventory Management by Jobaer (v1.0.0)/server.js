'use strict';
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`Enterprise Inventory needs Node.js 22.13 or newer (found ${process.versions.node}). Install the current LTS from https://nodejs.org`);
  process.exit(1);
}

const http = require('node:http');
const os = require('node:os');
const config = require('./src/config');
const { createApp } = require('./src/app');

let app;
try {
  app = createApp(config);
} catch (err) {
  console.error(`[fatal] Could not open the database at ${config.dbPath}: ${err.message}`);
  process.exit(1);
}

const server = http.createServer((req, res) => {
  app.handle(req, res).catch((err) => {
    console.error('[fatal] unhandled request error', err);
    if (!res.headersSent) res.writeHead(500);
    res.end();
  });
});
server.headersTimeout = 30_000;
server.requestTimeout = 120_000; // allow large CSV imports

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') console.error(`[fatal] Port ${config.port} is already in use. Change PORT in config.env or stop the other program.`);
  else if (err.code === 'EACCES') console.error(`[fatal] No permission to listen on port ${config.port}. Use a port above 1024 or run with more privileges.`);
  else console.error('[fatal]', err);
  process.exit(1);
});

server.listen(config.port, config.host, () => {
  console.log(`Enterprise Inventory ${config.version} (created by Jobaer Alam)`);
  console.log(`Settings: ${config.configFile || 'environment variables only'}`);
  console.log(`Database: ${config.dbPath}`);
  console.log(`Open http://localhost:${config.port}`);
  if (config.host === '0.0.0.0') {
    for (const list of Object.values(os.networkInterfaces())) {
      for (const a of list || []) if (a.family === 'IPv4' && !a.internal) console.log(`  or http://${a.address}:${config.port} from other computers`);
    }
  }
});

function shutdown(signal) {
  console.log(`${signal} received, shutting down...`);
  server.close(() => { app.close(); process.exit(0); });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
