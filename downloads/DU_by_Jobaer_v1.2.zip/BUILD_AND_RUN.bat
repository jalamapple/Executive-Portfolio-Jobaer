@echo off
setlocal
cd /d "%~dp0"
title DU by Jobaer - Windows Build
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo ERROR: The Microsoft .NET Framework C# compiler was not found.
  echo Please enable/install Microsoft .NET Framework 4.x or use Visual Studio Build Tools.
  pause
  exit /b 1
)
if not exist "DUByJobaer.cs" (
  echo ERROR: DUByJobaer.cs is missing.
  pause
  exit /b 1
)
echo Building DU by Jobaer for Windows...
"%CSC%" /nologo /target:winexe /platform:anycpu /codepage:65001 /optimize+ /win32icon:"DUByJobaer.ico" /out:"DU by Jobaer.exe" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll "DUByJobaer.cs"
if errorlevel 1 (
  echo.
  echo BUILD FAILED. See the compiler errors above.
  pause
  exit /b 1
)
echo.
echo Build successful: DU by Jobaer.exe
echo Starting application...
start "" "%~dp0DU by Jobaer.exe"
exit /b 0
