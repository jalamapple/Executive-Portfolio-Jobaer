﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace DUByJobaer
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Dashboard());
        }
    }

    internal static class Theme
    {
        internal static readonly Color Bg = Color.FromArgb(12, 17, 30);
        internal static readonly Color Card = Color.FromArgb(23, 32, 51);
        internal static readonly Color Line = Color.FromArgb(42, 58, 79);
        internal static readonly Color White = Color.FromArgb(235, 243, 255);
        internal static readonly Color Muted = Color.FromArgb(151, 168, 187);
        internal static readonly Color Down = Color.FromArgb(56, 190, 255);
        internal static readonly Color Up = Color.FromArgb(76, 224, 153);
    }

    internal sealed class AdapterItem
    {
        internal readonly string Id;
        internal readonly string DisplayName;
        internal AdapterItem(string id, string displayName) { Id = id; DisplayName = displayName; }
        public override string ToString() { return DisplayName; }
    }

    internal sealed class TrafficChart : Panel
    {
        private readonly List<double> down = new List<double>();
        private readonly List<double> up = new List<double>();
        private const int Capacity = 60;

        internal TrafficChart()
        {
            DoubleBuffered = true;
            BackColor = Theme.Card;
        }

        internal void AddPoint(double downloadBytesPerSecond, double uploadBytesPerSecond)
        {
            down.Add(downloadBytesPerSecond);
            up.Add(uploadBytesPerSecond);
            if (down.Count > Capacity) { down.RemoveAt(0); up.RemoveAt(0); }
            Invalidate();
        }

        internal void ClearChart() { down.Clear(); up.Clear(); Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (Pen border = new Pen(Theme.Line))
                g.DrawRectangle(border, 0, 0, Width - 1, Height - 1);
            using (Font heading = new Font("Segoe UI", 11f, FontStyle.Bold))
            using (SolidBrush text = new SolidBrush(Theme.White))
                g.DrawString("LIVE TRAFFIC  /  LAST 60 SECONDS", heading, text, 18, 14);
            using (Font legendFont = new Font("Segoe UI", 9f))
            using (SolidBrush downBrush = new SolidBrush(Theme.Down))
            using (SolidBrush upBrush = new SolidBrush(Theme.Up))
            {
                g.DrawString("● Download", legendFont, downBrush, Width - 198, 20);
                g.DrawString("● Upload", legendFont, upBrush, Width - 100, 20);
            }

            Rectangle plot = new Rectangle(48, 55, Math.Max(1, Width - 66), Math.Max(1, Height - 85));
            double maximum = 1024.0;
            foreach (double d in down) if (d > maximum) maximum = d;
            foreach (double u in up) if (u > maximum) maximum = u;
            maximum = NiceCeiling(maximum);

            using (Pen grid = new Pen(Theme.Line, 1f))
            using (Font axisFont = new Font("Segoe UI", 8f))
            using (SolidBrush muted = new SolidBrush(Theme.Muted))
            {
                for (int i = 0; i <= 4; i++)
                {
                    float y = plot.Y + (plot.Height * i / 4f);
                    g.DrawLine(grid, plot.X, y, plot.Right, y);
                    string label = Dashboard.FormatRate(maximum * (4 - i) / 4.0);
                    g.DrawString(label, axisFont, muted, 3, y - 7);
                }
                g.DrawString("-60s", axisFont, muted, plot.Left, plot.Bottom + 7);
                g.DrawString("Now", axisFont, muted, plot.Right - 25, plot.Bottom + 7);
            }

            DrawSeries(g, plot, down, maximum, Theme.Down);
            DrawSeries(g, plot, up, maximum, Theme.Up);
        }

        private static double NiceCeiling(double value)
        {
            if (value <= 0) return 1024;
            double power = Math.Pow(10, Math.Floor(Math.Log10(value)));
            double scaled = value / power;
            double step = scaled <= 1 ? 1 : scaled <= 2 ? 2 : scaled <= 5 ? 5 : 10;
            return step * power;
        }

        private static void DrawSeries(Graphics g, Rectangle plot, List<double> points, double max, Color color)
        {
            if (points.Count < 2) return;
            PointF[] positions = new PointF[points.Count];
            for (int i = 0; i < points.Count; i++)
            {
                // The chart always uses a fixed 60-second horizontal time scale.
                float x = plot.Right - (points.Count - 1 - i) * plot.Width / 59f;
                float y = plot.Bottom - (float)(Math.Max(0, points[i]) / max) * plot.Height;
                positions[i] = new PointF(x, y);
            }
            using (Pen pen = new Pen(color, 2.4f))
                g.DrawLines(pen, positions);
            PointF last = positions[positions.Length - 1];
            using (SolidBrush brush = new SolidBrush(color))
                g.FillEllipse(brush, last.X - 3.5f, last.Y - 3.5f, 7f, 7f);
        }
    }

    // v1.2: compact, semi-transparent Windows-taskbar overlay.
    // This is a normal topmost WinForms window, NOT a shell-injected taskbar extension.
    internal sealed class MiniBar : Form
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr FindWindow(string className, string windowName);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetWindowRect(IntPtr windowHandle, out RECT rect);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetWindowPos(IntPtr windowHandle, IntPtr insertAfter,
                                                int x, int y, int width, int height, uint flags);

        private static readonly IntPtr HwndTopMost = new IntPtr(-1);
        private const uint SwpNoActivate = 0x0010;
        private const uint SwpNoOwnerZOrder = 0x0200;
        private const int WsExNoActivate = 0x08000000;
        private const int WsExToolWindow = 0x00000080;
        private const int BarHeight = 22;
        private const int BadgeWidth = 22;
        private const int LeftPad = 4;
        private const int TextGap = 7;

        private readonly Dashboard dashboard;
        private readonly Timer dockingTimer;
        private readonly Font badgeFont;
        private readonly Font ratesFont;
        private string downText = "D:0B/s";
        private string upText = "U:0B/s";
        private int dockOffset = 72;
        private int dragStartOffset;
        private Point dragStart;
        private bool dragging;
        private Rectangle lastTaskbar = Rectangle.Empty;

        // Keeps the overlay from stealing keyboard focus when appearing over taskbar.
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WsExNoActivate | WsExToolWindow;
                return cp;
            }
        }

        internal int DockOffset
        {
            get { return dockOffset; }
            set { dockOffset = Math.Max(4, value); }
        }

        internal MiniBar(Dashboard parent, ContextMenuStrip context)
        {
            dashboard = parent;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            ShowIcon = false;
            StartPosition = FormStartPosition.Manual;
            AutoScaleMode = AutoScaleMode.None;
            Opacity = 0.86; // Slightly translucent, including badge and text.
            ClientSize = new Size(170, BarHeight);
            BackColor = Color.FromArgb(18, 30, 48);
            Cursor = Cursors.Hand;
            ContextMenuStrip = context;
            DoubleBuffered = true;
            badgeFont = new Font("Segoe UI", 8f, FontStyle.Bold, GraphicsUnit.Point);
            ratesFont = new Font("Segoe UI", 8.25f, FontStyle.Bold, GraphicsUnit.Point);

            MouseDoubleClick += delegate(object sender, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left) dashboard.RestoreDashboard();
            };
            MouseDown += BarMouseDown;
            MouseMove += BarMouseMove;
            MouseUp += BarMouseUp;

            // Windows Explorer may move/recreate the taskbar after display or DPI changes.
            // Recheck docking and restore topmost order without activating this window.
            dockingTimer = new Timer();
            dockingTimer.Interval = 1500;
            dockingTimer.Tick += delegate
            {
                if (Visible && !dragging && (ContextMenuStrip == null || !ContextMenuStrip.Visible))
                    DockOnTaskbar();
            };
            dockingTimer.Start();
        }

        private static Rectangle GetTaskbarRectangle()
        {
            // Shell_TrayWnd is the primary Windows taskbar on Windows 10 and 11.
            // GetWindowRect reflects the actual location, including top/side taskbars.
            try
            {
                IntPtr hwnd = FindWindow("Shell_TrayWnd", null);
                RECT rc;
                if (hwnd != IntPtr.Zero && GetWindowRect(hwnd, out rc) &&
                    rc.Right > rc.Left && rc.Bottom > rc.Top)
                    return Rectangle.FromLTRB(rc.Left, rc.Top, rc.Right, rc.Bottom);
            }
            catch { }

            // Fallback if Explorer/taskbar is temporarily unavailable.
            Screen screen = Screen.PrimaryScreen;
            Rectangle b = screen.Bounds;
            Rectangle w = screen.WorkingArea;
            if (w.Bottom < b.Bottom) return Rectangle.FromLTRB(b.Left, w.Bottom, b.Right, b.Bottom);
            if (w.Top > b.Top) return Rectangle.FromLTRB(b.Left, b.Top, b.Right, w.Top);
            if (w.Left > b.Left) return Rectangle.FromLTRB(b.Left, b.Top, w.Left, b.Bottom);
            if (w.Right < b.Right) return Rectangle.FromLTRB(w.Right, b.Top, b.Right, b.Bottom);
            return new Rectangle(b.Left, b.Bottom - 40, b.Width, 40);
        }

        internal void DockOnTaskbar()
        {
            if (IsDisposed || !IsHandleCreated) return;
            Rectangle taskbar = GetTaskbarRectangle();
            lastTaskbar = taskbar;
            bool horizontal = taskbar.Width >= taskbar.Height;
            int alongLength = horizontal ? taskbar.Width : taskbar.Height;
            int barLength = horizontal ? Width : Height;
            int maxOffset = Math.Max(4, alongLength - barLength - 5);
            dockOffset = Math.Max(4, Math.Min(dockOffset, maxOffset));

            // Overlay INSIDE the Windows taskbar, instead of floating above it.
            int x = horizontal ? taskbar.Left + dockOffset :
                taskbar.Left + (taskbar.Width - Width) / 2;
            int y = horizontal ? taskbar.Top + (taskbar.Height - Height) / 2 :
                taskbar.Top + dockOffset;

            if (Left != x || Top != y) Location = new Point(x, y);
            try
            {
                SetWindowPos(Handle, HwndTopMost, x, y, Width, Height,
                             SwpNoActivate | SwpNoOwnerZOrder);
            }
            catch { }
        }

        internal void PositionNearTaskbar() { DockOnTaskbar(); }

        private void BarMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left || e.Clicks > 1) return;
            dragging = true;
            dragStart = Cursor.Position;
            dragStartOffset = dockOffset;
        }

        private void BarMouseMove(object sender, MouseEventArgs e)
        {
            if (!dragging || Control.MouseButtons != MouseButtons.Left) return;
            bool horizontal = lastTaskbar.Width >= lastTaskbar.Height;
            Point mouse = Cursor.Position;
            dockOffset = Math.Max(4, dragStartOffset +
                (horizontal ? mouse.X - dragStart.X : mouse.Y - dragStart.Y));
            DockOnTaskbar();
        }

        private void BarMouseUp(object sender, MouseEventArgs e)
        {
            if (!dragging) return;
            dragging = false;
            dashboard.SaveMiniPosition();
            DockOnTaskbar();
        }

        internal void SetRates(string downloadRate, string uploadRate)
        {
            // Remove spaces only in the small overlay, keeping B/s, KB/s, MB/s.
            string nextDown = "D:" + downloadRate.Replace(" ", "");
            string nextUp = "U:" + uploadRate.Replace(" ", "");
            if (nextDown == downText && nextUp == upText) return;
            downText = nextDown;
            upText = nextUp;

            // No wasted blank space: width follows the actual combined text lengths.
            TextFormatFlags flags = TextFormatFlags.SingleLine | TextFormatFlags.NoPadding;
            int downWidth = TextRenderer.MeasureText(downText, ratesFont, new Size(400, BarHeight), flags).Width;
            int upWidth = TextRenderer.MeasureText(upText, ratesFont, new Size(400, BarHeight), flags).Width;
            int width = LeftPad + BadgeWidth + 6 + downWidth + TextGap + upWidth + 5;
            width = Math.Max(137, Math.Min(width, 230));
            if (ClientSize.Width != width)
            {
                ClientSize = new Size(width, BarHeight);
                if (Visible) DockOnTaskbar();
            }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(BackColor);

            using (SolidBrush badge = new SolidBrush(Color.FromArgb(45, 77, 116)))
                g.FillRectangle(badge, LeftPad, 3, BadgeWidth, Height - 6);
            TextFormatFlags flags = TextFormatFlags.SingleLine | TextFormatFlags.NoPadding |
                                    TextFormatFlags.VerticalCenter;
            TextRenderer.DrawText(g, "JA", badgeFont, new Rectangle(LeftPad + 3, 2, BadgeWidth - 4, Height - 3),
                                  Theme.White, flags);
            int downX = LeftPad + BadgeWidth + 6;
            int downWidth = TextRenderer.MeasureText(g, downText, ratesFont,
                            new Size(400, BarHeight), flags).Width;
            TextRenderer.DrawText(g, downText, ratesFont,
                new Rectangle(downX, 0, downWidth, Height), Theme.Down, flags);
            int upX = downX + downWidth + TextGap;
            TextRenderer.DrawText(g, upText, ratesFont,
                new Rectangle(upX, 0, Math.Max(1, Width - upX - 3), Height), Theme.Up, flags);

            using (Pen edge = new Pen(Color.FromArgb(60, 110, 150)))
                g.DrawRectangle(edge, 0, 0, Width - 1, Height - 1);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                dockingTimer.Stop();
                dockingTimer.Dispose();
                badgeFont.Dispose();
                ratesFont.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    internal sealed class Dashboard : Form
    {
        private readonly System.Windows.Forms.Timer timer;
        private readonly Stopwatch sampleClock = new Stopwatch();
        private readonly NotifyIcon tray;
        private readonly MiniBar mini;
        private readonly ContextMenuStrip context;
        private readonly ComboBox adapterChoice;
        private readonly TrafficChart chart;
        private readonly Label downSpeed;
        private readonly Label upSpeed;
        private readonly Label downTotal;
        private readonly Label upTotal;
        private readonly Label status;
        private readonly Label networkName;
        private readonly Button toggle;
        private readonly CheckBox showMini;
        private readonly CheckBox runAtLogin;
        private bool running = true;
        private bool shuttingDown = false;
        private string lastAdapterId = null;
        private string savedAdapterId = null;
        private long lastReceived;
        private long lastSent;
        private long totalReceived;
        private long totalSent;
        private string configPath;
        private const string StartupKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

        internal Dashboard()
        {
            Text = "DU by Jobaer - Live Network Monitor";
            BackColor = Theme.Bg;
            ForeColor = Theme.White;
            Font = new Font("Segoe UI", 10f);
            ClientSize = new Size(856, 633);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = Size;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { Icon = SystemIcons.Application; }
            try
            {
                string settingsDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DU by Jobaer");
                configPath = Path.Combine(settingsDir, "settings.ini");
            }
            catch { configPath = null; }

            // Shared right-click menu for the tray icon and mini display.
            context = new ContextMenuStrip();
            context.Items.Add("Open DU by Jobaer", null, delegate { RestoreDashboard(); });
            context.Items.Add("Minimize to taskbar bar", null, delegate { MinimizeToBar(); });
            context.Items.Add("Reset JA position on taskbar", null, delegate
            {
                mini.DockOffset = 72;
                SavePreferences();
                if (mini.Visible) mini.DockOnTaskbar();
            });
            context.Items.Add(new ToolStripSeparator());
            context.Items.Add("Exit", null, delegate { Close(); });

            tray = new NotifyIcon();
            tray.Icon = Icon;
            tray.Text = "DU by Jobaer";
            tray.Visible = true;
            tray.ContextMenuStrip = context;
            tray.DoubleClick += delegate { RestoreDashboard(); };
            mini = new MiniBar(this, context);

            Label heading = MakeLabel("DU by Jobaer", 28, 18, 480, 42, 23f, true, Theme.White);
            Label subheading = MakeLabel("REAL-TIME PC NETWORK TRAFFIC MONITOR", 29, 61, 550, 22, 9.3f, false, Theme.Muted);
            status = MakeLabel("● Starting monitor...", 585, 31, 237, 26, 10f, true, Theme.Up);
            status.TextAlign = ContentAlignment.MiddleRight;
            Controls.Add(heading);
            Controls.Add(subheading);
            Controls.Add(status);

            Panel rule = new Panel();
            rule.BackColor = Theme.Line;
            rule.Bounds = new Rectangle(29, 94, 798, 1);
            Controls.Add(rule);

            Panel cardDown = MakeCard(29, 113, 385, 135);
            Panel cardUp = MakeCard(442, 113, 385, 135);
            Controls.Add(cardDown);
            Controls.Add(cardUp);
            cardDown.Controls.Add(MakeLabel("↓ DOWNLOAD  /  INBOUND", 18, 12, 350, 26, 11f, true, Theme.Down));
            cardUp.Controls.Add(MakeLabel("↑ UPLOAD  /  OUTBOUND", 18, 12, 350, 26, 11f, true, Theme.Up));
            downSpeed = MakeLabel("0 B/s", 18, 41, 355, 52, 28f, true, Theme.White);
            upSpeed = MakeLabel("0 B/s", 18, 41, 355, 52, 28f, true, Theme.White);
            cardDown.Controls.Add(downSpeed);
            cardUp.Controls.Add(upSpeed);
            downTotal = MakeLabel("Session downloaded: 0 B", 19, 101, 355, 23, 9.5f, false, Theme.Muted);
            upTotal = MakeLabel("Session uploaded: 0 B", 19, 101, 355, 23, 9.5f, false, Theme.Muted);
            cardDown.Controls.Add(downTotal);
            cardUp.Controls.Add(upTotal);

            chart = new TrafficChart();
            chart.Bounds = new Rectangle(29, 264, 798, 220);
            Controls.Add(chart);

            Controls.Add(MakeLabel("NETWORK ADAPTER", 29, 502, 210, 21, 9.5f, true, Theme.Muted));
            adapterChoice = new ComboBox();
            adapterChoice.Bounds = new Rectangle(29, 526, 474, 34);
            adapterChoice.DropDownStyle = ComboBoxStyle.DropDownList;
            adapterChoice.BackColor = Color.White;
            adapterChoice.ForeColor = Color.Black;
            adapterChoice.Font = new Font("Segoe UI", 10f);
            adapterChoice.SelectedIndexChanged += delegate { ResetBaseline(); SavePreferences(); };
            Controls.Add(adapterChoice);
            Button refresh = MakeButton("Refresh", 510, 526, 78, 34);
            refresh.Click += delegate { RefreshAdapters(); };
            Controls.Add(refresh);
            toggle = MakeButton("Pause", 599, 526, 95, 34);
            toggle.Click += delegate
            {
                running = !running;
                toggle.Text = running ? "Pause" : "Resume";
                ResetBaseline();
                if (!running) { UpdateRates(0, 0); SetStatus("● Paused", Theme.Muted); }
            };
            Controls.Add(toggle);
            Button minimize = MakeButton("Minimize", 703, 526, 124, 34);
            minimize.Click += delegate { MinimizeToBar(); };
            Controls.Add(minimize);

            showMini = new CheckBox();
            showMini.Text = "Show translucent JA / D / U overlay ON taskbar when minimized";
            showMini.Bounds = new Rectangle(29, 578, 465, 23);
            showMini.ForeColor = Theme.Muted;
            showMini.Checked = true;
            showMini.CheckedChanged += delegate { SavePreferences(); if (!Visible || WindowState == FormWindowState.Minimized) { if (showMini.Checked) { mini.Show(); mini.DockOnTaskbar(); } else mini.Hide(); } };
            Controls.Add(showMini);

            runAtLogin = new CheckBox();
            runAtLogin.Text = "Start with Windows";
            runAtLogin.Bounds = new Rectangle(650, 578, 178, 23);
            runAtLogin.ForeColor = Theme.Muted;
            runAtLogin.Checked = IsStartupEnabled();
            runAtLogin.CheckedChanged += delegate { SetStartup(runAtLogin.Checked); };
            Controls.Add(runAtLogin);

            networkName = MakeLabel("Adapter: Detecting active connection...", 29, 605, 797, 21, 9f, false, Theme.Muted);
            Controls.Add(networkName);

            LoadPreferences();
            RefreshAdapters();
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000;
            timer.Tick += delegate { PollTraffic(); };
            timer.Start();
            PollTraffic();

            // Windows startup launches directly into the compact bar.
            string[] commandArgs = Environment.GetCommandLineArgs();
            for (int i = 1; i < commandArgs.Length; i++)
                if (string.Equals(commandArgs[i], "--minimized", StringComparison.OrdinalIgnoreCase))
                {
                    Shown += delegate { BeginInvoke((MethodInvoker)delegate { MinimizeToBar(); }); };
                    break;
                }

            Resize += delegate
            {
                if (!shuttingDown && WindowState == FormWindowState.Minimized)
                    BeginInvoke((MethodInvoker)delegate { if (!shuttingDown) MinimizeToBar(); });
            };
        }

        private static Label MakeLabel(string text, int x, int y, int width, int height, float fontSize, bool bold, Color color)
        {
            Label label = new Label();
            label.Text = text;
            label.Bounds = new Rectangle(x, y, width, height);
            label.Font = new Font("Segoe UI", fontSize, bold ? FontStyle.Bold : FontStyle.Regular);
            label.ForeColor = color;
            label.TextAlign = ContentAlignment.MiddleLeft;
            return label;
        }

        private static Panel MakeCard(int x, int y, int width, int height)
        {
            Panel card = new Panel();
            card.Location = new Point(x, y);
            card.Size = new Size(width, height);
            card.BackColor = Theme.Card;
            card.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (Pen border = new Pen(Theme.Line))
                    e.Graphics.DrawRectangle(border, 0, 0, card.Width - 1, card.Height - 1);
            };
            return card;
        }

        private static Button MakeButton(string text, int x, int y, int width, int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Bounds = new Rectangle(x, y, width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderColor = Theme.Line;
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(45, 67, 95);
            button.BackColor = Theme.Card;
            button.ForeColor = Theme.White;
            button.Cursor = Cursors.Hand;
            return button;
        }

        internal static string FormatRate(double bytesPerSecond)
        {
            if (double.IsNaN(bytesPerSecond) || double.IsInfinity(bytesPerSecond) || bytesPerSecond < 0) bytesPerSecond = 0;
            string[] units = new string[] { "B/s", "KB/s", "MB/s", "GB/s", "TB/s" };
            int i = 0;
            while (bytesPerSecond >= 1024 && i < units.Length - 1) { bytesPerSecond /= 1024; i++; }
            return bytesPerSecond.ToString(bytesPerSecond >= 100 ? "0" : "0.0") + " " + units[i];
        }

        private static string FormatSize(long bytes)
        {
            double value = Math.Max(0, bytes);
            string[] units = new string[] { "B", "KB", "MB", "GB", "TB" };
            int i = 0;
            while (value >= 1024 && i < units.Length - 1) { value /= 1024; i++; }
            return value.ToString(value >= 100 ? "0" : "0.0") + " " + units[i];
        }

        private void SetStatus(string text, Color color) { status.Text = text; status.ForeColor = color; }

        private static bool IsCandidate(NetworkInterface ni)
        {
            return ni.NetworkInterfaceType != NetworkInterfaceType.Loopback && ni.NetworkInterfaceType != NetworkInterfaceType.Tunnel;
        }

        private void RefreshAdapters()
        {
            string previousId = savedAdapterId;
            AdapterItem old = adapterChoice.SelectedItem as AdapterItem;
            if (old != null) previousId = old.Id;
            adapterChoice.BeginUpdate();
            adapterChoice.Items.Clear();
            adapterChoice.Items.Add(new AdapterItem(null, "Auto - primary connected network"));
            try
            {
                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                    if (IsCandidate(ni))
                        adapterChoice.Items.Add(new AdapterItem(ni.Id, ni.Name + " (" + ni.NetworkInterfaceType.ToString() + ")"));
            }
            catch { }
            int selected = 0;
            if (previousId != null)
                for (int i = 1; i < adapterChoice.Items.Count; i++)
                    if (((AdapterItem)adapterChoice.Items[i]).Id == previousId) { selected = i; break; }
            adapterChoice.SelectedIndex = selected;
            adapterChoice.EndUpdate();
            ResetBaseline();
        }

        private static bool HasGateway(NetworkInterface ni)
        {
            try
            {
                foreach (GatewayIPAddressInformation gateway in ni.GetIPProperties().GatewayAddresses)
                    if (gateway.Address.AddressFamily == AddressFamily.InterNetwork && !gateway.Address.Equals(IPAddress.Any))
                        return true;
            }
            catch { }
            return false;
        }

        private NetworkInterface FindNetwork()
        {
            NetworkInterface[] all;
            try { all = NetworkInterface.GetAllNetworkInterfaces(); }
            catch { return null; }

            AdapterItem selected = adapterChoice.SelectedItem as AdapterItem;
            if (selected != null && selected.Id != null)
            {
                foreach (NetworkInterface ni in all)
                    if (ni.Id == selected.Id && ni.OperationalStatus == OperationalStatus.Up) return ni;
                return null;
            }

            // Prefer an active interface with a real IPv4 default gateway.
            // Users can override this if their VPN or multi-NIC configuration needs it.
            NetworkInterface firstConnected = null;
            foreach (NetworkInterface ni in all)
            {
                if (!IsCandidate(ni) || ni.OperationalStatus != OperationalStatus.Up) continue;
                if (HasGateway(ni)) return ni;
                if (firstConnected == null) firstConnected = ni;
            }
            return firstConnected;
        }

        private void ResetBaseline()
        {
            sampleClock.Reset();
            lastAdapterId = null;
            lastReceived = 0;
            lastSent = 0;
        }

        private void PollTraffic()
        {
            if (!running) return;
            NetworkInterface ni = FindNetwork();
            if (ni == null)
            {
                ResetBaseline();
                UpdateRates(0, 0);
                SetStatus("● Disconnected", Color.FromArgb(250, 145, 123));
                networkName.Text = "No active network adapter. Select one above or reconnect your network.";
                return;
            }
            try
            {
                IPv4InterfaceStatistics stats = ni.GetIPv4Statistics();
                long rx = stats.BytesReceived;
                long tx = stats.BytesSent;
                double seconds = sampleClock.IsRunning ? sampleClock.Elapsed.TotalSeconds : 0;
                bool valid = lastAdapterId == ni.Id && seconds > 0.2 && rx >= lastReceived && tx >= lastSent;
                double d = 0, u = 0;
                if (valid)
                {
                    long dr = rx - lastReceived;
                    long du = tx - lastSent;
                    d = dr / seconds;
                    u = du / seconds;
                    totalReceived = SaturatingAdd(totalReceived, dr);
                    totalSent = SaturatingAdd(totalSent, du);
                }
                lastReceived = rx;
                lastSent = tx;
                lastAdapterId = ni.Id;
                sampleClock.Restart();
                UpdateRates(d, u);
                SetStatus("● Monitoring", Theme.Up);
                networkName.Text = "Active adapter: " + ni.Name + "  |  " + ni.NetworkInterfaceType;
            }
            catch
            {
                ResetBaseline();
                UpdateRates(0, 0);
                SetStatus("● Adapter unavailable", Color.FromArgb(250, 145, 123));
            }
        }

        private static long SaturatingAdd(long a, long b)
        {
            return b > long.MaxValue - a ? long.MaxValue : a + b;
        }

        private void UpdateRates(double download, double upload)
        {
            string ds = FormatRate(download);
            string us = FormatRate(upload);
            downSpeed.Text = ds;
            upSpeed.Text = us;
            downTotal.Text = "Session downloaded: " + FormatSize(totalReceived);
            upTotal.Text = "Session uploaded: " + FormatSize(totalSent);
            chart.AddPoint(download, upload);
            mini.SetRates(ds, us);
            string tooltip = "DU by Jobaer  D: " + ds + "  U: " + us;
            tray.Text = tooltip.Length <= 63 ? tooltip : tooltip.Substring(0, 63);
        }

        internal void SaveMiniPosition() { SavePreferences(); }

        internal void MinimizeToBar()
        {
            if (shuttingDown) return;
            Hide();
            ShowInTaskbar = false;
            if (showMini.Checked)
            {
                mini.PositionNearTaskbar();
                mini.Show();
                mini.DockOnTaskbar();
            }
            else mini.Hide();
        }

        internal void RestoreDashboard()
        {
            if (shuttingDown) return;
            mini.Hide();
            ShowInTaskbar = true;
            WindowState = FormWindowState.Normal;
            Show();
            Activate();
            BringToFront();
        }

        private void LoadPreferences()
        {
            try
            {
                if (configPath == null || !File.Exists(configPath)) return;
                foreach (string line in File.ReadAllLines(configPath))
                {
                    if (line.StartsWith("adapter=")) savedAdapterId = line.Substring("adapter=".Length);
                    if (line == "mini=false") showMini.Checked = false;
                    if (line.StartsWith("dock_offset="))
                    {
                        int position;
                        if (int.TryParse(line.Substring("dock_offset=".Length), out position))
                            mini.DockOffset = position;
                    }
                }
                if (savedAdapterId == "") savedAdapterId = null;
            }
            catch { }
        }

        private void SavePreferences()
        {
            try
            {
                if (configPath == null || adapterChoice == null || showMini == null) return;
                Directory.CreateDirectory(Path.GetDirectoryName(configPath));
                AdapterItem item = adapterChoice.SelectedItem as AdapterItem;
                string id = item == null || item.Id == null ? "" : item.Id;
                File.WriteAllText(configPath, "adapter=" + id + Environment.NewLine +
                    "mini=" + (showMini.Checked ? "true" : "false") + Environment.NewLine +
                    "dock_offset=" + mini.DockOffset.ToString());
            }
            catch { }
        }

        private static bool IsStartupEnabled()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(StartupKey, false))
                    return key != null && key.GetValue("DU by Jobaer") != null;
            }
            catch { return false; }
        }

        private void SetStartup(bool enabled)
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(StartupKey, true))
                {
                    if (key == null) throw new InvalidOperationException("Startup registry key unavailable.");
                    if (enabled) key.SetValue("DU by Jobaer", "\"" + Application.ExecutablePath + "\" --minimized");
                    else key.DeleteValue("DU by Jobaer", false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not update Windows startup: " + ex.Message, "DU by Jobaer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            shuttingDown = true;
            timer.Stop();
            SavePreferences();
            tray.Visible = false;
            mini.Close();
            tray.Dispose();
            context.Dispose();
            base.OnFormClosing(e);
        }
    }
}
