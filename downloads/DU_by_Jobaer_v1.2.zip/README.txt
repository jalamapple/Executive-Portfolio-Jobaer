DU by Jobaer  |  Version 1.2  |  JA Compact Transparent Taskbar Overlay
==========================================================================

WHAT IS NEW IN v1.2
- Very small JA/D/U display, only 22 px tall at 100% display scaling.
- Width automatically fits current download and upload speeds: typically
  ~145-195 px depending on numbers/units (v1.1 was fixed at 258 x 28 px).
- Slightly transparent dark background (86% opacity).
- Lives ON TOP OF the Windows taskbar while the dashboard is minimized,
  rather than floating above it. The bar is always-on-top without stealing focus.
- Automatically re-docks if Windows moves/resizes the taskbar.
- Drag left/right to move along the taskbar; location is saved.
- Right-click the bar > Reset JA position on taskbar to return to left position.
- Double-click JA compact bar or tray icon to open the full dashboard.

INSTALL / UPDATE
1. Exit previous DU by Jobaer from the tray icon (right-click > Exit).
2. Extract this ZIP to a permanent folder on your Windows 10/11 PC.
3. Double-click BUILD_AND_RUN.bat to compile and launch the app.
4. After successful build you can open "DU by Jobaer.exe" directly.
5. Click Minimize to show the new overlay, or check Start with Windows.

BUILD PREREQUISITES
- Windows 10 or Windows 11, Microsoft .NET Framework 4.x and the Microsoft
  .NET Framework C# compiler (normally under C:\Windows\Microsoft.NET\).
- The package contains the complete C# source, Windows build script and icon.
- This is NOT a precompiled EXE. The source has NOT been run on Windows here.
- It is unsigned. You may inspect the C# source before running it.

USAGE
- Shows D:download and U:upload in BYTES per second (B/s, KB/s, MB/s).
- Auto adapter selection prefers a connected network with an IPv4 gateway.
- Manually select Wi-Fi or Ethernet if auto detects the wrong connection.
- Shows interface traffic, including LAN traffic, not just internet traffic.
- Hover the system tray icon for current rates; right-click for Open/Exit.
- Optional HKCU login startup uses --minimized (no admin permission required).
- Settings stored in %APPDATA%\DU by Jobaer\settings.ini.

IMPORTANT WINDOWS LIMITATION
Windows 10/11 do not expose a supported, stable third-party API for inserting
live arbitrary text inside the actual taskbar. This application puts a small
independent always-on-top WINDOW OVER the taskbar, matching the requested look.
It may cover an icon beneath it; drag JA sideways to free that icon. Windows
Explorer restarts, auto-hide, special third-party taskbars, multiple monitors,
and certain fullscreen apps may change overlay behavior. The overlay targets
the PRIMARY Windows taskbar. It does not reserve permanent taskbar space.

To fully uninstall: disable Start with Windows (if checked), exit via tray,
then delete the program folder. Optionally remove %APPDATA%\DU by Jobaer.
