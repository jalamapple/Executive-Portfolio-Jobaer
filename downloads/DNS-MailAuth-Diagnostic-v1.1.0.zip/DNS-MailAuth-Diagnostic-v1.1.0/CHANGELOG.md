# Changelog

## v1.1.0 (2026)
- Added **"Created by Jobaer"** console and HTML report banner.
- Added recursive SPF 10-DNS-lookup counter (RFC 7208) with loop protection and CIDR/token syntax validation.
- Added `-CheckM365Selectors` validation for `selector1` and `selector2` CNAME targets and RSA key verification.
- Added DMARC alignment (`adkim`/`aspf`), `pct=`, `sp=`, and `rua=` reporting checks.
- Added BIMI (`default._bimi`), MTA-STS (`_mta-sts` TXT + HTTPS policy check), and SMTP TLS-RPT (`_smtp._tls`) diagnostics.
- Added `-ExportHtml`, `-ExportCsv`, `-ExportJson`, `-DnsServer`, and `-DemoMode` switches plus `Run-MailAuthDNS.bat`.
