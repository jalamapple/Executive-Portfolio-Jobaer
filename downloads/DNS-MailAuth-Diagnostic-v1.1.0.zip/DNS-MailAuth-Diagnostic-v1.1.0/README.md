# DNS, SPF, DKIM & DMARC Diagnostic Utility (v1.1.0)

**Created by Jobaer**  
**Author:** S M Jobaer Alam | [www.jobaeralam.com](https://www.jobaeralam.com) | hello@jobaeralam.com  
**License:** Freeware

---

## Overview

Lightweight mail-security diagnostic tool that validates **MX**, **SPF lookup limits** (including recursive nested `include:` resolution), **DKIM selectors** (with automatic Microsoft 365 `selector1`/`selector2` CNAME & public key verification), **DMARC policies**, and **BIMI / MTA-STS / TLS-RPT** records in seconds.

## Key Features

- **Recursive SPF 10-DNS-Lookup & Syntax Analyzer (RFC 7208):** Recursively walks nested `include:`, `redirect=`, `a`, `mx`, `ptr`, and `exists:` mechanisms to detect 10-lookup `PermError` limits, duplicate SPF records, invalid CIDR masks, and unsafe `+all`/`?all` qualifiers before mail delivery breaks.
- **Microsoft 365 DKIM Selector Validation (RFC 6376):** Automatically validates `selector1._domainkey` and `selector2._domainkey` CNAME records and verifies their underlying RSA public keys (plus optional extra custom selectors via `-DkimSelectors`).
- **DMARC, BIMI & MTA-STS Auditing:** Checks `_dmarc` policy enforcement (`p=reject` / `quarantine` / `none`), `pct=`, `adkim`/`aspf` alignment, `rua=` reporting, `_mta-sts` TXT + HTTPS policy mode, `_smtp._tls` TLS-RPT, and `default._bimi` SVG/VMC records.
- **Migration-Ready Troubleshooting Reports:** Exports clean, client-ready **HTML**, **CSV**, and **JSON** troubleshooting reports for Exchange Online and tenant migrations.
- **Zero External Dependencies:** Runs natively on Windows 10/11 with PowerShell 5.1 or PowerShell 7+.

## Requirements

- Windows 10 / 11
- PowerShell 5.1 or PowerShell 7+ (`pwsh`)

## Quick Start

```powershell
# Basic Microsoft 365 & Mail Authentication Diagnostic
.\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com" -CheckM365Selectors

# Audit and export clean HTML + CSV troubleshooting reports
.\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com" -CheckM365Selectors -ExportHtml -ExportCsv -OpenReport

# Query a specific public DNS server (e.g., Cloudflare 1.1.1.1) during DNS cutover
.\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com" -CheckM365Selectors -DnsServer "1.1.1.1"

# Audit extra third-party DKIM selectors alongside M365 selectors
.\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com" -CheckM365Selectors -DkimSelectors "google","k1","sendgrid"

# Run offline Demo Mode to preview HTML & CSV report output
.\Test-MailAuthDNS.ps1 -DemoMode -ExportHtml -ExportCsv -OpenReport
```

Or simply double-click **`Run-MailAuthDNS.bat`** for an interactive menu launcher.
