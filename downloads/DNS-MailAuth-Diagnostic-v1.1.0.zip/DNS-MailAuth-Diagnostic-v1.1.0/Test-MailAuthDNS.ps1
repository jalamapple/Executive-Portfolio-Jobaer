<#
.SYNOPSIS
    DNS, SPF, DKIM & DMARC Diagnostic Utility (v1.1.0) — Created by Jobaer

.DESCRIPTION
    Lightweight mail-security diagnostic tool that validates MX, SPF lookup limits,
    DKIM selectors, DMARC policies, and BIMI/MTA-STS records in seconds.
    Designed for Exchange Online administrators, security engineers, and client migrations.

.PARAMETER Domain
    One or more domain names to audit (e.g., "jobaeralam.com" or "contoso.com","fabrikam.com").

.PARAMETER CheckM365Selectors
    Explicitly validates Microsoft 365 selector1 and selector2 DKIM CNAME records and public keys.

.PARAMETER DkimSelectors
    Optional additional custom DKIM selectors to probe (e.g., "google","k1","s1","sendgrid","mimecast").

.PARAMETER BimiSelector
    BIMI selector name to query under _bimi.<domain>. Defaults to "default".

.PARAMETER DnsServer
    Optional DNS resolver IP address (e.g., "1.1.1.1" or "8.8.8.8") for external DNS verification.

.PARAMETER ExportHtml
    Exports a clean, executive HTML troubleshooting report for Exchange Online and client migrations.

.PARAMETER ExportCsv
    Exports structured CSV troubleshooting reports (Summary + Detailed DNS Records).

.PARAMETER ExportJson
    Exports machine-readable JSON diagnostic results.

.PARAMETER OutputPath
    Directory where exported reports are saved. Defaults to .\Reports.

.PARAMETER OpenReport
    Automatically opens the generated HTML report in your default browser.

.PARAMETER DemoMode
    Runs an offline simulation across sample migration domains to preview console, HTML, and CSV outputs.

.EXAMPLE
    .\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com" -CheckM365Selectors

.EXAMPLE
    .\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com","contoso.com" -CheckM365Selectors -ExportHtml -ExportCsv -OpenReport

.EXAMPLE
    .\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com" -CheckM365Selectors -DnsServer "1.1.1.1" -DkimSelectors "google","k1"

.NOTES
    Utility   : DNS, SPF, DKIM & DMARC Diagnostic Utility
    Version   : 1.1.0
    Author    : S M Jobaer Alam
    Website   : https://www.jobaeralam.com
    Email     : hello@jobaeralam.com
    License   : Freeware
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false, Position = 0, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
    [string[]]$Domain = @(),

    [Parameter(Mandatory = $false)]
    [switch]$CheckM365Selectors,

    [Parameter(Mandatory = $false)]
    [string[]]$DkimSelectors = @(),

    [Parameter(Mandatory = $false)]
    [string]$BimiSelector = "default",

    [Parameter(Mandatory = $false)]
    [string]$DnsServer = "",

    [Parameter(Mandatory = $false)]
    [switch]$ExportHtml,

    [Parameter(Mandatory = $false)]
    [switch]$ExportCsv,

    [Parameter(Mandatory = $false)]
    [switch]$ExportJson,

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = "",

    [Parameter(Mandatory = $false)]
    [switch]$OpenReport,

    [Parameter(Mandatory = $false)]
    [switch]$DemoMode
)

begin {
    Set-StrictMode -Version Latest
    $ErrorActionPreference = "Stop"

    $ToolTitle   = "DNS, SPF, DKIM & DMARC Diagnostic Utility (v1.1.0)"
    $AuthorLine  = "Author: S M Jobaer Alam | www.jobaeralam.com | hello@jobaeralam.com"
    $LicenseLine = "License: Freeware"
    $RunDate     = Get-Date
    $Timestamp   = $RunDate.ToString("yyyyMMdd_HHmmss")

    if ($OpenReport -and -not $ExportHtml) { $ExportHtml = $true }
    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $baseDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
        $OutputPath = Join-Path -Path $baseDir -ChildPath "Reports"
    }

    #region Banner ("Created by Jobaer")
    function Show-JobaerBanner {
        Write-Host ""
        Write-Host "====================================================================" -ForegroundColor Cyan
        Write-Host "   ____                _           _   _             _       _                 " -ForegroundColor Cyan
        Write-Host "  / ___|_ __ ___  __ _| |_ ___  __| | | |__  _   _  | | ___ | |__   __ _  ___ _ __ " -ForegroundColor Cyan
        Write-Host " | |   | '__/ _ \/ _`` | __/ _ \/ _`` | | '_ \| | | | | |/ _ \| '_ \ / _`` |/ _ \ '__|" -ForegroundColor Cyan
        Write-Host " | |___| | |  __/ (_| | ||  __/ (_| | | |_) | |_| | | | (_) | |_) | (_| |  __/ |   " -ForegroundColor Cyan
        Write-Host "  \____|_|  \___|\__,_|\__\___|\__,_| |_.__/ \__, | |_|\___/|_.__/ \__,_|\___|_|   " -ForegroundColor Cyan
        Write-Host "                                             |___/                                 " -ForegroundColor Cyan
        Write-Host "  *** CREATED BY JOBAER ***" -ForegroundColor Yellow
        Write-Host "  $ToolTitle" -ForegroundColor White
        Write-Host "  $AuthorLine" -ForegroundColor Gray
        Write-Host "  $LicenseLine" -ForegroundColor DarkGray
        Write-Host "====================================================================" -ForegroundColor Cyan
        Write-Host ""
    }
    #endregion

    Show-JobaerBanner

    # Collect domains across pipeline if piped
    $AllTargetDomains = [System.Collections.Generic.List[string]]::new()

    function ConvertTo-HtmlSafe {
        param([AllowNull()][string]$Text)
        if ([string]::IsNullOrEmpty($Text)) { return "" }
        return [System.Net.WebUtility]::HtmlEncode($Text)
    }

    #region Cross-Version DNS Query Helpers (PS 5.1 & PS 7+)
    function Invoke-DnsQuerySafe {
        param(
            [string]$Name,
            [ValidateSet("MX", "TXT", "CNAME", "A", "AAAA")]
            [string]$Type,
            [string]$Server = ""
        )

        $cleanName = $Name.Trim().TrimEnd('.')
        try {
            if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
                $params = @{
                    Name        = $cleanName
                    Type        = $Type
                    ErrorAction = "Stop"
                }
                if (-not [string]::IsNullOrWhiteSpace($Server)) {
                    $params["Server"] = $Server
                }
                $records = @(Resolve-DnsName @params)
                return $records
            }
        }
        catch {
            return @()
        }

        # Fallback using nslookup if Resolve-DnsName is unavailable
        try {
            $nsArgs = @("-type=$($Type.ToLower())", $cleanName)
            if (-not [string]::IsNullOrWhiteSpace($Server)) { $nsArgs += $Server }
            $raw = & nslookup @nsArgs 2>$null
            $fallbackResults = @()
            if ($Type -eq "TXT") {
                foreach ($line in $raw) {
                    if ($line -match '"(.+)"') {
                        $fallbackResults += [PSCustomObject]@{ QueryType = "TXT"; Strings = @($Matches[1]) }
                    }
                }
            }
            elseif ($Type -eq "CNAME") {
                foreach ($line in $raw) {
                    if ($line -match 'canonical name\s*=\s*(\S+)') {
                        $fallbackResults += [PSCustomObject]@{ QueryType = "CNAME"; NameHost = $Matches[1].TrimEnd('.') }
                    }
                }
            }
            elseif ($Type -eq "MX") {
                foreach ($line in $raw) {
                    if ($line -match 'MX preference\s*=\s*(\d+),\s*mail exchanger\s*=\s*(\S+)') {
                        $fallbackResults += [PSCustomObject]@{
                            QueryType    = "MX"
                            Preference   = [int]$Matches[1]
                            NameExchange = $Matches[2].TrimEnd('.')
                        }
                    }
                }
            }
            return $fallbackResults
        }
        catch {
            return @()
        }
    }

    function Get-DnsTxtStrings {
        param([string]$Name, [string]$Server = "")
        $records = @(Invoke-DnsQuerySafe -Name $Name -Type "TXT" -Server $Server)
        $txtList = @()
        foreach ($r in $records) {
            if ($r.PSObject.Properties["QueryType"] -and $r.QueryType -ne "TXT") { continue }
            if ($r.PSObject.Properties["Strings"] -and $r.Strings) {
                # Join multi-chunk TXT strings (>255 chars) per RFC 7208
                $txtList += ($r.Strings -join "")
            }
        }
        return $txtList
    }

    function Get-DnsCnameTarget {
        param([string]$Name, [string]$Server = "")
        $records = @(Invoke-DnsQuerySafe -Name $Name -Type "CNAME" -Server $Server)
        foreach ($r in $records) {
            if ($r.PSObject.Properties["NameHost"] -and $r.NameHost) {
                return $r.NameHost.TrimEnd('.')
            }
        }
        return $null
    }
    #endregion

    #region 1. MX Record Analyzer
    function Test-MxDiagnostic {
        param([string]$DomainName, [string]$Server = "")
        $mxRaw = @(Invoke-DnsQuerySafe -Name $DomainName -Type "MX" -Server $Server | Where-Object { $_.PSObject.Properties["NameExchange"] })
        if ($mxRaw.Count -eq 0) {
            return [PSCustomObject]@{
                Status         = "Fail"
                Provider       = "None"
                Records        = "Missing"
                Summary        = "No MX records found. Inbound email delivery will fail."
                Recommendation = "Publish MX records pointing to your mail gateway (e.g., <domain-key>.mail.protection.outlook.com for Exchange Online)."
            }
        }

        $sorted = @($mxRaw | Sort-Object Preference)
        # Check Null MX (RFC 7505: 0 .)
        if ($sorted.Count -eq 1 -and ($sorted[0].NameExchange -eq "." -or [string]::IsNullOrWhiteSpace($sorted[0].NameExchange))) {
            return [PSCustomObject]@{
                Status         = "Warning"
                Provider       = "Null MX (RFC 7505)"
                Records        = "0 ."
                Summary        = "Domain explicitly advertises Null MX (accepts no inbound email)."
                Recommendation = "If this domain should receive email, replace '0 .' with valid MX hostnames."
            }
        }

        $formatted = @()
        $provider  = "Custom / Third-Party Mail Gateway"
        foreach ($mx in $sorted) {
            $hostName = $mx.NameExchange.TrimEnd('.')
            $formatted += "$($mx.Preference) $hostName"
            if ($hostName -match '\.mail\.protection\.outlook\.com$|\.mx\.microsoft$') {
                $provider = "Microsoft 365 / Exchange Online"
            }
            elseif ($hostName -match 'google\.com$|googlemail\.com$') {
                $provider = "Google Workspace"
            }
            elseif ($hostName -match 'mimecast\.com$') {
                $provider = "Mimecast Secure Email Gateway"
            }
            elseif ($hostName -match 'pphosted\.com$') {
                $provider = "Proofpoint Protection"
            }
        }

        return [PSCustomObject]@{
            Status         = "Pass"
            Provider       = $provider
            Records        = ($formatted -join "; ")
            Summary        = "$($sorted.Count) MX record(s) active ($provider)."
            Recommendation = "MX routing healthy. Ensure SPF, DKIM, and DMARC align with $provider."
        }
    }
    #endregion

    #region 2. Recursive SPF Syntax & 10-DNS-Lookup Analyzer (RFC 7208)
    function Get-RecursiveSpfLookups {
        param(
            [string]$TargetDomain,
            [string]$Server = "",
            [int]$Depth = 0,
            [hashtable]$Visited = @{}
        )

        if ($Depth -gt 12) {
            return [PSCustomObject]@{ Count = 0; Errors = @("Max recursion depth exceeded"); Chain = @() }
        }
        $key = $TargetDomain.ToLower()
        if ($Visited.ContainsKey($key)) {
            return [PSCustomObject]@{ Count = 0; Errors = @("SPF redirect/include loop detected on $TargetDomain"); Chain = @() }
        }
        $Visited[$key] = $true

        $txts = @(Get-DnsTxtStrings -Name $TargetDomain -Server $Server)
        $spfs = @($txts | Where-Object { $_ -match '^v=spf1(\s|$)' })
        if ($spfs.Count -eq 0) {
            return [PSCustomObject]@{ Count = 0; Errors = @("Included domain '$TargetDomain' has no SPF record"); Chain = @() }
        }
        if ($spfs.Count -gt 1) {
            return [PSCustomObject]@{ Count = 0; Errors = @("Included domain '$TargetDomain' has multiple SPF records"); Chain = @() }
        }

        $record = $spfs[0]
        $tokens = @($record -split '\s+' | Where-Object { $_ -ne "" })
        $count  = 0
        $errors = [System.Collections.Generic.List[string]]::new()
        $chain  = [System.Collections.Generic.List[string]]::new()

        foreach ($tok in $tokens) {
            if ($tok -ieq "v=spf1") { continue }
            $cleanTok = $tok -replace '^[+\-~?]', ''

            if ($cleanTok -match '^include:(.+)$') {
                $incDom = $Matches[1]
                $count++
                $chain.Add("include:$incDom")
                $sub = Get-RecursiveSpfLookups -TargetDomain $incDom -Server $Server -Depth ($Depth + 1) -Visited $Visited
                $count += $sub.Count
                foreach ($e in $sub.Errors) { $errors.Add($e) }
                foreach ($c in $sub.Chain)  { $chain.Add("  -> $c") }
            }
            elseif ($cleanTok -match '^redirect=(.+)$') {
                $redDom = $Matches[1]
                $count++
                $chain.Add("redirect=$redDom")
                $sub = Get-RecursiveSpfLookups -TargetDomain $redDom -Server $Server -Depth ($Depth + 1) -Visited $Visited
                $count += $sub.Count
                foreach ($e in $sub.Errors) { $errors.Add($e) }
                foreach ($c in $sub.Chain)  { $chain.Add("  -> $c") }
            }
            elseif ($cleanTok -match '^(a|mx)(:|/|$)') {
                $count++
                $chain.Add($cleanTok)
            }
            elseif ($cleanTok -match '^ptr(:|$)') {
                $count++
                $chain.Add($cleanTok)
                $errors.Add("Deprecated 'ptr' mechanism used in $TargetDomain (RFC 7208 discourages ptr).")
            }
            elseif ($cleanTok -match '^exists:(.+)$') {
                $count++
                $chain.Add($cleanTok)
            }
        }

        return [PSCustomObject]@{
            Count  = $count
            Errors = @($errors)
            Chain  = @($chain)
        }
    }

    function Test-SpfDiagnostic {
        param([string]$DomainName, [string]$Server = "")

        $txts = @(Get-DnsTxtStrings -Name $DomainName -Server $Server)
        $spfs = @($txts | Where-Object { $_ -match '^v=spf1(\s|$)' })

        if ($spfs.Count -eq 0) {
            return [PSCustomObject]@{
                Status           = "Fail"
                Record           = "Missing"
                DirectLookups    = 0
                RecursiveLookups = 0
                Qualifier        = "None"
                SyntaxIssues     = "No v=spf1 TXT record found."
                Summary          = "Missing SPF record — domain is unprotected against direct spoofing."
                Recommendation   = "Publish TXT record: v=spf1 include:spf.protection.outlook.com -all"
            }
        }

        if ($spfs.Count -gt 1) {
            return [PSCustomObject]@{
                Status           = "Fail"
                Record           = ($spfs -join " || ")
                DirectLookups    = 0
                RecursiveLookups = 0
                Qualifier        = "Multiple"
                SyntaxIssues     = "Multiple SPF records ($($spfs.Count)) found (RFC 7208 PermError)."
                Summary          = "CRITICAL: $($spfs.Count) SPF records exist. Receiving servers return PermError."
                Recommendation   = "Merge all SPF mechanisms into a single v=spf1 TXT record and delete duplicates."
            }
        }

        $spf = $spfs[0].Trim()
        $tokens = @($spf -split '\s+' | Where-Object { $_ -ne "" })
        $syntaxIssues = [System.Collections.Generic.List[string]]::new()
        $directLookups = 0
        $allQualifier  = "Missing"

        foreach ($tok in $tokens) {
            if ($tok -ieq "v=spf1") { continue }

            # Validate mechanism syntax
            if ($tok -match '^([+\-~?])?all$') {
                $q = if ($Matches[1]) { $Matches[1] } else { "+" }
                $allQualifier = "${q}all"
            }
            elseif ($tok -match '^[+\-~?]?(include|exists):([a-zA-Z0-9._\-/%{}]+)$') {
                $directLookups++
            }
            elseif ($tok -match '^redirect=([a-zA-Z0-9._\-/%{}]+)$') {
                $directLookups++
            }
            elseif ($tok -match '^[+\-~?]?(a|mx)(:[a-zA-Z0-9._\-/%{}]+)?(/\d{1,3})?$') {
                $directLookups++
            }
            elseif ($tok -match '^[+\-~?]?ptr(:[a-zA-Z0-9._\-]+)?$') {
                $directLookups++
                $syntaxIssues.Add("Deprecated 'ptr' mechanism detected.")
            }
            elseif ($tok -match '^[+\-~?]?ip4:(\d{1,3}(?:\.\d{1,3}){3})(?:/(\d{1,2}))?$') {
                $ipOctets = $Matches[1].Split('.')
                foreach ($oct in $ipOctets) {
                    if ([int]$oct -gt 255) { $syntaxIssues.Add("Invalid IPv4 octet in '$tok'.") }
                }
                if ($Matches[2] -and [int]$Matches[2] -gt 32) {
                    $syntaxIssues.Add("Invalid IPv4 CIDR mask in '$tok'.")
                }
            }
            elseif ($tok -match '^[+\-~?]?ip6:([0-9a-fA-F:]+)(?:/(\d{1,3}))?$') {
                if ($Matches[2] -and [int]$Matches[2] -gt 128) {
                    $syntaxIssues.Add("Invalid IPv6 CIDR mask in '$tok'.")
                }
            }
            elseif ($tok -match '^exp=[a-zA-Z0-9._\-/%{}]+$') {
                # Valid explanation modifier
            }
            else {
                $syntaxIssues.Add("Invalid/unrecognized SPF token: '$tok'")
            }
        }

        if ($spf.Length -gt 450) {
            $syntaxIssues.Add("SPF record length is $($spf.Length) chars (risk of UDP DNS 512-byte truncation).")
        }

        # Recursive 10-DNS-lookup calculation
        $recResult = Get-RecursiveSpfLookups -TargetDomain $DomainName -Server $Server
        $totalLookups = $recResult.Count
        foreach ($re in $recResult.Errors) {
            if (-not $syntaxIssues.Contains($re)) { $syntaxIssues.Add($re) }
        }

        $status = "Pass"
        $recs   = [System.Collections.Generic.List[string]]::new()

        if ($totalLookups -gt 10) {
            $status = "Fail"
            $recs.Add("Reduce recursive DNS lookups from $totalLookups to <= 10 (remove unused includes or flatten static IPs).")
        }
        elseif ($totalLookups -ge 8) {
            if ($status -eq "Pass") { $status = "Warning" }
            $recs.Add("Approaching 10-lookup ceiling ($totalLookups/10 recursive lookups used).")
        }

        if ($allQualifier -eq "+all") {
            $status = "Fail"
            $syntaxIssues.Add("Dangerous '+all' allows any server on the internet to spoof this domain.")
            $recs.Add("Replace '+all' with '-all' immediately.")
        }
        elseif ($allQualifier -eq "?all" -or $allQualifier -eq "Missing") {
            if ($status -eq "Pass") { $status = "Warning" }
            $recs.Add("Add explicit '-all' (or '~all' during migration) at the end of the SPF record.")
        }
        elseif ($allQualifier -eq "~all") {
            if ($status -eq "Pass") { $status = "Warning" }
            $recs.Add("Softfail (~all) active; harden to '-all' once all legitimate senders are verified.")
        }

        if ($syntaxIssues.Count -gt 0 -and ($syntaxIssues -join " ") -match "Invalid|Multiple|PermError|loop") {
            $status = "Fail"
        }

        $issueText = if ($syntaxIssues.Count -gt 0) { $syntaxIssues -join "; " } else { "None" }
        $recText   = if ($recs.Count -gt 0) { $recs -join " " } else { "SPF valid ($totalLookups/10 recursive lookups, $allQualifier)." }

        return [PSCustomObject]@{
            Status           = $status
            Record           = $spf
            DirectLookups    = $directLookups
            RecursiveLookups = $totalLookups
            Qualifier        = $allQualifier
            SyntaxIssues     = $issueText
            Summary          = "Lookups: $totalLookups/10 (Direct: $directLookups) | Qualifier: $allQualifier | Issues: $issueText"
            Recommendation   = $recText
        }
    }
    #endregion

    #region 3. DKIM & Microsoft 365 Selector1/Selector2 Validator (RFC 6376)
    function Test-DkimDiagnostic {
        param(
            [string]$DomainName,
            [bool]$CheckM365,
            [string[]]$ExtraSelectors,
            [string]$Server = ""
        )

        $selectorsToTest = [System.Collections.Generic.List[string]]::new()
        if ($CheckM365) {
            $selectorsToTest.Add("selector1")
            $selectorsToTest.Add("selector2")
        }
        foreach ($s in $ExtraSelectors) {
            $cleanS = $s.Trim()
            if (-not [string]::IsNullOrWhiteSpace($cleanS) -and -not $selectorsToTest.Contains($cleanS)) {
                $selectorsToTest.Add($cleanS)
            }
        }
        # Default to M365 selectors if none specified at all
        if ($selectorsToTest.Count -eq 0) {
            $selectorsToTest.Add("selector1")
            $selectorsToTest.Add("selector2")
        }

        $findings = [System.Collections.Generic.List[object]]::new()
        $m365ValidCount = 0
        $anyValidCount  = 0

        foreach ($sel in $selectorsToTest) {
            $fqdn = "$sel._domainkey.$DomainName"
            $cname = Get-DnsCnameTarget -Name $fqdn -Server $Server
            $txts  = @(Get-DnsTxtStrings -Name $fqdn -Server $Server)
            $dkimTxt = @($txts | Where-Object { $_ -match 'v=DKIM1|p=' } | Select-Object -First 1)

            $isM365Target = $false
            if ($cname -and ($cname -match '\.onmicrosoft\.com$|\.dkim\.mail\.microsoft$')) {
                $isM365Target = $true
            }

            if ($dkimTxt.Count -gt 0 -and $dkimTxt[0] -match 'p=([A-Za-z0-9+/=]{16,})') {
                $anyValidCount++
                if ($sel -in @("selector1", "selector2")) { $m365ValidCount++ }
                $keyBits = [math]::Round(($Matches[1].Length * 6) / 8) * 8
                $targetNote = if ($cname) { "CNAME -> $cname (RSA ~${keyBits}-bit)" } else { "TXT Public Key (~${keyBits}-bit)" }
                $findings.Add([PSCustomObject]@{
                    Selector = $sel
                    Fqdn     = $fqdn
                    Status   = "Pass"
                    Target   = $targetNote
                })
            }
            elseif ($cname) {
                # CNAME exists, check if key is empty/revoked or unresolvable
                $statusNote = if ($dkimTxt.Count -gt 0 -and $dkimTxt[0] -match 'p=\s*(;|$)') {
                    "CNAME -> $cname (Key revoked: empty p=)"
                }
                else {
                    "CNAME -> $cname (Target TXT key not resolving — enable DKIM in M365 Defender portal)"
                }
                $findings.Add([PSCustomObject]@{
                    Selector = $sel
                    Fqdn     = $fqdn
                    Status   = "Warning"
                    Target   = $statusNote
                })
            }
            else {
                $findings.Add([PSCustomObject]@{
                    Selector = $sel
                    Fqdn     = $fqdn
                    Status   = "Fail"
                    Target   = "Not found in DNS"
                })
            }
        }

        $detailStr = ($findings | ForEach-Object { "$($_.Selector) [$($_.Status)]: $($_.Target)" }) -join " | "
        $status = "Fail"
        $rec    = ""

        if ($CheckM365 -or ($selectorsToTest -contains "selector1" -and $selectorsToTest -contains "selector2")) {
            if ($m365ValidCount -eq 2) {
                $status = "Pass"
                $rec    = "Both Microsoft 365 DKIM selectors (selector1 & selector2) are active and valid."
            }
            elseif ($m365ValidCount -eq 1 -or @($findings | Where-Object { $_.Status -eq "Warning" }).Count -gt 0) {
                $status = "Warning"
                $rec    = "Incomplete M365 DKIM setup. Publish both selector1 & selector2 CNAMEs and click 'Enable' in Microsoft Defender > Email authentication > DKIM."
            }
            else {
                $status = "Fail"
                $rec    = "Publish selector1._domainkey and selector2._domainkey CNAME records pointing to selector1-<domain-guid>._domainkey.<tenant>.onmicrosoft.com."
            }
        }
        else {
            if ($anyValidCount -gt 0) {
                $status = "Pass"
                $rec    = "$anyValidCount custom DKIM selector(s) verified."
            }
            else {
                $status = "Fail"
                $rec    = "No valid DKIM public keys found for queried selectors."
            }
        }

        return [PSCustomObject]@{
            Status         = $status
            Details        = $detailStr
            Findings       = $findings
            Summary        = $detailStr
            Recommendation = $rec
        }
    }
    #endregion

    #region 4. DMARC Policy & Alignment Analyzer (RFC 7489)
    function Test-DmarcDiagnostic {
        param([string]$DomainName, [string]$Server = "")

        $fqdn = "_dmarc.$DomainName"
        $txts = @(Get-DnsTxtStrings -Name $fqdn -Server $Server)
        $dmarcs = @($txts | Where-Object { $_ -match '^v=DMARC1(\s|;|$)' })

        if ($dmarcs.Count -eq 0) {
            return [PSCustomObject]@{
                Status         = "Fail"
                Policy         = "Missing"
                SubPolicy      = "N/A"
                Pct            = "N/A"
                Alignment      = "N/A"
                Rua            = "None"
                Record         = "Missing"
                Summary        = "No DMARC record found at $fqdn."
                Recommendation = "Publish TXT at _dmarc.$DomainName: v=DMARC1; p=quarantine; pct=100; rua=mailto:dmarc@$DomainName; adkim=r; aspf=r"
            }
        }

        if ($dmarcs.Count -gt 1) {
            return [PSCustomObject]@{
                Status         = "Fail"
                Policy         = "Multiple"
                SubPolicy      = "N/A"
                Pct            = "N/A"
                Alignment      = "N/A"
                Rua            = "N/A"
                Record         = ($dmarcs -join " || ")
                Summary        = "Multiple DMARC records found ($($dmarcs.Count)). RFC 7489 requires a single record."
                Recommendation = "Remove duplicate _dmarc TXT records so only one v=DMARC1 record remains."
            }
        }

        $rec = $dmarcs[0].Trim()
        $pol = if ($rec -match '(?i)(?:^|;\s*)p=(none|quarantine|reject)\b') { $Matches[1].ToLower() } else { "invalid" }
        $sp  = if ($rec -match '(?i)(?:^|;\s*)sp=(none|quarantine|reject)\b') { $Matches[1].ToLower() } else { "inherits ($pol)" }
        $pct = if ($rec -match '(?i)(?:^|;\s*)pct=(\d{1,3})\b') { [int]$Matches[1] } else { 100 }
        $adkim = if ($rec -match '(?i)(?:^|;\s*)adkim=(r|s)\b') { $Matches[1].ToLower() } else { "r" }
        $aspf  = if ($rec -match '(?i)(?:^|;\s*)aspf=(r|s)\b')  { $Matches[1].ToLower() } else { "r" }
        $rua   = if ($rec -match '(?i)(?:^|;\s*)rua=([^;]+)') { $Matches[1].Trim() } else { "None" }

        $status = "Fail"
        $notes  = [System.Collections.Generic.List[string]]::new()

        switch ($pol) {
            "reject" {
                $status = "Pass"
                $notes.Add("Enforced (p=reject) — maximum spoofing protection.")
            }
            "quarantine" {
                $status = "Pass"
                $notes.Add("Enforced (p=quarantine). Upgrade to p=reject after monitoring reports.")
            }
            "none" {
                $status = "Warning"
                $notes.Add("Monitoring-only (p=none) — spoofed emails are NOT blocked.")
            }
            default {
                $status = "Fail"
                $notes.Add("Invalid or missing 'p=' tag in DMARC record.")
            }
        }

        if ($pct -lt 100) {
            if ($status -eq "Pass") { $status = "Warning" }
            $notes.Add("Partial enforcement (pct=$pct%). Increase to pct=100.")
        }
        if ($rua -eq "None") {
            if ($status -eq "Pass") { $status = "Warning" }
            $notes.Add("Missing aggregate report URI (rua=mailto:...).")
        }

        return [PSCustomObject]@{
            Status         = $status
            Policy         = $pol
            SubPolicy      = $sp
            Pct            = "$pct%"
            Alignment      = "DKIM:$adkim / SPF:$aspf"
            Rua            = $rua
            Record         = $rec
            Summary        = "p=$pol | sp=$sp | pct=$pct% | Align(DKIM:$adkim, SPF:$aspf) | rua=$rua"
            Recommendation = ($notes -join " ")
        }
    }
    #endregion

    #region 5. BIMI, MTA-STS & TLS-RPT Diagnostics (RFC 8461 / RFC 8460)
    function Test-BimiAndMtaStsDiagnostic {
        param(
            [string]$DomainName,
            [string]$Selector = "default",
            [string]$Server = ""
        )

        # MTA-STS DNS TXT check (_mta-sts.<domain>)
        $mtaStsTxt = @(Get-DnsTxtStrings -Name "_mta-sts.$DomainName" -Server $Server | Where-Object { $_ -match '^v=STSv1' } | Select-Object -First 1)
        $mtaStsStatus = "Missing"
        $mtaStsDetail = "No _mta-sts.$DomainName TXT record"
        if ($mtaStsTxt.Count -gt 0) {
            $mtaStsStatus = "Configured"
            $mtaStsDetail = $mtaStsTxt[0]
            # Try fetching HTTPS policy file (non-blocking short timeout)
            try {
                $policyUri = "https://mta-sts.$DomainName/.well-known/mta-sts.txt"
                $resp = Invoke-WebRequest -Uri $policyUri -TimeoutSec 4 -UseBasicParsing -ErrorAction Stop
                if ($resp.Content -match '(?m)^mode:\s*(enforce|testing|none)') {
                    $mtaStsStatus = "Active ($($Matches[1]))"
                    $mtaStsDetail = "$($mtaStsTxt[0]) | HTTPS Policy mode=$($Matches[1])"
                }
            }
            catch {
                $mtaStsDetail = "$($mtaStsTxt[0]) | HTTPS policy unreachable"
            }
        }

        # SMTP TLS-RPT check (_smtp._tls.<domain>)
        $tlsRptTxt = @(Get-DnsTxtStrings -Name "_smtp._tls.$DomainName" -Server $Server | Where-Object { $_ -match '^v=TLSRPTv1' } | Select-Object -First 1)
        $tlsRptStatus = if ($tlsRptTxt.Count -gt 0) { "Configured" } else { "Missing" }

        # BIMI check (<selector>._bimi.<domain>)
        $bimiFqdn = "$Selector._bimi.$DomainName"
        $bimiTxt  = @(Get-DnsTxtStrings -Name $bimiFqdn -Server $Server | Where-Object { $_ -match '^v=BIMI1' } | Select-Object -First 1)
        $bimiStatus = "Missing"
        $bimiDetail = "No $bimiFqdn record"
        if ($bimiTxt.Count -gt 0) {
            $hasLogo = $bimiTxt[0] -match '(?i)\bl=https://\S+\.svg'
            $hasVmc  = $bimiTxt[0] -match '(?i)\ba=https://\S+\.pem'
            $bimiStatus = if ($hasLogo -and $hasVmc) { "Active (SVG + VMC)" } elseif ($hasLogo) { "Partial (SVG only, no VMC)" } else { "Configured" }
            $bimiDetail = $bimiTxt[0]
        }

        $overall = if ($mtaStsStatus -match '^Active|^Configured' -and $bimiStatus -match '^Active|^Partial') {
            "Pass"
        }
        elseif ($mtaStsStatus -ne "Missing" -or $tlsRptStatus -ne "Missing" -or $bimiStatus -ne "Missing") {
            "Info"
        }
        else {
            "Warning"
        }

        return [PSCustomObject]@{
            Status         = $overall
            MtaStsStatus   = $mtaStsStatus
            MtaStsDetail   = $mtaStsDetail
            TlsRptStatus   = $tlsRptStatus
            BimiStatus     = $bimiStatus
            BimiDetail     = $bimiDetail
            Summary        = "MTA-STS: $mtaStsStatus | TLS-RPT: $tlsRptStatus | BIMI: $bimiStatus"
            Recommendation = "Optional hardening: Publish _mta-sts & _smtp._tls for enforced TLS transport, and BIMI (requires DMARC p=quarantine/reject) for brand logo display."
        }
    }
    #endregion

    #region Demo Mode Dataset
    function Get-DemoDiagnostics {
        return @(
            [PSCustomObject]@{
                Domain          = "jobaeralam.com"
                Score           = 95
                Grade           = "A"
                OverallStatus   = "Pass"
                MxStatus        = "Pass"
                MxProvider      = "Microsoft 365 / Exchange Online"
                MxRecords       = "0 jobaeralam-com.mail.protection.outlook.com"
                SpfStatus       = "Pass"
                SpfRecord       = "v=spf1 include:spf.protection.outlook.com -all"
                SpfLookups      = "2/10 (Direct: 1)"
                SpfIssues       = "None"
                DkimStatus      = "Pass"
                DkimDetails     = "selector1 [Pass]: CNAME -> selector1-jobaeralam-com._domainkey.jobaeralam.onmicrosoft.com (RSA ~2048-bit) | selector2 [Pass]: CNAME -> selector2-jobaeralam-com._domainkey.jobaeralam.onmicrosoft.com (RSA ~2048-bit)"
                DmarcStatus     = "Pass"
                DmarcPolicy     = "reject"
                DmarcRecord     = "v=DMARC1; p=reject; pct=100; rua=mailto:dmarc@jobaeralam.com; adkim=r; aspf=r"
                DmarcSummary    = "p=reject | sp=inherits (reject) | pct=100% | Align(DKIM:r, SPF:r) | rua=mailto:dmarc@jobaeralam.com"
                BimiMtaSts      = "MTA-STS: Active (enforce) | TLS-RPT: Configured | BIMI: Active (SVG + VMC)"
                TopAction       = "All core and advanced mail security controls (MX, SPF, M365 DKIM, DMARC p=reject, MTA-STS, BIMI) are properly enforced."
            },
            [PSCustomObject]@{
                Domain          = "migration-client-demo.com"
                Score           = 45
                Grade           = "F"
                OverallStatus   = "Fail"
                MxStatus        = "Pass"
                MxProvider      = "Microsoft 365 / Exchange Online"
                MxRecords       = "0 migrationclientdemo-com.mail.protection.outlook.com"
                SpfStatus       = "Fail"
                SpfRecord       = "v=spf1 include:spf.protection.outlook.com include:_spf.google.com include:servers.mcsv.net include:spf.mandrillapp.com include:mail.zendesk.com ~all"
                SpfLookups      = "12/10 (Direct: 5)"
                SpfIssues       = "Exceeds RFC 7208 10-DNS-lookup limit (12 recursive lookups); Softfail (~all)"
                DkimStatus      = "Warning"
                DkimDetails     = "selector1 [Pass]: CNAME -> selector1-migrationclientdemo-com._domainkey.contoso.onmicrosoft.com (RSA ~2048-bit) | selector2 [Fail]: Not found in DNS"
                DmarcStatus     = "Warning"
                DmarcPolicy     = "none"
                DmarcRecord     = "v=DMARC1; p=none; rua=mailto:dmarc@migration-client-demo.com"
                DmarcSummary    = "p=none | sp=inherits (none) | pct=100% | Align(DKIM:r, SPF:r) | rua=mailto:dmarc@migration-client-demo.com"
                BimiMtaSts      = "MTA-STS: Missing | TLS-RPT: Missing | BIMI: Missing"
                TopAction       = "1) Flatten/prune SPF includes from 12 to <=10 lookups; 2) Publish selector2._domainkey CNAME for M365 DKIM rotation; 3) Upgrade DMARC from p=none to p=quarantine/reject."
            }
        )
    }
    #endregion

    $Results = [System.Collections.Generic.List[object]]::new()
}

process {
    foreach ($d in $Domain) {
        if (-not [string]::IsNullOrWhiteSpace($d)) {
            $AllTargetDomains.Add($d.Trim().ToLower())
        }
    }
}

end {
    if ($DemoMode) {
        Write-Host "[*] Running in DEMO MODE (offline migration simulation)..." -ForegroundColor Yellow
        foreach ($item in (Get-DemoDiagnostics)) {
            $Results.Add($item)
        }
    }
    else {
        if ($AllTargetDomains.Count -eq 0) {
            Write-Host "[!] No -Domain specified. Example:" -ForegroundColor Yellow
            Write-Host '    .\Test-MailAuthDNS.ps1 -Domain "jobaeralam.com" -CheckM365Selectors' -ForegroundColor White
            Write-Host '    .\Test-MailAuthDNS.ps1 -DemoMode -ExportHtml -OpenReport' -ForegroundColor Gray
            exit 1
        }

        foreach ($dom in $AllTargetDomains) {
            Write-Host "[*] Auditing domain: $dom $(if($DnsServer){"(DNS: $DnsServer)"})" -ForegroundColor Cyan

            $mx   = Test-MxDiagnostic -DomainName $dom -Server $DnsServer
            $spf  = Test-SpfDiagnostic -DomainName $dom -Server $DnsServer
            $dkim = Test-DkimDiagnostic -DomainName $dom -CheckM365 ([bool]$CheckM365Selectors) -ExtraSelectors $DkimSelectors -Server $DnsServer
            $dmarc = Test-DmarcDiagnostic -DomainName $dom -Server $DnsServer
            $adv  = Test-BimiAndMtaStsDiagnostic -DomainName $dom -Selector $BimiSelector -Server $DnsServer

            # Calculate weighted MailAuth Security Score (0-100)
            $score = 0
            if ($mx.Status -eq "Pass") { $score += 15 } elseif ($mx.Status -eq "Warning") { $score += 5 }
            if ($spf.Status -eq "Pass") { $score += 25 } elseif ($spf.Status -eq "Warning") { $score += 15 }
            if ($dkim.Status -eq "Pass") { $score += 25 } elseif ($dkim.Status -eq "Warning") { $score += 12 }
            if ($dmarc.Status -eq "Pass") {
                $score += if ($dmarc.Policy -eq "reject") { 25 } else { 20 }
            }
            elseif ($dmarc.Status -eq "Warning") { $score += 10 }
            if ($adv.Status -eq "Pass") { $score += 10 } elseif ($adv.Status -eq "Info") { $score += 5 }

            $grade = switch ($score) {
                { $_ -ge 90 } { "A"; break }
                { $_ -ge 80 } { "B"; break }
                { $_ -ge 70 } { "C"; break }
                { $_ -ge 60 } { "D"; break }
                default       { "F" }
            }

            $overall = "Pass"
            if ($mx.Status -eq "Fail" -or $spf.Status -eq "Fail" -or $dkim.Status -eq "Fail" -or $dmarc.Status -eq "Fail") {
                $overall = "Fail"
            }
            elseif ($spf.Status -eq "Warning" -or $dkim.Status -eq "Warning" -or $dmarc.Status -eq "Warning") {
                $overall = "Warning"
            }

            $actions = [System.Collections.Generic.List[string]]::new()
            if ($mx.Status -ne "Pass")    { $actions.Add("MX: $($mx.Recommendation)") }
            if ($spf.Status -ne "Pass")   { $actions.Add("SPF: $($spf.Recommendation)") }
            if ($dkim.Status -ne "Pass")  { $actions.Add("DKIM: $($dkim.Recommendation)") }
            if ($dmarc.Status -ne "Pass") { $actions.Add("DMARC: $($dmarc.Recommendation)") }
            if ($actions.Count -eq 0)     { $actions.Add("All core mail-security records (MX, SPF, DKIM, DMARC) passed validation.") }

            $Results.Add([PSCustomObject]@{
                Domain        = $dom
                Score         = $score
                Grade         = $grade
                OverallStatus = $overall
                MxStatus      = $mx.Status
                MxProvider    = $mx.Provider
                MxRecords     = $mx.Records
                SpfStatus     = $spf.Status
                SpfRecord     = $spf.Record
                SpfLookups    = "$($spf.RecursiveLookups)/10 (Direct: $($spf.DirectLookups))"
                SpfIssues     = $spf.SyntaxIssues
                DkimStatus    = $dkim.Status
                DkimDetails   = $dkim.Details
                DmarcStatus   = $dmarc.Status
                DmarcPolicy   = $dmarc.Policy
                DmarcRecord   = $dmarc.Record
                DmarcSummary  = $dmarc.Summary
                BimiMtaSts    = $adv.Summary
                TopAction     = ($actions -join " | ")
            })
        }
    }

    #region Console Output
    foreach ($r in $Results) {
        $statusColor = switch ($r.OverallStatus) {
            "Pass"    { "Green" }
            "Warning" { "Yellow" }
            default   { "Red" }
        }
        Write-Host ""
        Write-Host "--------------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host "  DOMAIN: $($r.Domain.ToUpper())   |   SCORE: $($r.Score)/100 (Grade $($r.Grade))   |   STATUS: $($r.OverallStatus.ToUpper())" -ForegroundColor $statusColor
        Write-Host "--------------------------------------------------------------------" -ForegroundColor DarkGray
        Write-Host ("  [MX]       {0,-8} | {1} ({2})" -f $r.MxStatus.ToUpper(), $r.MxProvider, $r.MxRecords) -ForegroundColor $(if($r.MxStatus -eq "Pass"){"Green"}else{"Red"})
        Write-Host ("  [SPF]      {0,-8} | Lookups: {1} | Issues: {2}" -f $r.SpfStatus.ToUpper(), $r.SpfLookups, $r.SpfIssues) -ForegroundColor $(if($r.SpfStatus -eq "Pass"){"Green"}elseif($r.SpfStatus -eq "Warning"){"Yellow"}else{"Red"})
        Write-Host ("             Record   : {0}" -f $r.SpfRecord) -ForegroundColor Gray
        Write-Host ("  [DKIM]     {0,-8} | {1}" -f $r.DkimStatus.ToUpper(), $r.DkimDetails) -ForegroundColor $(if($r.DkimStatus -eq "Pass"){"Green"}elseif($r.DkimStatus -eq "Warning"){"Yellow"}else{"Red"})
        Write-Host ("  [DMARC]    {0,-8} | {1}" -f $r.DmarcStatus.ToUpper(), $r.DmarcSummary) -ForegroundColor $(if($r.DmarcStatus -eq "Pass"){"Green"}elseif($r.DmarcStatus -eq "Warning"){"Yellow"}else{"Red"})
        Write-Host ("  [BIMI/STS] {0}" -f $r.BimiMtaSts) -ForegroundColor Cyan
        Write-Host ("  [ACTION]   {0}" -f $r.TopAction) -ForegroundColor White
    }
    Write-Host ""
    #endregion

    #region Report Exports (HTML / CSV / JSON)
    if ($ExportHtml -or $ExportCsv -or $ExportJson) {
        New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
    }

    if ($ExportCsv) {
        $csvPath = Join-Path -Path $OutputPath -ChildPath "MailAuth-Troubleshooting-Report_$Timestamp.csv"
        $Results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
        Write-Host "[+] CSV Report exported : $csvPath" -ForegroundColor Green
    }

    if ($ExportJson) {
        $jsonPath = Join-Path -Path $OutputPath -ChildPath "MailAuth-Troubleshooting-Report_$Timestamp.json"
        $Results | ConvertTo-Json -Depth 5 | Out-File -FilePath $jsonPath -Encoding UTF8
        Write-Host "[+] JSON Report exported: $jsonPath" -ForegroundColor Green
    }

    if ($ExportHtml) {
        $htmlPath = Join-Path -Path $OutputPath -ChildPath "MailAuth-Troubleshooting-Report_$Timestamp.html"

        function Get-StatusBadge {
            param([string]$St)
            switch ($St) {
                "Pass"    { return "<span class='badge pass'>PASS</span>" }
                "Warning" { return "<span class='badge warn'>WARNING</span>" }
                default   { return "<span class='badge fail'>FAIL</span>" }
            }
        }

        $cardsHtml = ($Results | ForEach-Object {
            $scColor = if ($_.Score -ge 80) { "#10b981" } elseif ($_.Score -ge 60) { "#f59e0b" } else { "#ef4444" }
            @"
            <div class="domain-card">
              <div class="card-header">
                <div>
                  <h2>$(ConvertTo-HtmlSafe $_.Domain)</h2>
                  <span class="provider">$(ConvertTo-HtmlSafe $_.MxProvider)</span>
                </div>
                <div class="score-pill" style="border-color:$scColor;color:$scColor;">
                  Score: <strong>$($_.Score)/100</strong> (Grade $($_.Grade)) &nbsp; $(Get-StatusBadge $_.OverallStatus)
                </div>
              </div>
              <table>
                <thead><tr><th style="width:140px;">Control</th><th style="width:105px;">Status</th><th>Diagnostic Finding &amp; DNS Record</th></tr></thead>
                <tbody>
                  <tr><td><strong>MX Routing</strong></td><td>$(Get-StatusBadge $_.MxStatus)</td><td><code>$(ConvertTo-HtmlSafe $_.MxRecords)</code></td></tr>
                  <tr><td><strong>SPF (RFC 7208)</strong></td><td>$(Get-StatusBadge $_.SpfStatus)</td><td><strong>Lookups:</strong> $(ConvertTo-HtmlSafe $_.SpfLookups) | <strong>Issues:</strong> $(ConvertTo-HtmlSafe $_.SpfIssues)<br><code>$(ConvertTo-HtmlSafe $_.SpfRecord)</code></td></tr>
                  <tr><td><strong>DKIM (M365)</strong></td><td>$(Get-StatusBadge $_.DkimStatus)</td><td>$(ConvertTo-HtmlSafe $_.DkimDetails)</td></tr>
                  <tr><td><strong>DMARC (RFC 7489)</strong></td><td>$(Get-StatusBadge $_.DmarcStatus)</td><td>$(ConvertTo-HtmlSafe $_.DmarcSummary)<br><code>$(ConvertTo-HtmlSafe $_.DmarcRecord)</code></td></tr>
                  <tr><td><strong>BIMI / MTA-STS</strong></td><td><span class="badge info">CHECK</span></td><td>$(ConvertTo-HtmlSafe $_.BimiMtaSts)</td></tr>
                </tbody>
              </table>
              <div class="remediation"><strong>Troubleshooting &amp; Migration Action:</strong> $(ConvertTo-HtmlSafe $_.TopAction)</div>
            </div>
"@
        }) -join "`n"

        $htmlDoc = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>$ToolTitle — Created by Jobaer</title>
<style>
  body { margin:0; font-family:'Segoe UI',system-ui,sans-serif; background:#0b1120; color:#f1f5f9; padding:28px 20px 56px; }
  .wrap { max-width:1180px; margin:0 auto; }
  .banner { background:linear-gradient(135deg,#0f172a,#1e293b); border:1px solid #334155; border-radius:14px; padding:22px 26px; display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:14px; margin-bottom:24px; }
  .creator-tag { display:inline-block; background:rgba(56,189,248,0.15); color:#38bdf8; border:1px solid rgba(56,189,248,0.4); padding:3px 10px; border-radius:99px; font-size:0.76rem; font-weight:700; letter-spacing:0.05em; text-transform:uppercase; margin-bottom:6px; }
  h1 { margin:0; font-size:1.45rem; color:#fff; }
  .sub { margin:4px 0 0; font-size:0.86rem; color:#94a3b8; }
  .btn { background:#38bdf8; color:#0f172a; border:none; padding:8px 15px; border-radius:8px; font-weight:600; cursor:pointer; }
  .domain-card { background:#111827; border:1px solid #334155; border-radius:14px; padding:20px 22px; margin-bottom:20px; }
  .card-header { display:flex; flex-wrap:wrap; justify-content:space-between; align-items:center; gap:12px; margin-bottom:14px; padding-bottom:12px; border-bottom:1px solid #1e293b; }
  .card-header h2 { margin:0; font-size:1.25rem; color:#38bdf8; }
  .provider { font-size:0.84rem; color:#94a3b8; }
  .score-pill { padding:6px 14px; border:1px solid #334155; border-radius:99px; font-size:0.88rem; background:#0f172a; }
  table { width:100%; border-collapse:collapse; font-size:0.86rem; }
  th { text-align:left; padding:9px 10px; background:#0f172a; color:#94a3b8; font-size:0.75rem; text-transform:uppercase; border-bottom:1px solid #334155; }
  td { padding:10px; border-bottom:1px solid rgba(51,65,85,0.5); vertical-align:top; line-height:1.45; }
  code { display:inline-block; background:#0f172a; color:#e2e8f0; padding:3px 7px; border-radius:6px; font-size:0.8rem; word-break:break-all; margin-top:3px; }
  .badge { display:inline-block; padding:2px 9px; border-radius:99px; font-size:0.73rem; font-weight:700; }
  .pass { background:rgba(16,185,129,0.16); color:#34d399; border:1px solid rgba(16,185,129,0.35); }
  .warn { background:rgba(245,158,11,0.16); color:#fbbf24; border:1px solid rgba(245,158,11,0.35); }
  .fail { background:rgba(239,68,68,0.16); color:#f87171; border:1px solid rgba(239,68,68,0.35); }
  .info { background:rgba(56,189,248,0.16); color:#38bdf8; border:1px solid rgba(56,189,248,0.35); }
  .remediation { margin-top:14px; padding:12px 14px; background:#0f172a; border-left:3px solid #38bdf8; border-radius:6px; font-size:0.86rem; color:#e2e8f0; }
  footer { text-align:center; color:#94a3b8; font-size:0.82rem; margin-top:28px; }
  footer a { color:#38bdf8; text-decoration:none; }
  @media print { body { background:#fff; color:#111; } .domain-card, .banner, code, .remediation { background:#fff; color:#111; border-color:#cbd5e1; } .btn { display:none; } }
</style>
</head>
<body>
<div class="wrap">
  <div class="banner">
    <div>
      <div class="creator-tag">Created by Jobaer</div>
      <h1>$ToolTitle</h1>
      <p class="sub">$AuthorLine &bull; $LicenseLine &bull; Generated: $($RunDate.ToString("yyyy-MM-dd HH:mm:ss"))</p>
    </div>
    <button class="btn" onclick="window.print()">Print / Save PDF</button>
  </div>
  $cardsHtml
  <footer>
    <strong>Created by Jobaer</strong> &mdash; $ToolTitle<br>
    Author: S M Jobaer Alam | <a href="https://www.jobaeralam.com">www.jobaeralam.com</a> | <a href="mailto:hello@jobaeralam.com">hello@jobaeralam.com</a> | License: Freeware
  </footer>
</div>
</body>
</html>
"@
        $htmlDoc | Out-File -FilePath $htmlPath -Encoding UTF8
        Write-Host "[+] HTML Report exported: $htmlPath" -ForegroundColor Green

        if ($OpenReport) {
            Start-Process $htmlPath
        }
    }
    #endregion
}
