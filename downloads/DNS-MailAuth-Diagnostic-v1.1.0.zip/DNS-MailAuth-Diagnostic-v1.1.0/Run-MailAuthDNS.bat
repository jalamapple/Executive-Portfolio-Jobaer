@echo off
title DNS, SPF, DKIM ^& DMARC Diagnostic Utility (v1.1.0) - Created by Jobaer
color 0B
where pwsh.exe >nul 2>&1 && (set "PS_EXE=pwsh.exe") || (set "PS_EXE=powershell.exe")

:MENU
cls
echo ====================================================================
echo   *** CREATED BY JOBAER ***
echo   DNS, SPF, DKIM ^& DMARC Diagnostic Utility (v1.1.0)
echo   Author: S M Jobaer Alam ^| www.jobaeralam.com ^| hello@jobaeralam.com
echo   License: Freeware
echo ====================================================================
echo.
echo   [1] Audit a Domain (MX, SPF 10-Lookup, M365 DKIM, DMARC, BIMI/MTA-STS)
echo   [2] Audit a Domain + Export HTML ^& CSV Troubleshooting Reports
echo   [3] Audit Multiple Domains (Comma-Separated) + Export Reports
echo   [4] Run Demo Mode (Offline Migration Simulation + Preview HTML Report)
echo   [5] Exit
echo.
set /p choice="Select an option [1-5]: "

if "%choice%"=="1" goto SINGLE
if "%choice%"=="2" goto SINGLE_EXPORT
if "%choice%"=="3" goto MULTI
if "%choice%"=="4" goto DEMO
if "%choice%"=="5" exit /b 0
goto MENU

:SINGLE
set /p dom="Enter domain name (e.g., jobaeralam.com): "
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-MailAuthDNS.ps1" -Domain "%dom%" -CheckM365Selectors
pause
goto MENU

:SINGLE_EXPORT
set /p dom="Enter domain name (e.g., jobaeralam.com): "
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-MailAuthDNS.ps1" -Domain "%dom%" -CheckM365Selectors -ExportHtml -ExportCsv -OpenReport
pause
goto MENU

:MULTI
set /p doms="Enter comma-separated domains (e.g., jobaeralam.com,contoso.com): "
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0Test-MailAuthDNS.ps1' -Domain ('%doms%' -split ',') -CheckM365Selectors -ExportHtml -ExportCsv -OpenReport"
pause
goto MENU

:DEMO
%PS_EXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test-MailAuthDNS.ps1" -DemoMode -ExportHtml -ExportCsv -OpenReport
pause
goto MENU
